"use strict";
/* Nera · Arkadaşlar: kim çevrimiçi, hangi cihazdan (PC / mobil), ne zamandır aktif, son görülme, mesajlaşma.
   Kurulum gerekmez: ücretsiz ve hesapsız ntfy.sh yayın/abone servisi kullanılır. Herkes aynı "grup kodu"nda buluşur (varsayılan: genel).
   - Varlık: her cihaz 40 sn'de bir gruba "buradayım" mesajı (takma ad + küçük foto) yollar.
   - Mesaj: alıcının ve kendi gelen kutusu konusuna yazılır; tek bir canlı bağlantı (SSE) ile anında gelir.
   - ntfy mesajları 12 saat saklar; sohbet geçmişi ve kişi listesi ayrıca bu cihazda kalıcıdır (masaüstünde uygulama klasörüne de yedeklenir).
   Gizlilik: grup kodunu bilen herkes o gruptaki mesajları okuyabilir; kişisel bilgi yazma, özel grup için tahmin edilmesi zor bir kod kullan. */
(function () {
const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const NT = "https://ntfy.sh/", PLAT = matchMedia("(max-width:900px)").matches ? "mobil" : "pc", START = Date.now();
const LSg = (k, d) => { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } }, LSs = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* dolu */ } };
let P = Object.assign({ nick: "", photo: "", room: "genel" }, LSg("nera_prof", {})); if (!P.room) P.room = "genel";
const id = (n) => String(n || "").toLowerCase().replace(/ç/g, "c").replace(/ğ/g, "g").replace(/ı/g, "i").replace(/ö/g, "o").replace(/ş/g, "s").replace(/ü/g, "u").replace(/[^a-z0-9_]/g, "").slice(0, 24);
const me = () => id(P.nick), room = () => id(P.room) || "genel", pre = () => `nera7_${room()}`, tPres = () => pre() + "_p", tBox = (u) => `${pre()}_u_${u}`;
const U = { users: LSg("nera_fr_users", {}), chats: LSg("nera_fr_chat", {}), chat: null, lastRead: LSg("nera_lastread", {}), err: "", ok: false, es: null, seen: new Set() };
const ICON = { pc: '<svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/></svg>', mobil: '<svg viewBox="0 0 24 24"><rect x="7" y="2.5" width="10" height="19" rx="2.5"/><path d="M11 18.5h2"/></svg>' };
const ago = (ms) => { const s = Math.max(0, Math.floor(ms / 1000)); return s < 60 ? "az önce" : s < 3600 ? Math.floor(s / 60) + " dk" : s < 86400 ? Math.floor(s / 3600) + " sa " + (Math.floor(s / 60) % 60) + " dk" : Math.floor(s / 86400) + " gün"; };
const ini = (n) => (n || "?").slice(0, 2).toUpperCase(), col = (n) => `hsl(${[...String(n)].reduce((a, c) => a + c.charCodeAt(0), 0) * 37 % 360},60%,45%)`;
const av = (u, size = 38) => `<span class="avt" style="width:${size}px;height:${size}px;background:${u.photo ? `url(${u.photo}) center/cover` : col(u.nick)};font-size:${size * 0.4}px">${u.photo ? "" : ini(u.nick)}</span>`;
const save = () => { LSs("nera_prof", P); if (window.NERA_SAVE) setTimeout(window.NERA_SAVE, 50); };
const keep = () => { LSs("nera_fr_users", U.users); LSs("nera_fr_chat", U.chats); LSs("nera_lastread", U.lastRead); };
const pub = async (topic, obj) => { const r = await fetch(NT + topic, { method: "POST", body: JSON.stringify(obj) }); if (!r.ok) throw new Error("HTTP " + r.status); };

/* gelen her ntfy mesajı */
function onMsg(m) {
  if (!m || m.event !== "message" || U.seen.has(m.id)) return; U.seen.add(m.id); if (U.seen.size > 3000) U.seen.clear(); let o; try { o = JSON.parse(m.message); } catch (e) { return; } if (!o || !o.id) return;
  if (o.k === "hb") { const u = U.users[o.id] = U.users[o.id] || {}; const prev = u[o.plat] || {}; if ((prev.seen || 0) > o.t) return; u[o.plat] = { nick: String(o.nick || o.id).slice(0, 20), photo: typeof o.photo === "string" && o.photo.startsWith("data:image/") ? o.photo : prev.photo || "", seen: o.t, since: o.since || o.t }; return; }
  if (o.k === "msg") { const other = o.id === me() ? o.to : o.id; if (!other) return; const a = U.chats[other] = U.chats[other] || []; if (a.some((x) => x.mid === o.mid)) return; a.push({ mid: o.mid, id: o.id, m: String(o.m || "").slice(0, 400), t: o.t }); a.sort((x, y) => x.t - y.t); if (a.length > 200) a.splice(0, a.length - 200);
    if (o.id !== me() && U.chat !== other && o.t > (U.lastRead[other] || 0) && Date.now() - o.t < 120000) { if (window.Lab && Lab.toast) Lab.toast(`<b>${esc(o.nick || o.id)}</b><br>${esc(String(o.m).slice(0, 80))}`, "#8a7bff"); if (window.Sound) Sound.tone(660, 0.1, 0.5); $$('[data-v="friends"]').forEach((b) => b.classList.add("glow")); try { if (window.LM) LM.event("friends", { color: "#8a7bff", msg: "Yeni mesaj" }); } catch (x) { /* */ } }
    if (U.chat === other) { U.lastRead[other] = Math.max(U.lastRead[other] || 0, o.t); renderChat(); } }
}
async function poll(topic, since) { const r = await fetch(`${NT}${topic}/json?poll=1&since=${since}`); if (!r.ok) throw new Error("HTTP " + r.status); const txt = await r.text(); txt.split("\n").forEach((ln) => { if (!ln.trim()) return; try { onMsg(JSON.parse(ln)); } catch (e) { /* */ } }); }
async function connect() {
  if (U.es) { try { U.es.close(); } catch (e) { /* */ } U.es = null; } if (!me()) { upd(); return; }
  try { await poll(tPres(), "15m"); await poll(tBox(me()), "12h"); U.ok = true; U.err = ""; keep(); } catch (e) { U.ok = false; U.err = String(e.message || e); }
  try { const es = new EventSource(`${NT}${tPres()},${tBox(me())}/sse`); es.onmessage = (e) => { try { onMsg(JSON.parse(e.data)); U.ok = true; } catch (x) { /* */ } }; es.onerror = () => { U.ok = false; }; es.onopen = () => { U.ok = true; U.err = ""; }; U.es = es; } catch (e) { U.err = "canlı bağlantı açılamadı"; }
  beat(); upd();
}
async function beat() { if (!me()) return; try { await pub(tPres(), { k: "hb", id: me(), nick: P.nick, photo: P.photo || "", plat: PLAT, since: START, t: Date.now() }); U.ok = true; U.err = ""; } catch (e) { U.ok = false; U.err = String(e.message || e); } upd(); }
function roster() {
  return Object.entries(U.users).map(([uid, d]) => { const devs = Object.entries(d || {}).filter(([, v]) => v && v.seen).map(([plat, v]) => ({ plat, ...v, on: Date.now() - v.seen < 95000 })), last = Math.max(0, ...devs.map((x) => x.seen)), nick = (devs[0] || {}).nick || uid, photo = (devs.find((x) => x.photo) || {}).photo || "";
    return { uid, nick, photo, devs, on: devs.some((x) => x.on), last, since: Math.min(...devs.filter((x) => x.on).map((x) => x.since), Infinity) }; }).filter((u) => u.last > 0).sort((a, b) => b.on - a.on || b.last - a.last);
}
function build() {
  const el = $("#pg-friends"); if (!el) return;
  el.innerHTML = `<div class="eyebrow">Sistem · çevrimiçi kişiler</div><h1>Arkadaşlar</h1><p class="lead">Takma adını yaz, kaydet. Aynı grup kodundakiler birbirini görür.</p>
  <div class="panel"><div class="ph">Profilim <small id="fr-st"></small></div><div class="pb"><div class="frme"><div id="fr-av" class="fr-avw" title="Fotoğraf seç"></div><div class="frfld"><label class="fld">Takma ad<input id="fr-nick" maxlength="20" placeholder="örn. adile" value="${esc(P.nick)}"></label><label class="fld">Profil fotoğrafı<input id="fr-photo" type="file" accept="image/*"></label><label class="fld">Grup kodu<input id="fr-room" maxlength="24" placeholder="genel" value="${esc(P.room)}"></label></div></div>
    <div class="ctl" style="margin-top:10px"><button class="btn pri" id="fr-save">Kaydet ve bağlan</button><span class="muted" style="font-size:11.5px;max-width:620px">Altyapı: ücretsiz ntfy.sh (hesap gerekmez). Arkadaşlarınla özel kalmak için hepiniz aynı, tahmin edilmesi zor bir grup kodu yazın (örn. <i>ates-kurdu-4821</i>). Grup kodunu bilen herkes o gruptaki mesajları okuyabilir: kişisel bilgi, şifre ya da hesap bilgisi yazma. Profilin ve sohbet geçmişin bu cihazda kalıcıdır.</span></div></div></div>
  <div class="two frgrid"><div class="panel"><div class="ph">Kişiler <small id="fr-n"></small></div><div id="fr-list"></div></div><div class="panel" id="fr-chat"><div class="ph">Mesajlar</div><div class="pb muted" style="padding:30px;text-align:center">Mesajlaşmak için soldan bir kişiye dokun.</div></div></div>`;
  $("#fr-photo").onchange = (e) => { const f = e.target.files[0]; if (!f) return; const im = new Image(); im.onload = () => { const c = document.createElement("canvas"), s = Math.min(im.width, im.height); c.width = c.height = 64; c.getContext("2d").drawImage(im, (im.width - s) / 2, (im.height - s) / 2, s, s, 0, 0, 64, 64); let q = 0.7, d = c.toDataURL("image/jpeg", q); while (d.length > 2600 && q > 0.3) { q -= 0.1; d = c.toDataURL("image/jpeg", q); } P.photo = d; save(); upd(); beat(); URL.revokeObjectURL(im.src); }; im.src = URL.createObjectURL(f); };
  $("#fr-av").onclick = () => $("#fr-photo").click();
  $("#fr-save").onclick = () => { const was = room() + "|" + me(); P.nick = $("#fr-nick").value.trim(); P.room = $("#fr-room").value.trim() || "genel"; save(); if (was !== room() + "|" + me()) { U.users = {}; U.chats = {}; keep(); } connect(); };
}
function upd() {
  if (!$("#fr-list")) return; const st = $("#fr-st"), a = $("#fr-av"); if (a) a.innerHTML = av({ nick: P.nick || "?", photo: P.photo }, 64);
  if (st) st.textContent = !me() ? "takma ad gir ve kaydet" : U.ok ? `bağlı · grup "${room()}" · ${PLAT === "pc" ? "PC" : "mobil"} olarak aktifsin` : U.err ? "bağlanamadı: " + U.err : "bağlanıyor…";
  const L = roster(), unread = (uid) => (U.chats[uid] || []).filter((m) => m.id !== me() && m.t > (U.lastRead[uid] || 0)).length;
  const h = L.map((u) => { const n = unread(u.uid); return `<div class="fru ${U.chat === u.uid ? "sel" : ""}" data-u="${u.uid}">${av(u)}<div class="frm"><b>${esc(u.nick)}${u.uid === me() ? ' <span class="muted">(sen)</span>' : ""}</b><span class="muted">${u.on ? `çevrimiçi · ${ago(Date.now() - u.since)}dır aktif` : `son görülme ${ago(Date.now() - u.last)} önce`}</span></div><div class="frp">${u.devs.map((d) => `<i class="${d.on ? "on" : ""}" title="${d.plat}">${ICON[d.plat] || ""}</i>`).join("")}</div><i class="dotp ${u.on ? "on" : ""}"></i>${n ? `<em class="unr">${n}</em>` : ""}</div>`; }).join("") || '<div class="pb muted">Henüz kimse görünmüyor. Takma adını kaydet; aynı grup kodunu kullanan arkadaşların açınca burada belirir.</div>';
  const le = $("#fr-list"); if (le._h !== h) { le._h = h; le.innerHTML = h; $$(".fru", le).forEach((e) => (e.onclick = () => openChat(e.dataset.u))); } $("#fr-n").textContent = `${L.filter((x) => x.on).length} çevrimiçi`;
  const tot = L.reduce((s, u) => s + (u.uid === U.chat ? 0 : unread(u.uid)), 0); $$('[data-v="friends"]').forEach((b) => b.classList.toggle("glow", tot > 0 && document.body.dataset.view !== "friends"));
}
function openChat(uid) { U.chat = uid; const a = U.chats[uid] || []; U.lastRead[uid] = a.length ? a[a.length - 1].t : Date.now(); keep(); renderChat(); upd(); document.body.classList.add("chat-open"); }
function renderChat() {
  const box = $("#fr-chat"); if (!box || !U.chat) return; const u = roster().find((x) => x.uid === U.chat) || { nick: U.chat, devs: [], on: false, last: 0 };
  if (!box._built || box._u !== U.chat) { box._built = 1; box._u = U.chat; box.innerHTML = `<div class="ph"><button class="btn bk2" id="fr-back">‹</button>${av(u, 26)} <span>${esc(u.nick)}</span><small id="fr-s2"></small></div><div id="fr-msgs"></div><form id="fr-form" class="frform"><input id="fr-in" placeholder="mesaj yaz…" autocomplete="off" maxlength="400"><button class="btn pri">Gönder</button></form>`;
    $("#fr-form").onsubmit = async (e) => { e.preventDefault(); const v = $("#fr-in").value.trim(); if (!v || !me()) return; $("#fr-in").value = ""; const o = { k: "msg", id: me(), nick: P.nick, to: U.chat, t: Date.now(), m: v, mid: Math.random().toString(36).slice(2, 12) };
      onMsg({ event: "message", id: "loc" + o.mid, message: JSON.stringify(o) }); keep(); try { await pub(tBox(U.chat), o); if (U.chat !== me()) await pub(tBox(me()), o); } catch (er) { U.err = String(er.message); upd(); } };
    $("#fr-back").onclick = () => { document.body.classList.remove("chat-open"); }; }
  $("#fr-s2").textContent = u.on ? " çevrimiçi" : u.last ? " son görülme " + ago(Date.now() - u.last) + " önce" : "";
  const msgs = U.chats[U.chat] || [], h = msgs.map((m) => `<div class="msg ${m.id === me() ? "me" : ""}"><span>${esc(m.m)}</span><i>${new Date(m.t).toLocaleString("tr-TR", { hour: "2-digit", minute: "2-digit", day: "2-digit", month: "2-digit" })}</i></div>`).join("") || '<div class="muted" style="padding:20px;text-align:center">Henüz mesaj yok.</div>';
  const ms = $("#fr-msgs"); if (ms._h !== h) { ms._h = h; ms.innerHTML = h; ms.scrollTop = ms.scrollHeight; } if (msgs.length) { U.lastRead[U.chat] = msgs[msgs.length - 1].t; keep(); }
}
window.addEventListener("DOMContentLoaded", () => { build(); upd(); setTimeout(connect, 2500); setInterval(beat, 40000); setInterval(() => { if (document.body.dataset.view === "friends") upd(); keep(); }, 5000); setInterval(() => { if (U.chat && document.body.dataset.view === "friends") renderChat(); }, 2000); document.addEventListener("visibilitychange", () => { if (!document.hidden) { beat(); if (!U.es || U.es.readyState === 2) connect(); } }); DT.on("view", (v) => { if (v === "friends") { upd(); $$('[data-v="friends"]').forEach((b) => b.classList.remove("glow")); } }); });
})();
