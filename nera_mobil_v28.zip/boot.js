/* DayTrader Pro (mobil) · açılış: JavaScript motorunu başlatır, arayüzü (app.js) ona bağlar. Sunucu yok; her şey telefonda çalışır. */
import { Engine } from "./engine/engine.js";
const eng = new Engine();
window.ENGINE = eng;
window.LOCAL_API = (path, opt) => eng.handle(path, opt);
eng.start();
if (window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform()) import("./native.js").then((m) => m.init(eng)).catch(() => {});
const s = document.createElement("script");
s.src = "app.js";
s.onload = () => { const m = document.createElement("script"); m.src = "mobile.js"; document.body.appendChild(m); };      // mobil kabuk app.js'ten sonra yüklenir
document.body.appendChild(s);
if ("serviceWorker" in navigator && location.protocol.startsWith("http") && !window.Capacitor) navigator.serviceWorker.register("sw.js").catch(() => {});
