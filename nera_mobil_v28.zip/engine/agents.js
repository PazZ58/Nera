/* DayTrader Pro (mobil) · ajanlar + koordinatör + işlem planı: pro/pro_agents.py'nin JavaScript karşılığı (kural tabanlı; LLM yok).
   DÜRÜSTLÜK: kanıtlı avantaj yok; sinyal bilgidir, tavsiye değildir. */
const W = { trend: 0.22, momentum: 0.12, flow: 0.22, ict: 0.22, liquidity: 0.14, pa: 0.10, news: 0.08 };
export const ADX_MIN = 16.0;
const isn = (x) => typeof x === "number" && isFinite(x);
export const rowAt = (d, i) => { const r = {}; for (const k in d) { const a = d[k]; if (Array.isArray(a)) r[k] = a[i]; } return r; };
const G = (r, k, def = NaN) => { const v = r[k]; return isn(v) ? v : def; };
const sgn = (x, eps = 0) => (x > eps ? 1 : x < -eps ? -1 : 0);
export const sgnPub = sgn;
const clip = (x, lo, hi) => Math.min(hi, Math.max(lo, x));
const comma = (s) => s.replace(/\B(?=(\d{3})+(?!\d))/g, (m, o, str) => (str.indexOf(".") >= 0 && o > str.indexOf(".") ? "" : ","));
const cn = (x, d) => { const s = Number(x).toFixed(d), [i, fr] = s.split("."); return i.replace(/\B(?=(\d{3})+(?!\d))/g, ",") + (fr ? "." + fr : ""); };   // Python {x:,.nf} ile aynı yuvarlama
const c2 = (x) => cn(x, 2);
const f = (x, d) => { const m = 10 ** d, y = Number(x) * m; if (Math.abs(y % 1) === 0.5) { const fl = Math.floor(y), r = fl % 2 === 0 ? fl : fl + 1; return (r / m).toFixed(d); } return Number(x).toFixed(d); };      // Python gibi: tam .5'te çifte yuvarla
const sf = (x, d) => (x >= 0 ? "+" : "-") + Math.abs(Number(x)).toFixed(d);   // Python {x:+.nf}

function agent(name, icon, parts, why, extra) {
  if (!parts.length) return { name, icon, vote: 0.0, conf: 0.0, why: why && why.length ? why : ["veri yok"], ...(extra || {}) };
  const ws = parts.map(([, w]) => Math.max(w, 1e-9)), vs = parts.map(([v]) => v), sw = ws.reduce((a, b) => a + b, 0);
  const vote = vs.reduce((s, v, i) => s + v * ws[i], 0) / sw;
  const idx = vs.map((v, i) => (Math.abs(v) > 0.05 ? i : -1)).filter((i) => i >= 0);
  let agree = 0;
  if (idx.length) { const sws = idx.reduce((s, i) => s + ws[i], 0); agree = Math.abs(idx.reduce((s, i) => s + Math.sign(vs[i]) * ws[i], 0)) / sws; }
  const conf = clip(Math.abs(vote) * 0.8 + agree * 0.4 - (idx.length >= 2 ? 0.0 : 0.2), 0, 1);
  return { name, icon, vote: clip(vote, -1, 1), conf, why, ...(extra || {}) };
}

export function trendAgent(d, smc, htf) {
  const n = d.close.length, r = rowAt(d, n - 1), c = G(r, "close"), parts = [], why = [];
  const [e9, e21, e50, e200] = [9, 21, 50, 200].map((k) => G(r, "ema" + k));
  const st = e9 > e21 && e21 > e50 ? 1 : e9 < e21 && e21 < e50 ? -1 : 0;
  parts.push([st, 1.0]); if (st) why.push(`EMA 9/21/50 ${st > 0 ? "yukarı" : "aşağı"} dizilimde`);
  if (isn(e200)) { parts.push([sgn(c - e200), 0.7]); why.push(`Fiyat EMA200'ün ${c > e200 ? "üstünde" : "altında"}`); }
  const sa = G(r, "spana"), sb = G(r, "spanb");
  if (isn(sa) && isn(sb)) {
    const top = Math.max(sa, sb), bot = Math.min(sa, sb);
    const ich = c > top && G(r, "tenkan") >= G(r, "kijun") ? 1 : c < bot && G(r, "tenkan") <= G(r, "kijun") ? -1 : 0;
    parts.push([ich, 0.9]); why.push("Ichimoku: " + (ich > 0 ? "bulut üstü + tenkan>kijun" : ich < 0 ? "bulut altı + tenkan<kijun" : "bulut içinde/karışık"));
  }
  parts.push([G(r, "st_dir", 0.0), 0.8]); why.push(`Supertrend ${G(r, "st_dir", 0) > 0 ? "yukarı" : "aşağı"}`);
  const adx = G(r, "adx", 0), pdi = G(r, "pdi", 0), mdi = G(r, "mdi", 0), di = sgn(pdi - mdi) * Math.min(1.0, adx / 30.0);
  parts.push([di, 1.2]); why.push(`ADX ${f(adx, 0)} (${adx >= 25 ? "güçlü trend" : adx >= ADX_MIN ? "trend var" : "YATAY"}) · +DI ${f(pdi, 0)} / -DI ${f(mdi, 0)}`);
  if (htf) for (const tfn of Object.keys(htf)) { const s = htf[tfn]; if (s.struct !== null && s.struct !== undefined) { parts.push([Number(s.struct) * 0.8 + Number(s.ema || 0) * 0.2, 0.8]); why.push(`${tfn} yapısı ${s.struct > 0 ? "yükseliş" : s.struct < 0 ? "düşüş" : "belirsiz"}`); } }
  const a = agent("Trend", "📈", parts, why, { adx, regime: adx >= 25 ? "trend" : adx >= ADX_MIN ? "zayıf trend" : "yatay" });
  a.conf = a.conf * (0.5 + 0.5 * Math.min(1.0, adx / 25.0));
  return a;
}

export function momentumAgent(d) {
  const n = d.close.length, r = rowAt(d, n - 1), p = rowAt(d, n - 2), parts = [], why = [];
  const rs = G(r, "rsi", 50);
  parts.push([clip((rs - 50) / 20, -1, 1) * (rs > 75 || rs < 25 ? 0.4 : 1.0), 1.0]); why.push(`RSI ${f(rs, 0)}` + (rs > 75 ? " (aşırı alım: devam riski düşük)" : rs < 25 ? " (aşırı satım)" : ""));
  const k = G(r, "srsi_k", 50), kd = G(r, "srsi_d", 50), pk = G(p, "srsi_k", 50), pkd = G(p, "srsi_d", 50);
  const cross = k > kd && pk <= pkd ? 1.0 : k < kd && pk >= pkd ? -1.0 : 0.0;
  parts.push([cross ? cross : sgn(k - kd) * 0.4, 0.7]); if (cross) why.push(`Stochastic RSI ${cross > 0 ? "yukarı" : "aşağı"} kesişim`);
  const mh = G(r, "macdh", 0), pmh = G(p, "macdh", 0);
  parts.push([sgn(mh) * (Math.abs(mh) > Math.abs(pmh) ? 1.0 : 0.5), 1.0]); why.push(`MACD histogram ${mh > 0 ? "pozitif" : "negatif"}, ${Math.abs(mh) > Math.abs(pmh) ? "güçleniyor" : "zayıflıyor"}`);
  const pu = G(r, "pulse", 0); parts.push([clip(pu / 60, -1, 1), 0.8]); why.push(`Pulse (bileşik osilatör) ${sf(pu, 0)}`);
  const sq = G(r, "squeeze", 0), psq = G(p, "squeeze", 0);
  if (psq === 1 && sq === 0) { parts.push([sgn(G(r, "sqmom", 0)), 1.2]); why.push("Sıkışma (squeeze) az önce bitti, momentum " + (G(r, "sqmom", 0) > 0 ? "yukarı" : "aşağı")); }
  else if (sq === 1) why.push("Sıkışma (squeeze) sürüyor: kırılım bekleniyor, yön belirsiz");
  parts.push([sgn(G(r, "roc10", 0)) * 0.5, 0.4]);
  return agent("Momentum", "⚡", parts, why, { squeeze: Boolean(sq) });
}

export function flowAgent(d, sym, flow, real, nowSec = Date.now() / 1000) {
  const n = d.close.length, r = rowAt(d, n - 1), parts = [], why = [];
  const lab = real ? "GERÇEK order flow (taker alış/satış)" : "VEKİL delta (mum içi kapanış konumu; gerçek order flow YOK)", scale = real ? 1.0 : 0.35;
  const dp = d.dpct.slice(-3).map((x) => (isn(x) ? x : 0)), dpm = dp.reduce((a, b) => a + b, 0) / dp.length;
  parts.push([clip(dpm * 4, -1, 1) * scale, 1.0]); why.push(`Son 3 mum delta %: ${sf(dpm * 100, 1)} (${lab})`);
  const cdz = G(r, "cdz", 0); parts.push([clip(cdz / 2, -1, 1) * scale, 0.9]); why.push(`20 mumluk kümülatif delta z-skoru ${sf(cdz, 1)}`);
  const cv = d.cvd, cl = d.close;
  if (cv.length > 30) {
    const dpx = cl[n - 1] - cl[n - 21], dcv = cv[n - 1] - cv[n - 21];
    if (dpx > 0 && dcv < 0) { parts.push([-0.8 * scale, 1.0]); why.push("Fiyat yükseliyor ama CVD düşüyor (alım zayıf: uyumsuzluk)"); }
    else if (dpx < 0 && dcv > 0) { parts.push([0.8 * scale, 1.0]); why.push("Fiyat düşüyor ama CVD yükseliyor (satış zayıf: uyumsuzluk)"); }
  }
  const rng = (G(r, "high") - G(r, "low")) / Math.max(G(r, "atr", 1e-9), 1e-9);
  if (G(r, "vz", 0) > 1.5 && rng < 0.9) {
    const a_ = -sgn(G(r, "dpct", 0)) * 0.9 * scale;
    if (a_) { parts.push([a_, 1.1]); why.push(`Absorpsiyon: yüksek hacim (z ${f(G(r, "vz"), 1)}) ama dar aralık; ${a_ < 0 ? "alıcılar emildi" : "satıcılar emildi"}`); }
  }
  const extra = { real: Boolean(real) };
  if (flow && real && flow.minutes && flow.minutes.size) {
    const now = Math.floor(nowSec), mins = [...flow.minutes.entries()].filter(([m]) => now - m <= 300);
    const buy = mins.reduce((s, [, b]) => s + b.buy, 0), sell = mins.reduce((s, [, b]) => s + b.sell, 0);
    if (buy + sell > 0) {
      const ratio = (buy - sell) / (buy + sell); parts.push([clip(ratio * 3, -1, 1), 1.0]);
      why.push(`Son 5 dk canlı agresör akışı: alış %${f((100 * buy) / (buy + sell), 0)} / satış %${f((100 * sell) / (buy + sell), 0)}`); extra.live_ratio = ratio;
    }
    let imbB = 0, imbS = 0;
    for (const [, b] of mins.slice(-3)) {
      const ks = [...b.bins.keys()].sort((x, y) => x - y);
      ks.forEach((kk, i) => {
        const [buyK, sellK] = b.bins.get(kk), lower = i > 0 ? b.bins.get(ks[i - 1])[1] : 0.0;
        if (buyK > 3 * Math.max(lower, 1e-12) && buyK > 0) imbB++;
        const upper = i + 1 < ks.length ? b.bins.get(ks[i + 1])[0] : 0.0;
        if (sellK > 3 * Math.max(upper, 1e-12) && sellK > 0) imbS++;
      });
    }
    if (imbB + imbS >= 3) { parts.push([clip((imbB - imbS) / Math.max(imbB + imbS, 1), -1, 1) * 0.7, 0.7]); why.push(`Footprint dengesizlik (3x): ${imbB} alış / ${imbS} satış kutusu`); }
    const big = flow.big.filter((x) => now - x.t <= 600);
    if (big.length) {
      const net = big.reduce((s, x) => s + x.side * x.usd, 0), tot = big.reduce((s, x) => s + x.usd, 0);
      parts.push([clip((net / tot) * 1.5, -1, 1), 0.8]); why.push(`Büyük işlemler (son 10 dk, ${big.length} adet): net ${net > 0 ? "alış" : "satış"} ${f(Math.abs(net) / 1e6, 2)} M$`); extra.big_net = net;
    }
    const liq = flow.liq.filter((x) => now - x.t <= 900);
    if (liq.length) {
      const longs = liq.filter((x) => x.side === -1).reduce((s, x) => s + x.usd, 0), shorts = liq.filter((x) => x.side === 1).reduce((s, x) => s + x.usd, 0);
      if (longs + shorts > 0) { parts.push([clip((longs - shorts) / (longs + shorts), -1, 1) * 0.4, 0.5]); why.push(`Tasfiyeler (15 dk): uzun ${f(longs / 1e3, 0)} K$ / kısa ${f(shorts / 1e3, 0)} K$`); }
    }
  }
  return agent("Order Flow", "🌊", parts, why, extra);
}

export function ictAgent(d, smc, price) {
  const parts = [], why = [], tr = smc.struct;
  parts.push([Number(tr), 1.0]); why.push("Piyasa yapısı " + (tr > 0 ? "yükseliş (HH/HL)" : tr < 0 ? "düşüş (LH/LL)" : "belirsiz"));
  const ev = smc.events.filter((e) => smc.n - 1 - e.i <= 12);
  if (ev.length) { const e = ev[ev.length - 1]; parts.push([e.dir * (e.type === "CHoCH" ? 1.0 : 0.7), 1.2]); why.push(`Son ${smc.n - 1 - e.i} mumda ${e.type} ${e.dir > 0 ? "yukarı" : "aşağı"} (kırılan seviye ${c2(e.level)})`); }
  const pdz = smc.pd;
  if (pdz) {
    const z = pdz.zone === "discount" ? 1.0 : -1.0; parts.push([z * 0.6, 0.6]);
    why.push(`Fiyat ${z > 0 ? "DISCOUNT (ucuz)" : "PREMIUM (pahalı)"} bölgesinde (aralığın %${f(pdz.pos * 100, 0)}'i)`);
    const [lo_, hi_] = pdz.ote;
    if (lo_ <= price && price <= hi_) { parts.push([pdz.up_leg ? 1.0 : -1.0, 1.0]); why.push(`OTE bölgesinde (%62-79 geri çekilme: ${c2(lo_)}–${c2(hi_)})`); }
  }
  for (const ob of smc.obs) if (ob.inside) { parts.push([Number(ob.dir), 1.1]); why.push(`${ob.dir > 0 ? "Boğa" : "Ayı"} order block içinde (${c2(ob.lo)}–${c2(ob.hi)}${ob.fresh ? ", dokunulmamış" : ""})`); }
  for (const fv of smc.fvgs) if (fv.lo <= price && price <= fv.hi) { parts.push([fv.dir * 0.8, 0.8]); why.push(`${fv.dir > 0 ? "Boğa" : "Ayı"} FVG içinde (${c2(fv.lo)}–${c2(fv.hi)})`); }
  const sw = smc.sweeps;
  if (sw.length) { const s = sw[sw.length - 1]; parts.push([Number(s.dir), 1.3]); why.push(`${s.k} likiditesi süpürüldü (${c2(s.level)}) → ${s.dir > 0 ? "yukarı" : "aşağı"} dönüş ihtimali (turtle soup)`); }
  const kz = smc.kz || ""; if (kz) why.push(`${kz} içinde (daha fazla hacim/oynaklık beklenir)`);
  const a = agent("ICT / Smart Money", "🏛", parts, why, { kz });
  if (kz && kz.includes("kill")) a.conf = Math.min(1.0, a.conf * 1.15);
  return a;
}

export function liquidityAgent(d, smc, price) {
  const parts = [], why = [], atr = smc.atr, liq = smc.liq.filter((x) => !x.swept);
  const above = liq.filter((x) => x.p > price).sort((a, b) => a.p - price - (b.p - price)), below = liq.filter((x) => x.p < price).sort((a, b) => price - a.p - (price - b.p));
  if (above.length && below.length) {
    const da = (above[0].p - price) / atr, db = (price - below[0].p) / atr;
    parts.push([clip((db - da) / Math.max(da + db, 1e-9), -1, 1) * 0.5, 0.6]);
    why.push(`En yakın likidite: üstte ${above[0].k} ${c2(above[0].p)} (${f(da, 1)} ATR) · altta ${below[0].k} ${c2(below[0].p)} (${f(db, 1)} ATR)`);
  }
  for (const s of smc.sweeps.slice(-2)) { parts.push([Number(s.dir), 1.4]); why.push(`${s.k} süpürmesi, fitil ${c2(s.wick)}: stop avı sonrası dönüş adayı`); }
  const vp = smc.vp;
  if (vp) {
    if (price < vp.val) { parts.push([0.5, 0.7]); why.push(`Fiyat değer alanı altında (VAL ${c2(vp.val)}); POC ${c2(vp.poc)} mıknatıs olabilir`); }
    else if (price > vp.vah) { parts.push([-0.5, 0.7]); why.push(`Fiyat değer alanı üstünde (VAH ${c2(vp.vah)}); POC ${c2(vp.poc)} mıknatıs olabilir`); }
    else why.push(`Fiyat değer alanı içinde (${c2(vp.val)}–${c2(vp.vah)}), POC ${c2(vp.poc)}`);
  }
  return agent("Likidite", "💧", parts, why, { above: above.slice(0, 3), below: below.slice(0, 3) });
}

export function paAgent(d, smc, price) {
  const parts = [], why = [], atr = smc.atr, near = smc.sr.filter((x) => Math.abs(x.p - price) <= 0.8 * atr);
  for (const p of smc.patterns) {
    if (p.dir === 0) { why.push(`${p.k} (yön vermez)`); continue; }
    const ctx = near.filter((x) => (x.k === "destek" && p.dir > 0) || (x.k === "direnç" && p.dir < 0));
    parts.push([p.dir * (ctx.length ? 1.0 : 0.45), 1.0]);
    why.push(`${p.k}` + (ctx.length ? ` · ${ctx[0].k} seviyesinde (${c2(ctx[0].p)}, ${ctx[0].n} dokunuş)` : " · seviye desteği yok (zayıf)"));
  }
  for (const dv of smc.div) { parts.push([dv.dir * 0.7, 0.7]); why.push(dv.k); }
  const n = d.close.length, r = rowAt(d, n - 1), pr = rowAt(d, n - 2);
  if (G(r, "close") > G(pr, "dch", Infinity)) { parts.push([0.6, 0.6]); why.push("20 mumluk zirve kırıldı"); }
  else if (G(r, "close") < G(pr, "dcl", -Infinity)) { parts.push([-0.6, 0.6]); why.push("20 mumluk dip kırıldı"); }
  if (near.length) why.push("Yakın seviyeler: " + near.slice(0, 3).map((x) => `${x.k} ${c2(x.p)}`).join(", "));
  return agent("Fiyat Hareketi", "🕯", parts, why);
}

export function newsAgent(news) {
  if (!news || !news.n) return { name: "Haber", icon: "📰", vote: 0.0, conf: 0.0, why: ["Son 24 saatte bu varlıkla ilgili haber bulunamadı (ya da haber akışı henüz yüklenmedi)."], shock: false };
  const why = [`${news.n} haber · ağırlıklı duygu ${news.score >= 0 ? "+" : ""}${news.score.toFixed(2)}${news.shock ? " · büyük olay kelimesi var" : ""}`]; for (const t of news.top.slice(0, 3)) why.push(`${t.age_min} dk önce (${t.src || "?"}): ${t.title.slice(0, 90)} [${t.score >= 0 ? "+" : ""}${t.score.toFixed(1)}]`);
  return { name: "Haber", icon: "📰", vote: news.score, conf: news.conf * 0.8, why, shock: !!news.shock };
}
export function riskAgent(d, smc, spread, eventsNear, agents, sym, nowTs, news = null) {
  const n = d.close.length, r = rowAt(d, n - 1), c = G(r, "close"), atrPct = (G(r, "atr") / c) * 100;
  const hist = d.atr.slice(-200).map((a, i) => (a / d.close.slice(-200)[i]) * 100), pct = hist.filter((x) => x < atrPct).length / hist.length;
  let pts = 0; const notes = [];
  if (pct > 0.85) { pts += 25; notes.push(`Oynaklık yüksek (ATR %${f(atrPct, 2)}, son 200 mumun %${f(pct * 100, 0)}'ından yüksek)`); }
  else if (pct < 0.15) { pts += 8; notes.push("Oynaklık çok düşük: kırılım ani olabilir"); }
  const adx = G(r, "adx", 0);
  if (adx < ADX_MIN) { pts += 15; notes.push(`Piyasa yatay (ADX ${f(adx, 0)}): trend sinyalleri sık yanılır`); }
  if (spread !== null && spread !== undefined && G(r, "atr") > 0 && spread / G(r, "atr") > 0.06) { pts += 12; notes.push(`Spread geniş (ATR'nin %${f((spread / G(r, "atr")) * 100, 0)}'i)`); }
  let veto = false;
  if (eventsNear) {
    const [mins, nm] = eventsNear;
    if (mins >= -20 && mins <= 30) { pts += 45; veto = (mins >= 0 && mins <= 20) || (mins >= -10 && mins < 0); notes.push(`${nm} ${mins >= 0 ? mins + " dk sonra" : -mins + " dk önce"}: spread açılır, ani hareket olur`); }
    else if (mins > 30 && mins <= 120) { pts += 15; notes.push(`${nm} ${Math.floor(mins / 60)} sa ${mins % 60} dk sonra: pozisyonu olay öncesi kapatmayı düşün`); }
  }
  const dt = new Date(nowTs * 1000), dow = dt.getUTCDay(), hr = dt.getUTCHours();
  if (dow === 0 || dow === 6 || ([21, 22, 23].includes(hr) && ["XAUUSDT", "XAGUSDT", "EURUSD"].includes(sym))) { pts += 10; notes.push("Düşük likidite saati/hafta sonu: fiyat sıçramaları olabilir"); }
  if (news && news.shock) { pts += 20; notes.push("Son 2 saatte büyük olay içeren haber var: ani hareket/spread riski"); }
  const votes = agents.filter((a) => a.name !== "Risk" && Math.abs(a.vote) > 0.15).map((a) => a.vote);
  if (votes.length >= 3) { const pos = votes.filter((v) => v > 0).length, neg = votes.filter((v) => v < 0).length; if (Math.min(pos, neg) >= 2) { pts += 18; notes.push(`Ajanlar çelişiyor (${pos} yukarı / ${neg} aşağı)`); } }
  const lab = pts >= 60 ? "ÇOK YÜKSEK" : pts >= 40 ? "YÜKSEK" : pts >= 20 ? "ORTA" : "DÜŞÜK";
  return { name: "Risk", icon: "🛡", vote: 0.0, conf: 0.0, score: pts, label: lab, veto, notes, atr_pct: atrPct, atr_pctile: pct, why: notes.length ? notes : ["Belirgin ek risk işareti yok"] };
}

export function buildPlan(side, price, smc, atr, agents, spread, riskUsd, sym) {
  const cands = [], buf = 0.1 * atr;
  if (side === 1) {
    for (const ob of smc.obs) if (ob.dir === 1 && ob.lo < price) cands.push(ob.lo - buf);
    for (const s of [...smc.swings].reverse()) if (s.k === "L" && s.p < price) { cands.push(s.p - buf); break; }
    for (const sw of smc.sweeps) if (sw.dir === 1) cands.push(sw.ext - buf);
  } else {
    for (const ob of smc.obs) if (ob.dir === -1 && ob.hi > price) cands.push(ob.hi + buf);
    for (const s of [...smc.swings].reverse()) if (s.k === "H" && s.p > price) { cands.push(s.p + buf); break; }
    for (const sw of smc.sweeps) if (sw.dir === -1) cands.push(sw.ext + buf);
  }
  const ok = cands.filter((x) => 0.7 * atr <= side * (price - x) && side * (price - x) <= 2.5 * atr);
  let stop, basis = "yapı (swing/order block/süpürme fitili)";
  if (ok.length) stop = side === 1 ? Math.max(...ok) : Math.min(...ok); else { stop = price - side * 1.2 * atr; basis = "1,2 ATR (yakında uygun yapı yok)"; }
  let risk = Math.abs(price - stop);
  if (spread) { risk = Math.max(risk, 2.5 * spread); stop = price - side * risk; }
  const tgt = [];
  for (const q of smc.liq) if (!q.swept && side * (q.p - price) >= 1.3 * risk) tgt.push([side * (q.p - price), q.p, q.k]);
  for (const fv of smc.fvgs) { const lvl = side === 1 ? fv.lo : fv.hi; if (fv.dir === -side && side * (lvl - price) >= 1.3 * risk) tgt.push([side * (lvl - price), lvl, "FVG"]); }
  for (const ob of smc.obs) { const lvl = side === 1 ? ob.lo : ob.hi; if (ob.dir === -side && side * (lvl - price) >= 1.3 * risk) tgt.push([side * (lvl - price), lvl, "order block"]); }
  tgt.sort((a, b) => a[0] - b[0] || a[1] - b[1] || (a[2] < b[2] ? -1 : a[2] > b[2] ? 1 : 0));    // Python demet sıralaması
  let tp1 = price + side * 1.5 * risk, t1lab = "1,5R";
  if (tgt.length && tgt[0][0] <= 2.6 * risk) { tp1 = tgt[0][1]; t1lab = tgt[0][2]; }
  let tp2 = price + side * Math.max(2.5 * risk, side * (tp1 - price) + 0.8 * risk), t2lab = "2,5R+";
  for (const [dist, lvl, k] of tgt) if (dist >= side * (tp1 - price) + 0.5 * risk && dist <= 6 * risk) { tp2 = lvl; t2lab = k; break; }
  const r1 = (side * (tp1 - price)) / risk, r2 = (side * (tp2 - price)) / risk, pWin = risk / (risk + Math.abs(tp1 - price)), qty = risk > 0 ? riskUsd / risk : 0;
  return { side, entry: price, stop, tp1, tp2, risk, r1, r2, tp1_basis: t1lab, tp2_basis: t2lab, stop_basis: basis, stop_atr: risk / atr, p_random_win: pWin, qty, risk_usd: riskUsd, stop_pct: (risk / price) * 100 };
}

export function setupType(side, agents, smc) {
  const sw = smc.sweeps.filter((s) => s.dir === side), ev = smc.events.filter((e) => e.dir === side && smc.n - 1 - e.i <= 12), fl = agents.find((a) => a.name === "Order Flow");
  if (sw.length && ev.length && ev[ev.length - 1].type === "CHoCH") return "Likidite süpürme + CHoCH dönüşü";
  if (sw.length) return "Likidite süpürme dönüşü";
  if (ev.length && smc.obs.some((o) => o.inside && o.dir === side)) return "Yapı kırılımı + order block retest";
  if (fl && fl.real && Math.abs(fl.vote) > 0.5 && fl.vote * side > 0) return "Order flow baskısı";
  if (smc.pd && smc.pd.ote && smc.pd.ote[0] <= smc.price && smc.price <= smc.pd.ote[1]) return "OTE geri çekilme girişi";
  return "Trend devamı (çok ajan uyumu)";
}

export function evaluate(sym, tf, d, smc, flow, realFlow, spread, htf, eventsNear, riskUsd, stats, nowTs, livePrice = null, news = null) {
  const n = d.close.length;
  const price = livePrice ? Number(livePrice) : (flow === null || flow === undefined || flow.price === null || flow.price === undefined) ? Number(d.close[n - 1]) : Number(flow.price);
  const atr = smc.atr;
  const ag = [trendAgent(d, smc, htf), momentumAgent(d), flowAgent(d, sym, flow, realFlow, nowTs), ictAgent(d, smc, price), liquidityAgent(d, smc, price), paAgent(d, smc, price), newsAgent(news)];
  const keys = ["trend", "momentum", "flow", "ict", "liquidity", "pa", "news"], w = { ...W };
  if (!realFlow) w.flow = 0.06;
  const totW = Object.values(w).reduce((a, b) => a + b, 0);
  const score = keys.reduce((s, k, i) => s + w[k] * ag[i].vote * (0.5 + 0.5 * ag[i].conf), 0) / totW;
  const risk = riskAgent(d, smc, spread, eventsNear, ag, sym, nowTs, news), adx = G(rowAt(d, n - 1), "adx", 0);
  const side = score > 0 ? 1 : -1, agree = ag.filter((a) => a.vote * side > 0.15 && a.conf >= 0.3).length, conf = clip(Math.abs(score) * 1.8, 0, 1);
  let state = "BEKLE", stype = null; const whyWait = [];
  const reversal = smc.sweeps.some((s) => s.dir === side) || (ag[2].real && ag[2].vote * side > 0.55 && ag[2].conf > 0.5);
  if (Math.abs(score) < 0.25) whyWait.push(`Ajan oyları zayıf (skor ${sf(score, 2)}, giriş eşiği ±0.25)`);
  else if (agree < 3) whyWait.push(`Yeterli uyum yok: aynı yöne ${agree} ajan (en az 3 gerekir)`);
  else if (adx < ADX_MIN && !reversal) whyWait.push(`ADX ${f(adx, 0)} < ${f(ADX_MIN, 0)}: piyasa yatay, trend sinyali verilmez (likidite süpürme/order flow dönüşü olmadıkça)`);
  else if (risk.veto) whyWait.push("Makro haber çok yakın: yeni işlem önerilmez");
  else if (ag.some((a) => a.vote * side < -0.7 && a.conf >= 0.7)) { const opp = ag.find((a) => a.vote * side < -0.7 && a.conf >= 0.7); whyWait.push(`${opp.name} ajanı güçlü şekilde TERS yönde (oy ${sf(opp.vote, 2)}): çelişki var, sinyal verilmez`); }
  else {                                       // kalite kapıları (pro_agents.py ile aynı)
    const hd = htf || {}, ks = Object.keys(hd), against = ks.filter((k) => Number(hd[k].ema || 0) * side < 0 && Number(hd[k].struct || 0) * side < 0), hour = new Date(nowTs * 1000).getUTCHours();
    if (ks.length && against.length === ks.length && !reversal) whyWait.push(`Üst zaman dilimleri (${against.join(", ")}) ters yönde: trende karşı sinyal verilmez`);
    else if (risk.score >= 60) whyWait.push(`Risk çok yüksek (${risk.score}/100): sinyal verilmez`);
    else if ((risk.atr_pctile || 0) > 0.97) whyWait.push("Oynaklık aşırı (son 200 mumun en yüksek %3'ü): ani sıçrama riski, sinyal verilmez");
    else if (["XAUUSDT", "XAGUSDT", "EURUSD"].includes(sym) && ["1m", "5m", "15m"].includes(tf) && hour >= 21) whyWait.push("Düşük likidite saati (21-24 UTC): kısa vadeli sinyal verilmez");
    else {
      stype = setupType(side, ag, smc); const p0 = buildPlan(side, price, smc, atr, ag, spread, riskUsd, sym), s0 = (stats || {})[stype];
      if (p0.r1 < 1.2) whyWait.push(`İlk hedef çok yakın: ödül/risk ${f(p0.r1, 1)} < 1,2`);
      else if (s0 && s0.n >= 15 && s0.avg_r < -0.15 && (s0.hi ?? 1) < p0.p_random_win) whyWait.push(`'${stype}' kurulumu geçmişte kaybettirdi (${s0.n} sinyal, ort ${sf(s0.avg_r, 2)}R): şu an verilmez`);
      else state = side === 1 ? "LONG" : "SHORT";
    }
    if (state === "BEKLE") stype = null;
  }
  const out = { sym, tf, price, atr, score, conf, agree, state, why_wait: whyWait, agents: [...ag, risk], adx, t: Math.floor(nowTs) };
  if (state !== "BEKLE") {
    const plan = buildPlan(side, price, smc, atr, ag, spread, riskUsd, sym), st = (stats || {})[stype];
    out.setup = stype; out.plan = plan; out.reasons = [];
    const ord = keys.map((k, i) => [k, ag[i]]).sort((a, b) => W[b[0]] * Math.abs(b[1].vote) * b[1].conf - W[a[0]] * Math.abs(a[1].vote) * a[1].conf);
    for (const [, a] of ord) if (a.vote * side > 0.15) out.reasons.push({ agent: a.name, icon: a.icon, pts: a.why.slice(0, 4) });
    const miss = plan.p_random_win, fp = price < 10 ? (x) => cn(x, 5) : price < 100 ? (x) => cn(x, 4) : c2;
    out.wrong = { baseline_win: miss, baseline_loss: 1 - miss,
      text: `Stop ${fp(plan.risk)} / ilk hedef ${fp(Math.abs(plan.tp1 - price))} mesafesinde, hiçbir avantaj olmayan (rastgele) piyasada hedefe stoptan önce ulaşma olasılığı ≈ %${f(miss * 100, 0)}, yani ≈ %${f((1 - miss) * 100, 0)} ihtimalle stop çalışır. Bu botun sinyallerinin bunu iyileştirdiği KANITLANMADI.`, measured: st || null };
    out.invalid = `Fiyat ${fp(plan.stop)} seviyesini ${side === 1 ? "aşağı" : "yukarı"} keserse fikir geçersiz (stop).`;
  }
  return out;
}
