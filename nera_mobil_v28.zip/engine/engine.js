/* DayTrader Pro (mobil) · motor + yerel "API": pro/pro_server.py'deki Engine'in JavaScript karşılığı. Arayüz (app.js) aynı JSON şekillerini bekler. */
import * as D from "./data.js";
import { compute, pivots } from "./ind.js";
import { analyze } from "./smc.js";
import * as A from "./agents.js";
import { Ledger } from "./ledger.js";
import { EVENTS } from "./events.js";
import { News, KEYS, llmAny } from "./news.js";

const SCAN_TFS = ["5m", "15m", "1h", "4h"];
const HTF = { "1m": ["5m", "15m"], "5m": ["15m", "1h"], "15m": ["1h", "4h"], "30m": ["1h", "4h"], "1h": ["4h", "1d"], "4h": ["1d"], "1d": [] };
const EV_NAME = { FOMC: "FOMC faiz kararı", CPI: "ABD enflasyon (CPI)", NFP: "ABD istihdam (NFP)" };

export function san(o) {
  if (o === null || o === undefined) return null;
  if (typeof o === "number") return isFinite(o) ? o : null;
  if (Array.isArray(o)) return o.map(san);
  if (o instanceof Map) return null;
  if (typeof o === "object") { const r = {}; for (const k in o) r[k] = san(o[k]); return r; }
  return o;
}

/* ---- takvim */
function nthSunday(y, m, n) { const d = new Date(Date.UTC(y, m - 1, 1)); const add = (7 - d.getUTCDay()) % 7; return Date.UTC(y, m - 1, 1 + add + 7 * (n - 1)); }
function nyOff(y, m, dd) { const t = Date.UTC(y, m - 1, dd); return nthSunday(y, 3, 2) <= t && t < nthSunday(y, 11, 1) ? 4 : 5; }
export const EVS = EVENTS.map(([ds, tur, hm]) => { const [y, m, d] = ds.split("-").map(Number), [hh, mm] = hm.split(":").map(Number); return [Date.UTC(y, m - 1, d, hh + nyOff(y, m, d), mm) / 1000, tur]; });
export function eventNear(now = Date.now() / 1000) {
  let best = null;
  for (const [t, k] of EVS) { const m = (t - now) / 60; if (m >= -30 && m <= 180 && (best === null || Math.abs(m) < Math.abs(best[0]))) best = [Math.trunc(m), EV_NAME[k]]; }
  return best;
}

const lastOf = (a) => a[a.length - 1];
const slice0 = (df, n) => ({ ts: df.ts.slice(0, n), open: df.open.slice(0, n), high: df.high.slice(0, n), low: df.low.slice(0, n), close: df.close.slice(0, n), volume: df.volume.slice(0, n), tbv: df.tbv.slice(0, n) });

export class Engine {
  constructor(storage = globalThis.localStorage, opts = {}) {
    this.m = new D.Market(opts); this.led = new Ledger(storage); this.st = storage;
    this.cache = new Map(); this.events = []; this.evId = 0; this.lastState = new Map(); this.liveState = new Map(); this.settings = { risk_usd: 50.0 };
    try { Object.assign(this.settings, JSON.parse(storage.getItem("dt_pro_ayar") || "{}")); } catch (e) { /* varsayılan */ }
    try { this.lastState = new Map(JSON.parse(storage.getItem("dt_pro_state") || "[]")); } catch (e) { this.lastState = new Map(); }
    this.listeners = [];
    try { this.keys = JSON.parse(storage.getItem("nera_keys") || "{}"); } catch (e) { this.keys = {}; }
    this.news = opts.skipNews ? null : new News(() => this.keys);
  }
  start() { if (this.news) this.news.start(); this.m.start(); this.scanTimer = setInterval(() => this.scanOnce(), 1500); }
  stop() { clearInterval(this.scanTimer); this.m.stop(); }
  saveSettings() { try { this.st.setItem("dt_pro_ayar", JSON.stringify(this.settings)); } catch (e) { /* yoksay */ } }

  prep(sym, tf) {
    const df = this.m.get(sym, tf); if (!df || df.ts.length < 260) return [null, false];
    const n = df.ts.length - 1, bar = df.ts[n - 1], key = sym + "|" + tf, c = this.cache.get(key);
    if (c && c.bar === bar) return [c, false];
    const closed = slice0(df, n), d = compute(closed, D.hasFlow(sym), tf), smc = analyze(d, tf), nc = { bar, d, smc, piv: pivots(closed) };
    this.cache.set(key, nc); return [nc, true];
  }
  htfCtx(sym, tf) {
    const out = {};
    for (const h of HTF[tf] || []) { const [c] = this.prep(sym, h); if (c) { const i = c.d.close.length - 1; out[h] = { struct: c.smc.struct, ema: Math.sign(c.d.ema21[i] - c.d.ema50[i]) }; } }
    return out;
  }
  closed(sym) { if (["XAUUSDT", "XAGUSDT", "EURUSD"].includes(sym) && D.weekendTs(Date.now() / 1000)) return true; const df = this.m.get(sym, "1m"); return !!(df && df.ts.length && Date.now() / 1000 - df.ts[df.ts.length - 1] > 1200); }
  evaluate(sym, tf) {
    const [c] = this.prep(sym, tf); if (!c) return null;
    const flow = this.m.flow[sym] || null, real = Boolean(lastOf(c.d.delta_real));
    const ev = A.evaluate(sym, tf, c.d, c.smc, flow, real, this.m.spread(sym), this.htfCtx(sym, tf), eventNear(), Number(this.settings.risk_usd), this.led.stats(), Date.now() / 1000, this.m.price(sym), this.news ? this.news.summary(sym) : null);
    if (ev && this.closed(sym)) { ev.state = "BEKLE"; ev.why_wait = ["Piyasa şu an kapalı (hafta sonu / günlük ara / tatil): yeni sinyal verilmez; grafik son kapanışı gösterir.", ...(ev.why_wait || [])]; ev.closed = true; for (const k of ["plan", "setup", "reasons", "wrong", "invalid"]) delete ev[k]; }
    return ev;
  }
  maybeFire(sym, tf, ev) {
    const key = sym + "|" + tf; if (this.closed(sym)) { this.liveState.set(key, "BEKLE"); this.lastState.set(key, "BEKLE"); return; }
    this.liveState.set(key, ev.state);
    if (tf === "5m" && this.settings.no5m) { this.lastState.set(key, ev.state); return; }          // ayarlardan: 5 dakikalık sinyal verme
    const prev = this.lastState.get(key); this.lastState.set(key, ev.state);
    try { this.st.setItem("dt_pro_state", JSON.stringify([...this.lastState.entries()])); } catch (e) { /* yoksay */ }      // uygulama kapanıp açılsa da geçişler yakalanır
    if (prev !== undefined && ev.state !== "BEKLE" && prev !== ev.state && !this.led.openFor(sym, tf, ev.state === "LONG" ? 1 : -1).length) {
      const c = this.cache.get(key), tfs = D.TF_SEC[tf], barClose = c ? c.bar + tfs : ev.t, age = Date.now() / 1000 - barClose, side = ev.state === "LONG" ? 1 : -1;
      if (age > 1.5 * tfs) {                  // uygulama kapalı/askıdayken oluşmuş: eski plan geçersiz olabilir, işlem planı verilmez, sadece haber
        if (age > 6 * 3600) return null;      // çok eski: anlamsız
        this.evId++; const e = { id: this.evId, missed: true, sym, tf, side, ago: Math.round(age / 60), name: D.NAMES[sym] }; this.events.push(e); if (this.events.length > 60) this.events.shift();
        this.listeners.forEach((f) => { try { f(e); } catch (x) { /* yoksay */ } });
        return null;
      }
      const s = this.led.add(ev); this.evId++; const e = { id: this.evId, sig: s, name: D.NAMES[sym] }; this.events.push(e); if (this.events.length > 60) this.events.shift();
      this.listeners.forEach((f) => { try { f(e); } catch (x) { /* yoksay */ } });
      return s;
    }
    return null;
  }
  /** Arka plan servisinin (arayüz kapalıyken) ürettiği sinyalleri deftere aktarır; aynı sinyal iki kez eklenmez. Dönüş: eklenen sayısı. */
  importExternal(list) {
    let n = 0;
    for (const e of list || []) {
      const s = e && e.sig; if (!s) continue;
      const dup = this.led.sigs.some((x) => x.sym === s.sym && x.tf === s.tf && x.side === s.side && Math.abs(x.ts - s.ts) < (D.TF_SEC[s.tf] || 900));
      if (dup) continue;
      s.id = this.led.nextId++; this.led.sigs.push(s); n++;
    }
    if (n) this.led.save();
    return n;
  }
  async scanOnce() {
    if (this._scanning) return; this._scanning = true;
    try {
      for (const sym of D.SYMS) for (const tf of SCAN_TFS) {
        const [c, nw] = this.prep(sym, tf); if (!c) continue;
        if (nw || !this.liveState.has(sym + "|" + tf)) { const ev = this.evaluate(sym, tf); if (ev) this.maybeFire(sym, tf, ev); }
        await new Promise((r) => setTimeout(r, 0));          // arayüze nefes aldır
      }
      if (!this._tres || Date.now() - this._tres > 4000) { this._tres = Date.now(); this.led.resolve((s) => this.m.get(s, "1m"), D.TF_SEC); }
    } catch (e) { this.m.err.scan = String(e).slice(0, 100); }
    this._scanning = false;
  }

  chart(sym, tf) {
    const df = this.m.get(sym, tf), [c] = this.prep(sym, tf); if (!df || !c) return { ready: false, reason: this.noData(sym) };
    const d = c.d, n = 500, N = df.ts.length, s0 = Math.max(0, N - n);
    const candles = []; for (let i = s0; i < N; i++) candles.push({ time: df.ts[i], open: df.open[i], high: df.high[i], low: df.low[i], close: df.close[i], volume: df.volume[i] });
    const M = d.close.length, d0 = Math.max(0, M - n), tt = d.ts.slice(d0);
    const ser = (col) => { const a = d[col].slice(d0), out = []; for (let i = 0; i < a.length; i++) if (isFinite(a[i])) out.push({ time: tt[i], value: a[i] }); return out; };
    const series = {}; for (const k of ["ema9", "ema21", "ema50", "ema200", "vwap", "bbu", "bbl", "bbm", "st_line", "tenkan", "kijun", "spana", "spanb", "adx", "pdi", "mdi", "rsi", "srsi_k", "srsi_d", "macd", "macds", "macdh", "cvd", "sar", "kcu", "kcl", "sqmom", "mfi", "cmf", "pulse"]) series[k] = ser(k);
    series.st_dir = tt.map((t, i) => ({ time: t, v: d.st_dir[d0 + i] }));
    series.delta = []; for (let i = 0; i < tt.length; i++) if (isFinite(d.delta[d0 + i])) series.delta.push({ time: tt[i], value: d.delta[d0 + i], v: d.volume[d0 + i] });
    return { ready: true, sym, tf, real_flow: Boolean(lastOf(d.delta_real)), bar: lastOf(tt), candles, series, smc: c.smc, pivots: c.piv, names: D.NAMES };
  }

  indicators(sym, tf) {
    const [c] = this.prep(sym, tf); if (!c) return {};
    const d = c.d, i = d.close.length - 1, r = A.rowAt(d, i), g = (k, def) => (isFinite(r[k]) ? r[k] : def === undefined ? NaN : def), px = g("close"), sgn = A.sgnPub;
    const f2 = (x) => Number(x).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), f3 = (x) => Number(x).toLocaleString("en-US", { minimumFractionDigits: 3, maximumFractionDigits: 3 });
    const ma = [], osc = [];
    for (const n of [9, 21, 50, 200]) ma.push([`EMA ${n}`, f2(g("ema" + n)), sgn(px - g("ema" + n))]);
    for (const n of [20, 50]) ma.push([`SMA ${n}`, f2(g("sma" + n)), sgn(px - g("sma" + n))]);
    ma.push(["VWAP", f2(g("vwap")), sgn(px - g("vwap"))]);
    const top = Math.max(g("spana"), g("spanb")), bot = Math.min(g("spana"), g("spanb"));
    ma.push(["Ichimoku bulut", px > top ? "üstünde" : px < bot ? "altında" : "içinde", px > top ? 1 : px < bot ? -1 : 0]);
    ma.push(["Ichimoku tenkan/kijun", `${f2(g("tenkan"))} / ${f2(g("kijun"))}`, sgn(g("tenkan") - g("kijun"))]);
    ma.push(["Supertrend", g("st_dir") > 0 ? "yukarı" : "aşağı", Math.trunc(g("st_dir", 0))]);
    ma.push(["Parabolic SAR", f2(g("sar")), Math.trunc(g("sar_dir", 0))]);
    const rs = g("rsi"); osc.push(["RSI 14", rs.toFixed(1), rs > 55 && rs < 75 ? 1 : rs < 45 && rs > 25 ? -1 : 0]);
    osc.push(["Stochastic %K/%D", `${g("stk").toFixed(0)} / ${g("std").toFixed(0)}`, g("stk") > g("std") && g("stk") < 80 ? 1 : g("stk") < g("std") && g("stk") > 20 ? -1 : 0]);
    osc.push(["Stochastic RSI", `${g("srsi_k").toFixed(0)} / ${g("srsi_d").toFixed(0)}`, g("srsi_k") > g("srsi_d") && g("srsi_k") < 80 ? 1 : g("srsi_k") < g("srsi_d") && g("srsi_k") > 20 ? -1 : 0]);
    osc.push(["MACD", `${f3(g("macd"))} / h ${f3(g("macdh"))}`, sgn(g("macdh"))]);
    osc.push(["CCI 20", g("cci").toFixed(0), g("cci") > 100 ? 1 : g("cci") < -100 ? -1 : 0]);
    osc.push(["Williams %R", g("willr").toFixed(0), g("willr") < -80 ? 1 : g("willr") > -20 ? -1 : 0]);
    osc.push(["MFI 14", g("mfi").toFixed(0), g("mfi") < 20 ? 1 : g("mfi") > 80 ? -1 : 0]);
    osc.push(["Aroon", `↑${g("aroon_u").toFixed(0)} ↓${g("aroon_d").toFixed(0)}`, sgn(g("aroon_u") - g("aroon_d"), 30)]);
    osc.push(["ROC 10", `%${g("roc10").toFixed(2)}`, sgn(g("roc10"))]);
    osc.push(["Pulse (bileşik)", (g("pulse") >= 0 ? "+" : "-") + Math.abs(g("pulse")).toFixed(0), g("pulse") > 25 ? 1 : g("pulse") < -25 ? -1 : 0]);
    osc.push(["ADX 14 · DI", `${g("adx").toFixed(0)} · +${g("pdi").toFixed(0)}/-${g("mdi").toFixed(0)}`, g("adx") >= 16 ? sgn(g("pdi") - g("mdi")) : 0]);
    osc.push(["Kümülatif delta z", (g("cdz") >= 0 ? "+" : "-") + Math.abs(g("cdz")).toFixed(1) + (g("delta_real") ? "" : " (vekil)"), g("cdz") > 0.7 ? 1 : g("cdz") < -0.7 ? -1 : 0]);
    osc.push(["CMF 20", (g("cmf") >= 0 ? "+" : "-") + Math.abs(g("cmf")).toFixed(2), g("cmf") > 0.05 ? 1 : g("cmf") < -0.05 ? -1 : 0]);
    const extra = [["Bollinger %B", ((px - g("bbl")) / Math.max(g("bbu") - g("bbl"), 1e-9) * 100).toFixed(0)], ["Squeeze (BB/KC)", g("squeeze") ? "SIKIŞMA" : "yok"], ["ATR %", (g("atr") / px * 100).toFixed(2)], ["Hacim z", (g("vz") >= 0 ? "+" : "-") + Math.abs(g("vz")).toFixed(1)], ["Verim oranı (X-Ray)", g("er").toFixed(2)]];
    const summ = (it) => { const b = it.filter((x) => x[2] > 0).length, s = it.filter((x) => x[2] < 0).length, n_ = it.filter((x) => x[2] === 0).length; return { buy: b, sell: s, neutral: n_, score: (b - s) / Math.max(it.length, 1) }; };
    return { ma: ma.map(([n, v, o]) => ({ n, v, o })), osc: osc.map(([n, v, o]) => ({ n, v, o })), extra: extra.map(([n, v]) => ({ n, v })), sum: { ma: summ(ma), osc: summ(osc), all: summ([...ma, ...osc]) } };
  }

  noData(sym) {
    const dead = Object.keys(this.m.err).some((k) => k.startsWith(sym + "|"));
    return dead ? (sym === "EURUSD" ? "EUR/USD verisi bu cihazda alınamıyor (tarayıcı kısıtı). Android uygulamasında (APK) çalışır; kripto/altın/gümüş etkilenmez." : `${D.NAMES[sym]} verisi alınamıyor: ${Object.entries(this.m.err).find(([k]) => k.startsWith(sym + "|"))[1]}`) : "";
  }
  analysis(sym, tf) { const ev = this.evaluate(sym, tf); if (!ev) return { ready: false, reason: this.noData(sym) }; return { ready: true, eval: ev, ind: this.indicators(sym, tf), stats: this.led.stats(), event: eventNear() }; }

  flowPayload(sym) {
    const f = this.m.flow[sym]; if (!f) return null;
    const now = Math.floor(Date.now() / 1000), mins = [...f.minutes.entries()], last5 = mins.filter(([m]) => now - m <= 300).map(([, b]) => b);
    const buy5 = last5.reduce((s, b) => s + b.buy, 0), sell5 = last5.reduce((s, b) => s + b.sell, 0), cur = mins.length ? mins[mins.length - 1][1] : { buy: 0, sell: 0 };
    const fp = mins.slice(-8).map(([m, b]) => ({ t: m, buy: b.buy, sell: b.sell, bins: [...b.bins.entries()].sort((a, c) => a[0] - c[0]).map(([k, v]) => [k, v[0], v[1]]) }));
    return { price: f.price, bid: f.bid, ask: f.ask, bidq: f.bidq, askq: f.askq, buy5, sell5, cur_buy: cur.buy, cur_sell: cur.sell, cvd: f.cvd, cvd_hist: f.cvd_hist.slice(-180), fp, step: f.step, big: f.big.slice(-14).reverse(), liq: f.liq.slice(-14).reverse(), trades: f.ntr };
  }

  tick(sym, tf, since) {
    const watch = {};
    for (const s of D.SYMS) {
      const px = this.m.price(s) ?? (this.m.get(s, "1m") ? lastOf(this.m.get(s, "1m").close) : null), h1 = this.m.get(s, "1h"); let chg = null;
      if (h1 && h1.close.length > 25 && px) chg = (px / h1.close[h1.close.length - 25] - 1) * 100;
      const states = {}; SCAN_TFS.forEach((t) => (states[t] = this.liveState.get(s + "|" + t) || null));
      watch[s] = { price: px, chg, spread: this.m.spread(s), closed: this.closed(s), states };
    }
    const df = this.m.get(sym, tf); let candle = null;
    if (df && df.ts.length) {
      const i = df.ts.length - 1, px = this.m.price(sym) ?? df.close[i];
      candle = { time: df.ts[i], open: df.open[i], high: Math.max(df.high[i], px), low: Math.min(df.low[i], px), close: px, volume: df.volume[i] };
    }
    const evs = this.events.filter((e) => e.id > since);
    return { watch, candle, events: evs, last_ev: this.evId, flow: this.closed(sym) ? null : this.flowPayload(sym), ws_age: this.m.wsOk ? Date.now() / 1000 - this.m.wsOk : null, err: Object.fromEntries(Object.entries(this.m.err).slice(0, 3)), ready: this.m.df.size, now: Date.now() / 1000 };
  }

  calendar() { const now = Date.now() / 1000; return EVS.filter(([t]) => t >= now - 1800).slice(0, 8).map(([t, k]) => ({ t, k, name: EV_NAME[k] })); }

  /** app.js'in fetch yerine kullandığı yerel yönlendirici */
  handle(path, opt) {
    const u = new URL(path, "http://yerel/"), q = Object.fromEntries(u.searchParams.entries());
    const sym = D.SYMS.includes(q.sym) ? q.sym : "XAUUSDT", tf = D.TFS.includes(q.tf) ? q.tf : "15m";
    switch (u.pathname) {
      case "/api/ping": { const eurDead = Object.keys(this.m.err).some((k) => k.startsWith("EURUSD") && !this.m.get("EURUSD", "1m")); return { ok: 1, ready: this.m.df.size, need: D.SYMS.length * D.TFS.length - (eurDead ? D.TFS.length : 0), err: Object.fromEntries(Object.entries(this.m.err).slice(0, 2)) }; }
      case "/api/chart": return san(this.chart(sym, tf));
      case "/api/analysis": return san(this.analysis(sym, tf));
      case "/api/tick": return san(this.tick(sym, tf, parseInt(q.since || "0", 10)));
      case "/api/signals": return san({ sigs: this.led.recent(300), stats: this.led.stats() });
      case "/api/calendar": return san(this.calendar());
      case "/api/news": return san({ items: this.news ? this.news.feed(60) : [], sum: Object.fromEntries(["BTCUSDT", "ETHUSDT", "XAUUSDT", "XAGUSDT", "EURUSD"].map((s) => [s, this.news ? this.news.summary(s) : { sym: s, n: 0, score: 0, conf: 0, shock: false, top: [] }])), status: this.news ? this.news.status : {}, keys: Object.fromEntries(KEYS.map((k) => [k, !!this.keys[k]])), prov: this.keys._prov || "auto" });
      case "/api/keys": { if (opt && opt.method === "POST") { try { const b = JSON.parse(opt.body || "{}"); for (const k of [...KEYS, "_prov"]) if (k in b) { const v = String(b[k] || "").trim(); if (v) this.keys[k] = v; else delete this.keys[k]; } this.st.setItem("nera_keys", JSON.stringify(this.keys)); if (this.news) { this.news._next = 0; this.news.refresh(); } } catch (e) { /* yoksay */ } } return Object.fromEntries(KEYS.map((k) => [k, !!this.keys[k]])); }
      case "/api/llm": return (async () => { try { const b = JSON.parse((opt && opt.body) || "{}"), [text, prov] = await llmAny(this.keys, String(b.prompt || "").slice(0, 6000), b.only); return { text, prov }; } catch (e) { return { err: String(e.message || e).slice(0, 160) }; } })();
      case "/api/settings": if (opt && opt.method === "POST") { try { const b = JSON.parse(opt.body || "{}"); if (b.risk_usd !== undefined) this.settings.risk_usd = Math.min(Math.max(parseFloat(b.risk_usd), 1), 1e6); if (b.no5m !== undefined) this.settings.no5m = !!b.no5m; this.saveSettings(); } catch (e) { /* yoksay */ } } return { ...this.settings };
      default: return { err: "yok" };
    }
  }
}
