/* DayTrader Pro (mobil) · göstergeler: pro/pro_ind.py'nin JavaScript karşılığı. */
import * as T from "./ta.js";
const { isn } = T;

const nz = (x, y) => (y === 0 || y !== y ? NaN : x / y);        // x / y.replace(0, nan)

export function rsi(c, n = 14) {
  const d = T.diff(c), up = d.map((x) => (x > 0 ? x : x === x ? 0 : NaN)), dn = d.map((x) => (x < 0 ? -x : x === x ? 0 : NaN));
  const au = T.wilder(up, n), ad = T.wilder(dn, n);
  return au.map((a, i) => { const r = 100 - 100 / (1 + nz(a, ad[i])); return r === r ? r : 50; });
}

export function linregEnd(x, n) {
  const N = x.length, out = T.nans(N), tm = (n - 1) / 2; let tv = 0; for (let k = 0; k < n; k++) tv += (k - tm) ** 2;
  for (let i = n - 1; i < N; i++) {
    let bad = false, m = 0; for (let j = i - n + 1; j <= i; j++) { if (x[j] !== x[j]) { bad = true; break; } m += x[j]; }
    if (bad) continue; m /= n; let b = 0; for (let k = 0; k < n; k++) b += (k - tm) * (x[i - n + 1 + k] - m);
    out[i] = m + (b / tv) * ((n - 1) - tm);
  }
  return out;
}

export function supertrend(h, l, c, n = 10, m = 3.0) {
  const N = c.length, tr = trueRange(h, l, c), atr = T.wilder(tr, n);
  const ub = [], lb = [];
  for (let i = 0; i < N; i++) { const hl2 = (h[i] + l[i]) / 2; ub.push(hl2 + m * atr[i]); lb.push(hl2 - m * atr[i]); }
  const fu = ub.slice(), fl = lb.slice(), d = T.zeros(N, 1);
  for (let i = 1; i < N; i++) {
    fu[i] = (ub[i] < fu[i - 1] || c[i - 1] > fu[i - 1]) ? ub[i] : fu[i - 1];
    fl[i] = (lb[i] > fl[i - 1] || c[i - 1] < fl[i - 1]) ? lb[i] : fl[i - 1];
    d[i] = (d[i - 1] === 1 && c[i] < fl[i]) ? -1 : (d[i - 1] === -1 && c[i] > fu[i]) ? 1 : d[i - 1];
  }
  return [d, d.map((x, i) => (x === 1 ? fl[i] : fu[i]))];
}

export function psar(h, l, af0 = 0.02, afmax = 0.2) {
  const n = h.length, sar = T.zeros(n), out = T.zeros(n, 1); let bull = true, ep = h[0], af = af0; sar[0] = l[0];
  for (let i = 1; i < n; i++) {
    sar[i] = sar[i - 1] + af * (ep - sar[i - 1]);
    if (bull) {
      sar[i] = Math.min(sar[i], l[i - 1], i > 1 ? l[i - 2] : l[i - 1]);
      if (l[i] < sar[i]) { bull = false; sar[i] = ep; ep = l[i]; af = af0; } else if (h[i] > ep) { ep = h[i]; af = Math.min(af + af0, afmax); }
    } else {
      sar[i] = Math.max(sar[i], h[i - 1], i > 1 ? h[i - 2] : h[i - 1]);
      if (h[i] > sar[i]) { bull = true; sar[i] = ep; ep = h[i]; af = af0; } else if (l[i] < ep) { ep = l[i]; af = Math.min(af + af0, afmax); }
    }
    out[i] = bull ? 1 : -1;
  }
  return [out, sar];
}

function trueRange(h, l, c) {
  return h.map((_, i) => { const a = h[i] - l[i]; if (i === 0) return a; return Math.max(a, Math.abs(h[i] - c[i - 1]), Math.abs(l[i] - c[i - 1])); });
}

/** df: {ts:[sn], open, high, low, close, volume, tbv}. Kapanmış mumlar. Dönüş: aynı uzunlukta dizilerden oluşan nesne. */
export function compute(df, flow = true, tf = "1h") {
  const d = { ts: df.ts, open: df.open, high: df.high, low: df.low, close: df.close, tbv: df.tbv };
  const c = df.close, o = df.open, h = df.high, l = df.low, N = c.length;
  let v = df.volume.slice();
  if (!flow || T.meanOf(v.map((x) => (x > 0 ? 1 : 0))) < 0.5) v = h.map((_, i) => ((h[i] - l[i]) / c[i]) * 1e4 + 1e-6);
  d.volume = v;
  const tr = trueRange(h, l, c);
  d.atr = T.wilder(tr, 14);
  for (const n of [9, 21, 50, 200]) d["ema" + n] = T.ewmSpan(c, n);
  d.sma20 = T.rollMean(c, 20); d.sma50 = T.rollMean(c, 50);
  // ADX / DI
  const up = T.diff(h), dn = T.diff(l).map((x) => -x);
  const pdm = up.map((u, i) => (u > dn[i] && u > 0 ? u : 0)), mdm = dn.map((q, i) => (q > up[i] && q > 0 ? q : 0));
  d.pdi = T.wilder(pdm, 14).map((x, i) => (100 * x) / d.atr[i]); d.mdi = T.wilder(mdm, 14).map((x, i) => (100 * x) / d.atr[i]);
  const dx = d.pdi.map((p, i) => { const s = p + d.mdi[i]; const r = (100 * Math.abs(p - d.mdi[i])) / (s === 0 ? NaN : s); return r === r ? r : 0; });
  d.adx = T.wilder(dx, 14);
  // VWAP (UTC günü), Bollinger, Keltner, TTM squeeze
  const tp = h.map((_, i) => (h[i] + l[i] + c[i]) / 3), vv = v.map((x) => (x > 0 ? x : 1e-9));
  if (tf === "1d") { const a = T.rollSum(tp.map((x, i) => x * vv[i]), 20), b = T.rollSum(vv, 20); d.vwap = a.map((x, i) => x / b[i]); }
  else { let day = -1, pv = 0, vs = 0; d.vwap = df.ts.map((t, i) => { const dd = Math.floor(t / 86400); if (dd !== day) { day = dd; pv = 0; vs = 0; } pv += tp[i] * vv[i]; vs += vv[i]; return pv / vs; }); }
  const mid = T.rollMean(c, 20), sd = T.rollStd(c, 20);
  d.bbu = mid.map((m, i) => m + 2 * sd[i]); d.bbl = mid.map((m, i) => m - 2 * sd[i]); d.bbm = mid; d.bbw = d.bbu.map((u, i) => (u - d.bbl[i]) / mid[i]);
  const kmid = T.ewmSpan(c, 20);
  d.kcu = kmid.map((m, i) => m + 1.5 * d.atr[i]); d.kcl = kmid.map((m, i) => m - 1.5 * d.atr[i]);
  d.squeeze = d.bbu.map((u, i) => (u < d.kcu[i] && d.bbl[i] > d.kcl[i] ? 1 : 0));
  const hmax20 = T.rollMax(h, 20), lmin20 = T.rollMin(l, 20);
  const dm = hmax20.map((a, i) => ((a + lmin20[i]) / 2 + mid[i]) / 2);
  d.sqmom = linregEnd(c.map((x, i) => x - dm[i]), 20);
  // osilatörler
  d.rsi = rsi(c, 14);
  const r = d.rsi, rmin = T.rollMin(r, 14), rmax = T.rollMax(r, 14);
  const srsi = r.map((x, i) => nz(x - rmin[i], rmax[i] - rmin[i]));
  d.srsi_k = T.rollMean(srsi, 3).map((x) => x * 100); d.srsi_d = T.rollMean(d.srsi_k, 3);
  const e12 = T.ewmSpan(c, 12), e26 = T.ewmSpan(c, 26);
  d.macd = e12.map((x, i) => x - e26[i]); d.macds = T.ewmSpan(d.macd, 9); d.macdh = d.macd.map((x, i) => x - d.macds[i]);
  const ll14 = T.rollMin(l, 14), hh14 = T.rollMax(h, 14);
  d.stk = c.map((x, i) => { const q = (100 * (x - ll14[i])) / (hh14[i] - ll14[i] === 0 ? NaN : hh14[i] - ll14[i]); return q === q ? q : 50; });
  d.std = T.rollMean(d.stk, 3);
  d.willr = c.map((x, i) => { const q = (-100 * (hh14[i] - x)) / (hh14[i] - ll14[i] === 0 ? NaN : hh14[i] - ll14[i]); return q === q ? q : -50; });
  const tpm = T.rollMean(tp, 20), mad = T.rollMad(tp, 20);
  d.cci = tp.map((x, i) => { const q = (x - tpm[i]) / (mad[i] === 0 ? NaN : 0.015 * mad[i]); return q === q ? q : 0; });
  d.aroon_u = T.rollArgMax(h, 26).map((k) => (100 * (25 - (25 - k))) / 25); d.aroon_d = T.rollArgMin(l, 26).map((k) => (100 * (25 - (25 - k))) / 25);
  d.roc10 = c.map((x, i) => (i >= 10 ? (x / c[i - 10] - 1) * 100 : NaN));
  // hacim tabanlı
  const dc = T.diff(c);
  d.obv = T.cumsum(dc.map((x, i) => (x === x ? Math.sign(x) * v[i] : 0)));
  const mf = tp.map((x, i) => x * v[i]), tps = T.shift(tp, 1);
  const pos = T.rollSum(mf.map((x, i) => (tp[i] > tps[i] ? x : 0)), 14), neg = T.rollSum(mf.map((x, i) => (tp[i] < tps[i] ? x : 0)), 14);
  d.mfi = pos.map((p, i) => { const q = 100 - 100 / (1 + nz(p, neg[i])); return q === q ? q : 50; });
  const clv = h.map((_, i) => { const q = ((c[i] - l[i]) - (h[i] - c[i])) / (h[i] - l[i] === 0 ? NaN : h[i] - l[i]); return q === q ? q : 0; });
  d.clv = clv;
  const cvs = T.rollSum(clv.map((x, i) => x * v[i]), 20), vs20 = T.rollSum(v, 20);
  d.cmf = cvs.map((x, i) => nz(x, vs20[i]));
  const vm = T.rollMean(v, 50), vsd = T.rollStd(v, 50);
  d.vz = v.map((x, i) => { const q = (x - vm[i]) / (vsd[i] === 0 ? NaN : vsd[i]); return q === q ? q : 0; });
  // delta (gerçek: taker alış - taker satış)
  const tbv = df.tbv, real = flow && tbv && tbv.every((x) => isn(x)) && v.every((x) => x > 0);
  d.delta = real ? tbv.map((x, i) => 2 * x - v[i]) : v.map((x, i) => x * clv[i]);
  d.delta_real = T.zeros(N, real ? 1 : 0);
  d.dpct = d.delta.map((x, i) => nz(x, v[i]));
  d.cvd = T.cumsum(d.delta);
  d.cd20 = T.rollSum(d.delta, 20);
  const cm = T.rollMean(d.cd20, 100), cs = T.rollStd(d.cd20, 100);
  d.cdz = d.cd20.map((x, i) => { const q = (x - cm[i]) / (cs[i] === 0 ? NaN : cs[i]); return q === q ? q : 0; });
  // trend sistemleri
  [d.st_dir, d.st_line] = supertrend(h, l, c, 10, 3.0);
  [d.sar_dir, d.sar] = psar(h, l);
  const h9 = T.rollMax(h, 9), l9 = T.rollMin(l, 9), h26 = T.rollMax(h, 26), l26 = T.rollMin(l, 26), h52 = T.rollMax(h, 52), l52 = T.rollMin(l, 52);
  d.tenkan = h9.map((x, i) => (x + l9[i]) / 2); d.kijun = h26.map((x, i) => (x + l26[i]) / 2);
  d.spana = T.shift(d.tenkan.map((x, i) => (x + d.kijun[i]) / 2), 26); d.spanb = T.shift(h52.map((x, i) => (x + l52[i]) / 2), 26);
  d.dch = hmax20; d.dcl = lmin20;
  d.pulse = c.map((_, i) => (2 * (d.rsi[i] - 50) + (d.stk[i] - 50) * 2 + Math.min(100, Math.max(-100, d.cci[i] / 2)) + Math.min(100, Math.max(-100, (d.macdh[i] / d.atr[i]) * 150))) / 4);
  const c20 = T.shift(c, 20), ad = dc.map(Math.abs), sad = T.rollSum(ad, 20);
  d.er = c.map((x, i) => { const q = Math.abs(x - c20[i]) / (sad[i] === 0 ? NaN : sad[i]); return q === q ? q : 0; });
  return d;
}

/** Klasik günlük pivotlar (önceki UTC gününün OHLC'sinden). */
export function pivots(df) {
  const days = new Map();
  df.ts.forEach((t, i) => { const dd = Math.floor(t / 86400); const g = days.get(dd); if (!g) days.set(dd, { high: df.high[i], low: df.low[i], close: df.close[i] }); else { g.high = Math.max(g.high, df.high[i]); g.low = Math.min(g.low, df.low[i]); g.close = df.close[i]; } });
  const keys = [...days.keys()].sort((a, b) => a - b); if (keys.length < 2) return {};
  const p = days.get(keys[keys.length - 2]), P = (p.high + p.low + p.close) / 3;
  return { P, R1: 2 * P - p.low, S1: 2 * P - p.high, R2: P + (p.high - p.low), S2: P - (p.high - p.low), PDH: p.high, PDL: p.low, PDC: p.close };
}
