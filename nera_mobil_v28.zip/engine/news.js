/* Nera (mobil) · haber toplayıcı + duygu puanı + yapay zekâ sağlayıcıları. pro/pro_news.py'nin JavaScript karşılığı.
   Ağ istekleri CORS'a takılmasın diye Capacitor'ın yerel HTTP katmanıyla (CapacitorHttp) yapılır; yoksa fetch'e düşer. Anahtarlar yalnız bu telefonda saklanır. */
export const SYMS = ["BTCUSDT", "ETHUSDT", "XAUUSDT", "XAGUSDT", "EURUSD"];
const QUERY = { BTCUSDT: "bitcoin OR BTC", ETHUSDT: "ethereum OR ETH", XAUUSDT: "gold price OR XAU OR gold futures", XAGUSDT: "silver price OR XAG", EURUSD: "EUR/USD OR euro dollar OR ECB OR Federal Reserve" };
const GENERIC = { BTCUSDT: ["bitcoin", "btc"], ETHUSDT: ["ethereum", "ether", "eth "] };
const POS = ["surge", "rally", "soar", "jump", "gain", "rise", "rises", "bullish", "record high", "all-time high", "breakout", "approve", "approval", "adoption", "inflow", "inflows", "buy", "upgrade", "beat", "strong demand", "recover", "rebound", "climb"];
const NEG = ["plunge", "crash", "slump", "drop", "fall", "falls", "tumble", "bearish", "selloff", "sell-off", "hack", "hacked", "exploit", "ban", "lawsuit", "outflow", "outflows", "liquidation", "downgrade", "miss", "weak", "fear", "decline", "lose", "losses", "dump", "fraud"];
const DOV = ["rate cut", "rate cuts", "dovish", "easing", "stimulus", "weaker dollar", "dollar falls", "dollar slides", "inflation cools", "inflation eases"];
const HAWK = ["rate hike", "rate hikes", "hawkish", "tightening", "stronger dollar", "dollar rises", "dollar surges", "inflation hotter", "inflation rises", "yields jump", "yields rise"];
const SHOCK = ["fomc", "cpi", "nfp", "payrolls", "rate decision", "emergency", "hack", "exploit", "sec ", "ban", "war", "missile", "strike", "default", "collapse", "halt", "bankrupt", "liquidat", "etf"];
export const KEYS = ["gemini", "groq", "openrouter", "mistral", "finnhub"], LLMS = ["gemini", "groq", "openrouter", "mistral"];
const CH = () => globalThis.Capacitor && globalThis.Capacitor.Plugins && globalThis.Capacitor.Plugins.CapacitorHttp;

export async function http(url, o = {}) {
  const ch = CH(), method = (o.method || "GET").toUpperCase();
  if (ch) { const r = await (method === "GET" ? ch.get({ url, headers: o.headers || {}, responseType: "text", connectTimeout: 15000, readTimeout: 30000 }) : ch.post({ url, headers: o.headers || {}, data: o.body ? JSON.parse(o.body) : {}, responseType: "text", connectTimeout: 15000, readTimeout: 30000 })); if (r.status >= 400) throw new Error(`HTTP ${r.status}: ${String(typeof r.data === "string" ? r.data : JSON.stringify(r.data)).slice(0, 150)}`); return typeof r.data === "string" ? r.data : JSON.stringify(r.data); }
  const r = await fetch(url, { method, headers: o.headers, body: o.body }); const t = await r.text(); if (!r.ok) throw new Error(`HTTP ${r.status}: ${t.slice(0, 150)}`); return t;
}
function scoreTitle(sym, title) {
  const t = " " + title.toLowerCase() + " "; let s = POS.filter((w) => t.includes(w)).length - NEG.filter((w) => t.includes(w)).length;
  const macro = DOV.filter((w) => t.includes(w)).length - HAWK.filter((w) => t.includes(w)).length; s += macro * (sym === "EURUSD" ? 0.6 : 1);
  return [Math.max(-1, Math.min(1, s / 2)), SHOCK.some((w) => t.includes(w))];
}
export class News {
  constructor(getKeys) { this.keys = getKeys; this.items = new Map(); this.status = { last: 0, err: {}, n: 0, llm: "" }; this._next = 0; }
  start() { setTimeout(() => this.refresh(), 4000); this.timer = setInterval(() => this.refresh(), 5 * 60 * 1000); }
  add(sym, title, src, link, ts) {
    if (!title || !ts) return; const key = title.toLowerCase().replace(/\W+/g, "").slice(0, 80), it = this.items.get(key); if (it) { if (!it.syms.includes(sym)) it.syms.push(sym); return; }
    const [score, shock] = scoreTitle(sym, title); this.items.set(key, { t: ts, title, src, link, syms: [sym], score, shock, llm: false });
  }
  async refresh() {
    if (this._busy) return; this._busy = true;
    try {
      for (const sym of SYMS) {
        try { const xml = await http(`https://news.google.com/rss/search?q=${encodeURIComponent(QUERY[sym] + " when:2d")}&hl=en-US&gl=US&ceid=US:en`), doc = new DOMParser().parseFromString(xml, "text/xml");
          doc.querySelectorAll("item").forEach((it) => { let title = (it.querySelector("title") || {}).textContent || "", src = (it.querySelector("source") || {}).textContent || ""; if (src && title.endsWith(" - " + src)) title = title.slice(0, -src.length - 3); const ts = Date.parse((it.querySelector("pubDate") || {}).textContent || "") / 1000; this.add(sym, title.trim(), src || "Google News", (it.querySelector("link") || {}).textContent || "", ts); });
          delete this.status.err[sym]; } catch (e) { this.status.err[sym] = String(e.message || e).slice(0, 60); }
      }
      const fk = (this.keys() || {}).finnhub;
      if (fk) for (const cat of ["general", "crypto", "forex"]) { try { const j = JSON.parse(await http(`https://finnhub.io/api/v1/news?category=${cat}&token=${encodeURIComponent(fk)}`)); for (const x of j.slice(0, 60)) { const low = (x.headline || "").toLowerCase(); for (const sym of SYMS) { const g = GENERIC[sym] || (sym === "XAUUSDT" ? ["gold", "xau"] : sym === "XAGUSDT" ? ["silver", "xag"] : ["euro", "ecb", "eur/usd"]); if (g.some((w) => low.includes(w))) this.add(sym, x.headline, x.source || "Finnhub", x.url || "", +x.datetime); } } delete this.status.err.finnhub; } catch (e) { this.status.err.finnhub = String(e.message || e).slice(0, 60); } }
      const now = Date.now() / 1000; for (const [k, v] of this.items) if (now - v.t > 3 * 86400) this.items.delete(k);
      this.status.last = now; this.status.n = this.items.size; await this.llmPass();
    } finally { this._busy = false; }
  }
  async llmPass() {
    const ks = this.keys() || {}; if (!LLMS.some((p) => ks[p])) { this.status.llm = ""; return; } if (Date.now() < this._next) return;
    const todo = [...this.items.values()].filter((v) => !v.llm && Date.now() / 1000 - v.t < 6 * 3600).sort((a, b) => b.t - a.t).slice(0, 10); if (!todo.length) return; this._next = Date.now() + 15 * 60000;
    const prompt = `Her haber başlığı için ilgili varlığın kısa vadeli (birkaç saat) fiyatına etkisini puanla. Yalnızca JSON dizisi döndür: [{"i":0,"score":-1..1,"shock":true/false}, ...]. score pozitif=yükseliş yönlü, negatif=düşüş yönlü, belirsizse 0. shock=piyasayı ani oynatabilecek büyük olay mı.\n` + todo.map((v, i) => `${i}. [${v.syms.join(",")}] ${v.title}`).join("\n");
    try { const [txt, prov] = await llmAny(ks, prompt), m = txt.match(/\[[\s\S]*\]/); for (const o of JSON.parse(m[0])) { const v = todo[+o.i]; if (v) { v.score = Math.max(-1, Math.min(1, +o.score)); v.shock = !!(o.shock === undefined ? v.shock : o.shock); v.llm = true; } } this.status.llm = "ok"; this.status.prov = prov; } catch (e) { this.status.llm = String(e.message || e).slice(0, 70); this._next = Date.now() + 25 * 60000; }
  }
  summary(sym) {
    const now = Date.now() / 1000, its = [...this.items.values()].filter((v) => v.syms.includes(sym) && now - v.t < 86400).sort((a, b) => b.t - a.t);
    if (!its.length) return { sym, n: 0, score: 0, conf: 0, shock: false, top: [] };
    let sw = 0, ws = 0; for (const v of its) { const w = Math.pow(0.5, (now - v.t) / 3600 / 3); sw += w * v.score; ws += w; }
    const score = sw / (ws + 1.5), shock = its.some((v) => v.shock && now - v.t < 7200), top = its.slice(0, 30).sort((a, b) => Math.abs(b.score) * Math.pow(0.5, (now - b.t) / 10800) - Math.abs(a.score) * Math.pow(0.5, (now - a.t) / 10800)).slice(0, 4);
    return { sym, n: its.length, score: Math.max(-1, Math.min(1, score * 1.6)), conf: Math.min(1, ws / 4), shock, top: top.map((v) => ({ title: v.title, score: v.score, age_min: Math.floor((now - v.t) / 60), src: v.src, shock: v.shock })) };
  }
  feed(limit = 60) { const now = Date.now() / 1000; return [...this.items.values()].sort((a, b) => b.t - a.t).slice(0, limit).map((v) => ({ title: v.title, src: v.src, link: v.link, syms: v.syms, score: v.score, shock: v.shock, age_min: Math.floor((now - v.t) / 60), llm: v.llm })); }
}

/* ---- yapay zekâ sağlayıcıları (model adı sağlayıcının kendi listesinden bulunur) */
const MODEL = {}, MODS = {}, LAST = {}, COOL = {}, QUEUE = {}, BAD = ["whisper", "guard", "tts", "playai", "embed", "moderation", "image", "vision-preview", "orpheus", "safeguard"];
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function models(prov, key) {
  if (prov === "gemini") { const j = JSON.parse(await http("https://generativelanguage.googleapis.com/v1beta/models?pageSize=200&key=" + encodeURIComponent(key))), names = (j.models || []).filter((m) => (m.supportedGenerationMethods || []).includes("generateContent")).map((m) => m.name.split("/").pop());
    const good = names.filter((n) => n.includes("flash") && !["preview", "exp", "image", "tts", "thinking", "live", "audio", "8b", "robotics", "computer"].some((b) => n.includes(b))).sort((a, b) => (a.includes("2.5-flash") && !a.includes("lite") ? 0 : a.includes("2.5-flash-lite") ? 1 : a.includes("2.0-flash") ? 2 : 3) - (b.includes("2.5-flash") && !b.includes("lite") ? 0 : b.includes("2.5-flash-lite") ? 1 : b.includes("2.0-flash") ? 2 : 3) || (a < b ? -1 : 1));
    return good.concat(names.filter((n) => !good.includes(n) && !BAD.some((b) => n.includes(b)) && !n.includes("embedding"))); }
  const url = { groq: "https://api.groq.com/openai/v1/models", openrouter: "https://openrouter.ai/api/v1/models", mistral: "https://api.mistral.ai/v1/models" }[prov], j = JSON.parse(await http(url, { headers: { Authorization: "Bearer " + key } }));
  let ids = (j.data || []).map((m) => m.id).filter((i) => !BAD.some((b) => i.toLowerCase().includes(b)));
  if (prov === "openrouter") { ids = ids.filter((i) => i.endsWith(":free")); const r = (s) => (["code", "preview", "lfm", "liquid", "dots", "vl-"].some((w) => s.includes(w)) ? 2 : ["llama", "gemma", "qwen", "gpt-oss", "mistral"].some((w) => s.includes(w)) ? 0 : 1); ids.sort((a, b) => r(a) - r(b) || (a < b ? -1 : 1)); }
  else if (prov === "groq") { const r = (s) => (s.includes("llama-3.3-70b") ? 0 : s.includes("gpt-oss") ? 1 : s.includes("llama-3.1") ? 2 : 3); ids.sort((a, b) => r(a) - r(b) || (a < b ? -1 : 1)); }
  else { const r = (s) => (s === "mistral-small-latest" ? 0 : s.includes("small") ? 1 : s.includes("open-mistral") ? 2 : 3); ids.sort((a, b) => r(a) - r(b) || (a < b ? -1 : 1)); }
  return ids;
}
async function gen(prov, key, model, prompt) {
  if (prov === "gemini") { const j = JSON.parse(await http(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(key)}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }], generationConfig: { temperature: 0.3, maxOutputTokens: 900 } }) })); return j.candidates[0].content.parts[0].text; }
  const url = { groq: "https://api.groq.com/openai/v1/chat/completions", openrouter: "https://openrouter.ai/api/v1/chat/completions", mistral: "https://api.mistral.ai/v1/chat/completions" }[prov];
  const j = JSON.parse(await http(url, { method: "POST", headers: { "Content-Type": "application/json", Authorization: "Bearer " + key }, body: JSON.stringify({ model, messages: [{ role: "user", content: prompt }], temperature: 0.3, max_tokens: 900 }) })); return j.choices[0].message.content;
}
async function ask1(prov, key, prompt) {
  const wait = 1400 - (Date.now() - (LAST[prov] || 0)); if (wait > 0) await sleep(wait);
  try {
    let err = null;
    for (let at = 0; at < 7; at++) {
      let mdl = MODEL[prov]; if (!mdl) { const ms = await models(prov, key); if (!ms.length) throw new Error("model listesi boş"); MODS[prov] = ms; MODEL[prov] = mdl = ms[0]; }
      try { return await gen(prov, key, mdl, prompt); }
      catch (e) { err = e; const s = String(e.message || e);
        if (s.includes("HTTP 429")) { COOL[prov + mdl] = Date.now() + 120000; const nxt = (MODS[prov] || []).find((m) => (COOL[prov + m] || 0) < Date.now()); if (nxt && at < 5) { MODEL[prov] = nxt; await sleep(800); continue; } throw new Error("HTTP 429: ücretsiz kota/hız sınırı doldu (birkaç dakika sonra yeniden denenir)"); }
        if (/HTTP (404|400|403)/.test(s)) { const ms = MODS[prov] || [], i = ms.indexOf(mdl); if (i >= 0 && i + 1 < ms.length) { MODEL[prov] = ms[i + 1]; continue; } }
        throw e; }
    }
    throw err;
  } finally { LAST[prov] = Date.now(); }
}
const ask = (prov, key, prompt) => { const q = (QUEUE[prov] || Promise.resolve()).then(() => ask1(prov, key, prompt)); QUEUE[prov] = q.catch(() => {}); return q; };       // aynı sağlayıcıya istekler sırayla
export async function llmAny(keys, prompt, only) {
  let order = LLMS.includes(only) ? [only] : [...LLMS]; const pick = only ? null : keys._prov; if (LLMS.includes(pick)) order = [pick, ...order.filter((p) => p !== pick)];
  let err = null; for (const p of order) { if (!keys[p]) continue; try { return [await ask(p, keys[p], prompt), p]; } catch (e) { err = new Error(`${p}: ${e.message || e}`); } }
  throw err || new Error("Hiçbir LLM anahtarı girilmemiş");
}
