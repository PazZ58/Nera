/* DayTrader Pro (mobil) · ICT / fiyat hareketi / likidite analizi: pro/pro_smc.py'nin JavaScript karşılığı. */
const L_PIV = 4, R_PIV = 4;
const mean = (a) => a.reduce((s, x) => s + x, 0) / a.length;
const maxs = (a, s, e) => { let m = -Infinity; for (let i = s; i < e; i++) if (a[i] > m) m = a[i]; return m; };
const mins = (a, s, e) => { let m = Infinity; for (let i = s; i < e; i++) if (a[i] < m) m = a[i]; return m; };
const anyGt = (a, s, v) => { for (let i = s; i < a.length; i++) if (a[i] > v) return true; return false; };
const anyLt = (a, s, v) => { for (let i = s; i < a.length; i++) if (a[i] < v) return true; return false; };

export function killZone(tsSec) {
  const h = new Date(tsSec * 1000).getUTCHours();
  if (h >= 7 && h < 10) return "Londra kill zone";
  if (h >= 12 && h < 15) return "New York kill zone";
  if (h >= 1 && h < 5) return "Asya seansı";
  return "";
}

function pivotsArr(h, l) {
  const n = h.length, ph = new Array(n).fill(false), pl = new Array(n).fill(false);
  for (let j = L_PIV; j < n - R_PIV; j++) {
    if (h[j] > maxs(h, j - L_PIV, j) && h[j] >= maxs(h, j + 1, j + R_PIV + 1)) ph[j] = true;
    if (l[j] < mins(l, j - L_PIV, j) && l[j] <= mins(l, j + 1, j + R_PIV + 1)) pl[j] = true;
  }
  return [ph, pl];
}

export function analyze(dFull, tf = "1h", nKeep = 600) {
  const N0 = dFull.close.length, s0 = Math.max(0, N0 - nKeep), n = N0 - s0;
  const sl_ = (a) => a.slice(s0);
  const o = sl_(dFull.open), h = sl_(dFull.high), l = sl_(dFull.low), c = sl_(dFull.close), atr = sl_(dFull.atr).map((x) => (x === x ? x : 0)), ts = sl_(dFull.ts);
  const vol = sl_(dFull.volume), rsiA = sl_(dFull.rsi), cvdA = sl_(dFull.cvd);
  const aLast = atr[n - 1] > 0 ? atr[n - 1] : mean(h.map((x, i) => x - l[i]));
  const out = { n, atr: aLast, price: c[n - 1], t: ts[n - 1] };
  const [ph, pl] = pivotsArr(h, l);
  // ---- piyasa yapısı: BOS / CHoCH
  let sh = null, sl = null, trend = 0, lastHi = null, lastLo = null;
  const swings = [], events = [], obs = [];
  for (let i = 0; i < n; i++) {
    const j = i - R_PIV;
    if (j >= L_PIV) {
      if (ph[j]) { const lab = lastHi === null ? "" : h[j] > lastHi ? "HH" : "LH"; swings.push({ i: j, t: ts[j], p: h[j], k: "H", lab }); sh = [j, h[j], false]; lastHi = h[j]; }
      if (pl[j]) { const lab = lastLo === null ? "" : l[j] > lastLo ? "HL" : "LL"; swings.push({ i: j, t: ts[j], p: l[j], k: "L", lab }); sl = [j, l[j], false]; lastLo = l[j]; }
    }
    if (sh && !sh[2] && c[i] > sh[1] && i > sh[0] + 1) {
      const typ = trend === -1 ? "CHoCH" : "BOS";
      events.push({ i, t: ts[i], type: typ, dir: 1, level: sh[1], from_t: ts[sh[0]] });
      sh[2] = true; trend = 1;
      const k0 = Math.max((sl ? sl[0] : i - 15) - 2, i - 30, 0);
      for (let k = i - 1; k >= k0; k--) if (c[k] < o[k]) { obs.push({ dir: 1, lo: l[k], hi: h[k], i: k, t: ts[k], ev: typ }); break; }
    }
    if (sl && !sl[2] && c[i] < sl[1] && i > sl[0] + 1) {
      const typ = trend === 1 ? "CHoCH" : "BOS";
      events.push({ i, t: ts[i], type: typ, dir: -1, level: sl[1], from_t: ts[sl[0]] });
      sl[2] = true; trend = -1;
      const k0 = Math.max((sh ? sh[0] : i - 15) - 2, i - 30, 0);
      for (let k = i - 1; k >= k0; k--) if (c[k] > o[k]) { obs.push({ dir: -1, lo: l[k], hi: h[k], i: k, t: ts[k], ev: typ }); break; }
    }
  }
  out.struct = trend; out.swings = swings.slice(-24); out.events = events.slice(-8);
  // ---- order block (kapanışla delinmemiş)
  const obl = [];
  for (const ob of obs) {
    const m = ob.i + 1; let broken = false, touched = false;
    for (let k = m; k < n; k++) {
      if (ob.dir === 1) { if (c[k] < ob.lo) broken = true; if (l[k] <= ob.hi) touched = true; } else { if (c[k] > ob.hi) broken = true; if (h[k] >= ob.lo) touched = true; }
    }
    if (broken || n - ob.i > 250) continue;
    ob.fresh = !touched; ob.inside = ob.lo <= c[n - 1] && c[n - 1] <= ob.hi; obl.push(ob);
  }
  out.obs = obl.slice(-6);
  // ---- FVG
  const fv = [];
  for (let i = 2; i < n; i++) {
    const a = Math.max(0.15 * atr[i], 1e-12); let lo_, hi_, dr;
    if (l[i] > h[i - 2] && l[i] - h[i - 2] >= a) { lo_ = h[i - 2]; hi_ = l[i]; dr = 1; }
    else if (h[i] < l[i - 2] && l[i - 2] - h[i] >= a) { lo_ = h[i]; hi_ = l[i - 2]; dr = -1; }
    else continue;
    if (n - i > 160) continue;
    if (dr === 1) {
      const m = i + 1 < n ? mins(l, i + 1, n) : hi_; if (m <= lo_) continue;
      fv.push({ dir: 1, lo: lo_, hi: Math.min(hi_, m), i, t: ts[i - 1], tested: m < hi_ });
    } else {
      const m = i + 1 < n ? maxs(h, i + 1, n) : lo_; if (m >= hi_) continue;
      fv.push({ dir: -1, lo: Math.max(lo_, m), hi: hi_, i, t: ts[i - 1], tested: m > lo_ });
    }
  }
  out.fvgs = fv.slice(-8);
  // ---- likidite
  const tol = Math.max(0.12 * aLast, c[n - 1] * 0.0003), liq = [];
  for (const [kind, arr, name, side] of [["H", h, "EQH", "buy"], ["L", l, "EQL", "sell"]]) {
    const pts = swings.filter((s) => s.k === kind).slice(-14), used = new Set();
    pts.forEach((s, ai) => {
      if (used.has(ai)) return;
      const grp = pts.filter((b) => Math.abs(b.p - s.p) <= tol);
      if (grp.length >= 2) {
        pts.forEach((b, bi) => { if (Math.abs(b.p - s.p) <= tol) used.add(bi); });
        const lvl = mean(grp.map((g) => g.p)), tLast = Math.max(...grp.map((g) => g.i));
        const swept = kind === "H" ? anyGt(arr, tLast + 1, lvl + tol) : anyLt(arr, tLast + 1, lvl - tol);
        liq.push({ p: lvl, k: name, side, n: grp.length, swept, t: ts[Math.min(...grp.map((g) => g.i))] });
      }
    });
  }
  for (const s of swings.slice(-10)) {
    const swept = s.k === "H" ? anyGt(h, s.i + 1, s.p) : anyLt(l, s.i + 1, s.p);
    if (!swept && !liq.some((x) => Math.abs(x.p - s.p) <= tol)) liq.push({ p: s.p, k: s.k === "H" ? "SwH" : "SwL", side: s.k === "H" ? "buy" : "sell", n: 1, swept: false, t: s.t });
  }
  const dayOf = ts.map((t) => Math.floor(t / 86400)), days = [...new Set(dayOf)];       // artan sırada
  const gd = days.map((dd) => { let hi = -Infinity, lo = Infinity; dayOf.forEach((x, i) => { if (x === dd) { hi = Math.max(hi, h[i]); lo = Math.min(lo, l[i]); } }); return { hi, lo }; });
  if (gd.length >= 2) {
    const pdh = gd[gd.length - 2].hi, pdl = gd[gd.length - 2].lo;
    liq.push({ p: pdh, k: "PDH", side: "buy", n: 1, swept: false, t: ts[0] }, { p: pdl, k: "PDL", side: "sell", n: 1, swept: false, t: ts[0] });
    out.pd_levels = { PDH: pdh, PDL: pdl, today_hi: gd[gd.length - 1].hi, today_lo: gd[gd.length - 1].lo };
  }
  const wkOf = dayOf.map((dd) => dd - ((dd + 3) % 7)), wks = [...new Set(wkOf)];
  const gw = wks.map((w) => { let hi = -Infinity, lo = Infinity; wkOf.forEach((x, i) => { if (x === w) { hi = Math.max(hi, h[i]); lo = Math.min(lo, l[i]); } }); return { hi, lo }; });
  if (gw.length >= 2) liq.push({ p: gw[gw.length - 2].hi, k: "PWH", side: "buy", n: 1, swept: false, t: ts[0] }, { p: gw[gw.length - 2].lo, k: "PWL", side: "sell", n: 1, swept: false, t: ts[0] });
  const asiaIdx = ts.map((t, i) => i).filter((i) => { const hh = new Date(ts[i] * 1000).getUTCHours(); return hh >= 0 && hh < 7; });
  if (asiaIdx.length) {
    const ad = dayOf[asiaIdx[asiaIdx.length - 1]], ar = asiaIdx.filter((i) => dayOf[i] === ad);
    liq.push({ p: Math.max(...ar.map((i) => h[i])), k: "AsyaH", side: "buy", n: 1, swept: false, t: ts[0] }, { p: Math.min(...ar.map((i) => l[i])), k: "AsyaL", side: "sell", n: 1, swept: false, t: ts[0] });
  }
  out.liq = liq;
  // ---- süpürmeler (son 6 mum)
  const sweeps = [];
  for (const q of liq) for (let i = Math.max(n - 6, 1); i < n; i++) {
    if (q.side === "buy" && h[i] > q.p && c[i] < q.p && maxs(h, Math.max(i - 30, 0), i) <= q.p + tol) sweeps.push({ i, t: ts[i], dir: -1, level: q.p, k: q.k, wick: h[i] - Math.max(o[i], c[i]), ext: h[i] });
    if (q.side === "sell" && l[i] < q.p && c[i] > q.p && mins(l, Math.max(i - 30, 0), i) >= q.p - tol) sweeps.push({ i, t: ts[i], dir: 1, level: q.p, k: q.k, wick: Math.min(o[i], c[i]) - l[i], ext: l[i] });
  }
  out.sweeps = sweeps.slice(-4);
  // ---- premium / discount + OTE
  const hs = swings.filter((s) => s.k === "H"), ls = swings.filter((s) => s.k === "L"); let pdz = null;
  if (hs.length && ls.length) {
    const top = hs[hs.length - 1].p, bot = ls[ls.length - 1].p;
    if (top > bot && top - bot >= 1.5 * aLast) {
      const eq = (top + bot) / 2, rng = top - bot, upLeg = ls[ls.length - 1].i < hs[hs.length - 1].i;
      const ote = upLeg ? [top - 0.79 * rng, top - 0.62 * rng] : [bot + 0.62 * rng, bot + 0.79 * rng];
      pdz = { hi: top, lo: bot, eq, zone: c[n - 1] > eq ? "premium" : "discount", up_leg: upLeg, ote, pos: (c[n - 1] - bot) / rng };
      const lv = {}; for (const r of [0.382, 0.5, 0.618, 0.786]) lv[String(r)] = upLeg ? top - r * rng : bot + r * rng;
      out.fib = { leg: upLeg ? "up" : "down", hi: top, lo: bot, lv };
    }
  }
  out.pd = pdz; out.kz = killZone(ts[n - 1]);
  // ---- mum formasyonları
  const body = c.map((x, i) => Math.abs(x - o[i])), rng_ = h.map((x, i) => Math.max(x - l[i], 1e-12)), pats = [], i = n - 1;
  const uw = h[i] - Math.max(o[i], c[i]), lw = Math.min(o[i], c[i]) - l[i];
  if (lw >= 0.6 * rng_[i] && body[i] <= 0.3 * rng_[i]) pats.push({ k: "Pin bar (boğa)", dir: 1 });
  if (uw >= 0.6 * rng_[i] && body[i] <= 0.3 * rng_[i]) pats.push({ k: "Pin bar (ayı)", dir: -1 });
  if (i >= 1) {
    if (c[i - 1] < o[i - 1] && c[i] > o[i] && o[i] <= c[i - 1] && c[i] >= o[i - 1] && body[i] >= 0.5 * aLast) pats.push({ k: "Yutan mum (boğa)", dir: 1 });
    if (c[i - 1] > o[i - 1] && c[i] < o[i] && o[i] >= c[i - 1] && c[i] <= o[i - 1] && body[i] >= 0.5 * aLast) pats.push({ k: "Yutan mum (ayı)", dir: -1 });
    if (h[i] < h[i - 1] && l[i] > l[i - 1]) pats.push({ k: "Inside bar", dir: 0 });
  }
  if (i >= 2) {
    if (c[i - 2] < o[i - 2] && body[i - 1] <= 0.3 * Math.max(body[i - 2], 1e-12) && c[i] > o[i] && c[i] > (o[i - 2] + c[i - 2]) / 2) pats.push({ k: "Sabah yıldızı", dir: 1 });
    if (c[i - 2] > o[i - 2] && body[i - 1] <= 0.3 * Math.max(body[i - 2], 1e-12) && c[i] < o[i] && c[i] < (o[i - 2] + c[i - 2]) / 2) pats.push({ k: "Akşam yıldızı", dir: -1 });
  }
  if (body[i] <= 0.1 * rng_[i]) pats.push({ k: "Doji", dir: 0 });
  out.patterns = pats;
  // ---- destek / direnç kümeleri (tüm swingler)
  const allp = swings.map((s) => s.p), sr = [], tol2 = 0.3 * aLast, seen = new Set();
  allp.forEach((p, ai) => {
    if (seen.has(ai)) return;
    const grp = []; allp.forEach((q, j) => { if (Math.abs(q - p) <= tol2) grp.push(j); });
    if (grp.length >= 2) { grp.forEach((j) => seen.add(j)); const lvl = mean(grp.map((j) => allp[j])); if (Math.abs(lvl - c[n - 1]) <= 8 * aLast) sr.push({ p: lvl, n: grp.length, k: lvl > c[n - 1] ? "direnç" : "destek" }); }
  });
  out.sr = sr.sort((a, b) => Math.abs(a.p - c[n - 1]) - Math.abs(b.p - c[n - 1])).slice(0, 8);
  // ---- hacim profili (son 200 mum, 32 kutu; numpy.histogram anlamı)
  const W = Math.min(200, n), tp = h.map((x, k) => (x + l[k] + c[k]) / 3).slice(-W), vv = vol.slice(-W);
  if (vv.reduce((s, x) => s + x, 0) > 0) {
    let mn = Math.min(...tp), mx = Math.max(...tp); if (mn === mx) { mn -= 0.5; mx += 0.5; }
    const edges = Array.from({ length: 33 }, (_, k) => mn + ((mx - mn) * k) / 32), hist = new Array(32).fill(0);
    tp.forEach((x, k) => { let b = Math.floor(((x - mn) / (mx - mn)) * 32); if (b >= 32) b = 31; if (b < 0) b = 0; hist[b] += vv[k]; });
    let kk = 0; hist.forEach((x, k) => { if (x > hist[kk]) kk = k; });
    let loI = kk, hiI = kk, acc = hist[kk]; const tot = hist.reduce((s, x) => s + x, 0);
    while (acc < 0.7 * tot && (loI > 0 || hiI < 31)) {
      const up = hiI < 31 ? hist[hiI + 1] : -1, dn = loI > 0 ? hist[loI - 1] : -1;
      if (up >= dn) { hiI++; acc += hist[hiI]; } else { loI--; acc += hist[loI]; }
    }
    const meanV = tot / 32;
    out.vp = { poc: (edges[kk] + edges[kk + 1]) / 2, vah: edges[hiI + 1], val: edges[loI], bins: hist.map((x, k) => ({ lo: edges[k], hi: edges[k + 1], v: x })),
      hvn: hist.map((x, k) => (x > 1.4 * meanV ? (edges[k] + edges[k + 1]) / 2 : null)).filter((x) => x !== null), lvn: hist.map((x, k) => (k >= 1 && k < 31 && x < 0.45 * meanV ? (edges[k] + edges[k + 1]) / 2 : null)).filter((x) => x !== null) };
  }
  // ---- uyumsuzluk (RSI ve CVD)
  const div = [];
  for (const kind of ["L", "H"]) {
    const pts = swings.filter((s) => s.k === kind).slice(-2);
    if (pts.length === 2 && n - pts[1].i <= 40) {
      const [a, b] = pts;
      if (kind === "L" && b.p < a.p) { if (rsiA[b.i] > rsiA[a.i] + 2) div.push({ k: "RSI boğa uyumsuzluğu", dir: 1 }); if (cvdA[b.i] > cvdA[a.i]) div.push({ k: "CVD boğa uyumsuzluğu", dir: 1 }); }
      if (kind === "H" && b.p > a.p) { if (rsiA[b.i] < rsiA[a.i] - 2) div.push({ k: "RSI ayı uyumsuzluğu", dir: -1 }); if (cvdA[b.i] < cvdA[a.i]) div.push({ k: "CVD ayı uyumsuzluğu", dir: -1 }); }
    }
  }
  out.div = div;
  return out;
}
