/* DayTrader Pro (mobil) · pandas benzeri dizi yardımcıları. NaN = eksik. Python sürümüyle birebir sonuç vermesi hedeflenir (bkz. mobil/test). */
export const NaNv = NaN;
export const isn = (x) => x === x && x !== Infinity && x !== -Infinity;
export const zeros = (n, v = 0) => new Array(n).fill(v);
export const nans = (n) => new Array(n).fill(NaN);
export const map2 = (a, b, f) => a.map((x, i) => f(x, b[i], i));
export const add = (a, b) => (typeof b === "number" ? a.map((x) => x + b) : map2(a, b, (x, y) => x + y));
export const sub = (a, b) => (typeof b === "number" ? a.map((x) => x - b) : map2(a, b, (x, y) => x - y));
export const mul = (a, b) => (typeof b === "number" ? a.map((x) => x * b) : map2(a, b, (x, y) => x * y));
export const div = (a, b) => (typeof b === "number" ? a.map((x) => x / b) : map2(a, b, (x, y) => (y === 0 ? NaN : x / y)));   // pandas: 0'a bölme -> inf; burada replace(0,nan) ile aynı davranış istenen yerlerde kullanılır
export const divRaw = (a, b) => map2(a, b, (x, y) => x / y);
export const abs = (a) => a.map(Math.abs);
export const clip = (a, lo, hi) => a.map((x) => (x !== x ? x : Math.min(hi, Math.max(lo, x))));
export const fillna = (a, v) => a.map((x) => (x !== x ? v : x));
export const shift = (a, k) => { const n = a.length, o = nans(n); for (let i = k; i < n; i++) o[i] = a[i - k]; return o; };
export const diff = (a) => map2(a, shift(a, 1), (x, y) => x - y);
export const sign = (a) => a.map((x) => (x !== x ? NaN : x > 0 ? 1 : x < 0 ? -1 : 0));

/** ewm(alpha, adjust=False): ilk geçerli değerden başlar, NaN girdide önceki değer taşınır */
export function ewmAlpha(x, alpha) {
  const n = x.length, o = nans(n); let p = NaN;
  for (let i = 0; i < n; i++) { const v = x[i]; if (v === v) { p = p === p ? alpha * v + (1 - alpha) * p : v; } o[i] = p; }
  return o;
}
export const ewmSpan = (x, span) => ewmAlpha(x, 2 / (span + 1));
export const wilder = (x, n) => ewmAlpha(x, 1 / n);

function rolling(x, w, f) {
  const n = x.length, o = nans(n);
  for (let i = w - 1; i < n; i++) {
    let bad = false; for (let j = i - w + 1; j <= i; j++) if (x[j] !== x[j]) { bad = true; break; }
    if (!bad) o[i] = f(x, i - w + 1, i);
  }
  return o;
}
export const rollMax = (x, w) => rolling(x, w, (a, s, e) => { let m = -Infinity; for (let j = s; j <= e; j++) if (a[j] > m) m = a[j]; return m; });
export const rollMin = (x, w) => rolling(x, w, (a, s, e) => { let m = Infinity; for (let j = s; j <= e; j++) if (a[j] < m) m = a[j]; return m; });
export const rollSum = (x, w) => rolling(x, w, (a, s, e) => { let t = 0; for (let j = s; j <= e; j++) t += a[j]; return t; });
export const rollMean = (x, w) => rolling(x, w, (a, s, e) => { let t = 0; for (let j = s; j <= e; j++) t += a[j]; return t / (e - s + 1); });
export const rollStd = (x, w) => rolling(x, w, (a, s, e) => { const k = e - s + 1; let t = 0; for (let j = s; j <= e; j++) t += a[j]; const m = t / k; let q = 0; for (let j = s; j <= e; j++) q += (a[j] - m) ** 2; return Math.sqrt(q / (k - 1)); });
export const rollArgMax = (x, w) => rolling(x, w, (a, s, e) => { let m = -Infinity, k = 0; for (let j = s; j <= e; j++) if (a[j] > m) { m = a[j]; k = j - s; } return k; });
export const rollArgMin = (x, w) => rolling(x, w, (a, s, e) => { let m = Infinity, k = 0; for (let j = s; j <= e; j++) if (a[j] < m) { m = a[j]; k = j - s; } return k; });
export const rollMad = (x, w) => rolling(x, w, (a, s, e) => { const k = e - s + 1; let t = 0; for (let j = s; j <= e; j++) t += a[j]; const m = t / k; let q = 0; for (let j = s; j <= e; j++) q += Math.abs(a[j] - m); return q / k; });
export const cumsum = (x) => { let t = 0; return x.map((v) => (v === v ? (t += v) : t)); };
export const maxOf = (...as) => as[0].map((_, i) => { let m = NaN; for (const a of as) { const v = a[i]; if (v === v && (m !== m || v > m)) m = v; } return m; });
export const meanOf = (x) => { let t = 0, k = 0; for (const v of x) if (v === v) { t += v; k++; } return k ? t / k : NaN; };
export const last = (a) => a[a.length - 1];
