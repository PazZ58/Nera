﻿/* Nera · MOBİL kabuk: telefonda uygulama gibi görünüm. app.js yüklendikten SONRA çalışır; masaüstü arayüzün DOM parçalarını (grafik, paneller, sekmeler)
   yeni kabuğa taşır: üst çubuk (sembol/aralık), alt gezinme, kayar alt panel (bottom sheet), modallar. Veri/analiz mantığı app.js'tedir (değişmez). */
(function () {
  if (!window.matchMedia("(max-width: 900px)").matches) return;
  const B = document.body; B.classList.add("m");
  const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const E = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html !== undefined) e.innerHTML = html; return e; };
  const haptic = (ms = 8) => { try { navigator.vibrate && navigator.vibrate(ms); } catch (e) { /* yok */ } };
  const ICON = {
    chart: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 4v3M6 13v5M6 7h0M4 7h4v6H4zM12 3v4M12 15v6M10 7h4v8h-4zM18 6v3M18 16v3M16 9h4v7h-4z"/></svg>',
    sig: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.2" fill="currentColor"/></svg>',
    analiz: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/></svg>',
    flow: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 8c3-4 5 4 9 0s6 4 9 0M3 15c3-4 5 4 9 0s6 4 9 0"/></svg>',
    syn: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M12 3v6M12 15v6M4.2 7.5l5.2 3M14.6 13.5l5.2 3M19.8 7.5l-5.2 3M9.4 13.5l-5.2 3"/><circle cx="12" cy="3" r="1.2"/><circle cx="12" cy="21" r="1.2"/></svg>',
    bolt: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M13.4 2 5.5 12.9h5.1L8.6 22l9.9-11.6H13L15.6 2z"/></svg>',
    menu: '<svg viewBox="0 0 24 24" fill="currentColor"><circle cx="5" cy="12" r="1.9"/><circle cx="12" cy="12" r="1.9"/><circle cx="19" cy="12" r="1.9"/></svg>',
    layers: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="m12 3 9 5-9 5-9-5zM3 13l9 5 9-5"/></svg>',
    panes: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 14h18M7 11l2-2 3 2 4-3"/></svg>',
    chev: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="m6 15 6-6 6 6"/></svg>',
    down: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>',
  };

  /* ---------- kabuk ---------- */
  const root = E("div"); root.id = "mroot";
  root.innerHTML = `
    <header id="mtop">
      <button class="m-sym rip" id="msym"><span class="n"><span id="msymn">—</span>${ICON.down}</span><span class="p"><b id="mprice">—</b><i id="mchg"></i></span></button>
      <div class="m-tfs" id="mtfs"></div>
      <button class="m-icon" id="mbell" aria-label="Sinaps geçmişi">${ICON.syn}<span class="badge hidden" id="mbadge">0</span></button>
      <button class="m-icon rip" id="mmenu" aria-label="Menü">${ICON.menu}</button>
    </header>
    <div id="mstrip"><span class="dot" id="mdot"></span><span id="mstat">Başlatılıyor</span></div>
    <main id="mchart"><div class="m-fabs"><button class="m-fab rip" id="fab-layers" aria-label="Katmanlar">${ICON.layers}</button><button class="m-fab rip" id="fab-panes" aria-label="Alt paneller">${ICON.panes}</button></div><div id="mpanes"></div></main>
    <section id="sheet">
      <div class="grab"><i></i></div>
      <div id="peek"><span class="pill W" id="pk-pill">BEKLE</span><div class="pk"><div class="a" id="pk-a">Analiz hazırlanıyor…</div><div class="b" id="pk-b"></div></div><span class="chev">${ICON.chev}</span></div>
      <div id="shead"><div id="stitle">Sinyal</div><div class="seg hidden" id="seg"><span class="blob"></span><button data-k="agents" class="on">Ajanlar</button><button data-k="ind">Göstergeler</button></div></div>
      <div id="sbody"></div>
    </section>
    <nav id="mnav"><span class="blob"></span>
      <button data-k="chart" class="on rip">${ICON.chart}<span>Grafik</span></button>
      <button data-k="sig" class="rip">${ICON.sig}<span>Sinyal</span></button>
      <button data-k="analiz" class="rip">${ICON.analiz}<span>Analiz</span></button>
      <button data-k="flow" class="rip">${ICON.flow}<span>Akış</span></button>
      <button data-k="hist">${ICON.syn}<span>Sinaps</span><span class="badge hidden" id="nbadge">0</span></button>
    </nav>
    <div id="mmodal"><div class="bd"></div><div class="card2"><div class="grab"><i></i></div><div id="mmbody"></div></div></div>`;
  B.appendChild(root);

  // masaüstü parçalarını yeni kabuğa taşı
  const chartCol = $("#mchart", root), wrap = $("#chart-wrap");
  chartCol.insertBefore(wrap, chartCol.firstChild);
  wrap.appendChild($("#legend"));
  $("#legend").style.position = "absolute";
  const panes = $("#mpanes", root);
  panes.append($("#pane1").previousElementSibling, $("#pane1"), $("#pane2").previousElementSibling, $("#pane2"));
  const sbody = $("#sbody", root);
  ["tab-sig", "tab-agents", "tab-ind", "tab-hist", "tab-cal"].forEach((id) => { const t = $("#" + id); if (t) sbody.appendChild(t); });      // takvim sekmesi kaldırıldı: yoksa atla (eskiden burada hata verip tüm mobil kabuğu durduruyordu)
  const flow = E("div", "tab"); flow.id = "tab-flow";
  flow.append($("#flow-card"), $("#fp-card"), $("#big-card")); sbody.appendChild(flow);
  $("#mstrip", root).insertBefore($("#banner"), $("#mstat"));

  /* ---------- sheet ---------- */
  const sheet = $("#sheet", root);
  const SH = { st: "peek", key: "chart" };
  const usable = () => sheet.offsetHeight;
  const visFor = (st) => (st === "peek" ? 88 : st === "half" ? Math.round(usable() * 0.58) : Math.max(120, usable() - 10));
  // içerik alanı = görünen yükseklik − başlıklar: böylece kaydırınca EN ALTA (ör. "Ne kadar yanılabilir") kadar inilebilir
  function fitBody(st) {
    const vis = visFor(st), used = $(".grab", sheet).offsetHeight + $("#shead", sheet).offsetHeight + (st === "peek" ? $("#peek", sheet).offsetHeight : 0);
    sbody.style.height = Math.max(0, vis - used) + "px";
  }
  function setSheet(st, instant) {
    SH.st = st; sheet.classList.remove("peek", "half", "full"); sheet.classList.add(st);
    const vis = visFor(st);
    sheet.style.setProperty("--vis", vis + "px"); fitBody(st); window.__flowOpen = st !== "peek" && SH.key === "flow";
    B.style.setProperty("--inset", (st === "full" ? Math.round(usable() * 0.3) : vis) + "px");
    if (st !== "peek" && history.state !== "sheet") history.pushState("sheet", "");
    if (instant) { sheet.classList.add("drag"); requestAnimationFrame(() => sheet.classList.remove("drag")); }
    setTimeout(() => window.dispatchEvent(new Event("resize")), 420);
  }
  window.addEventListener("popstate", () => { if (SH.st !== "peek") { setSheet("peek"); markNav("chart"); } });
  // sürükleme
  let drag = null;
  const startDrag = (e) => { if (e.target.closest("button,input,.seg")) return; drag = { y: e.clientY, t: Date.now(), base: usable() - parseFloat(getComputedStyle(sheet).getPropertyValue("--vis")), moved: false }; sheet.classList.add("drag"); try { e.currentTarget.setPointerCapture(e.pointerId); } catch (x) { /* yok */ } };
  const moveDrag = (e) => {
    if (!drag) return; const dy = e.clientY - drag.y; if (Math.abs(dy) > 4) drag.moved = true;
    const y = Math.min(usable() - 70, Math.max(6, drag.base + dy)); sheet.style.transform = `translateY(${y}px)`; drag.y2 = y;
  };
  const endDrag = (e) => {
    if (!drag) return; sheet.classList.remove("drag"); const d = drag; drag = null; sheet.style.transform = "";
    if (!d.moved) { if (SH.st === "peek") mTab("sig"); return; }
    const vis = usable() - (d.y2 ?? d.base), v = (e.clientY - d.y) / Math.max(1, Date.now() - d.t);       // px/ms (aşağı +)
    let target; const pts = [88, visFor("half"), visFor("full")], names = ["peek", "half", "full"];
    if (v > 0.6) target = Math.max(0, names.indexOf(SH.st) - 1); else if (v < -0.6) target = Math.min(2, names.indexOf(SH.st) + 1); else target = pts.reduce((bi, p, i) => (Math.abs(p - vis) < Math.abs(pts[bi] - vis) ? i : bi), 0);
    haptic(6); setSheet(names[target]); if (names[target] === "peek") markNav("chart");
  };
  [$(".grab", sheet), $("#peek", sheet), $("#shead", sheet)].forEach((el) => { el.addEventListener("pointerdown", startDrag); el.addEventListener("pointermove", moveDrag); el.addEventListener("pointerup", endDrag); el.addEventListener("pointercancel", endDrag); });

  /* ---------- sekmeler / gezinme ---------- */
  const _setTab = window.setTab, TITLES = { sig: "Sinyal", agents: "Ajanlar", ind: "Göstergeler", hist: "◉ Sinaps geçmişi", cal: "Makro takvim", flow: "Canlı order flow" };
  let subAnaliz = "agents";
  const blobTo = (container, btn) => { const b = $(".blob", container); if (!b || !btn) return; b.style.left = btn.offsetLeft + "px"; b.style.width = btn.offsetWidth + "px"; };
  function markNav(k) {
    SH.key = k; $$("#mnav button").forEach((b) => b.classList.toggle("on", b.dataset.k === k));
    const btn = $(`#mnav button[data-k="${k}"]`), blob = $("#mnav .blob"); blob.style.opacity = btn ? 1 : 0;
    blobTo($("#mnav"), btn);
  }
  function mTab(key) {
    haptic(8);
    const navKey = key === "agents" || key === "ind" ? "analiz" : key;
    if (key === "chart") { setSheet("peek"); markNav("chart"); if (history.state === "sheet") history.back(); return; }
    let app = key;
    if (key === "analiz") app = subAnaliz; else if (key === "agents" || key === "ind") subAnaliz = key;
    const seg = $("#seg", root); seg.classList.toggle("hidden", !(navKey === "analiz"));
    if (navKey === "analiz") { $$("#seg button").forEach((b) => b.classList.toggle("on", b.dataset.k === subAnaliz)); blobTo(seg, $(`#seg button[data-k="${subAnaliz}"]`)); }
    if (key === "flow") { _setTab("sig"); $$("#sbody .tab").forEach((e) => e.classList.remove("active")); void flow.offsetWidth; flow.classList.add("active"); }
    else _setTab(app);
    $("#stitle").textContent = TITLES[navKey === "analiz" ? subAnaliz : key] || "";
    markNav(navKey);
    setSheet(key === "hist" ? "full" : "half");
    window.__flowOpen = key === "flow";
    sbody.scrollTop = 0;
    if (key === "hist") { S.unseen = 0; badges(); }
  }
  window.setTab = (t) => mTab(t === "agents" || t === "ind" ? t : t);
  $$("#mnav button").forEach((b) => (b.onclick = () => mTab(b.dataset.k)));
  $$("#seg button").forEach((b) => (b.onclick = () => { haptic(6); mTab(b.dataset.k); }));
  $("#peek", root).addEventListener("click", () => {});
  requestAnimationFrame(() => { markNav("chart"); setSheet("peek", true); });
  window.addEventListener("resize", () => { blobTo($("#mnav"), $(`#mnav button[data-k="${SH.key}"]`)); fitBody(SH.st); });

  /* ---------- üst çubuk ---------- */
  const tfs = $("#mtfs", root);
  tfs.innerHTML = TFS.map((t) => `<button data-t="${t}" class="rip">${TF_LABEL[t]}</button>`).join("");
  const pulseSwap = () => { wrap.classList.remove("swap"); void wrap.offsetWidth; wrap.classList.add("swap"); };
  function markTf() { $$("button", tfs).forEach((b) => b.classList.toggle("on", b.dataset.t === S.tf)); const on = $("button.on", tfs); if (on) on.scrollIntoView({ inline: "center", block: "nearest", behavior: "smooth" }); }
  $$("button", tfs).forEach((b) => (b.onclick = () => { haptic(8); setTf(b.dataset.t); pulseSwap(); markTf(); }));
  markTf();
  const _setSym = window.setSym, _setTf = window.setTf;
  window.setSym = (s) => { _setSym(s); pulseSwap(); lastPx = null; topUpdate(); };
  window.setTf = (t) => { _setTf(t); markTf(); };
  let lastPx = null;
  function topUpdate() {
    const w = S.tk && S.tk.watch && S.tk.watch[S.sym]; $("#msymn").textContent = NAMES[S.sym];
    if (w && w.price) {
      const el = $("#mprice"); el.textContent = fp(w.price);
      if (lastPx !== null && w.price !== lastPx) { el.classList.remove("fu", "fd"); void el.offsetWidth; el.classList.add(w.price > lastPx ? "fu" : "fd"); }
      lastPx = w.price;
      const ch = $("#mchg"); ch.textContent = w.chg == null ? "" : (w.chg >= 0 ? "+" : "") + w.chg.toFixed(2) + "%"; ch.className = cls(w.chg);
    }
    const ok = S.tk && S.tk.ws_age != null && S.tk.ws_age < 20; $("#mdot").className = "dot" + (ok ? " ok" : ""); $("#mstat").textContent = ok ? "Canlı" : S.tk ? (S.tk.ready < 28 ? "Yükleniyor " + S.tk.ready : "Akış bekleniyor") : "Bağlanıyor";
  }
  function badges() {
    const n = S.unseen || 0;
    [["mbadge", $("#mbell")], ["nbadge", $('#mnav button[data-k="hist"]')]].forEach(([id, host]) => { const b = $("#" + id); if (b.textContent !== String(n)) { b.textContent = n; if (n) { b.classList.remove("hidden"); b.style.animation = "none"; void b.offsetWidth; b.style.animation = ""; } } b.classList.toggle("hidden", !n); });
  }
  $("#mbell", root).onclick = () => mTab("hist");
  const bellObs = new MutationObserver(() => { const b = $("#btn-hist"); if (b.classList.contains("pulse")) { const m = $("#mbell"); m.classList.remove("pulse"); void m.offsetWidth; m.classList.add("pulse"); haptic([40, 60, 40]); } });
  bellObs.observe($("#btn-hist"), { attributes: true, attributeFilter: ["class"] });

  /* ---------- peek (kapalı panelde görünen özet) ---------- */
  function peekUpdate() {
    const ev = S.ana && S.ana.eval, pill = $("#pk-pill"), a = $("#pk-a"), b = $("#pk-b");
    if (!ev) { pill.className = "pill W"; pill.textContent = "…"; a.textContent = S.reason || "Analiz hazırlanıyor…"; b.textContent = ""; return; }
    const k = ev.state === "LONG" ? "L" : ev.state === "SHORT" ? "S" : "W"; pill.className = "pill " + k; pill.textContent = ev.state === "LONG" ? "LONG ▲" : ev.state === "SHORT" ? "SHORT ▼" : "BEKLE";
    if (ev.state === "BEKLE") { a.textContent = "İşlem sinyali yok"; b.textContent = ev.why_wait[0] || ""; }
    else { const p = ev.plan; a.innerHTML = `<span class="down">Stop −${dist(p.risk)}</span> · <span class="up">Hedef +${dist(Math.abs(p.tp1 - p.entry))}</span>`; b.textContent = `${ev.setup} · ${p.r1.toFixed(1)}R · ${NAMES[S.sym]} ${TF_LABEL[S.tf]}`; }
  }

  /* ---------- modallar ---------- */
  const modal = $("#mmodal", root), mm = $("#mmbody", root);
  let mmDrag = null;
  function openModal(html, after, kind) {
    mm.innerHTML = html; mm.dataset.kind = kind || ""; modal.classList.add("show"); const rows = $$(".m-row", mm); rows.forEach((r, i) => (r.style.animationDelay = 0.05 + i * 0.045 + "s")); if (after) after();
    if (history.state !== "modal") history.pushState("modal", "");
  }
  function closeModal() { modal.classList.remove("show"); if (history.state === "modal") history.back(); }
  $(".bd", modal).onclick = closeModal;
  const card2 = $(".card2", modal);
  card2.addEventListener("pointerdown", (e) => { if (e.target.closest("input,button,.m-row,.m-chip") && !e.target.closest(".grab")) return; mmDrag = { y: e.clientY }; });
  card2.addEventListener("pointermove", (e) => { if (mmDrag && e.clientY > mmDrag.y) card2.style.transform = `translateY(${e.clientY - mmDrag.y}px)`; });
  card2.addEventListener("pointerup", (e) => { if (!mmDrag) return; const d = e.clientY - mmDrag.y; mmDrag = null; card2.style.transform = ""; if (d > 90) closeModal(); });
  window.addEventListener("popstate", () => { if (modal.classList.contains("show") && history.state !== "modal") modal.classList.remove("show"); });

  setInterval(() => {                       // sembol listesi açıkken fiyatlar canlı güncellenir
    if (!modal.classList.contains("show") || mm.dataset.kind !== "symbols") return; const w = (S.tk && S.tk.watch) || {};
    $$(".m-row[data-s]", mm).forEach((r) => { const x = w[r.dataset.s]; if (!x || !x.price) return; const b = $(".r b", r), c = $(".r div", r); b.textContent = fp(x.price, r.dataset.s); c.textContent = x.chg == null ? "" : (x.chg >= 0 ? "+" : "") + x.chg.toFixed(2) + "%"; c.className = cls(x.chg);
      $$(".sdot", r).forEach((d, i) => { const st = x.states && x.states[SCAN[i]]; d.className = "sdot " + (st === "LONG" ? "L" : st === "SHORT" ? "S" : ""); }); });
  }, 800);
  function symbolsModal() {
    const w = (S.tk && S.tk.watch) || {};
    openModal(`<h3>Sembol seç</h3>` + SYMS.map((s) => { const x = w[s] || {}, st = x.states || {}; return `<div class="m-row rip ${s === S.sym ? "act" : ""}" data-s="${s}"><div class="l"><b>${NAMES[s]}</b><small>${s === "EURUSD" ? "spot FX · order flow yok" : "Binance Futures · gerçek order flow"}</small></div>
      <div class="r"><b>${x.price ? fp(x.price, s) : "—"}</b><div class="${cls(x.chg)}">${x.chg == null ? "" : (x.chg >= 0 ? "+" : "") + x.chg.toFixed(2) + "%"}</div><div class="dots">${SCAN.map((t) => `<i class="sdot ${st[t] === "LONG" ? "L" : st[t] === "SHORT" ? "S" : ""}"></i>`).join("")}</div></div></div>`; }).join("") +
      `<div class="mini" style="margin-top:6px">Noktalar: 5m / 15m / 1H / 4H tarama durumu (yeşil LONG, kırmızı SHORT)</div>`, () => $$(".m-row", mm).forEach((r) => (r.onclick = () => { haptic(10); window.setSym(r.dataset.s); closeModal(); })), "symbols");
  }
  function layersModal() {
    openModal(`<h3>Grafik katmanları</h3>` + IND_MENU.map(([g, items]) => `<div class="m-grp">${g}</div><div class="m-chips">${items.map(([k, n]) => `<button class="m-chip rip ${S.opts[k] ? "on" : ""}" data-k="${k}">${n}</button>`).join("")}</div>`).join(""),
      () => $$(".m-chip", mm).forEach((c) => (c.onclick = () => { haptic(8); const k = c.dataset.k; S.opts[k] = !S.opts[k]; c.classList.toggle("on", S.opts[k]); localStorage.setItem("opts", JSON.stringify(S.opts)); visOpts(); markers(); drawOverlay(); })));
  }
  function menuModal() {
    const sw = (on) => `<span class="sw ${on ? "on" : ""}"></span>`, bg = window.BG;
    openModal(`<h3>Ayarlar</h3>
      <div class="m-row rip" data-a="sound"><div class="l"><b>Sinyal sesi</b><small>Yeni sinyalde nöron çanı</small></div>${sw(S.sound)}</div>
      <div class="m-row rip" data-a="awake"><div class="l"><b>Ekranı açık tut</b><small>Uygulama açıkken kapanmasın (pil harcar)</small></div>${sw(S.awake)}</div>
      ${bg ? `<div class="m-row rip" data-a="bg"><div class="l"><b>Arka plan uyarısı</b><small>Uygulama kapalıyken de bildirim · kalıcı bildirim görünür</small></div>${sw(bg.on)}</div>` : ""}
      <div class="m-row rip" data-a="theme"><div class="l"><b>Siyah tema</b><small>TradingView koyu ↔ saf siyah</small></div>${sw(S.theme === "black")}</div>
      <div class="m-row"><div class="l"><b>Risk tutarı</b><small>Stop çalışırsa kaybedilecek tutar ($)</small></div><div style="width:110px"><input class="m-input" id="m-risk" inputmode="decimal" value="${S.risk}"></div></div>
      <div class="m-row rip" data-a="cal"><div class="l"><b>Makro takvim</b><small>FOMC · CPI · NFP geri sayımı</small></div><span class="mut">›</span></div>
      <div class="honest" style="margin-top:8px">Sadece analiz: emir/hesap yok. Hiçbir strateji kanıtlı avantaj göstermedi; sinyaller bilgidir, tavsiye değildir. Android uygulama arka planda sınırlıdır: 🔔 açık olmalı, pil kısıtlaması kapalı olmalı.</div>`,
      () => {
        $$(".m-row[data-a]", mm).forEach((r) => (r.onclick = async () => {
          haptic(8); const a = r.dataset.a, s = $(".sw", r);
          if (a === "sound") { $("#btn-sound").click(); s.classList.toggle("on", S.sound); }
          else if (a === "awake") { $("#btn-awake").click(); s.classList.toggle("on", S.awake); }
          else if (a === "theme") { $("#btn-theme").click(); s.classList.toggle("on", S.theme === "black"); }
          else if (a === "bg") { const on = await window.BG.toggle(); s.classList.toggle("on", on); }
          else if (a === "cal") { closeModal(); setTimeout(() => mTab("cal"), 250); }
        }));
        const ri = $("#m-risk"); ri.onchange = async () => { S.risk = parseFloat(String(ri.value).replace(",", ".")) || 50; await api("/api/settings", { method: "POST", body: JSON.stringify({ risk_usd: S.risk }) }); if (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.Monitor) try { window.Capacitor.Plugins.Monitor.setConfig({ risk_usd: S.risk }); } catch (e) { /* yok */ } loadAna(); };
      });
  }
  $("#msym", root).onclick = () => { haptic(8); symbolsModal(); };
  $("#mmenu", root).onclick = () => { haptic(8); menuModal(); };
  $("#fab-layers", root).onclick = () => { haptic(8); layersModal(); };
  $("#fab-panes", root).onclick = (e) => { haptic(8); const on = !panes.classList.contains("show"); panes.classList.toggle("show", on); wrap.classList.toggle("withpanes", on); e.currentTarget.classList.toggle("on", on); setTimeout(() => window.dispatchEvent(new Event("resize")), 60); };

  /* ---------- dalga (ripple) ---------- */
  document.addEventListener("pointerdown", (e) => {
    const t = e.target.closest(".rip"); if (!t) return; const r = t.getBoundingClientRect(), d = Math.max(r.width, r.height), s = E("span", "ripple");
    s.style.cssText = `width:${d}px;height:${d}px;left:${e.clientX - r.left - d / 2}px;top:${e.clientY - r.top - d / 2}px`; t.appendChild(s); setTimeout(() => s.remove(), 650);
  }, { passive: true });

  /* ---------- döngü ve başlangıç ---------- */
  setInterval(() => { topUpdate(); peekUpdate(); badges(); const ev = S.ana && S.ana.eval; B.dataset.state = ev ? ev.state : ""; }, 700);
  topUpdate(); peekUpdate();
  const Q = new URLSearchParams(location.search), mq = Q.get("m");
  if (mq) setTimeout(() => { if (mq === "symbols") symbolsModal(); else if (mq === "menu") menuModal(); else if (mq === "layers") layersModal(); else if (mq === "flow") mTab("flow"); else if (mq === "panes") $("#fab-panes").click(); }, 2500);
  window.MOBILE = { setSheet, mTab, openModal, closeModal };
})();
