﻿/* Nera (Android/Capacitor) · yerel özellikler.
   Arka plan uyarısı = MonitorService (Java): analiz motoru Activity'den bağımsız, kendi görünmez WebView'ında çalışır (www/headless.html),
   süreç ön plan servisiyle canlı tutulur; arayüz kapansa/kaydırılsa da sinyal bildirimi gelir. Telefonda denenmedi (bkz. CLAUDE.md). */
const fmtP = (x, sym) => Number(x).toLocaleString("en-US", { minimumFractionDigits: sym === "BTCUSDT" ? 1 : sym === "XAGUSDT" ? 3 : sym === "EURUSD" ? 5 : 2, maximumFractionDigits: sym === "BTCUSDT" ? 1 : sym === "XAGUSDT" ? 3 : sym === "EURUSD" ? 5 : 2 });
const fmtD = (x, sym) => (sym === "EURUSD" ? (x * 10000).toFixed(1) + " pip" : (x >= 100 ? x.toFixed(1) : x >= 1 ? x.toFixed(2) : x.toFixed(3)) + " $");
const TFL = { "1m": "1m", "5m": "5m", "15m": "15m", "30m": "30m", "1h": "1H", "4h": "4H", "1d": "1D" };

import { initOta } from "./ota.js";

export function init(eng) {
  try { initOta(); } catch (e) { /* güncelleme modülü */ }
  const P = window.Capacitor.Plugins, LN = P.LocalNotifications, MON = P.Monitor, BO = P.BatteryOptimization;
  document.body.classList.add("cap");
  let on = localStorage.getItem("bg") === "1";
  window.BG = { get on() { return on; }, toggle: null, onChange: null };
  const setupNotif = async () => { try { await LN.requestPermissions(); await LN.createChannel({ id: "sinyal2", name: "Nera sinyalleri", description: "Yeni LONG/SHORT sinyalleri", importance: 5, visibility: 1, vibration: true, sound: "simsek.wav" }); } catch (e) { /* izin/kanal */ } };

  // arayüz görünürken: servise "yaşıyorum" kalp atışı (servis bu sırada bildirim göndermez); arka plandayken servis devralır
  setInterval(() => { try { if (!document.hidden && MON) MON.heartbeat(); } catch (e) { /* yoksay */ } }, 2000);
  const drain = async () => {
    try {
      const r = await MON.drain(); const n = eng.importExternal(r.signals || []);
      if (n > 0) { eng.evId++; eng.events.push({ id: eng.evId, bgsum: true, n }); }
    } catch (e) { /* yok */ }
  };
  document.addEventListener("visibilitychange", () => { if (!document.hidden) drain(); });
  drain();

  // servis KAPALIyken arayüz arka plandaysa (WebView hâlâ canlıysa) bildirimi arayüz gönderir
  eng.listeners.push((e) => {
    try {
      if (on || !LN) return;
      let title, body;
      if (e.missed) { title = `◷ Nera · kaçırılan ${e.side === 1 ? "LONG" : "SHORT"} · ${e.name} · ${TFL[e.tf]}`; body = `Yaklaşık ${e.ago} dk önce oluştu; eski plan geçersiz olabilir.`; }
      else if (e.sig) { const x = e.sig; title = `◉ Nera · ${x.side === 1 ? "LONG" : "SHORT"} · ${e.name} · ${TFL[x.tf]}`; body = `${x.setup} · giriş ${fmtP(x.entry, x.sym)} · stop −${fmtD(x.risk, x.sym)} · hedef +${fmtD(Math.abs(x.tp1 - x.entry), x.sym)} · tavsiye değil`; }
      else return;
      LN.schedule({ notifications: [{ id: (e.id % 2000000000) + 1, title, body, channelId: "sinyal2", schedule: { at: new Date(Date.now() + 300) } }] });
    } catch (err) { /* bildirim gönderilemedi */ }
  });

  const start = async () => {
    await setupNotif();
    try { await MON.setConfig({ risk_usd: eng.settings.risk_usd }); await MON.start(); } catch (e) { /* servis başlamadı */ }
    try { const { enabled } = await BO.isBatteryOptimizationEnabled(); if (enabled) await BO.requestIgnoreBatteryOptimization(); } catch (e) { /* pil izni */ }
  };
  const mark = () => { const btn = document.getElementById("btn-bg"); if (btn) { btn.style.opacity = on ? 1 : 0.45; btn.title = on ? "Arka plan uyarısı AÇIK (kalıcı bildirim görünür)" : "Arka plan uyarısı kapalı"; } if (window.BG.onChange) window.BG.onChange(on); };
  window.BG.toggle = async () => {
    on = !on; localStorage.setItem("bg", on ? "1" : "0"); mark();
    if (on) await start(); else { try { await MON.stop(); } catch (e) { /* zaten durdu */ } }
    return on;
  };
  mark();
  if (on) start();
  const btn = document.getElementById("btn-bg"); if (btn) btn.onclick = () => window.BG.toggle();
  window.ENGINE_NATIVE = true;
}
