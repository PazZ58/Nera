/* Nera (Android) · çevrimiçi güncelleme: yeni arayüz + motor paketi (mobil www) manifest'ten indirilir, sha256 ile doğrulanır,
   cihazın uygulama klasörüne açılır ve WebView o klasörden yüklenir. APK yeniden kurulmaz.
   Yeni bir APK kurulursa Capacitor kayıtlı klasörü yok sayar ve APK'daki sürüme döner (güvenli geri dönüş). */
const PL = () => window.Capacitor.Plugins;
const DEF = "https://raw.githubusercontent.com/PazZ58/Nera/main/manifest.json";
const st = { cur: 0, avail: 0, ready: false, err: "", busy: false, notes: "", checked: 0, path: "", src: "kurulu sürüm" };
const url = () => (localStorage.getItem("nera_upd_url") || DEF).trim();
async function curV() { try { const r = await fetch("version.json", { cache: "no-store" }); return (await r.json()).v || 0; } catch (e) { return 0; } }
const hex = (buf) => [...new Uint8Array(buf)].map((x) => x.toString(16).padStart(2, "0")).join("");

async function check(apply = false) {
  if (st.busy) return st; st.cur = await curV(); const u = url(); if (!u) { st.err = "güncelleme adresi ayarlanmadı"; return st; }
  st.busy = true;
  try {
    const H = PL().CapacitorHttp, m = await H.get({ url: u + (u.includes("?") ? "&" : "?") + "t=" + Date.now(), responseType: "json" }), j = typeof m.data === "string" ? JSON.parse(m.data) : m.data;
    st.avail = +j.v || 0; st.notes = String(j.notes || "").slice(0, 400); st.err = ""; st.checked = Date.now(); const mo = j.mobil || {};
    if (!(st.avail > st.cur && mo.url)) return st;
    const z = await H.get({ url: new URL(mo.url, u).href, responseType: "arraybuffer" }), bin = atob(z.data), bytes = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    if (mo.sha256 && hex(await crypto.subtle.digest("SHA-256", bytes)) !== mo.sha256) throw new Error("indirilen paket bozuk (sha256 tutmadı)");
    const zip = await window.JSZip.loadAsync(bytes), FS = PL().Filesystem, dir = `ota/v${st.avail}`;
    try { await FS.rmdir({ path: dir, directory: "DATA", recursive: true }); } catch (e) { /* yoktu */ }
    for (const [name, f] of Object.entries(zip.files)) { if (f.dir) continue; if (name.includes("..") || name.startsWith("/")) throw new Error("geçersiz dosya yolu"); await FS.writeFile({ path: `${dir}/${name}`, data: await f.async("base64"), directory: "DATA", recursive: true }); }
    const vj = await FS.readFile({ path: `${dir}/version.json`, directory: "DATA", encoding: "utf8" }); if ((JSON.parse(vj.data).v || 0) !== st.avail) throw new Error("paket eksik");
    const { uri } = await FS.getUri({ path: dir, directory: "DATA" }); st.path = decodeURIComponent(uri.replace(/^file:\/\//, "")); st.ready = true;
    if (apply) await applyNow();
  } catch (e) { st.err = String((e && e.message) || e).slice(0, 160); } finally { st.busy = false; }
  return st;
}
async function applyNow() { if (!st.ready || !st.path) return; const W = PL().WebView; await W.setServerBasePath({ path: st.path }); await W.persistServerBasePath(); }

export function initOta() {
  window.NeraOTA = { status: async () => { st.cur = st.cur || (await curV()); try { const p = await PL().WebView.getServerBasePath(); st.src = p && p.path && p.path.includes("/ota/") ? "çevrimiçi paket" : "kurulu sürüm"; } catch (e) { /* */ } return Object.assign({ url: url() }, st); }, setUrl: (u) => localStorage.setItem("nera_upd_url", String(u || "").trim()), check: () => check(false), apply: applyNow };
  setTimeout(() => check(false), 25000); setInterval(() => check(false), 3 * 3600 * 1000);
}
