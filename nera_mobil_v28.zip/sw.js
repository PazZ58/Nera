/* DayTrader Pro · çevrimdışı kabuk önbelleği. Veri (Binance) her zaman ağdan gelir; önbellek sadece uygulama dosyalarını tutar. */
const V = "dtpro-5";
const FILES = ["index.html", "style.css", "neo.css", "brain.js", "lab/labcore.js", "lab/lab.js", "lab/lab2.js", "lab/lab3.js", "lab/council.js", "lab/notif.js", "lab/social.js", "lab/pool.js", "lab/lab4.js", "lab/bot.js", "lab/xbot.js", "lab/whatsnew.js", "changelog.json", "app.js", "lw.js", "boot.js", "native.js", "mobile.js", "mobile.css", "manifest.webmanifest", "icon-192.png", "icon-512.png", "version.json", "logo.png", "ota.js", "jszip.min.js", "engine/agents.js", "engine/data.js", "engine/engine.js", "engine/events.js", "engine/ind.js", "engine/ledger.js", "engine/news.js", "engine/smc.js", "engine/ta.js"];
self.addEventListener("install", (e) => { e.waitUntil(caches.open(V).then((c) => c.addAll(FILES)).then(() => self.skipWaiting())); });
self.addEventListener("activate", (e) => { e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== V).map((k) => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener("fetch", (e) => {
  const u = new URL(e.request.url);
  if (e.request.method !== "GET" || u.origin !== location.origin) return;
  e.respondWith(caches.match(e.request).then((r) => r || fetch(e.request)));
});
self.addEventListener("notificationclick", (e) => { e.notification.close(); e.waitUntil(self.clients.matchAll({ type: "window" }).then((cs) => (cs[0] ? cs[0].focus() : self.clients.openWindow("./")))); });
