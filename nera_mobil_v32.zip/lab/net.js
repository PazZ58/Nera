"use strict";
/* Nera · hesap + mesaj taşıyıcısı. Firebase (Authentication e-posta/şifre + Realtime Database, REST) kuruluysa onu kullanır:
   kullanıcı adı + şifre ile giriş, profil sunucuda kalıcı (PC ve telefon aynı hesap), günlük mesaj kotası yok.
   Kurulmamışsa eski yol: ntfy.sh (hesapsız, IP başına günlük kota). social.js, pool.js, bot.js bu katmanı kullanır.
   Firebase yolları: rooms/<konu> (grup/varlık/bilardo), inbox/<kullanıcı>/<konu> (özel mesaj, yalnız sahibi okur), public/<uid> (profil),
   usernames/<ad> → uid, users/<uid>/bot/{status,cmd} (telefon ↔ PC XM Nera köprüsü). Kurallar: Ayarlar › Hesap sunucusu. */
(function () {
const LSg = (k, d) => { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } }, LSs = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* */ } if (window.NERA_SAVE) setTimeout(window.NERA_SAVE, 50); };
const DEF = { apiKey: "AIzaSyAbdSK0JFNb17dCn2UAwA6hVnUWJMU9-1Q", dbUrl: "https://nera-a1bee-default-rtdb.europe-west1.firebasedatabase.app" };                  // Firebase projesi nera-a1bee: bütün cihazlar otomatik bağlanır (web anahtarı gizli değildir; veriyi kurallar korur)
const NT = "https://ntfy.sh/";
const cfg = () => Object.assign({}, DEF, LSg("nera_fb", {}));
let A = Object.assign({ uid: "", user: "", id: "", rt: "", exp: 0 }, LSg("nera_auth", {}));
const uname = (n) => String(n || "").toLowerCase().replace(/ç/g, "c").replace(/ğ/g, "g").replace(/ı/g, "i").replace(/ö/g, "o").replace(/ş/g, "s").replace(/ü/g, "u").replace(/[^a-z0-9_]/g, "").slice(0, 24);
const authBase = () => cfg().authUrl || "https://identitytoolkit.googleapis.com/v1", tokBase = () => cfg().tokUrl || "https://securetoken.googleapis.com/v1", db = () => String(cfg().dbUrl || "").replace(/\/+$/, "");
const conf = () => !!(cfg().apiKey && cfg().dbUrl), on = () => conf() && !!A.rt, nsq = () => (cfg().ns ? "&ns=" + cfg().ns : "");
const ERR = { EMAIL_EXISTS: "Bu kullanıcı adı alınmış", EMAIL_NOT_FOUND: "Kullanıcı bulunamadı", INVALID_PASSWORD: "Şifre yanlış", INVALID_LOGIN_CREDENTIALS: "Kullanıcı adı ya da şifre yanlış", WEAK_PASSWORD: "Şifre en az 6 karakter olmalı", TOO_MANY_ATTEMPTS_TRY_LATER: "Çok fazla deneme, biraz sonra dene", OPERATION_NOT_ALLOWED: "Firebase'de E-posta/Şifre girişi açık değil", CONFIGURATION_NOT_FOUND: "Firebase'de Authentication açılmamış" };
const emsg = (j) => { const c = String((j && j.error && j.error.message) || "hata").split(" ")[0]; return ERR[c] || c; };
const save = () => LSs("nera_auth", A);
function setTok(j) { A.id = j.idToken || j.id_token; A.rt = j.refreshToken || j.refresh_token || A.rt; A.exp = Date.now() + (+(j.expiresIn || j.expires_in) || 3600) * 1000; if (j.localId || j.user_id) A.uid = j.localId || j.user_id; save(); }
async function token() {
  if (!on()) return null; if (A.id && Date.now() < A.exp - 120000) return A.id;
  const r = await fetch(`${tokBase()}/token?key=${cfg().apiKey}`, { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: `grant_type=refresh_token&refresh_token=${encodeURIComponent(A.rt)}` });
  const j = await r.json(); if (!r.ok) { if (/TOKEN_EXPIRED|INVALID_REFRESH|USER_NOT_FOUND|USER_DISABLED/.test(JSON.stringify(j))) { A.rt = ""; save(); emit("auth"); } throw new Error(emsg(j)); } setTok(j); return A.id;
}
async function rest(method, path, body) {
  const t = await token(); const r = await fetch(`${db()}/${path}.json?auth=${t}${nsq()}`, { method, body: body === undefined ? undefined : JSON.stringify(body) });
  if (r.status === 401) { A.exp = 0; } if (!r.ok) throw new Error("Firebase " + r.status); return r.json();
}
/* ---- hesap */
async function account(kind, user, pass) {
  if (!conf()) throw new Error("Hesap sunucusu kurulmadı (Ayarlar › Hesap sunucusu)"); const u = uname(user); if (u.length < 3) throw new Error("Kullanıcı adı en az 3 harf/rakam"); if (String(pass).length < 6) throw new Error("Şifre en az 6 karakter");
  const r = await fetch(`${authBase()}/accounts:${kind === "up" ? "signUp" : "signInWithPassword"}?key=${cfg().apiKey}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email: `${u}@nera-hesap.app`, password: pass, returnSecureToken: true }) });
  const j = await r.json(); if (!r.ok) throw new Error(emsg(j)); A.user = u; setTok(j);
  if (kind === "up") { try { await rest("PUT", `usernames/${u}`, A.uid); } catch (e) { /* kural: ad zaten varsa yazılmaz */ } await rest("PUT", `public/${A.uid}`, { user: u, nick: user, photo: "", t: { ".sv": "timestamp" } }); }
  emit("auth"); return u;
}
function signOut() { A = { uid: "", user: "", id: "", rt: "", exp: 0 }; save(); emit("auth"); }
const L = {}; function emit(e, d) { (L[e] || []).forEach((f) => { try { f(d); } catch (x) { console.error(x); } }); }
/* ---- yol eşlemesi: ..._u_<ad> konusu özel gelen kutusuna gider */
function pathOf(topic) { const m = String(topic).match(/^(.*)_u_([a-z0-9_]+)$/); return m ? `inbox/${m[2]}/${m[1]}` : `rooms/${String(topic).replace(/[.#$\[\]\/]/g, "_")}`; }
/* ---- yayınla: {key} verilirse aynı anahtarın üstüne yazar (varlık, yazıyor…: birikmez) */
async function pub(topic, obj, opt) {
  opt = opt || {};
  if (on()) { const v = { m: JSON.stringify(obj), t: { ".sv": "timestamp" }, by: A.uid }; if (opt.key) await rest("PUT", `${pathOf(topic)}/${opt.key}`, v); else await rest("POST", pathOf(topic), v); return; }
  const r = await fetch(NT + topic + (opt.ephemeral ? "?cache=no" : ""), { method: "POST", body: JSON.stringify(obj) }); if (!r.ok) throw new Error("HTTP " + r.status);
}
/* ---- dinle: [[konu, sinceMs], ...] → cb({event:"message", id, message}) ; geri dönen fonksiyon bağlantıları kapatır */
function listen(list, cb) {
  let closed = false, es = [], timer = 0;
  const close = () => { closed = true; clearTimeout(timer); es.forEach((e) => { try { e.close(); } catch (x) { /* */ } }); es = []; };
  if (!on()) {
    (async () => { for (const [tp, since] of list) { try { const r = await fetch(`${NT}${tp}/json?poll=1&since=${Math.max(1, Math.floor((Date.now() - since) / 1000))}s`); (await r.text()).split("\n").forEach((l) => { if (l.trim()) try { cb(JSON.parse(l), true); } catch (x) { /* */ } }); } catch (e) { /* */ } }
      if (closed) return; const e = new EventSource(`${NT}${list.map((x) => x[0]).join(",")}/sse`); e.onmessage = (ev) => { try { cb(JSON.parse(ev.data)); } catch (x) { /* */ } }; es.push(e); })();
    return close;
  }
  const open = async () => {
    if (closed) return; es.forEach((e) => { try { e.close(); } catch (x) { /* */ } }); es = []; let t; try { t = await token(); } catch (e) { timer = setTimeout(open, 15000); return; }
    for (const [tp, since] of list) {
      const e = new EventSource(`${db()}/${pathOf(tp)}.json?auth=${t}${nsq()}&orderBy=%22t%22&startAt=${Math.floor(since)}`), first = { v: true };
      const take = (key, v, replay) => { if (!v || typeof v !== "object" || !v.m) return; cb({ event: "message", id: key + ":" + v.t, message: v.m, time: v.t }, replay); };
      const onData = (ev) => { let d; try { d = JSON.parse(ev.data); } catch (x) { return; } if (!d) return; if (d.path === "/") { if (d.data && typeof d.data === "object") Object.entries(d.data).sort((a, b) => (a[1] && a[1].t) - (b[1] && b[1].t)).forEach(([k, v]) => take(k, v, first.v)); first.v = false; } else { const k = d.path.slice(1).split("/")[0]; if (d.path.split("/").length > 2) return; take(k, d.data, false); } };
      e.addEventListener("put", onData); e.addEventListener("patch", onData); e.addEventListener("auth_revoked", () => { A.exp = 0; clearTimeout(timer); timer = setTimeout(open, 1000); }); e.onerror = () => { if (e.readyState === 2) { clearTimeout(timer); timer = setTimeout(open, 5000); } }; es.push(e);
    }
    clearTimeout(timer); timer = setTimeout(open, Math.max(60000, A.exp - Date.now() - 180000));                  // kimlik süresi dolmadan yenile
  };
  open(); return close;
}
/* ---- profil (herkese açık: takma ad, foto, istatistik) */
const profile = { async load() { return on() ? (await rest("GET", `public/${A.uid}`)) || null : null; }, async save(p) { if (on()) await rest("PATCH", `public/${A.uid}`, Object.assign({}, p, { user: A.user, t: { ".sv": "timestamp" } })); } };
/* ---- XM Nera köprüsü (aynı hesap: PC durumu yazar, telefon komut yollar) */
const bot = {
  status: (s) => (on() ? rest("PUT", `users/${A.uid}/bot/status`, Object.assign({}, s, { at: { ".sv": "timestamp" } })) : Promise.resolve()),
  cmd: (c) => (on() ? rest("POST", `users/${A.uid}/bot/cmd`, Object.assign({}, c, { t: { ".sv": "timestamp" } })) : Promise.reject(new Error("Hesaba giriş yapılmadı"))),
  done: (k) => (on() ? rest("DELETE", `users/${A.uid}/bot/cmd/${k}`) : Promise.resolve()),
  watch(kind, cb) { if (!on()) return () => {}; let es = null, closed = false, timer = 0;
    const open = async () => { if (closed) return; try { const t = await token(); if (es) es.close(); es = new EventSource(`${db()}/users/${A.uid}/bot/${kind}.json?auth=${t}${nsq()}`); const h = (ev) => { try { const d = JSON.parse(ev.data); cb(d); } catch (x) { /* */ } }; es.addEventListener("put", h); es.addEventListener("patch", h); es.addEventListener("auth_revoked", () => { A.exp = 0; setTimeout(open, 1000); }); es.onerror = () => { if (es.readyState === 2) setTimeout(open, 5000); }; timer = setTimeout(open, Math.max(60000, A.exp - Date.now() - 180000)); } catch (e) { timer = setTimeout(open, 15000); } };
    open(); return () => { closed = true; clearTimeout(timer); if (es) es.close(); }; },
};
window.NeraNet = { conf, on, user: () => (on() ? A.user : ""), uid: () => A.uid, signUp: (u, p) => account("up", u, p), signIn: (u, p) => account("in", u, p), signOut, pub, listen, profile, bot, rest, token, uname, cfg, setCfg: (c) => { LSs("nera_fb", c); emit("auth"); }, onAuth: (f) => (L.auth = L.auth || []).push(f), DEF };
})();

/* Ayarlar › Hesap sunucusu: Firebase kurulum rehberi + ayar + test */
(function () {
const RULES = JSON.stringify({ rules: {
  rooms: { $topic: { ".read": "auth != null", ".indexOn": ["t"], $msg: { ".write": "auth != null && (!data.exists() || data.child('by').val() === auth.uid)" } } },
  inbox: { $name: { ".read": "auth != null && root.child('usernames').child($name).val() === auth.uid", $topic: { ".indexOn": ["t"], $msg: { ".write": "auth != null && (!data.exists() || data.child('by').val() === auth.uid)" } } } },
  public: { ".read": "auth != null", $uid: { ".write": "auth != null && auth.uid === $uid" } },
  usernames: { ".read": "auth != null", $name: { ".write": "auth != null && !data.exists() && newData.val() === auth.uid" } },
  users: { $uid: { ".read": "auth != null && auth.uid === $uid", ".write": "auth != null && auth.uid === $uid" } } } }, null, 2);
const $ = (s, r = document) => r.querySelector(s), esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
function panel() {
  const pg = $("#pg-set"); if (!pg || $("#fb-panel")) return; const N = window.NeraNet, c = N.cfg(), p = document.createElement("div"); p.className = "panel"; p.id = "fb-panel";
  p.innerHTML = `<div class="ph">Hesap sunucusu (Firebase) <small id="fb-st">${N.conf() ? (N.on() ? "bağlı · @" + esc(N.user()) : "kurulu · Arkadaşlar'dan giriş yap") : "kurulmadı"}</small></div><div class="pb">
    <div class="muted" style="font-size:12.5px;line-height:1.6">Kullanıcı adı + şifreyle giriş, her cihazda aynı profil, sınırsız sohbet/bilardo ve telefondan XM Nera için ücretsiz bir Firebase projesi gerekir (bir kez, ~5 dk). Kotası ntfy'den çok yüksektir.</div>
    <details class="fb-steps"><summary>Kurulum adımları</summary><ol>
      <li><a href="https://console.firebase.google.com" target="_blank" rel="noopener">console.firebase.google.com</a> › <b>Proje ekle</b> › ad: <code>nera</code> (Analytics kapalı olabilir).</li>
      <li>Sol menü <b>Build › Authentication</b> › <b>Başlayın</b> › Sign-in method › <b>E-posta/Şifre</b> › Etkinleştir › Kaydet.</li>
      <li><b>Build › Realtime Database</b> › <b>Veritabanı oluştur</b> › konum <b>europe-west1</b> › <b>kilitli modda başlat</b>.</li>
      <li>Realtime Database › <b>Kurallar</b> sekmesi › içeriği sil, aşağıdaki kuralları yapıştır › <b>Yayınla</b>.</li>
      <li>Proje ayarları (dişli) › Genel › <b>Uygulamalarınız</b> › <b>&lt;/&gt; Web</b> › ad: nera › kaydet. Çıkan kodda <code>apiKey</code> ve <code>databaseURL</code> değerlerini aşağıya yapıştır (bunlar gizli değildir).</li></ol>
      <div class="ctl"><button class="btn" id="fb-copy">Kuralları kopyala</button></div><pre class="fb-rules">${esc(RULES)}</pre></details>
    <div class="fb-grid"><label class="fld">apiKey<input id="fb-key" value="${esc(c.apiKey || "")}" placeholder="AIza..." autocomplete="off"></label><label class="fld">databaseURL<input id="fb-db" value="${esc(c.dbUrl || "")}" placeholder="https://nera-xxxx-default-rtdb.europe-west1.firebasedatabase.app"></label></div>
    <div class="ctl" style="margin-top:8px"><button class="btn pri" id="fb-save">Kaydet ve test et</button><span class="muted" id="fb-msg" style="font-size:12px"></span></div></div>`;
  const up = $("#upd-panel"); if (up) up.before(p); else pg.appendChild(p);
  $("#fb-copy").onclick = async () => { try { await navigator.clipboard.writeText(RULES); $("#fb-copy").textContent = "Kopyalandı ✓"; } catch (e) { /* */ } };
  $("#fb-save").onclick = async () => { const k = $("#fb-key").value.trim(), d = $("#fb-db").value.trim().replace(/\/+$/, ""), m = $("#fb-msg"); if (!k || !/^https:\/\/.+(firebaseio\.com|firebasedatabase\.app)$/.test(d)) { m.textContent = "apiKey ve databaseURL'yi kontrol et"; return; }
    m.textContent = "deneniyor…"; try { const r1 = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${k}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email: "deneme@nera-hesap.app", password: "x", returnSecureToken: true }) }), j = await r1.json(), code = String((j.error && j.error.message) || "");
      if (/API_KEY_INVALID|API key not valid/.test(code)) throw new Error("apiKey geçersiz"); if (/CONFIGURATION_NOT_FOUND|OPERATION_NOT_ALLOWED/.test(code)) throw new Error("Authentication › E-posta/Şifre açık değil (adım 2)");
      const r2 = await fetch(`${d}/rooms.json?shallow=true`); if (r2.status !== 401 && r2.status !== 200) throw new Error("databaseURL'ye ulaşılamadı (" + r2.status + ")"); if (r2.status === 200) throw new Error("Veritabanı herkese açık: adım 4'teki kuralları yayınla");
      N.setCfg({ apiKey: k, dbUrl: d }); m.textContent = "✓ Hazır. Arkadaşlar ekranından kayıt ol / giriş yap."; $("#fb-st").textContent = "kurulu"; } catch (e) { m.textContent = "✕ " + e.message; } };
}
window.addEventListener("DOMContentLoaded", () => { if (window.DT) DT.on("view", (v) => { if (v === "set") setTimeout(panel, 300); }); });
})();
