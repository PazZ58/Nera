"use strict";
/* Nera · XM Nera ekranı (yalnız PC). Solda canlı grafik (sembol geçişi, LONG/SHORT, giriş/stop/merdiven çizgileri), sağda etkileşimli 3B DNA beyni:
   sürükle = döndür, tekerlek = yakınlaş, küreye dokun = işlemi seç (grafik o sembole geçer), basamağa dokun = dalga. Altta canlı işlemler (tek tek kapat),
   kapananlar ve akış. XM Nera olayları kendi bildirim stiliyle gelir (notif.js kind "xm"). Veri: /api/bot, /api/chart, /api/tick. */
(function () {
const REMOTE = () => !!(window.LOCAL_API || window.Capacitor);          // telefon: XM Nera'yı aynı hesaptaki PC üzerinden izler/yönetir (Firebase köprüsü)
const api = async (path) => (REMOTE() ? NAPI(path) : (await fetch(path)).json());
const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s == null ? "" : s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const SY = [["XAUUSDT", "Altın", "Au", "oz", 1], ["XAGUSDT", "Gümüş", "Ag", "oz", 50], ["EURUSD", "EUR/USD", "€", "€", 1000], ["BTCUSDT", "BTC", "₿", "BTC", 0.01], ["ETHUSDT", "ETH", "Ξ", "ETH", 0.05]];
const SYM = Object.fromEntries(SY.map((x) => [x[0], { name: x[1], ic: x[2], unit: x[3], q: x[4] }]));
const money = (x, c) => (x == null || !isFinite(x) ? "—" : `${x >= 0 ? "+" : "−"}${Math.abs(x).toFixed(2)} ${!c || c === "USD" ? "$" : c}`);
const ago = (t) => { const s = Math.max(0, Date.now() / 1000 - t); return s < 60 ? Math.floor(s) + " sn" : s < 3600 ? Math.floor(s / 60) + " dk" : s < 86400 ? Math.floor(s / 3600) + " sa" : Math.floor(s / 86400) + " g"; };
const lvl = (step, g, k) => (k <= 0 ? 0 : Math.abs(g - 1) < 1e-6 ? step * k : (step * (Math.pow(g, k) - 1)) / (g - 1));
const loc = (t) => t - new Date().getTimezoneOffset() * 60;
const X = { s: null, prev: null, fx: [], sparks: [], waves: [], t: 0, col: null, sym: localStorage.getItem("nera_xm_sym") || "XAUUSDT", tf: localStorage.getItem("nera_xm_tf") || "15m", sel: null,
  yaw: 0, pitch: 0.18, zoom: 1, drag: null, hover: null, orbs: [], rungs: [], ch: null, ser: null, lines: [], lk: "", lastBar: null };

/* ---------- iskelet */
function build() {
  const pg = $("#pg-xbot"); if (!pg || pg._b) return; pg._b = 1;
  pg.innerHTML = `<div class="xn-head"><div><div class="eyebrow">XM · canlı işlem</div><h1>XM Nera</h1></div><div class="xn-hr"><span class="xb-st" id="xb-st"></span><div class="xb-eq"><span>Varlık</span><b id="xb-eq">—</b><em id="xb-acct"></em></div></div></div>
  <div class="xn-top">
    <div class="panel xn-chartp"><div class="xn-bar"><div class="seg xn-syms" id="xn-syms">${SY.map(([k, n, ic]) => `<button data-s="${k}"><i>${ic}</i>${n}</button>`).join("")}</div><div class="seg xn-tfs" id="xn-tfs">${["5m", "15m", "1h", "4h"].map((t) => `<button data-t="${t}">${t}</button>`).join("")}</div></div>
      <div class="xn-trade"><button class="xb-go L" id="xb-long"><span class="xb-gfx"></span><b>LONG</b><em>al</em></button><button class="xb-go S" id="xb-short"><span class="xb-gfx"></span><b>SHORT</b><em>sat</em></button>
        <label class="xn-in"><span>Miktar</span><input type="number" id="xn-qty" min="0" step="any"><em id="xn-unit">oz</em></label><label class="xn-in"><span>Stop ($)</span><input type="number" id="xn-stop" min="0" step="any" placeholder="oto"></label><div class="xn-risk" id="xn-risk"></div></div>
      <div class="xn-chart" id="xn-chart"><div class="xn-px"><b id="xn-px">—</b><span id="xn-pxs"></span></div></div></div>
    <div class="panel xn-brainp"><canvas id="xb-cv"></canvas><div class="xn-btip" id="xn-tip"></div><div class="xb-hint" id="xb-hint"></div><div class="xn-help">sürükle: döndür · tekerlek: yakınlaş · küre: işlemi seç</div></div>
  </div>
  <div class="xn-mid"><div class="xb-kpis"><div class="xb-k" id="k-day"><span>Bugün</span><b>—</b><i></i></div><div class="xb-k" id="k-open"><span>Açık K/Z</span><b>—</b><i></i></div><div class="xb-k" id="k-win"><span>Kazanma</span><b>—</b><i></i></div><div class="xb-k" id="k-tot"><span>Toplam K/Z</span><b>—</b><i></i></div></div>
    <div class="xn-ctl"><button class="btn pri" id="xb-on"></button><button class="btn" id="xb-pause"></button><button class="btn warn" id="xb-close">Tümünü kapat</button><button class="btn" id="xb-pre" title="ATR'ye göre adım, 8 basamak, %20 kısmi kâr">Önerilen ayarlar</button><button class="btn" id="xb-set">Ayarlar ›</button></div></div>
  <div class="panel xn-lad"><div class="ph">Merdiven ayarı <small id="xl-sym"></small></div><div class="xl-b"><label class="xn-in"><span>1. basamak</span><input type="number" id="xl-s1" min="0" step="any"><em>$</em></label>
    <div class="seg" id="xl-g">${[[1, "Eşit"], [1.25, "×1,25"], [1.5, "×1,5"], [2, "×2"]].map(([g, n]) => `<button data-g="${g}">${n}</button>`).join("")}</div><label class="xn-in"><span>Basamak</span><input type="number" id="xl-n" min="1" max="20" step="1"></label>
    <div class="xl-prev" id="xl-prev"></div><button class="btn pri" id="xl-save">Kaydet</button></div></div>
  <div class="panel"><div class="ph">Canlı işlemler <small id="xb-pn">—</small><small id="xb-tg" style="margin-left:auto"></small></div><div id="xb-pos" class="xb-pos"></div></div>
  <div class="two"><div class="panel"><div class="ph">Kapanan işlemler <small id="xb-sp-t"></small></div><canvas id="xb-sp" class="xn-sp"></canvas><div id="xb-closed" class="xb-list"></div></div><div class="panel"><div class="ph">XM Nera akışı <small>canlı</small></div><div id="xb-log" class="xb-list xb-log"></div></div></div>`;
  $$("#xn-syms button").forEach((b) => (b.onclick = () => setSym(b.dataset.s))); $$("#xn-tfs button").forEach((b) => (b.onclick = () => { X.tf = b.dataset.t; localStorage.setItem("nera_xm_tf", X.tf); loadChart(); marks(); }));
  $("#xb-on").onclick = async () => { if (!X.s) return; if (!X.s.cfg.on && X.s.acct && X.s.acct.real && !confirm("GERÇEK hesapta işlem açılacak. Devam?")) return; await post({ cfg: { on: !X.s.cfg.on } }); };
  $("#xb-pause").onclick = () => X.s && post({ cfg: { paused: !X.s.cfg.paused } });
  $("#xb-close").onclick = () => { if (confirm("XM Nera'nın açtığı tüm işlemler şimdi kapatılsın mı?")) post({ act: "close_all" }); };
  $("#xb-pre").onclick = () => { if (confirm("Önerilen ayarlar uygulansın mı?\nATR'ye göre merdiven adımı, 8 basamak, her basamakta %20 kâr al, hedefte yön sürerse yeni tur.\nRisk, semboller ve günlük sınırlar değişmez.")) post({ act: "preset" }); };
  $("#xb-set").onclick = () => { Lab.go("set"); setTimeout(() => { const b = $("#bot-panel"); if (b) { b.scrollIntoView({ behavior: "smooth" }); const d = b.querySelector(".bt-adv"); if (d) d.open = true; } }, 600); };
  $$("#xl-g button").forEach((b) => (b.onclick = () => { $$("#xl-g button").forEach((x) => x.classList.toggle("on", x === b)); ladPrev(); })); ["#xl-s1", "#xl-n"].forEach((i) => $(i).addEventListener("input", ladPrev));
  $("#xl-save").onclick = async () => { const v = +$("#xl-s1").value, g = +(($("#xl-g button.on") || {}).dataset || {}).g || 1, n = Math.max(1, Math.min(20, +$("#xl-n").value || 5)); if (!v) return alert("1. basamak mesafesini gir"); await post({ cfg: { step_mode: "fixed", step: { [X.sym]: v }, growth: g, steps: n } }); X.ladSet = 0; const b = $("#xl-save"); b.textContent = "Kaydedildi ✓"; setTimeout(() => (b.textContent = "Kaydet"), 1800); };
  const man = async (side, btn) => { if (!X.s || !X.s.xm) return alert("Önce Ayarlar › XM bağlantısı › Bağlan."); const m = SYM[X.sym], q = +$("#xn-qty").value, st = +$("#xn-stop").value, a = X.s.acct || {};
    if (!q) return alert("Miktar gir."); if (!confirm(`${m.name} ${side > 0 ? "LONG (al)" : "SHORT (sat)"} · ${q} ${m.unit}${st ? ` · stop ${st} $ uzakta` : " · stop otomatik"}\n${a.mode || ""} hesapta şimdi açılsın mı?`)) return;
    btn.classList.remove("fire"); void btn.offsetWidth; btn.classList.add("fire"); X.fx.push({ k: "open", side, t: 0 }); await post({ act: "manual", sym: X.sym, side, qty: q, dist: st || null }); setTimeout(poll, 900); };
  $("#xb-long").onclick = (e) => man(1, e.currentTarget); $("#xb-short").onclick = (e) => man(-1, e.currentTarget);
  ["#xn-qty", "#xn-stop"].forEach((id) => $(id).addEventListener("input", riskEst));
  const cv = $("#xb-cv");
  cv.addEventListener("pointerdown", (e) => { X.drag = { x: e.clientX, y: e.clientY, yaw: X.yaw, pitch: X.pitch, moved: 0 }; try { cv.setPointerCapture(e.pointerId); } catch (x) { /* */ } });
  cv.addEventListener("pointermove", (e) => { const r = cv.getBoundingClientRect(), mx = e.clientX - r.left, my = e.clientY - r.top; if (X.drag) { const dx = e.clientX - X.drag.x, dy = e.clientY - X.drag.y; X.drag.moved = Math.max(X.drag.moved, Math.abs(dx) + Math.abs(dy)); X.yaw = X.drag.yaw + dx * 0.012; X.pitch = Math.max(-0.9, Math.min(0.9, X.drag.pitch + dy * 0.008)); X.spin = 0; } X.mouse = [mx, my]; });
  cv.addEventListener("pointerup", (e) => { const d = X.drag; X.drag = null; if (d && d.moved < 6) click(X.mouse); setTimeout(() => (X.spin = 1), 2500); });
  cv.addEventListener("pointerleave", () => { X.mouse = null; }); cv.addEventListener("wheel", (e) => { e.preventDefault(); X.zoom = Math.max(0.6, Math.min(1.8, X.zoom * (e.deltaY > 0 ? 0.92 : 1.08))); }, { passive: false });
  setSym(X.sym, true);
}
function setSym(s, first) { X.ladSet = 0; X.sym = s; localStorage.setItem("nera_xm_sym", s); $$("#xn-syms button").forEach((b) => b.classList.toggle("on", b.dataset.s === s)); $$("#xn-tfs button").forEach((b) => b.classList.toggle("on", b.dataset.t === X.tf)); $("#xn-unit").textContent = SYM[s].unit; const q = $("#xn-qty"); q.value = localStorage.getItem("nera_xm_q_" + s) || SYM[s].q; q.onchange = () => localStorage.setItem("nera_xm_q_" + s, q.value); riskEst(); if (!first) { $(".xn-chart").classList.remove("swap"); void $(".xn-chart").offsetWidth; $(".xn-chart").classList.add("swap"); } loadChart(); X.lk = ""; marks(); }
function ladPrev() { const v = +$("#xl-s1").value || 0, g = +(($("#xl-g button.on") || {}).dataset || {}).g || 1, n = Math.max(1, Math.min(20, +$("#xl-n").value || 5)), q = +$("#xn-qty").value || 0; if (!v) { $("#xl-prev").innerHTML = ""; return; }
  $("#xl-prev").innerHTML = Array.from({ length: Math.min(n, 8) }, (_, i) => { const d = lvl(v, g, i + 1); return `<i style="--h:${Math.min(100, 18 + (i + 1) * 10)}%;--d:${i * 0.05}s" title="${i + 1}. basamak +${d.toFixed(2)}"><b>+${d < 100 ? d.toFixed(1) : Math.round(d)}</b></i>`; }).join("") + (q ? `<span>son basamakta ≈ +${(lvl(v, g, n) * q).toFixed(2)} $</span>` : ""); }
function ladFill() { if (!X.s || !$("#xl-s1") || X.ladSet === X.sym) return; const c = X.s.cfg || {}; X.ladSet = X.sym; $("#xl-sym").textContent = SYM[X.sym].name + (c.step_mode === "atr" ? " · şu an ATR modunda" : ""); $("#xl-s1").value = (c.step || {})[X.sym] || ""; $("#xl-n").value = c.steps || 5; const g = c.growth || 1; $$("#xl-g button").forEach((b) => b.classList.toggle("on", Math.abs(+b.dataset.g - g) < 0.01)); ladPrev(); }
function riskEst() { const q = +$("#xn-qty").value || 0, st = +$("#xn-stop").value || 0, e = $("#xn-risk"); e.innerHTML = q && st ? `risk ≈ <b>${(q * st).toFixed(2)} $</b>` : q ? `stop otomatik (ATR)` : ""; }
async function post(b) {
  if (REMOTE()) { try { await NeraNet.bot.cmd(b); if (window.NeraNotify) NeraNotify.push({ kind: "xm", title: "Komut PC'ye gönderildi", body: { manual: "işlem açılıyor", close_pos: "işlem kapatılıyor", close_all: "tümü kapatılıyor", modify: "stop/hedef değişiyor", preset: "önerilen ayarlar" }[b.act] || (b.cfg ? "ayar değişiyor" : "") , xm: { side: b.side || 1, n: 0, steps: 5 } }); } catch (e) { alert(e.message); } return; }
  try { X.s = await (await fetch("/api/bot", { method: "POST", body: JSON.stringify(b) })).json(); render(); relay(true); } catch (e) { /* */ } }
async function poll() { if (REMOTE()) return; try { const s = await (await fetch("/api/bot", { cache: "no-store" })).json(); X.prev = X.s; X.s = s; window.__xmTot = s.tot; events(); tabs(); render(); relay(); } catch (e) { /* sunucu yok */ } }
function take(s) { if (!s || !s.cfg) return; X.prev = X.s; X.s = s; window.__xmTot = s.tot; events(); tabs(); render(); }
/* PC → hesap: durum yaz (değişince, en sık 4 sn) + telefondan gelen komutları uygula */
let rlT = 0, rlH = "", cmdW = null;
function relay(force) {
  if (REMOTE() || !window.NeraNet || !NeraNet.on() || !X.s) return; const s = X.s, lite = { cfg: s.cfg, xm: s.xm, acct: s.acct, day: s.day, trades: s.trades, cool: s.cool, pos: s.pos, closed: (s.closed || []).slice(0, 12), log: (s.log || []).slice(0, 20), tot: s.tot, map: s.map }, h = JSON.stringify(lite);
  if (h === rlH || (!force && Date.now() - rlT < 4000)) return; rlH = h; rlT = Date.now(); NeraNet.bot.status(lite).catch(() => {});
  if (!cmdW) cmdW = NeraNet.bot.watch("cmd", (d) => { const all = d && d.path === "/" ? d.data || {} : d && d.data ? { [d.path.slice(1)]: d.data } : {}; Object.entries(all).forEach(async ([k, c]) => { if (!c || typeof c !== "object") return; NeraNet.bot.done(k).catch(() => {}); if (Date.now() - (c.t || 0) > 120000) return; const b = Object.assign({}, c); delete b.t; await post(b); NeraNotify && NeraNotify.push({ kind: "xm", title: "Telefondan komut", body: b.act || (b.cfg ? Object.keys(b.cfg).join(", ") : ""), xm: { side: 1, n: 0, steps: 5 } }); }); });
}

/* ---------- grafik */
function cv(n, d) { return getComputedStyle(document.body).getPropertyValue(n).trim() || d; }
function mkChart() {
  const el = $("#xn-chart"); if (!el || X.ch || !window.LightweightCharts) return;
  X.ch = LightweightCharts.createChart(el, { layout: { background: { type: "solid", color: "transparent" }, textColor: cv("--text2", "#aab1c4"), fontFamily: "Segoe UI, sans-serif", attributionLogo: false }, grid: { vertLines: { color: "rgba(120,130,160,.07)" }, horzLines: { color: "rgba(120,130,160,.07)" } },
    rightPriceScale: { borderColor: "rgba(120,130,160,.18)" }, timeScale: { borderColor: "rgba(120,130,160,.18)", timeVisible: true, rightOffset: 10, barSpacing: 8 }, crosshair: { mode: 0 }, autoSize: true });
  dragInit(); X.ser = X.ch.addCandlestickSeries({ upColor: "#26c6a0", downColor: "#f2566a", borderVisible: false, wickUpColor: "#26c6a0", wickDownColor: "#f2566a", priceLineColor: cv("--na", "#35e0c4") });
}
async function loadChart() {
  mkChart(); if (!X.ser) return; const sym = X.sym, tf = X.tf;
  try { const j = await api(`/api/chart?sym=${sym}&tf=${tf}`); if (sym !== X.sym || tf !== X.tf || !j.candles) return; X.ser.setData(j.candles.map((c) => ({ time: loc(c.time), open: c.open, high: c.high, low: c.low, close: c.close }))); X.lastBar = j.candles[j.candles.length - 1]; X.ch.timeScale().scrollToRealTime(); X.lk = ""; marks(); if (!j.candles.length) throw 0; } catch (e) { clearTimeout(X._rl); X._rl = setTimeout(loadChart, 2500); }      // veri henüz hazır değilse tekrar dene
}
async function tick() {
  if (!X.ser || document.body.dataset.view !== "xbot") return; try { const j = await api(`/api/tick?sym=${X.sym}&tf=${X.tf}&since=0`), c = j && j.candle; if (!c) return;
    X.ser.update({ time: loc(c.time), open: c.open, high: c.high, low: c.low, close: c.close }); const w = j.watch && j.watch[X.sym], pe = $("#xn-px"), dig = c.close > 1000 ? 2 : c.close > 10 ? 3 : 5, txt = c.close.toFixed(dig);
    if (pe.textContent !== txt) { const up = parseFloat(pe.textContent) < c.close; pe.textContent = txt; pe.className = up ? "up" : "dn"; pe.classList.remove("pop"); void pe.offsetWidth; pe.classList.add("pop"); }
    $("#xn-pxs").textContent = w ? `${w.chg >= 0 ? "+" : ""}${w.chg.toFixed(2)}%${w.spread ? ` · spread ${(+w.spread).toFixed(dig)}` : ""}${w.closed ? " · KAPALI" : ""}` : ""; } catch (e) { /* */ }
}
/* işlem çizgileri: giriş, stop, sonraki basamaklar, hedef */
function marks() {
  if (!X.ser || !X.s) return; const ps = (X.s.pos || []).filter((p) => p.ns === X.sym), key = JSON.stringify(ps.map((p) => [p.ticket, p.open, p.sl, p.tp, p.n, p.step, X.sel === p.ticket]));
  if (key === X.lk || X.dragging) return; X.lk = key; X.lines.forEach((l) => { try { X.ser.removePriceLine(l); } catch (e) { /* */ } }); X.lines = []; X.dl = [];
  const add = (price, color, title, style = 0, w = 1) => { if (!price) return null; const l = X.ser.createPriceLine({ price, color, lineWidth: w, lineStyle: style, axisLabelVisible: true, title }); X.lines.push(l); return l; };
  ps.forEach((p) => { const col = p.side > 0 ? "#26c6a0" : "#f2566a", sel = X.sel === p.ticket; add(p.open, col, `${p.side > 0 ? "LONG" : "SHORT"} ${p.qty}`, 0, sel ? 2 : 1);
    const sl = add(p.sl, "#ffb04a", "stop ⇕", 2, 2); if (sl) X.dl.push({ line: sl, kind: "sl", p, price: p.sl });
    if (p.step) for (let k = p.n + 1; k <= Math.min(p.steps || 5, p.n + 3); k++) add(p.open + p.side * lvl(p.step, p.g || 1, k), "rgba(53,224,196,.45)", `basamak ${k}`, 1);
    const tpP = p.tp || (p.step ? p.open + p.side * p.step * (p.steps || 5) : 0), tl = add(tpP, p.tp ? "#ffd27a" : "rgba(255,210,122,.45)", p.tp ? "hedef ⇕" : "hedef koy ⇕", 3, 2); if (tl) X.dl.push({ line: tl, kind: "tp", p, price: tpP }); });
}

/* grafikte stop / hedef çizgisini sürükle → MT5'te değişir */
function hitLine(e) { const el = $("#xn-chart"); if (!X.dl || !X.ser || !el) return null; const y = e.clientY - el.getBoundingClientRect().top; return X.dl.find((d) => { const c = X.ser.priceToCoordinate(d.price); return c != null && Math.abs(c - y) < 8; }) || null; }
function dragInit() {
  const el = $("#xn-chart"); if (!el || el._dg) return; el._dg = 1;
  el.addEventListener("pointerdown", (e) => { const h = hitLine(e); if (!h) return; e.preventDefault(); X.dragging = Object.assign({}, h); X.ch.applyOptions({ handleScroll: false, handleScale: false }); try { el.setPointerCapture(e.pointerId); } catch (x) { /* */ } el.classList.add("dragging"); }, true);
  el.addEventListener("pointermove", (e) => { const d = X.dragging; if (!d) { el.style.cursor = hitLine(e) ? "ns-resize" : ""; return; } const y = e.clientY - el.getBoundingClientRect().top, pr = X.ser.coordinateToPrice(y); if (pr == null) return; d.price = pr; const dig = d.p.dig != null ? d.p.dig : 2, risk = Math.abs(pr - d.p.open) * (parseFloat(d.p.qty) || 0);
    d.line.applyOptions({ price: pr, title: `${d.kind === "sl" ? "stop" : "hedef"} ${pr.toFixed(dig)} · ${d.kind === "sl" ? "−" : "+"}${risk.toFixed(2)} $` }); }, true);
  const up = () => { const d = X.dragging; if (!d) return; X.dragging = null; el.classList.remove("dragging"); X.ch.applyOptions({ handleScroll: true, handleScale: true }); const dig = d.p.dig != null ? d.p.dig : 2; X.lk = ""; post({ act: "modify", ticket: d.p.ticket, [d.kind]: +d.price.toFixed(dig) }); nf({ title: `${d.kind === "sl" ? "Stop" : "Hedef"} taşındı · ${(SYM[d.p.ns] || {}).name || d.p.sym}`, body: `${d.price.toFixed(dig)} olarak MT5'e gönderildi`, xm: { side: d.p.side, n: d.p.n, steps: d.p.steps } }); };
  el.addEventListener("pointerup", up, true); el.addEventListener("pointercancel", up, true);
}

/* ---------- olaylar → animasyon + XM Nera bildirimi */
const nf = (o) => { if (window.NeraNotify) NeraNotify.push(Object.assign({ kind: "xm" }, o)); };
function events() {
  const a = X.prev, b = X.s; if (!a || !b) return; const A = new Map((a.pos || []).map((p) => [p.ticket, p])), B = new Map((b.pos || []).map((p) => [p.ticket, p])), cur = (b.acct || {}).cur;
  for (const [k, p] of B) { const o = A.get(k), nm = (SYM[p.ns] || {}).name || p.sym;
    if (!o) { X.fx.push({ k: "open", side: p.side, t: 0 }); nf({ title: `${p.side > 0 ? "LONG" : "SHORT"} açıldı · ${nm}`, body: `${p.qty} @ ${p.open} · stop ${p.sl || "—"}`, xm: { side: p.side, n: 0, steps: p.steps }, onClick: () => { Lab.go("xbot"); X.sel = p.ticket; setSym(p.ns || X.sym); } }); }
    else if (p.n > o.n) { X.fx.push({ k: "step", side: p.side, t: 0, lvl: p.n / (p.steps || 5) }); nf({ title: `Basamak ${p.n} · ${nm}`, body: `stop → ${p.sl} · kâr ${money(p.pnl, cur)}`, xm: { side: p.side, n: p.n, steps: p.steps } }); } }
  for (const [k, p] of A) if (!B.has(k)) { const nm = (SYM[p.ns] || {}).name || p.sym, c = (b.closed || [])[0], pnl = c ? c.pnl : p.pnl; X.fx.push({ k: "close", side: p.side, t: 0, win: pnl >= 0, lvl: (p.n || 0) / (p.steps || 5) }); nf({ title: `${pnl >= 0 ? "Kârla" : "Zararla"} kapandı · ${nm}`, body: `${money(pnl, cur)} · ${p.n} basamak`, xm: { side: p.side, n: p.n, steps: p.steps, win: pnl >= 0, done: 1 } }); }
  const errs = (b.log || []).filter((l) => l.k === "err" && !(a.log || []).some((x) => x.t === l.t && x.m === l.m)); if (errs.length) nf({ title: "XM Nera uyarısı", body: errs[0].m, xm: { err: 1 } });
}

/* ---------- listeler */
function lad(p) { const n = Math.min(p.steps || 5, 12); let h = ""; for (let i = 1; i <= n; i++) h += `<i class="${i <= p.n ? "on" : ""}${i === p.n + 1 ? " nx" : ""}"></i>`; return `<div class="xb-lad">${h}</div>`; }
function posHTML(p, cur) {
  const prog = Math.max(0, Math.min(1, p.step ? ((p.now - p.open) * p.side) / (p.step * (p.steps || 5)) : 0)), locked = p.sl && (p.sl - p.open) * p.side >= 0, m = SYM[p.ns] || { ic: "•", name: p.sym };
  return `<div class="xb-p ${p.side > 0 ? "L" : "S"}${X.sel === p.ticket ? " sel" : ""}" data-k="${p.ticket}"><div class="xb-ic">${esc(m.ic)}</div><div class="xb-pm"><b>${esc(m.name)} <em class="xb-sd">${p.side > 0 ? "LONG" : "SHORT"}</em> <span class="muted">${esc(p.qty)}</span></b><span class="muted">giriş ${p.open} → şimdi <span class="xb-now">${p.now}</span> · stop ${p.sl || "—"} <em class="xb-lock ${locked ? "ok" : ""}">${locked ? "kâr kilitli" : "risk açık"}</em></span>
    <div class="xb-bar"><i style="width:${(prog * 100).toFixed(1)}%"></i></div></div>${lad(p)}<div class="xb-pl ${p.pnl >= 0 ? "up" : "dn"}"><b>${money(p.pnl, cur)}</b><span class="muted">basamak ${p.n}/${p.steps}${p.tgt ? ` · hedef ${p.tgt}$` : ""}${p.chain ? ` · ${p.chain + 1}. tur` : ""}</span></div><button class="xb-x" data-t="${p.ticket}" title="Bu işlemi kapat">✕</button></div>`;
}
function render() {
  const s = X.s; if (!s || !$("#pg-xbot") || !$("#xb-st")) return; const a = s.acct || {}, cur = a.cur, on = s.cfg.on, pa = s.cfg.paused;
  const st = !s.xm ? ["XM BAĞLI DEĞİL", "off"] : !on ? ["KAPALI", "off"] : pa ? ["DURAKLADI", "pause"] : s.cool > 0 ? [`MOLA · ${Math.ceil(s.cool / 60)} dk`, "pause"] : ["ÇALIŞIYOR", "run"]; X.state = st[1];
  const sh = `<i class="xb-dot ${st[1]}"></i>${st[0]}`, se = $("#xb-st"); if (se._h !== sh) { se._h = sh; se.innerHTML = sh; se.className = "xb-st " + st[1]; }
  $("#xb-eq").textContent = a.eq != null ? `${Number(a.eq).toFixed(2)} ${cur === "USD" ? "$" : cur || ""}` : "—"; $("#xb-acct").textContent = a.mode ? `${a.mode} hesap` : s.xm ? "" : "Ayarlar › XM bağlantısı"; $("#xb-acct").className = a.real ? "real" : "";
  $("#xb-hint").textContent = !s.xm ? "MT5 açık olmalı · Ayarlar › XM bağlantısı" : !on ? "XM Nera kapalı · elle işlem açılabilir" : (s.pos || []).length ? "" : pa ? "Duraklatıldı" : "Sinyal bekleniyor…";
  const ob = $("#xb-on"); ob.textContent = on ? "XM Nera'yı durdur" : "XM Nera'yı başlat"; ob.className = "btn " + (on ? "warn" : "pri"); $("#xb-pause").textContent = pa ? "Devam et" : "Duraklat"; $("#xb-pause").disabled = !on;
  const openPl = (s.pos || []).reduce((t, p) => t + (p.pnl || 0), 0), T = s.tot || { n: 0, w: 0, pnl: 0 };
  kpi("k-day", s.day == null ? "—" : money(s.day, cur), s.day || 0); kpi("k-open", (s.pos || []).length ? money(openPl, cur) : "—", openPl); kpi("k-win", T.n ? `%${Math.round((T.w / T.n) * 100)} <small>${T.w}/${T.n}</small>` : "—", T.n ? T.w / T.n - 0.5 : 0); kpi("k-tot", T.n ? money(T.pnl, cur) : "—", T.pnl || 0);
  ladFill(); $("#xb-pn").textContent = (s.pos || []).length ? `${s.pos.length} açık` : "yok"; const tg = s.cfg.target_usd > 0 ? `hedef ${s.cfg.target_usd}$${s.cfg.reenter ? ` · ${s.cfg.max_chain} tur` : ""}` : `${s.cfg.steps} basamak · adım ${s.cfg.step_mode === "atr" ? "ATR" : s.cfg.step_mode === "auto" ? "oto" : "sabit"}`; if ($("#xb-tg").textContent !== tg) $("#xb-tg").textContent = tg;
  const pe = $("#xb-pos"), have = new Set(); (s.pos || []).forEach((p) => { const k = String(p.ticket); have.add(k); let el = pe.querySelector(`[data-k="${k}"]`); const h = posHTML(p, cur);
    if (!el) { const d = document.createElement("div"); d.innerHTML = h; el = d.firstChild; el.classList.add("in"); pe.prepend(el); el._h = h; }
    else if (el._h !== h) { const old = el.querySelector(".xb-pl b").textContent; el.innerHTML = new DOMParser().parseFromString(h, "text/html").body.firstChild.innerHTML; el.className = `xb-p ${p.side > 0 ? "L" : "S"}${X.sel === p.ticket ? " sel" : ""}`; el._h = h; if (old !== el.querySelector(".xb-pl b").textContent) { const b = el.querySelector(".xb-pl"); b.classList.remove("tick"); void b.offsetWidth; b.classList.add("tick"); } }
    el.onclick = (e) => { const x = e.target.closest(".xb-x"); if (x) { e.stopPropagation(); if (confirm("Bu işlem şimdi kapatılsın mı?")) { el.classList.add("closing"); post({ act: "close_pos", ticket: +x.dataset.t }); } return; } X.sel = X.sel === p.ticket ? null : p.ticket; if (p.ns && p.ns !== X.sym) setSym(p.ns); X.lk = ""; marks(); render(); }; });
  pe.querySelectorAll(".xb-p").forEach((el) => { if (!have.has(el.dataset.k) && !el.classList.contains("out")) { el.classList.add("out"); setTimeout(() => el.remove(), 600); } });
  let emp = pe.querySelector(".xb-empty"); if (!(s.pos || []).length) { if (!emp) { emp = document.createElement("div"); emp.className = "xb-empty"; emp.innerHTML = `<div class="xb-radar"><i></i><i></i><i></i></div><span>Açık işlem yok · grafiğin üstündeki LONG / SHORT ile elle açabilirsin</span>`; pe.appendChild(emp); } } else if (emp) emp.remove();
  const cl = s.closed || []; sync($("#xb-closed"), cl, (c) => c.t + c.tag, (c) => `<div class="xb-c ${c.pnl >= 0 ? "up" : "dn"}"><i class="xb-cd"></i><div><b>${esc(c.tag)}</b><span class="muted"><em class="xb-ago">${ago(c.t)}</em> önce · ${c.n} basamak</span></div><b class="xb-cp">${money(c.pnl, cur)}</b></div>`, "Henüz kapanan işlem yok.");
  const LI = { open: "▲", close: "■", stop: "‖", err: "!", info: "·" }; sync($("#xb-log"), (s.log || []).slice(0, 30), (l) => l.t + l.m, (l) => `<div class="xb-l k-${l.k}"><i>${LI[l.k] || "·"}</i><span>${esc(l.m)}</span><em class="xb-ago">${ago(l.t)}</em></div>`, "Kayıt yok.");
  let c = 0; X.eq = (s.closed || []).slice().reverse().map((x) => (c += x.pnl || 0)); $("#xb-sp-t").textContent = (s.closed || []).length ? money(c, cur) : ""; marks();
}
function tabs() {
  const s = X.s; if (!s) return;
  const per = {}; (s.pos || []).forEach((p) => { if (p.ns) (per[p.ns] = per[p.ns] || []).push(p); }); window.__xmPos = per;
  $$("#xn-syms button").forEach((b) => { const L = per[b.dataset.s] || [], sd = L.length ? (L.every((p) => p.side > 0) ? "L" : L.every((p) => p.side < 0) ? "S" : "M") : "", h = L.length ? `<em class="xn-bd ${sd}">${sd === "L" ? "▲" : sd === "S" ? "▼" : "◆"}${L.length > 1 ? L.length : ""}</em>` : ""; let e = b.querySelector(".xn-bd"); if ((e ? e.outerHTML : "") !== h) { if (e) e.remove(); if (h) b.insertAdjacentHTML("beforeend", h); } b.classList.toggle("has", !!L.length); });
  SY.forEach(([k]) => { const d = document.getElementById("dots-" + k), t = d && d.closest(".symtab"); if (!t) return; const L = per[k] || []; t.classList.toggle("xm-on", !!L.length); t.classList.toggle("xm-L", !!L.length && L[0].side > 0); t.classList.toggle("xm-S", !!L.length && L[0].side < 0); t.title = L.length ? `XM Nera: ${L.length} açık işlem` : ""; });
}
/* anahtarlı liste: yalnız yeni satır eklenir (animasyonlu), eskilerin sadece "önce" yazısı güncellenir */
function sync(box, items, key, html, empty) {
  if (!box) return; const want = items.map(key), have = new Map([...box.children].filter((e) => e.dataset.key).map((e) => [e.dataset.key, e]));
  [...box.children].forEach((e) => { if (!e.dataset.key || !want.includes(e.dataset.key)) e.remove(); });
  let prev = null; items.forEach((it, i) => { const k = want[i]; let el = have.get(k); if (!el) { const d = document.createElement("div"); d.innerHTML = html(it); el = d.firstElementChild; el.dataset.key = k; if (box._init) el.classList.add("new"); }
    else { const ag = el.querySelector(".xb-ago"), nh = (html(it).match(/class="xb-ago">([^<]*)</) || [])[1]; if (ag && nh != null && ag.textContent !== nh) ag.textContent = nh; }
    const at = prev ? prev.nextSibling : box.firstChild; if (at !== el) box.insertBefore(el, at); prev = el; });
  if (!items.length && !box.querySelector(".xb-none")) box.innerHTML = `<div class="muted xb-none">${empty}</div>`; box._init = true;
}
function kpi(id, html, v) { const e = $("#" + id); if (!e) return; const b = e.querySelector("b"); if (b._h !== html) { b._h = html; b.innerHTML = html; e.classList.remove("bump"); void e.offsetWidth; e.classList.add("bump"); } e.classList.toggle("up", v > 0); e.classList.toggle("dn", v < 0); }

/* ---------- 3B DNA beyni */
const N = 170, CL = [], PAIRS = [];
for (let i = 0; i < N; i++) { const lobe = i % 2 ? 1 : -1, a = Math.random() * 6.283, r = Math.pow(Math.random(), 0.6); CL.push({ x: lobe * 0.42 + Math.cos(a) * r * 0.55, y: Math.sin(a) * r * 0.62 - 0.05, z: (Math.random() - 0.5) * 0.9, ph: Math.random() * 6.3, e: 0 }); }
for (let i = 0; i < N; i++) for (let j = i + 1; j < N; j++) { const d = Math.hypot(CL[i].x - CL[j].x, CL[i].y - CL[j].y, CL[i].z - CL[j].z); if (d < 0.17 && PAIRS.length < 460) PAIRS.push([i, j]); }
function colors() { X.col = { a: cv("--na", "#35e0c4"), b: cv("--nb", "#8a7bff"), c: cv("--nc", "#ffb04a"), up: "#3ddc84", dn: "#f2566a" }; }
const rgb = (hex, al) => { const h = String(hex).replace("#", ""), n = parseInt(h.length === 3 ? h.split("").map((x) => x + x).join("") : h.slice(0, 6), 16); return `rgba(${n >> 16},${(n >> 8) & 255},${n & 255},${al})`; };
function click(m) {
  if (!m) return; const o = X.orbs.find((q) => Math.hypot(q.x - m[0], q.y - m[1]) < 22); if (o) { X.sel = X.sel === o.p.ticket ? null : o.p.ticket; if (o.p.ns && o.p.ns !== X.sym) setSym(o.p.ns); X.lk = ""; marks(); render(); X.waves.push({ y: o.y, t: 0, col: o.p.side > 0 ? X.col.up : X.col.dn }); return; }
  const r = X.rungs.reduce((b, q) => (Math.abs(q.y - m[1]) < Math.abs(b.y - m[1]) ? q : b), { y: 1e9 }); if (Math.abs(r.y - m[1]) < 14) { X.waves.push({ y: r.y, t: 0, col: X.col.c, k: r.k }); try { Sound && Sound.tone && Sound.tone(520 + r.k * 40, 0.1, 0.3); } catch (e) { /* */ } }
}
function frame(dt) {
  const cvs = $("#xb-cv"); if (!cvs || !vis(cvs)) return; const w = cvs.parentElement.clientWidth, h = cvs.parentElement.clientHeight; if (w < 60) return; const c = fitCanvas(cvs, w, h); if (!X.col) colors(); const C = X.col, st = X.state || "off";
  X.t += dt * (st === "run" ? 1 : st === "pause" ? 0.35 : 0.55); if (X.spin !== 0 && !X.drag) X.yaw += dt * (st === "run" ? 0.55 : 0.25); const t = X.t; c.clearRect(0, 0, w, h);
  const cx = w * 0.5, cy = h * 0.5, S = Math.min(w, h * 0.95) * 0.82 * X.zoom, base = st === "run" ? C.a : st === "pause" ? C.c : "#5a6278";
  const g0 = c.createRadialGradient(cx, cy, 10, cx, cy, S * 1.3); g0.addColorStop(0, rgb(base, 0.14)); g0.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = g0; c.fillRect(0, 0, w, h);
  const cy1 = Math.cos(X.yaw), sy1 = Math.sin(X.yaw), cp = Math.cos(X.pitch), sp = Math.sin(X.pitch);
  const P3 = (x, y, z) => { const x1 = x * cy1 + z * sy1, z1 = -x * sy1 + z * cy1, y2 = y * cp - z1 * sp, z2 = y * sp + z1 * cp, k = 1 / (1.9 - z2 * 0.55); return [cx + x1 * S * k, cy + y2 * S * k, z2, k]; };
  // nöron bulutu (beyin)
  const br = 1 + Math.sin(t * 0.8) * 0.025, P = CL.map((n) => P3((n.x + Math.sin(t * 0.5 + n.ph) * 0.012) * br * 1.25, (n.y + Math.cos(t * 0.45 + n.ph) * 0.012) * br * 1.25, n.z * 1.1));
  if (Math.random() < dt * (st === "run" ? 4 : 1.2)) CL[(Math.random() * N) | 0].e = 1;
  c.lineWidth = 0.7; for (const [i, j] of PAIRS) { const e = Math.max(CL[i].e, CL[j].e); c.strokeStyle = rgb(e > 0.15 ? C.c : C.b, 0.08 + e * 0.5); c.beginPath(); c.moveTo(P[i][0], P[i][1]); c.lineTo(P[j][0], P[j][1]); c.stroke(); if (CL[i].e > 0.5) CL[j].e = Math.max(CL[j].e, CL[i].e * 0.6); }
  CL.forEach((n, i) => { n.e *= Math.pow(0.12, dt); const r = (1 + n.e * 2.4) * P[i][3] * 1.6; c.fillStyle = n.e > 0.3 ? "#fff" : rgb(i % 3 ? C.b : C.a, 0.45 + (P[i][2] + 0.5) * 0.4); c.beginPath(); c.arc(P[i][0], P[i][1], Math.max(0.6, r), 0, 6.283); c.fill(); });
  // DNA: gerçek 3B çift sarmal (y: -0.8 tepe hedef … +0.8 taban giriş)
  const RUN = 18, R3 = 0.2, TW = 7.5, pt = (u, off) => { const a = u * TW + off + t * 0.35; return P3(Math.cos(a) * R3, 0.8 - u * 1.6, Math.sin(a) * R3); };
  X.rungs = []; for (let k = 0; k <= RUN; k++) { const A = pt(k / RUN, 0), B = pt(k / RUN, Math.PI), back = (A[2] + B[2]) / 2 < 0, lit = X.litTop != null && k / RUN <= X.litTop + 0.001; X.rungs.push({ y: (A[1] + B[1]) / 2, k }); c.strokeStyle = rgb(lit ? C.up : C.a, (back ? 0.16 : 0.4) + (lit ? 0.35 : 0)); c.lineWidth = (back ? 1 : 2) * A[3] * 1.4; c.beginPath(); c.moveTo(A[0], A[1]); c.lineTo(B[0], B[1]); c.stroke();
    for (const q of [A, B]) { c.fillStyle = rgb(lit ? C.up : C.a, back ? 0.3 : 0.9); c.beginPath(); c.arc(q[0], q[1], (back ? 1.6 : 2.6) * q[3] * 1.4, 0, 6.283); c.fill(); } }
  for (const off of [0, Math.PI]) for (let k = 0; k < RUN * 5; k++) { const A = pt(k / (RUN * 5), off), B = pt((k + 1) / (RUN * 5), off); c.strokeStyle = rgb(off ? C.b : C.a, A[2] < 0 ? 0.28 : 0.95); c.lineWidth = (A[2] < 0 ? 1.5 : 3) * A[3] * 1.3; c.beginPath(); c.moveTo(A[0], A[1]); c.lineTo(B[0], B[1]); c.stroke(); }
  if (Math.random() < dt * (st === "run" ? 3 : 0.8)) X.sparks.push({ u: 0, off: Math.random() < 0.5 ? 0 : Math.PI, v: 0.25 + Math.random() * 0.3 });
  for (let i = X.sparks.length - 1; i >= 0; i--) { const sp = X.sparks[i]; sp.u += dt * sp.v; if (sp.u > 1) { X.sparks.splice(i, 1); continue; } const q = pt(sp.u, sp.off), g = c.createRadialGradient(q[0], q[1], 0, q[0], q[1], 9 * q[3]); g.addColorStop(0, "rgba(255,255,255,.9)"); g.addColorStop(0.4, rgb(sp.off ? C.b : C.a, 0.6)); g.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = g; c.fillRect(q[0] - 12, q[1] - 12, 24, 24); }
  // dokunma dalgaları
  for (let i = X.waves.length - 1; i >= 0; i--) { const wv = X.waves[i]; wv.t += dt / 0.9; if (wv.t >= 1) { X.waves.splice(i, 1); continue; } c.strokeStyle = rgb(wv.col, 1 - wv.t); c.lineWidth = 2; c.beginPath(); c.ellipse(cx, wv.y, S * 0.25 + wv.t * S * 0.6, 6 + wv.t * 18, 0, 0, 6.283); c.stroke(); }
  // işlemler: sarmalda seviyesindeki küre
  const pos = (X.s && X.s.pos) || []; X.litTop = null; X.orbs = []; let hov = null; c.font = '600 11px "Segoe UI",sans-serif';
  pos.forEach((p, i) => { const steps = p.steps || 5, lvl = p.step ? Math.max(0, Math.min(1, ((p.now - p.open) * p.side) / (p.step * steps))) : 0, q = pt(lvl, i * 2.1 + 0.6), col = p.side > 0 ? C.up : C.dn, sel = X.sel === p.ticket, pul = 1 + Math.sin(t * 4 + i) * 0.15, R = (sel ? 30 : 24) * pul * q[3] * 1.3;
    X.litTop = Math.max(X.litTop || 0, (p.n || 0) / steps); X.orbs.push({ x: q[0], y: q[1], p });
    const g = c.createRadialGradient(q[0], q[1], 0, q[0], q[1], R); g.addColorStop(0, "rgba(255,255,255,.95)"); g.addColorStop(0.25, rgb(col, 0.9)); g.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = g; c.beginPath(); c.arc(q[0], q[1], R, 0, 6.283); c.fill();
    c.strokeStyle = rgb(sel ? "#ffffff" : col, sel ? 0.9 : 0.6); c.lineWidth = sel ? 2 : 1.2; c.beginPath(); c.arc(q[0], q[1], 13 + Math.sin(t * 3) * 2, 0, 6.283); c.stroke();
    if (X.mouse && Math.hypot(q[0] - X.mouse[0], q[1] - X.mouse[1]) < 22) hov = p; });
  const tip = $("#xn-tip"); if (hov) { const m = SYM[hov.ns] || { name: hov.sym }; tip.innerHTML = `<b class="${hov.side > 0 ? "na" : "down"}">${m.name} ${hov.side > 0 ? "LONG" : "SHORT"}</b><span>${esc(hov.qty)} · giriş ${hov.open}</span><span>stop ${hov.sl || "—"} · basamak ${hov.n}/${hov.steps}</span><b class="${hov.pnl >= 0 ? "na" : "down"}">${money(hov.pnl, (X.s.acct || {}).cur)}</b>`; tip.style.left = Math.min(w - 170, X.mouse[0] + 14) + "px"; tip.style.top = Math.max(6, X.mouse[1] - 30) + "px"; tip.classList.add("on"); cvs.style.cursor = "pointer"; } else { tip.classList.remove("on"); cvs.style.cursor = X.drag ? "grabbing" : "grab"; }
  const T0 = pt(0, 0), T1 = pt(1, 0); c.textAlign = "center"; c.font = '9px "Cascadia Mono",Consolas,monospace'; c.fillStyle = rgb(C.a, 0.6); c.fillText("GİRİŞ", cx, Math.max(T0[1], T1[1]) + 22); c.fillText("HEDEF", cx, Math.min(T0[1], T1[1]) - 14);
  // olay efektleri
  const yTop = Math.min(T0[1], T1[1]), yBot = Math.max(T0[1], T1[1]);
  for (let i = X.fx.length - 1; i >= 0; i--) { const f = X.fx[i]; f.t += dt / (f.k === "open" ? 1.1 : 0.9); if (f.t >= 1) { X.fx.splice(i, 1); continue; } const col = f.k === "close" ? (f.win ? C.up : C.dn) : f.side > 0 ? C.up : C.dn, y = f.k === "open" ? yBot : yBot - (f.lvl || 0) * (yBot - yTop);
    if (f.k === "open") { for (let r = 0; r < 3; r++) { c.strokeStyle = rgb(col, (1 - f.t) * (0.8 - r * 0.2)); c.lineWidth = 2; c.beginPath(); c.arc(cx, y, (f.t + r * 0.12) * S * 0.9, 0, 6.283); c.stroke(); } }
    else if (f.k === "step") { c.strokeStyle = rgb(C.c, 1 - f.t); c.lineWidth = 3; c.beginPath(); c.moveTo(cx - S * 0.3 - f.t * 40, y); c.lineTo(cx + S * 0.3 + f.t * 40, y); c.stroke(); }
    else { for (let k = 0; k < 16; k++) { const a = (k / 16) * 6.283, d = f.t * S * 0.55; c.fillStyle = rgb(col, 1 - f.t); c.fillRect(cx + Math.cos(a) * d - 2, y + Math.sin(a) * d - 2, 4, 4); } } }
  spark();
}
function spark() {
  const cvs = $("#xb-sp"); if (!cvs || !vis(cvs)) return; const w = cvs.parentElement.clientWidth - 28, h = 64; if (w < 40) return; const c = fitCanvas(cvs, w, h), C = X.col, e = [0, ...(X.eq || [])]; c.clearRect(0, 0, w, h);
  if (e.length < 2) { c.fillStyle = rgb(C.a, 0.4); c.font = '11px "Segoe UI",sans-serif'; c.textAlign = "center"; c.fillText("kapanan işlem olunca eğri burada çizilir", w / 2, h / 2 + 4); return; }
  const mn = Math.min(...e), mx = Math.max(...e), sx = (i) => (i / (e.length - 1)) * (w - 4) + 2, sy = (v) => h - 6 - ((v - mn) / (mx - mn || 1)) * (h - 12), col = e[e.length - 1] >= 0 ? C.up : C.dn;
  const g = c.createLinearGradient(0, 0, 0, h); g.addColorStop(0, rgb(col, 0.35)); g.addColorStop(1, rgb(col, 0)); c.beginPath(); e.forEach((v, i) => (i ? c.lineTo(sx(i), sy(v)) : c.moveTo(sx(i), sy(v)))); c.lineTo(sx(e.length - 1), h); c.lineTo(sx(0), h); c.fillStyle = g; c.fill();
  c.beginPath(); e.forEach((v, i) => (i ? c.lineTo(sx(i), sy(v)) : c.moveTo(sx(i), sy(v)))); c.strokeStyle = col; c.lineWidth = 2; c.stroke(); const lx = sx(e.length - 1), ly = sy(e[e.length - 1]); c.fillStyle = col; c.beginPath(); c.arc(lx, ly, 3 + Math.sin(X.t * 4) * 1.5, 0, 6.283); c.fill();
}

let stW = null;
function remoteWatch() { if (!REMOTE() || !window.NeraNet) return; if (stW) { stW(); stW = null; } if (!NeraNet.on()) { const h = $("#xb-hint"); if (h) h.textContent = "Telefonda izlemek için PC'de ve burada aynı hesapla giriş yap (Arkadaşlar › Hesap)"; return; } stW = NeraNet.bot.watch("status", (d) => { if (d && d.path === "/" && d.data) take(d.data); else if (d && d.data && X.s) { const k = d.path.slice(1).split("/")[0]; if (k && !k.includes("/")) { X.s = Object.assign({}, X.s, { [k]: d.data }); take(X.s); } } }); }
window.addEventListener("DOMContentLoaded", () => {
  if (window.NeraNet) { NeraNet.onAuth(() => { remoteWatch(); cmdW && cmdW(); cmdW = null; relay(true); }); setTimeout(remoteWatch, 1500); }
  TICKS.push(frame); DT.on("palette", () => (X.col = null)); DT.on("theme", () => setTimeout(() => { X.col = null; if (X.ch) X.ch.applyOptions({ layout: { textColor: cv("--text2", "#aab1c4") } }); }, 60));
  DT.on("view", (v) => { if (v === "xbot") { build(); poll(); setTimeout(() => { loadChart(); }, 80); } });
  if (document.body.dataset.view === "xbot") { build(); poll(); setTimeout(loadChart, 120); }
  let k = 0; setInterval(() => { k++; const on = document.body.dataset.view === "xbot" && !document.hidden; if (on) { if (!$("#xb-st")) { build(); loadChart(); } poll(); tick(); } else if (k % 3 === 0) poll(); }, 1000);
});
})();
