"use strict";
const IS_MOB_DPR = matchMedia("(max-width:900px)").matches ? 1.5 : 3;          // mobilde tuval çözünürlüğü sınırı (pil)
/* Nera · arayüz. Grafik: TradingView Lightweight Charts (Apache-2.0). Veri: yerel sunucu (/api/*). Sadece analiz, emir yok. */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const SYMS = ["BTCUSDT", "ETHUSDT", "XAUUSDT", "XAGUSDT", "EURUSD"];
const NAMES = { BTCUSDT: "BTC/USDT", ETHUSDT: "ETH/USDT", XAUUSDT: "Altın XAU", XAGUSDT: "Gümüş XAG", EURUSD: "EUR/USD" };
const TFS = ["1m", "5m", "15m", "30m", "1h", "4h", "1d"];
const TF_LABEL = { "1m": "1m", "5m": "5m", "15m": "15m", "30m": "30m", "1h": "1H", "4h": "4H", "1d": "1D" };
const SCAN = ["5m", "15m", "1h", "4h"];
const OFF = -new Date().getTimezoneOffset() * 60;
const TV = { up: "#089981", down: "#f23645", blue: "#2962ff", orange: "#ff9800", yellow: "#fdd835", purple: "#ab47bc", cyan: "#4dd0e1", muted: "#787b86", text: "#d1d4dc" };
const OPTS_DEF = { ema: true, vwap: true, bb: false, ichi: false, st: false, sar: false, ob: true, fvg: true, liq: true, struct: true, pdz: true, vp: true, sr: false, fib: false, sess: true, plan: true, marks: true, cloud: false, liqmap: false, whales: false, pulse2: false, heat: false, exheat: false, money: true };
const IND_MENU = [
  ["Hareketli ortalamalar & trend", [["ema", "EMA 21 / 50 / 200"], ["vwap", "VWAP"], ["st", "Supertrend (10,3)"], ["ichi", "Ichimoku (çizgiler)"], ["cloud", "Ichimoku bulutu"], ["sar", "Parabolic SAR"], ["bb", "Bollinger bantları"]]],
  ["ICT / Smart Money", [["struct", "Yapı: HH/HL/LH/LL · BOS · CHoCH"], ["ob", "Order block"], ["fvg", "FVG (adil değer boşluğu)"], ["pdz", "Premium / Discount · OTE"], ["sess", "Kill zone seansları"]]],
  ["Likidite & hacim", [["liq", "Likidite havuzları (EQH/EQL/PDH/PDL…)"], ["vp", "Hacim profili · POC/VAH/VAL"], ["sr", "Destek / direnç kümeleri"], ["fib", "Fibonacci geri çekilme"]]],
  ["Order flow haritaları (kendi hesabımız)", [["money", "Likidite: para nerede? (emir defteri + tasfiye + stop havuzu + işlem hacmi)"], ["heat", "Sıcaklık haritası (işlem yoğunluğu + emir defteri) · dokun: bölge bilgisi"], ["liqmap", "Likidasyon haritası (tahmini + canlı)"], ["whales", "Balina haritası"], ["pulse2", "Pulse v2 (beta)"]]],
  ["Sinyal", [["plan", "Stop / hedef kutusu"], ["marks", "◉ sinyal işaretleri"]]],
];
const S = { sym: localStorage.getItem("sym") || "XAUUSDT", tf: localStorage.getItem("tf") || "15m", data: null, ana: null, tk: null, sigs: [], stats: {}, lastEv: 0, unseen: 0, tab: "sig", ready: false,
  opts: Object.assign({}, OPTS_DEF, JSON.parse(localStorage.getItem("opts") || "{}")), theme: localStorage.getItem("theme") || "dark", sound: localStorage.getItem("sound") === "1",
  pane2: localStorage.getItem("pane2") || "adx", times: [], cal: [], risk: 50, loadedKey: "", candleLast: null, selSig: null };

/* ---------- biçim ---------- */
const dec = (sym) => sym === "BTCUSDT" ? 1 : sym === "ETHUSDT" ? 2 : sym === "XAUUSDT" ? 2 : sym === "XAGUSDT" ? 3 : 5;
const fp = (x, sym = S.sym) => x == null || !isFinite(x) ? "—" : Number(x).toLocaleString("en-US", { minimumFractionDigits: dec(sym), maximumFractionDigits: dec(sym) });
const dist = (x, sym = S.sym) => sym === "EURUSD" ? (x * 10000).toFixed(1) + " pip" : (x >= 100 ? x.toFixed(1) : x >= 1 ? x.toFixed(2) : x.toFixed(3)) + " $";
const pct = (x, d = 1) => (x == null ? "—" : (x * 100).toFixed(d) + "%");
const loc = (t) => t + OFF;
const hhmm = (t) => new Date(t * 1000).toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" });
const dtm = (t) => new Date(t * 1000).toLocaleString("tr-TR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" });
const num = (x) => x == null || !isFinite(x) ? "—" : (Math.abs(x) >= 1e6 ? (x / 1e6).toFixed(2) + "M" : Math.abs(x) >= 1e3 ? (x / 1e3).toFixed(1) + "K" : Math.abs(x) >= 10 ? x.toFixed(0) : x.toFixed(2));
const cls = (v) => (v > 0 ? "up" : v < 0 ? "down" : "mut");
/* Masaüstü: yerel Python sunucusuna fetch. Mobil (APK/PWA): window.LOCAL_API (tarayıcı içi JavaScript motoru) tanımlıdır. */
async function api(path, opt) {
  try {
    if (window.LOCAL_API) return await window.LOCAL_API(path, opt);
    const r = await fetch(path, opt); return await r.json();
  } catch (e) { window.__apiErr = path.split("?")[0] + " · " + String((e && e.message) || e).slice(0, 90); return null; }
}
const IS_MOBILE = () => window.matchMedia("(max-width: 900px)").matches;
window.__S = () => S;

/* ---------- tema ---------- */
const cv = (n) => getComputedStyle(document.getElementById("left") || document.body).getPropertyValue(n).trim();
function chartOpts() {
  return { autoSize: true, layout: { background: { type: "solid", color: cv("--bg") }, textColor: cv("--muted"), fontFamily: "Trebuchet MS, Segoe UI, sans-serif", fontSize: 12 },
    grid: { vertLines: { color: cv("--grid") }, horzLines: { color: cv("--grid") } }, rightPriceScale: { borderColor: cv("--line"), minimumWidth: 74 },
    timeScale: { borderColor: cv("--line"), timeVisible: true, secondsVisible: false, rightOffset: 8, barSpacing: 8 },
    crosshair: { mode: 0, vertLine: { color: "#758696", labelBackgroundColor: "#2a2e39" }, horzLine: { color: "#758696", labelBackgroundColor: "#2a2e39" } },
    handleScroll: { mouseWheel: true, pressedMouseMove: true, horzTouchDrag: true, vertTouchDrag: !IS_MOBILE() },      // telefonda dikey kaydırma sayfayı kaydırır
    handleScale: { mouseWheel: true, pinch: true, axisPressedMouseMove: true } };
}
function paneOpts() { const o = chartOpts(); o.timeScale = { visible: false, borderColor: cv("--line"), rightOffset: 8, barSpacing: 8 }; o.layout.attributionLogo = false; return o; }   // atıf logosu ana grafikte duruyor
const THEMES = ["dark", "black", "light", "halloween", "neon", "ocean", "forest", "sunset", "matrix"];
function setThemeClass() { if (!THEMES.includes(S.theme)) S.theme = "dark"; document.documentElement.style.colorScheme = S.theme === "light" ? "light" : "dark"; document.body.classList.remove(...THEMES.map((k) => "theme-" + k)); document.body.classList.add("theme-" + S.theme); }     // diğer sınıfları (mobil "m", "cap") silme
function applyTheme() { S._tr = null;
  setThemeClass();
  C.main && C.main.applyOptions(chartOpts()); [C.p1, C.p2].forEach((c) => c && c.applyOptions(paneOpts()));
}

/* ---------- grafik nesneleri ---------- */
const C = { main: null, p1: null, p2: null, ser: {}, p1s: {}, p2s: {}, lines: [] };
function mk() {
  C.main = LightweightCharts.createChart($("#chart"), chartOpts());
  C.p1 = LightweightCharts.createChart($("#pane1"), paneOpts());
  C.p2 = LightweightCharts.createChart($("#pane2"), paneOpts());
  C.main.subscribeClick((p) => { if (!S.opts.heat || !p.point) return; const z = S.hz; if (z && z.box) { const b = z.box, x = p.point.x, y = p.point.y; if (x >= b.x && x <= b.x + b.w && y >= b.y && y <= b.y + b.h) { if (x > b.x + b.w - 40 && y < b.y + 38) { S.hz = null; drawOverlay(); } return; } } const pr = C.ser && C.ser.candle ? C.ser.candle.coordinateToPrice(p.point.y) : null; S.hz = pr != null && S.data ? zoneAt(pr) : null; drawOverlay(); });
  const s = C.ser;
  s.candle = C.main.addCandlestickSeries({ upColor: TV.up, downColor: TV.down, borderVisible: false, wickUpColor: TV.up, wickDownColor: TV.down, priceLineColor: "#787b86" });
  s.vol = C.main.addHistogramSeries({ priceFormat: { type: "volume" }, priceScaleId: "vol", lastValueVisible: false, priceLineVisible: false });
  C.main.priceScale("vol").applyOptions({ scaleMargins: { top: 0.84, bottom: 0 } });
  const L = (color, w = 1, extra = {}) => C.main.addLineSeries(Object.assign({ color, lineWidth: w, lastValueVisible: false, priceLineVisible: false, crosshairMarkerVisible: false }, extra));
  s.ema21 = L("#ffb74d", 1); s.ema50 = L("#42a5f5", 1); s.ema200 = L("#ab47bc", 2); s.vwap = L("#fdd835", 1, { lineStyle: 2 });
  s.bbu = L("#2962ff", 1); s.bbl = L("#2962ff", 1); s.bbm = L("#2962ff", 1, { lineStyle: 2 });
  s.st = L(TV.up, 2); s.tenkan = L("#2962ff", 1); s.kijun = L("#b71c1c", 1); s.spana = L("rgba(8,153,129,.7)", 1); s.spanb = L("rgba(242,54,69,.7)", 1);
  s.sar = L("#e0e0e0", 1, { lineVisible: false, pointMarkersVisible: true, pointMarkersRadius: 1.5 });
  // alt paneller
  C.p1s.delta = C.p1.addHistogramSeries({ priceFormat: { type: "volume" }, lastValueVisible: false, priceLineVisible: false });
  C.p1s.cvd = C.p1.addLineSeries({ color: "#fdd835", lineWidth: 1, priceScaleId: "cvd", lastValueVisible: false, priceLineVisible: false });
  C.p1.priceScale("cvd").applyOptions({ scaleMargins: { top: 0.1, bottom: 0.1 } });
  // ana grafikten alt panellere aralık senkronu
  [C.main, C.p1, C.p2].forEach(hookSync);
  C.main.subscribeCrosshairMove((p) => legend(p));
}
const SYNC = { lock: false };
function hookSync(src) {
  src.timeScale().subscribeVisibleLogicalRangeChange((r) => {
    if (SYNC.lock || !r) return; SYNC.lock = true;
    try { [C.main, C.p1, C.p2].filter((c) => c && c !== src).forEach((c) => c.timeScale().setVisibleLogicalRange(r)); } catch (e) { }
    SYNC.lock = false;
  });
}
function visOpts() {
  const o = S.opts, s = C.ser;
  s.ema21.applyOptions({ visible: o.ema }); s.ema50.applyOptions({ visible: o.ema }); s.ema200.applyOptions({ visible: o.ema });
  s.vwap.applyOptions({ visible: o.vwap }); ["bbu", "bbl", "bbm"].forEach((k) => s[k].applyOptions({ visible: o.bb }));
  s.st.applyOptions({ visible: o.st }); ["tenkan", "kijun"].forEach((k) => s[k].applyOptions({ visible: o.ichi })); ["spana", "spanb"].forEach((k) => s[k].applyOptions({ visible: o.ichi || o.cloud }));
  s.sar.applyOptions({ visible: o.sar });
}

/* ---------- veri yükleme ---------- */
const align = (arr, times, key = "value") => { const m = new Map(arr.map((p) => [p.time, p])); return times.map((t) => { const p = m.get(t); return p && p[key] != null ? { time: loc(t), value: p.value } : { time: loc(t) }; }); };
async function loadChart(reset) {
  const j = await api(`/api/chart?sym=${S.sym}&tf=${S.tf}`);
  if (!j || !j.ready) { $("#loader").classList.remove("hidden"); $("#loader").textContent = j && j.reason ? j.reason : "Veri yükleniyor…"; return false; }
  $("#loader").classList.add("hidden"); { const w = $("#chart-wrap"); if (w) w.classList.remove("swap"); }
  S.data = j;
  const times = j.candles.map((c) => c.time);
  S.times = times.map(loc);
  const pf = { type: "price", precision: dec(S.sym), minMove: Math.pow(10, -dec(S.sym)) };
  C.ser.candle.applyOptions({ priceFormat: pf });
  C.ser.candle.setData(j.candles.map((c) => ({ time: loc(c.time), open: c.open, high: c.high, low: c.low, close: c.close })));
  C.ser.vol.setData(j.candles.map((c) => ({ time: loc(c.time), value: c.volume, color: c.close >= c.open ? "rgba(8,153,129,.35)" : "rgba(242,54,69,.35)" })));
  const sr = j.series;
  ["ema21", "ema50", "ema200", "vwap", "bbu", "bbl", "bbm", "tenkan", "kijun", "spana", "spanb", "sar"].forEach((k) => C.ser[k].setData(align(sr[k] || [], times)));
  const stm = new Map(sr.st_dir.map((p) => [p.time, p.v]));
  C.ser.st.setData(align(sr.st_line, times).map((p) => (p.value == null ? p : Object.assign(p, { color: stm.get(p.time - OFF) > 0 ? TV.up : TV.down }))));
  const dm = new Map(sr.delta.map((p) => [p.time, p.value]));
  C.p1s.delta.setData(times.map((t) => (dm.has(t) ? { time: loc(t), value: dm.get(t), color: dm.get(t) >= 0 ? "rgba(8,153,129,.8)" : "rgba(242,54,69,.8)" } : { time: loc(t) })));
  C.p1s.cvd.setData(align(sr.cvd, times));
  $("#pane1-title").textContent = j.real_flow ? "Delta (taker alış − satış, GERÇEK) + CVD" : "Delta (VEKİL: mum içi konum; gerçek order flow yok) + CVD";
  setPane2();
  visOpts();
  markers();
  if (reset || S.loadedKey !== S.sym + S.tf) {
    const n = j.candles.length;
    C.main.timeScale().setVisibleLogicalRange({ from: Math.max(0, n - 130), to: n + 10 });
    S.loadedKey = S.sym + S.tf;
  }
  S.candleLast = j.candles[j.candles.length - 1];
  return true;
}
function setPane2() {
  if (!S.data) return;
  const times = S.data.candles.map((c) => c.time), sr = S.data.series;
  C.p2.remove(); C.p2 = LightweightCharts.createChart($("#pane2"), paneOpts());
  const L = (c, w = 1, e = {}) => C.p2.addLineSeries(Object.assign({ color: c, lineWidth: w, lastValueVisible: true, priceLineVisible: false }, e));
  const m = S.pane2;
  if (m === "adx") {
    const a = L("#e0e0e0", 2); a.setData(align(sr.adx, times)); a.createPriceLine({ price: 16, color: TV.orange, lineStyle: 2, lineWidth: 1, axisLabelVisible: true, title: "16" }); a.createPriceLine({ price: 25, color: TV.muted, lineStyle: 2, lineWidth: 1, axisLabelVisible: true, title: "25" });
    L(TV.up, 1).setData(align(sr.pdi, times)); L(TV.down, 1).setData(align(sr.mdi, times));
  } else if (m === "rsi") {
    const a = L("#b388ff", 2); a.setData(align(sr.rsi, times)); [30, 50, 70].forEach((p) => a.createPriceLine({ price: p, color: TV.muted, lineStyle: 2, lineWidth: 1, axisLabelVisible: false }));
  } else if (m === "srsi") {
    const a = L("#2962ff", 2); a.setData(align(sr.srsi_k, times)); L("#ff9800", 1).setData(align(sr.srsi_d, times)); [20, 80].forEach((p) => a.createPriceLine({ price: p, color: TV.muted, lineStyle: 2, lineWidth: 1, axisLabelVisible: false }));
  } else if (m === "macd") {
    const h = C.p2.addHistogramSeries({ lastValueVisible: false, priceLineVisible: false }); const hm = new Map(sr.macdh.map((p) => [p.time, p.value]));
    h.setData(times.map((t) => (hm.has(t) ? { time: loc(t), value: hm.get(t), color: hm.get(t) >= 0 ? "rgba(8,153,129,.7)" : "rgba(242,54,69,.7)" } : { time: loc(t) })));
    L("#2962ff", 1).setData(align(sr.macd, times)); L("#ff9800", 1).setData(align(sr.macds, times));
  } else if (m === "mfi") {
    const a = L("#4dd0e1", 2); a.setData(align(sr.mfi, times)); [20, 80].forEach((p) => a.createPriceLine({ price: p, color: TV.muted, lineStyle: 2, lineWidth: 1, axisLabelVisible: false }));
    const b = L("#fdd835", 1, { priceScaleId: "cmf" }); b.setData(align(sr.cmf, times));
  } else if (m === "sq") {
    const h = C.p2.addHistogramSeries({ lastValueVisible: false, priceLineVisible: false }); const hm = new Map(sr.sqmom.map((p) => [p.time, p.value]));
    h.setData(times.map((t) => (hm.has(t) ? { time: loc(t), value: hm.get(t), color: hm.get(t) >= 0 ? "rgba(8,153,129,.75)" : "rgba(242,54,69,.75)" } : { time: loc(t) })));
  }
  hookSync(C.p2);
  const r = C.main.timeScale().getVisibleLogicalRange(); if (r) C.p2.timeScale().setVisibleLogicalRange(r);
}
function markers() {
  if (!S.opts.marks || !S.data) { C.ser.candle.setMarkers([]); return; }
  const bars = S.times, out = [];
  S.sigs.filter((x) => x.sym === S.sym && x.tf === S.tf).forEach((x) => {
    const t = loc(x.ts); let b = null;
    for (let i = bars.length - 1; i >= 0; i--) if (bars[i] <= t) { b = bars[i]; break; }
    if (b == null) return;
    out.push({ time: b, position: x.side === 1 ? "belowBar" : "aboveBar", color: x.side === 1 ? TV.up : TV.down, shape: x.side === 1 ? "arrowUp" : "arrowDown", text: "◉" + (x.side === 1 ? "LONG" : "SHORT") });
  });
  out.sort((a, b) => a.time - b.time);
  C.ser.candle.setMarkers(out);
}

/* ---------- gösterge menüsü ---------- */
function buildMenu() {
  const m = $("#ind-menu");
  m.innerHTML = IND_MENU.map(([g, items]) => `<div class="grp">${g}</div>` + items.map(([k, n]) => `<label><input type="checkbox" data-k="${k}" ${S.opts[k] ? "checked" : ""}> ${n}</label>`).join("")).join("");
  $$("input", m).forEach((i) => (i.onchange = () => { S.opts[i.dataset.k] = i.checked; localStorage.setItem("opts", JSON.stringify(S.opts)); visOpts(); markers(); drawOverlay(); }));
}

/* ---------- üst çubuk ---------- */
function buildTop() {
  $("#syms").innerHTML = SYMS.map((s) => `<div class="symtab" data-s="${s}"><div class="n"><span>${NAMES[s]}</span><span class="dots" id="dots-${s}"></span></div><div class="p"><span id="px-${s}">—</span><span id="ch-${s}"></span></div></div>`).join("");
  $$(".symtab").forEach((e) => (e.onclick = () => setSym(e.dataset.s)));
  $("#tfs").innerHTML = TFS.map((t) => `<button class="tfb" data-t="${t}">${TF_LABEL[t]}</button>`).join("");
  $$(".tfb").forEach((e) => (e.onclick = () => setTf(e.dataset.t)));
  $("#btn-ind").onclick = (e) => { e.stopPropagation(); $("#ind-menu").classList.toggle("hidden"); };
  document.addEventListener("click", (e) => { if (!e.target.closest(".menu")) $("#ind-menu").classList.add("hidden"); });
  window.setNeraTheme = (th) => { const was = S.theme; S.theme = th; localStorage.setItem("theme", th); if (THEME_PAL[th]) { if (!THEME_PAL[was]) localStorage.setItem("nera_pal_prev", JSON.stringify(getPalette())); applyPalette(THEME_PAL[th]); } else if (THEME_PAL[was]) { let p = null; try { p = JSON.parse(localStorage.getItem("nera_pal_prev")); } catch (e) { /* */ } applyPalette(p || PALDEF); } applyTheme(); setPane2(); DT.emit("theme", th); };
  window.setSignalSound = (on) => { S.sound = !!on; localStorage.setItem("sound", S.sound ? "1" : "0"); if (S.sound) { try { thunder(); if ("Notification" in window && Notification.permission === "default") Notification.requestPermission(); } catch (e) { /* yok */ } } };
  $("#btn-sound").onclick = () => { S.sound = !S.sound; localStorage.setItem("sound", S.sound ? "1" : "0"); $("#btn-sound").textContent = S.sound ? "🔊" : "🔇"; if (S.sound) { thunder(); try { const LN = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.LocalNotifications; if (LN) LN.requestPermissions(); else if ("Notification" in window && Notification.permission === "default") Notification.requestPermission(); } catch (e) { /* yok */ } } };
  S.awake = localStorage.getItem("awake") === "1"; markAwake();
  $("#btn-awake").onclick = () => { S.awake = !S.awake; localStorage.setItem("awake", S.awake ? "1" : "0"); markAwake(); setAwake(S.awake); };
  document.addEventListener("visibilitychange", () => { if (!document.hidden && S.awake) setAwake(true); });
  if (S.awake) setAwake(true);
  $("#btn-sound").textContent = S.sound ? "🔊" : "🔇";
  $("#btn-hist").onclick = () => setTab("hist");
  $$("#tabs button").forEach((b) => (b.onclick = () => setTab(b.dataset.tab)));
  $("#pane2-sel").value = S.pane2;
  $("#pane2-sel").onchange = (e) => { S.pane2 = e.target.value; localStorage.setItem("pane2", S.pane2); setPane2(); };
  markTop();
}
let wakeLock = null;
async function setAwake(on) { try { if (on) { if (navigator.wakeLock) wakeLock = await navigator.wakeLock.request("screen"); } else if (wakeLock) { await wakeLock.release(); wakeLock = null; } } catch (e) { /* desteklenmiyor / izin yok */ } }
function markAwake() { const b = $("#btn-awake"); if (b) { b.style.opacity = S.awake ? 1 : 0.45; b.title = S.awake ? "Ekran açık kalıyor (pil harcar)" : "Ekranı açık tut"; } }
function markTop() { $$(".symtab").forEach((e) => e.classList.toggle("active", e.dataset.s === S.sym)); $$(".tfb").forEach((e) => e.classList.toggle("active", e.dataset.t === S.tf)); }
function swapOn() { const w = $("#chart-wrap"); if (w) { w.classList.add("swap"); clearTimeout(w._h); w._h = setTimeout(() => w.classList.remove("swap"), 5000); } }
function setSym(s) { swapOn(); S.sym = s; localStorage.setItem("sym", s); S.data = null; S.ana = null; markTop(); reload(true); }
function setTf(t) { swapOn(); S.tf = t; localStorage.setItem("tf", t); S.data = null; S.ana = null; markTop(); reload(true); }
function setTab(t) {
  S.tab = t; document.body.classList.toggle("sig-hide", t !== "sig"); { const g = $("#ag-graph"); if (g) g.classList.toggle("hidden", t !== "agents"); } requestAnimationFrame(inkTo); $$("#tabs button").forEach((b) => b.classList.toggle("active", b.dataset.tab === t)); $$(".tab").forEach((e) => e.classList.toggle("active", e.id === "tab-" + t));
  if (t === "hist") { S.unseen = 0; badge(); renderHist(); }
  renderTabs();
}
function inkTo() { const b = $("#tabs button.active"), k = $("#tab-ink"); if (b && k) { k.style.width = b.offsetWidth + "px"; k.style.transform = `translateX(${b.offsetLeft}px)`; } }
window.addEventListener("resize", () => inkTo());
function badge() { const b = $("#bolt-badge"); b.textContent = S.unseen; b.classList.toggle("hidden", !S.unseen); }
async function reload(reset) { $("#loader").classList.remove("hidden"); await loadChart(reset); await loadAna(); renderTabs(); drawOverlay(); }

/* ---------- ICT / PA / likidite katmanı (tuval) ---------- */
const cvs = $("#overlay");
function sizeOverlay() { const r = $("#chart-wrap").getBoundingClientRect(), d = Math.min(window.devicePixelRatio || 1, IS_MOB_DPR); if (cvs.width !== Math.round(r.width * d) || cvs.height !== Math.round(r.height * d)) { cvs.width = Math.round(r.width * d); cvs.height = Math.round(r.height * d); cvs.style.width = r.width + "px"; cvs.style.height = r.height + "px"; } return d; }
function drawOverlay() {
  const d = sizeOverlay(), ctx = cvs.getContext("2d");
  ctx.setTransform(d, 0, 0, d, 0, 0); ctx.clearRect(0, 0, cvs.width, cvs.height);
  if (!S.data || !C.main) return;
  const ts = C.main.timeScale(), sr = C.ser.candle, W = ts.width(), H = cvs.height / d - 28;
  const X = (t) => { const x = ts.timeToCoordinate(loc(t)); return x == null ? (S.times.length && loc(t) < S.times[0] ? 0 : W) : x; };
  const Y = (p) => sr.priceToCoordinate(p);
  const smc = S.data.smc, o = S.opts;
  drawHeatBg(X, Y, W, H);
  const band = (x0, x1, y0, y1, fill, stroke, dash) => { if (y0 == null || y1 == null) return; x0 = Math.max(0, Math.min(W, x0)); x1 = Math.max(0, Math.min(W, x1)); if (x1 <= x0) return; ctx.fillStyle = fill; ctx.fillRect(x0, Math.min(y0, y1), x1 - x0, Math.abs(y1 - y0)); if (stroke) { ctx.strokeStyle = stroke; ctx.setLineDash(dash || []); ctx.strokeRect(x0 + .5, Math.min(y0, y1) + .5, x1 - x0, Math.abs(y1 - y0)); ctx.setLineDash([]); } };
  const hline = (p, x0, x1, color, dash, w = 1) => { const y = Y(p); if (y == null) return null; ctx.strokeStyle = color; ctx.lineWidth = w; ctx.setLineDash(dash || []); ctx.beginPath(); ctx.moveTo(Math.max(0, x0), y + .5); ctx.lineTo(Math.min(W, x1), y + .5); ctx.stroke(); ctx.setLineDash([]); ctx.lineWidth = 1; return y; };
  const txt = (s, x, y, color, size = 11, align = "left", bold = false) => { ctx.font = `${bold ? "700 " : ""}${size}px Trebuchet MS, Segoe UI, sans-serif`; ctx.fillStyle = color; ctx.textAlign = align; ctx.fillText(s, x, y); };
  ctx.save(); ctx.beginPath(); ctx.rect(0, 0, W, H + 28); ctx.clip();
  // kill zone seansları
  if (o.sess) {
    const cs = S.data.candles; let seg = null; const segs = [];
    cs.forEach((c) => { const h = new Date(c.time * 1000).getUTCHours(); const k = h >= 7 && h < 10 ? "L" : h >= 12 && h < 15 ? "N" : h >= 1 && h < 5 ? "A" : ""; if (seg && seg.k === k) seg.t1 = c.time; else { seg = { k, t0: c.time, t1: c.time }; segs.push(seg); } });
    const col = { L: "rgba(41,98,255,.07)", N: "rgba(255,152,0,.07)", A: "rgba(171,71,188,.06)" }, nm = { L: "Londra KZ", N: "New York KZ", A: "Asya" };
    segs.forEach((s) => { if (!s.k) return; const x0 = X(s.t0), x1 = X(s.t1) + 6; if (x1 < 0 || x0 > W) return; ctx.fillStyle = col[s.k]; ctx.fillRect(Math.max(0, x0), 0, x1 - Math.max(0, x0), H); if (x1 - x0 > 70) txt(nm[s.k], Math.max(2, x0) + 3, 12, TV.muted, 10); });
  }
  // Ichimoku bulutu
  if (o.cloud) {
    const A = S.data.series.spana, B = S.data.series.spanb, bm = new Map(B.map((p) => [p.time, p.value]));
    let prev = null;
    A.forEach((p) => { const b = bm.get(p.time); if (b == null) { prev = null; return; } const x = X(p.time), ya = Y(p.value), yb = Y(b); if (ya == null || yb == null) { prev = null; return; }
      if (prev && x <= W + 10 && x >= -10) { ctx.fillStyle = p.value >= b ? "rgba(8,153,129,.16)" : "rgba(242,54,69,.16)"; ctx.beginPath(); ctx.moveTo(prev.x, prev.ya); ctx.lineTo(x, ya); ctx.lineTo(x, yb); ctx.lineTo(prev.x, prev.yb); ctx.closePath(); ctx.fill(); }
      prev = { x, ya, yb }; });
  }
  // premium / discount + OTE
  if (o.pdz && smc.pd) {
    const p = smc.pd; band(0, W, Y(p.hi), Y(p.eq), "rgba(242,54,69,.045)"); band(0, W, Y(p.eq), Y(p.lo), "rgba(8,153,129,.045)");
    const ye = hline(p.eq, 0, W, "rgba(120,123,134,.7)", [5, 4]); if (ye != null) txt("EQ 50%", 6, ye - 3, TV.muted, 10);
    band(0, W, Y(p.ote[1]), Y(p.ote[0]), "rgba(255,152,0,.10)"); const yo = Y(p.ote[1]); if (yo != null) txt("OTE", 6, yo + 11, TV.orange, 10);
    txt("PREMIUM", W - 6, (Y(p.hi) || 0) + 12, "rgba(242,54,69,.7)", 10, "right"); txt("DISCOUNT", W - 6, (Y(p.lo) || 0) - 4, "rgba(8,153,129,.8)", 10, "right");
  }
  // hacim profili (sağ kenar)
  if (o.vp && smc.vp) {
    const vp = smc.vp, mx = Math.max(...vp.bins.map((b) => b.v)), wmax = W * 0.14;
    vp.bins.forEach((b) => { const y0 = Y(b.hi), y1 = Y(b.lo); if (y0 == null || y1 == null) return; const inVA = b.lo >= vp.val - 1e-9 && b.hi <= vp.vah + 1e-9; ctx.fillStyle = inVA ? "rgba(41,98,255,.28)" : "rgba(120,123,134,.22)"; const w = wmax * b.v / mx; ctx.fillRect(W - w, y0, w, Math.max(1, y1 - y0 - 1)); });
    [[vp.poc, "POC", TV.orange], [vp.vah, "VAH", TV.cyan], [vp.val, "VAL", TV.cyan]].forEach(([p, n, c]) => { const y = hline(p, W * 0.72, W, c, [3, 3]); if (y != null) txt(n + " " + fp(p), W - wmax - 4, y - 2, c, 10, "right"); });
  }
  // order block / FVG
  if (o.ob) smc.obs.forEach((ob) => { const x0 = X(ob.t), c = ob.dir > 0 ? "8,153,129" : "242,54,69"; band(x0, W, Y(ob.hi), Y(ob.lo), `rgba(${c},${ob.fresh ? .22 : .12})`, `rgba(${c},.7)`); const y = Y(ob.hi); if (y != null) txt((ob.dir > 0 ? "Boğa OB" : "Ayı OB") + (ob.fresh ? " ●" : ""), Math.max(4, x0) + 4, y + 11, `rgba(${c},1)`, 10); });
  if (o.fvg) smc.fvgs.forEach((f) => { const x0 = X(f.t), c = f.dir > 0 ? "77,208,225" : "171,71,188"; band(x0, W, Y(f.hi), Y(f.lo), `rgba(${c},.13)`, `rgba(${c},.55)`, [3, 3]); const y = Y(f.hi); if (y != null) txt("FVG" + (f.tested ? " (test)" : ""), Math.max(4, x0) + 4, y + 10, `rgba(${c},1)`, 10); });
  // likidite havuzları
  if (o.liq) {
    const seen = {}, px0 = S.candleLast ? S.candleLast.close : smc.price;
    const lq = smc.liq.filter((q) => !q.swept), up = lq.filter((q) => q.p > px0).sort((a, b) => a.p - b.p).slice(0, 4), dn = lq.filter((q) => q.p <= px0).sort((a, b) => b.p - a.p).slice(0, 4);
    [...up, ...dn].forEach((q) => { const key = Math.round(q.p * 100); if (seen[key]) return; seen[key] = 1; const c = q.side === "buy" ? "#ef5350" : "#26a69a"; const y = hline(q.p, X(q.t), W, c, [2, 4], 1); if (y != null) txt((q.side === "buy" ? "BSL " : "SSL ") + q.k + (q.n > 1 ? " ×" + q.n : "") + " " + fp(q.p), W - 4 - (o.vp ? W * 0.0 : 0), y - 3, c, 10, "right"); });
    smc.sweeps.forEach((s) => { const x = X(s.t); const y = Y(s.ext); if (y == null) return; ctx.fillStyle = s.dir > 0 ? TV.up : TV.down; ctx.beginPath(); ctx.arc(x, y + (s.dir > 0 ? 9 : -9), 4, 0, 7); ctx.fill(); txt("süpürme", x, y + (s.dir > 0 ? 24 : -16), ctx.fillStyle, 9, "center"); });
  }
  if (o.sr) smc.sr.forEach((q) => { const y = hline(q.p, 0, W, "rgba(209,212,220,.35)", [1, 3]); if (y != null) txt(q.k + " " + q.n + "×", 6, y - 2, "rgba(209,212,220,.6)", 9); });
  if (o.fib && smc.fib) Object.entries(smc.fib.lv).forEach(([r, p]) => { const y = hline(p, 0, W, "rgba(253,216,53,.45)", [2, 3]); if (y != null) txt("Fib " + r, 6, y - 2, "rgba(253,216,53,.8)", 9); });
  // yapı
  if (o.struct) {
    smc.events.forEach((e) => { const x0 = X(e.from_t), x1 = X(e.t), y = Y(e.level); if (y == null) return; const c = e.dir > 0 ? TV.up : TV.down; ctx.strokeStyle = c; ctx.setLineDash([4, 3]); ctx.beginPath(); ctx.moveTo(Math.max(0, x0), y); ctx.lineTo(x1, y); ctx.stroke(); ctx.setLineDash([]); txt(e.type, (Math.max(0, x0) + x1) / 2, y + (e.dir > 0 ? -4 : 11), c, 10, "center", e.type === "CHoCH"); });
    smc.swings.forEach((s) => { if (!s.lab) return; const y = Y(s.p); if (y == null) return; txt(s.lab, X(s.t), s.k === "H" ? y - 6 : y + 14, s.lab[0] === "H" ? TV.up : TV.down, 10, "center", true); });
  }
  drawHeat(ctx, o, X, Y, W, H, txt);
  if (o.liqmap || o.whales || o.pulse2) drawMaps(ctx, o, X, Y, W, H, txt);
  if (o.money) drawMoney(ctx, X, Y, W, H, txt); else moneyCard(null);
  // sinyal planı (TradingView pozisyon aracı gibi)
  if (o.plan) { const pl = currentPlan(); if (pl) drawPlan(ctx, pl, X, Y, W, band, hline, txt); }
  ctx.restore();
}
/* ---------- order flow haritaları: Likidasyon · Balina · Pulse v2 (TradingView'daki kapalı kaynaklı göstergelerin kendi hesabımızla yapılan karşılıkları) ---------- */
const usdS = (x) => "$" + (x >= 1e9 ? (x / 1e9).toFixed(2) + "B" : x >= 1e6 ? (x / 1e6).toFixed(2) + "M" : x >= 1e3 ? (x / 1e3).toFixed(0) + "K" : x.toFixed(0));
function feedWh(fl) {                                           // canlı büyük işlem + tasfiye akışını oturum boyunca biriktirir (aynı olay iki kez eklenmez)
  if (!fl) return; const w = S.wh = S.wh || {}, a = w[S.sym] = w[S.sym] || { big: [], liq: [], seen: new Set() };
  [["big", fl.big], ["liq", fl.liq]].forEach(([k, arr]) => (arr || []).forEach((e) => { const id = k + e.t + "|" + e.p + "|" + Math.round(e.usd); if (a.seen.has(id)) return; a.seen.add(id); a[k].push(e); if (a[k].length > 250) a[k].shift(); if (a.seen.size > 2000) a.seen.clear(); }));
}
function liqModel() {                                           // tahmini tasfiye seviyeleri: her mum fiyat-hacim ağırlıklı giriş sayılır; 10/25/50/100x kaldıraç; fiyatın sonradan geçtiği seviye tasfiye edilmiş sayılıp silinir
  const cs = S.data.candles, n = cs.length, key = S.sym + S.tf + cs[n - 1].time + ":" + n; if (S._lm && S._lm.key === key) return S._lm;
  const sl = new Array(n + 1), sh = new Array(n + 1); sl[n] = Infinity; sh[n] = -Infinity; for (let i = n - 1; i >= 0; i--) { sl[i] = Math.min(sl[i + 1], cs[i].low); sh[i] = Math.max(sh[i + 1], cs[i].high); }
  const s0 = Math.max(0, n - 400); let lo = Infinity, hi = -Infinity; for (let i = s0; i < n; i++) { lo = Math.min(lo, cs[i].low); hi = Math.max(hi, cs[i].high); }
  const pad = (hi - lo) * 0.3, a0 = lo - pad, NB = 150, st = (hi + pad - a0) / NB, Lg = new Float64Array(NB), Sh = new Float64Array(NB);
  for (let i = s0; i < n; i++) { const c = cs[i], typ = (c.high + c.low + c.close) / 3, v = c.volume || 1;
    for (const [lev, w] of [[10, 0.15], [25, 0.3], [50, 0.35], [100, 0.2]]) { const pl = typ * (1 - 1 / lev + 0.005), ps = typ * (1 + 1 / lev - 0.005);
      if (sl[i + 1] > pl) { const b = Math.floor((pl - a0) / st); if (b >= 0 && b < NB) Lg[b] += v * w; }
      if (sh[i + 1] < ps) { const b = Math.floor((ps - a0) / st); if (b >= 0 && b < NB) Sh[b] += v * w; } } }
  let mx = 0; for (let b = 0; b < NB; b++) mx = Math.max(mx, Lg[b], Sh[b]);
  const peak = (A) => { let bi = -1; for (let b = 0; b < NB; b++) if (bi < 0 || A[b] > A[bi]) bi = b; return A[bi] > 0 ? a0 + (bi + 0.5) * st : null; };
  return (S._lm = { key, a0, st, NB, Lg, Sh, mx: mx || 1, pl: peak(Lg), ps: peak(Sh) });
}
function whaleModel() {                                         // hacim ani sıçramalı mumlar (z>2.2) + delta yönü
  const cs = S.data.candles, n = cs.length, key = S.sym + S.tf + cs[n - 1].time + ":" + n; if (S._wm && S._wm.key === key) return S._wm;
  const dm = new Map((S.data.series.delta || []).map((p) => [p.time, p.value])), out = [];
  for (let i = 40; i < n; i++) { let m = 0, q = 0; for (let k = i - 40; k < i; k++) m += cs[k].volume; m /= 40; for (let k = i - 40; k < i; k++) q += (cs[k].volume - m) ** 2; const sd = Math.sqrt(q / 40) || 1, z = (cs[i].volume - m) / sd; if (z > 2.2) { const d = dm.get(cs[i].time), side = d != null && d !== 0 ? Math.sign(d) : Math.sign(cs[i].close - cs[i].open) || 1; out.push({ t: cs[i].time, p: cs[i].close, z, side }); } }
  return (S._wm = { key, out });
}
function pulseModel() {                                         // Pulse (RSI+StochRSI+CCI+MACD bileşiği) 3'lü EMA ile yumuşatılır; ±25 eşik geçişleri sinyal oklarıdır
  const ps = S.data.series.pulse || [], key = S.sym + S.tf + (ps.length ? ps[ps.length - 1].time : 0) + ":" + ps.length; if (S._pm && S._pm.key === key) return S._pm;
  const out = []; let e = null; ps.forEach((p, i) => { e = e == null ? p.value : e + (p.value - e) * 0.5; out.push({ t: p.time, v: e, x: i && out[i - 1].v <= 25 && e > 25 ? 1 : i && out[i - 1].v >= -25 && e < -25 ? -1 : 0 }); });
  return (S._pm = { key, out });
}
/* ---------- sıcaklık haritaları ----------
   1) heat: Binance emir defteri (derinlik) 5 sn'de bir okunur, zaman×fiyat ızgarasında birikir. Bekleyen limit emirler = alıcıların/satıcıların beklediği, hedef ve stop'ların yığıldığı seviyeler.
   2) exheat: gerçekleşen alım/satım; her mumun hacmi aralığına yayılır, yeşil = alıcı baskın, kırmızı = satıcı baskın (geçmişten hemen çizilir).
   Kimin nerede ne hedef koyduğu hiçbir yerde görünmez; bunlar emir defteri ve işlem verisinden çıkan vekil göstergelerdir. */
const HM = { st: {}, busy: false, last: 0, ver: 0 };
async function pollDepth() {
  if (HM.busy || !(S.opts.heat || S.opts.money) || S.sym === "EURUSD" || document.hidden || Date.now() - HM.last < 4500 || (S.tk && S.tk.watch && S.tk.watch[S.sym] && S.tk.watch[S.sym].closed)) return; HM.busy = true; HM.last = Date.now();
  try {
    const sym = S.sym, r = await fetch(`https://fapi.binance.com/fapi/v1/depth?symbol=${sym}&limit=1000`), j = await r.json(); if (!j.bids || sym !== S.sym) return;
    const px = (+j.bids[0][0] + +j.asks[0][0]) / 2, h = HM.st[sym] = HM.st[sym] || { step: px * 0.0003, slots: new Map(), snap: null };
    const m = new Map(); j.bids.forEach(([p, q]) => { const b = Math.floor(+p / h.step); m.set(b, (m.get(b) || 0) + p * q); }); j.asks.forEach(([p, q]) => { const b = Math.floor(+p / h.step); m.set(b, (m.get(b) || 0) - p * q); });
    const slot = Math.floor(Date.now() / 30000) * 30; const old = h.slots.get(slot); if (old) m.forEach((v, b) => { const o2 = old.get(b); if (o2 === undefined || Math.abs(v) > Math.abs(o2)) old.set(b, v); }); else { h.slots.set(slot, m); if (h.slots.size > 1500) h.slots.delete(h.slots.keys().next().value); }
    h.snap = { bids: j.bids.slice(0, 1000).map(([p, q]) => [+p, p * q]), asks: j.asks.slice(0, 1000).map(([p, q]) => [+p, p * q]) }; HM.ver++;
  } catch (e) { /* ağ yok: sonraki turda yeniden denenir */ } finally { HM.busy = false; }
}
setInterval(pollDepth, 1500);
function heatModel() {
  const h = HM.st[S.sym], cs = S.data.candles, n = cs.length, stp = cs[1].time - cs[0].time, key = S.sym + S.tf + HM.ver + ":" + cs[n - 1].time; if (!h) return null; if (S._hm && S._hm.key === key) return S._hm;
  const bars = new Map(); h.slots.forEach((m, slot) => { const bt = Math.floor(slot / stp) * stp; let a = bars.get(bt); if (!a) bars.set(bt, (a = new Map())); m.forEach((v, b) => { const o2 = a.get(b); if (o2 === undefined || Math.abs(v) > Math.abs(o2)) a.set(b, v); }); });
  const all = []; bars.forEach((a) => a.forEach((v) => all.push(Math.abs(v)))); all.sort((x, y) => x - y); const ref = all.length ? all[Math.floor(all.length * 0.93)] || all[all.length - 1] : 1;
  let wb = null, wa = null; if (h.snap) { h.snap.bids.forEach(([p, u]) => { if (!wb || u > wb[1]) wb = [p, u]; }); h.snap.asks.forEach(([p, u]) => { if (!wa || u > wa[1]) wa = [p, u]; }); }
  return (S._hm = { key, bars, ref, step: h.step, stp, wb, wa, slots: h.slots.size });
}
const HCOL = [[0, 8, 10, 36, 0], [0.16, 28, 36, 130, 0.38], [0.34, 0, 150, 140, 0.58], [0.52, 105, 205, 45, 0.7], [0.7, 240, 212, 30, 0.8], [0.86, 255, 125, 20, 0.88], [1, 232, 40, 44, 0.94]];
function heatRGBA(k) {                                          // video'daki gibi: koyu → mavi → yeşil → sarı → turuncu → kırmızı
  k = Math.max(0, Math.min(1, k)); let i = 1; while (i < HCOL.length - 1 && HCOL[i][0] < k) i++; const a = HCOL[i - 1], b = HCOL[i], u = (k - a[0]) / (b[0] - a[0] || 1), m = (j) => a[j] + (b[j] - a[j]) * u;
  return `rgba(${Math.round(m(1))},${Math.round(m(2))},${Math.round(m(3))},${(m(4) * 0.72).toFixed(3)})`;
}
function exModel() {                                            // gerçekleşen işlem yoğunluğu ızgarası (mum × fiyat satırı); delta ile alıcı/satıcı payı
  const cs = S.data.candles, n = cs.length, key = S.sym + S.tf + cs[n - 1].time + ":" + n; if (S._em && S._em.key === key) return S._em;
  const dm = new Map((S.data.series.delta || []).map((p) => [p.time, p.value])), s0 = Math.max(0, n - 300); let lo = Infinity, hi = -Infinity;
  for (let i = s0; i < n; i++) { lo = Math.min(lo, cs[i].low); hi = Math.max(hi, cs[i].high); }
  const pad = (hi - lo) * 0.25, a0 = lo - pad, NB = 110, st = (hi + pad - a0) / NB, cols = [], rowV = new Float64Array(NB), rowBuy = new Float64Array(NB); let prev = new Float64Array(NB);
  for (let i = s0; i < n; i++) {
    const c = cs[i], v = (c.volume || 0) * ((c.high + c.low) / 2), d = dm.get(c.time), vv = c.volume || 0, sh = d != null && vv > 0 ? Math.min(1, Math.max(0, (vv + d) / (2 * vv))) : c.close >= c.open ? 0.6 : 0.4;
    const b0 = Math.max(0, Math.floor((c.low - a0) / st)), b1 = Math.min(NB - 1, Math.floor((c.high - a0) / st)), nb = Math.max(1, b1 - b0 + 1), cur = new Float64Array(NB);
    for (let b = b0; b <= b1; b++) { cur[b] = v / nb; rowV[b] += v / nb; rowBuy[b] += (v / nb) * sh; }
    const col = new Float64Array(NB); for (let b = 0; b < NB; b++) { const sm = cur[b] * 0.6 + ((cur[b - 1] || 0) + (cur[b + 1] || 0)) * 0.2; col[b] = Math.max(sm, prev[b] * 0.93); }       // hafif yumuşatma + önceki sütundan soluk devam (yatay bölge etkisi)
    cols.push({ t: c.time, v: col, sh }); prev = col;
  }
  const all = []; cols.forEach((c) => c.v.forEach((x) => x > 0 && all.push(x))); all.sort((x, y) => x - y); const ref = all.length ? all[Math.floor(all.length * 0.96)] || all[all.length - 1] : 1;
  let tot = 0; for (let b = 0; b < NB; b++) tot += rowV[b];
  return (S._em = { key, cols, a0, st, NB, ref, rowV, rowBuy, tot });
}
function zoneAt(price) {                                        // tıklanan fiyat çevresindeki 4 satırlık bölge: hacim, pay, alış/satış baskısı
  const m = exModel(), b = Math.floor((price - m.a0) / m.st); if (b < 0 || b >= m.NB) return null; let best = b, bv = 0; for (let k = Math.max(0, b - 2); k <= Math.min(m.NB - 1, b + 2); k++) if (m.rowV[k] > bv) { bv = m.rowV[k]; best = k; }
  let vol = 0, buy = 0; for (let k = Math.max(0, best - 1); k <= Math.min(m.NB - 1, best + 2); k++) { vol += m.rowV[k]; buy += m.rowBuy[k]; }
  return { price: m.a0 + (best + 0.5) * m.st, lo: m.a0 + best * m.st, hi: m.a0 + (best + 1) * m.st, vol, share: m.tot ? vol / m.tot : 0, buy: vol ? buy / vol : 0.5 };
}
function ensureHeatBg() { let h = $("#heatbg"); if (!h) { h = document.createElement("canvas"); h.id = "heatbg"; const w = $("#chart-wrap"); w.insertBefore(h, w.firstChild); } return h; }
function setChartBgTransparent(on) { if (S._tr === on) return; S._tr = on; try { C.main.applyOptions({ layout: { background: { type: "solid", color: on ? "rgba(0,0,0,0)" : cv("--bg") } } }); } catch (e) { /* */ } const h = $("#heatbg"); if (h) h.style.display = on ? "block" : "none"; }
function drawHeatBg(X, Y, W, Hh) {
  const o = S.opts, hb = ensureHeatBg(), d = Math.min(window.devicePixelRatio || 1, IS_MOB_DPR), r = $("#chart-wrap").getBoundingClientRect();
  if (hb.width !== Math.round(r.width * d) || hb.height !== Math.round(r.height * d)) { hb.width = Math.round(r.width * d); hb.height = Math.round(r.height * d); hb.style.width = r.width + "px"; hb.style.height = r.height + "px"; }
  const c = hb.getContext("2d"); c.setTransform(d, 0, 0, d, 0, 0); c.clearRect(0, 0, r.width, r.height); if (!o.heat) { setChartBgTransparent(false); return; } setChartBgTransparent(true);
  c.fillStyle = cv("--bg"); c.fillRect(0, 0, r.width, r.height);
  const cs = S.data.candles, stp = cs[1].time - cs[0].time, m = exModel(), dm = heatModel();
  m.cols.forEach((col) => { const x0 = X(col.t) - 1, x1 = X(col.t + stp) + 1; if (x1 < 0 || x0 > W) return; for (let b = 0; b < m.NB; b++) { const k = Math.sqrt(col.v[b] / m.ref); if (k < 0.16) continue; const y0 = Y(m.a0 + (b + 1) * m.st), y1 = Y(m.a0 + b * m.st); if (y0 == null || y1 == null) continue; c.fillStyle = heatRGBA(k); c.fillRect(x0, y0, Math.max(1, x1 - x0), Math.max(1.5, y1 - y0 + 0.6)); } });
  if (dm) { dm.bars.forEach((a, bt) => { const x0 = X(bt) - 1, x1 = X(bt + dm.stp) + 1; if (x1 < 0 || x0 > W) return; a.forEach((v, b) => { const k = Math.sqrt(Math.abs(v) / dm.ref) * 0.95; if (k < 0.18) return; const y0 = Y((b + 1) * dm.step), y1 = Y(b * dm.step); if (y0 == null || y1 == null) return; c.fillStyle = heatRGBA(k); c.fillRect(x0, y0, Math.max(1, x1 - x0), Math.max(1.5, y1 - y0 + 0.6)); }); }); }
}
function drawHeat(ctx, o, X, Y, W, H, txt) {                    // üst katman: duvar etiketleri + tıklanan bölge (sarı bant + bilgi kutusu)
  if (!o.heat) return; pollDepth(); const m = heatModel();
  if (m && m.wb) { const y = Y(m.wb[0]); if (y != null) txt(`Alış duvarı ${fp(m.wb[0])} · ${usdS(m.wb[1])}`, W - 6, y - 3, "rgba(150,230,255,.95)", 10, "right", true); }
  if (m && m.wa) { const y = Y(m.wa[0]); if (y != null) txt(`Satış duvarı ${fp(m.wa[0])} · ${usdS(m.wa[1])}`, W - 6, y - 3, "rgba(255,190,100,.95)", 10, "right", true); }
  const z = S.hz; if (!z) return; const y0 = Y(z.hi), y1 = Y(z.lo); if (y0 == null || y1 == null) return;
  const g = ctx.createLinearGradient(0, y0, 0, y1); g.addColorStop(0, "rgba(255,196,40,.55)"); g.addColorStop(0.5, "rgba(255,214,70,.95)"); g.addColorStop(1, "rgba(255,196,40,.55)"); ctx.save(); ctx.shadowColor = "rgba(255,190,30,.9)"; ctx.shadowBlur = 14; ctx.fillStyle = g; ctx.fillRect(0, Math.min(y0, y1), W, Math.max(5, Math.abs(y1 - y0))); ctx.restore();
  const bw = Math.min(W - 24, 250), bx = 12, by = Math.max(8, Math.min(y0, y1) - 92), type = z.buy >= 0.5 ? "Alış baskısı bölgesi" : "Satış baskısı bölgesi", col = z.buy >= 0.5 ? "#4fe3b0" : "#ffb04a";
  ctx.fillStyle = "rgba(12,14,22,.94)"; ctx.strokeStyle = "#ff9f2e"; ctx.lineWidth = 2; ctx.beginPath(); (ctx.roundRect ? ctx.roundRect(bx, by, bw, 78, 10) : ctx.rect(bx, by, bw, 78)); ctx.fill(); ctx.stroke(); ctx.lineWidth = 1;
  txt(fp(z.price), bx + 14, by + 26, "#fff", 15, "left", true); txt("Hacim", bx + 14, by + 48, "#9aa3b8", 12); txt(usdS(z.vol), bx + bw - 40, by + 48, "#fff", 14, "right", true); txt(`%${(z.share * 100).toFixed(1)} · ${type}`, bx + 14, by + 68, col, 12, "left", true);
  txt("✕", bx + bw - 16, by + 22, "#cfd5e6", 15, "center"); z.box = { x: bx, y: by, w: bw, h: 78 };
}
/* ---------- Likidite: para nerede? ----------
   Kimin nerede işlem açtığı tek tek görünmez. Paranın toplandığı yeri dört gerçek/vekil kaynaktan birleştiririz:
   1) emir defteri (Binance vadeli, bekleyen limit emirler: aşağıda alış, yukarıda satış duvarları), 2) tahmini tasfiye seviyeleri (liqModel),
   3) stop havuzları (eşit tepe/dipler: üstünde shortların, altında longların stopları birikir), 4) gerçekleşen işlem hacmi (POC, alıcı/satıcı baskın bölge).
   Fiyat çoğu zaman yoğun likiditeye çekilir (mıknatıs); bu bir eğilimdir, kesin değildir. */
function stopPools(cs) {
  const n = cs.length, s0 = Math.max(2, n - 300); let atr = 0; for (let i = n - 14; i < n; i++) atr += cs[i].high - cs[i].low; atr /= 14; const tol = atr * 0.3, H = [], L = [];
  for (let i = s0; i < n - 2; i++) { const c = cs[i]; if (c.high >= cs[i - 1].high && c.high >= cs[i - 2].high && c.high >= cs[i + 1].high && c.high >= cs[i + 2].high) H.push([c.high, i]); if (c.low <= cs[i - 1].low && c.low <= cs[i - 2].low && c.low <= cs[i + 1].low && c.low <= cs[i + 2].low) L.push([c.low, i]); }
  const grp = (A, up) => { const out = []; A.forEach(([p, i]) => { const g = out.find((q) => Math.abs(q.p - p) <= tol); if (g) { g.n++; g.p = up ? Math.max(g.p, p) : Math.min(g.p, p); g.last = Math.max(g.last, i); } else out.push({ p, n: 1, last: i }); });
    return out.filter((g) => { if (g.n < 2) return false; for (let k = g.last + 1; k < n; k++) if (up ? cs[k].high > g.p + tol * 0.2 : cs[k].low < g.p - tol * 0.2) return false; return true; }); };
  return { up: grp(H, true), dn: grp(L, false) };
}
function moneyModel() {
  const cs = S.data.candles, n = cs.length; if (n < 30) return null; const key = S.sym + S.tf + cs[n - 1].time + ":" + n + ":" + HM.ver; if (S._mm && S._mm.key === key) return S._mm;
  const em = exModel(), lm = liqModel(), h = HM.st[S.sym], NB = em.NB, a0 = em.a0, st = em.st, px = cs[n - 1].close, at = (p) => Math.floor((p - a0) / st), pb = at(px);
  const bid = new Float64Array(NB), ask = new Float64Array(NB), lqL = new Float64Array(NB), lqS = new Float64Array(NB), pool = new Float64Array(NB);
  const book = !!(h && h.snap && S.sym !== "EURUSD"); if (book) { h.snap.bids.forEach(([p, u]) => { const b = at(p); if (b >= 0 && b < NB) bid[b] += u; }); h.snap.asks.forEach(([p, u]) => { const b = at(p); if (b >= 0 && b < NB) ask[b] += u; }); }
  for (let b = 0; b < lm.NB; b++) { const k = at(lm.a0 + (b + 0.5) * lm.st); if (k >= 0 && k < NB) { lqL[k] += lm.Lg[b]; lqS[k] += lm.Sh[b]; } }
  const sp = stopPools(cs); [...sp.up, ...sp.dn].forEach((g) => { const k = at(g.p); if (k >= 0 && k < NB) pool[k] += g.n; });
  const mx = (A) => { let m = 0; for (let i = 0; i < NB; i++) m = Math.max(m, A[i]); return m || 1; }, mB = Math.max(mx(bid), mx(ask)), mL = Math.max(mx(lqL), mx(lqS)), mP = mx(pool), mV = mx(em.rowV);
  const comb = new Float64Array(NB); for (let b = 0; b < NB; b++) comb[b] = (book ? 0.42 * (bid[b] + ask[b]) / mB : 0) + (book ? 0.33 : 0.6) * (lqL[b] + lqS[b]) / mL + 0.25 * pool[b] / mP;
  let up = 0, dn = 0, bu = 0, bd = 0, lu = 0, ld = 0; for (let b = 0; b < NB; b++) { if (b > pb) { up += comb[b]; bu += ask[b] + bid[b]; lu += lqS[b] + lqL[b]; } else if (b < pb) { dn += comb[b]; bd += bid[b] + ask[b]; ld += lqL[b] + lqS[b]; } }
  const best = (lo, hi) => { let bi = -1; for (let b = Math.max(0, lo); b <= Math.min(NB - 1, hi); b++) if (bi < 0 || comb[b] > comb[bi]) bi = b; return bi >= 0 && comb[bi] > 0.05 ? { p: a0 + (bi + 0.5) * st, v: comb[bi], b: bi } : null; };
  let poc = 0; for (let b = 1; b < NB; b++) if (em.rowV[b] > em.rowV[poc]) poc = b; let bz = -1, sz = -1, bzv = 0, szv = 0; for (let b = 0; b < NB; b++) { if (em.rowV[b] < mV * 0.35) continue; const sh = em.rowBuy[b] / (em.rowV[b] || 1); if (sh > 0.5 && em.rowV[b] * (sh - 0.5) > bzv) { bzv = em.rowV[b] * (sh - 0.5); bz = b; } if (sh < 0.5 && em.rowV[b] * (0.5 - sh) > szv) { szv = em.rowV[b] * (0.5 - sh); sz = b; } }
  return (S._mm = { key, NB, a0, st, px, pb, bid, ask, lqL, lqS, pool, comb, book, mB, mL, up, dn, upPct: up + dn ? up / (up + dn) : 0.5, bu, bd, lu, ld, sp, magUp: best(pb + 1, NB - 1), magDn: best(0, pb - 1), poc: a0 + (poc + 0.5) * st, bz: bz >= 0 ? a0 + (bz + 0.5) * st : null, sz: sz >= 0 ? a0 + (sz + 0.5) * st : null });
}
function drawMoney(ctx, X, Y, W, H, txt) {
  const m = moneyModel(); if (!m) return; const bw = W * 0.26, by = (b) => [Y(m.a0 + (b + 1) * m.st), Y(m.a0 + b * m.st)];
  for (let b = 0; b < m.NB; b++) { const [y0, y1] = by(b); if (y0 == null || y1 == null) continue; const hgt = Math.max(1.2, y1 - y0 - 0.6), above = b > m.pb;
    const ob = m.book ? (above ? m.ask[b] : m.bid[b]) / m.mB : 0, lq = (above ? m.lqS[b] : m.lqL[b]) / m.mL;
    if (ob > 0.04) { const w = bw * Math.sqrt(ob); ctx.fillStyle = above ? `rgba(242,86,106,${0.18 + 0.55 * ob})` : `rgba(38,198,160,${0.18 + 0.55 * ob})`; ctx.fillRect(W - w, y0, w, hgt); }
    if (lq > 0.06) { const w = bw * 0.75 * Math.sqrt(lq); ctx.fillStyle = above ? `rgba(77,208,196,${0.15 + 0.5 * lq})` : `rgba(255,138,101,${0.15 + 0.5 * lq})`; ctx.fillRect(W - bw - 4 - w, y0 + hgt * 0.2, w, Math.max(1, hgt * 0.6)); } }
  const pl = (g, up) => { const y = Y(g.p); if (y == null) return; ctx.strokeStyle = up ? "rgba(255,210,122,.85)" : "rgba(255,210,122,.85)"; ctx.setLineDash([2, 4]); ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo(0, y + 0.5); ctx.lineTo(W - bw - 8, y + 0.5); ctx.stroke(); ctx.setLineDash([]); ctx.lineWidth = 1; txt(`Stop havuzu ${up ? "▲" : "▼"} ${g.n} eşit ${up ? "tepe" : "dip"} · ${fp(g.p)}`, 8, y - 4, "rgba(255,210,122,.95)", 10, "left", true); };
  m.sp.up.slice(-3).forEach((g) => pl(g, true)); m.sp.dn.slice(-3).forEach((g) => pl(g, false));
  const mag = (g, up) => { if (!g) return; const y = Y(g.p); if (y == null) return; const pulse = 0.55 + 0.45 * Math.sin(Date.now() / 350), col = up ? "242,86,106" : "38,198,160"; const gr = ctx.createLinearGradient(0, 0, W, 0); gr.addColorStop(0, `rgba(${col},0)`); gr.addColorStop(1, `rgba(${col},${0.22 * pulse})`); ctx.fillStyle = gr; ctx.fillRect(0, y - 5, W, 10);
    ctx.strokeStyle = `rgba(${col},.95)`; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(W * 0.25, y + 0.5); ctx.lineTo(W, y + 0.5); ctx.stroke(); ctx.lineWidth = 1; txt(`🧲 ${up ? "Yukarı" : "Aşağı"} mıknatıs ${fp(g.p)} (${up ? "+" : ""}${(((g.p - m.px) / m.px) * 100).toFixed(2)}%)`, W - bw - 10, y + (up ? -7 : 14), `rgb(${col})`, 11, "right", true); };
  mag(m.magUp, true); mag(m.magDn, false);
  const yp = Y(m.poc); if (yp != null) txt("◆ en çok işlem (POC) " + fp(m.poc), W - bw - 10, yp + 3, "rgba(255,210,122,.75)", 9, "right");
  moneyCard(m);
}
function moneyCard(m) {
  let el = document.getElementById("money-card"); if (!m) { if (el) el.remove(); return; } const wrap = document.getElementById("chart-wrap"); if (!wrap) return;
  if (!el) { el = document.createElement("div"); el.id = "money-card"; el.innerHTML = `<div class="mc-h"><b>Para nerede?</b><button class="mc-x" title="küçült">–</button></div><div class="mc-g"><span class="mc-up"></span><span class="mc-dn"></span><i class="mc-px"></i></div><div class="mc-l"><b class="mc-ut"></b><b class="mc-dt"></b></div><div class="mc-rows"></div><div class="mc-n">Tahmindir: emir defteri, tahmini tasfiye, stop havuzu ve işlem hacminden. Fiyat çoğu zaman yoğun likiditeye çekilir; kesin değildir.</div>`; wrap.appendChild(el); el.querySelector(".mc-x").onclick = () => { el.classList.toggle("mini"); localStorage.setItem("nera_mc_mini", el.classList.contains("mini") ? "1" : "0"); }; const mm = localStorage.getItem("nera_mc_mini"); if (mm === "1" || (mm == null && wrap.clientWidth < 760)) el.classList.add("mini"); }
  const now = Date.now(); if (el._t && now - el._t < 900) return; el._t = now; const up = Math.round(m.upPct * 100);
  el.querySelector(".mc-up").style.width = up + "%"; el.querySelector(".mc-dn").style.width = 100 - up + "%"; el.querySelector(".mc-ut").textContent = `▲ Yukarıda %${up}`; el.querySelector(".mc-dt").textContent = `▼ Aşağıda %${100 - up}`;
  el.classList.toggle("bull", up > 55); el.classList.toggle("bear", up < 45);
  const rel = (a, b) => (a + b ? Math.round((a / (a + b)) * 100) : 50), dir = up > 55 ? "Yukarıda daha çok para birikmiş: fiyat yukarı çekilebilir" : up < 45 ? "Aşağıda daha çok para birikmiş: fiyat aşağı çekilebilir" : "Likidite iki tarafta dengeli";
  const rows = [m.book ? ["Emir defteri", `yukarı satış ${usdS(m.bu)} · aşağı alış ${usdS(m.bd)}`] : ["Emir defteri", S.sym === "EURUSD" ? "EUR/USD'de emir defteri yayınlanmıyor" : S.tk && S.tk.watch && S.tk.watch[S.sym] && S.tk.watch[S.sym].closed ? "piyasa kapalı: emir defteri okunmuyor" : "okunuyor…"], ["Tasfiye (tahmini)", `shortlar yukarıda %${rel(m.lu, m.ld)} · longlar aşağıda %${rel(m.ld, m.lu)}`], ["Stop havuzu", `yukarıda ${m.sp.up.length} · aşağıda ${m.sp.dn.length} (eşit tepe/dip)`],
    ["En çok işlem", `${fp(m.poc)}${m.bz ? ` · alıcı bölgesi ${fp(m.bz)}` : ""}${m.sz ? ` · satıcı bölgesi ${fp(m.sz)}` : ""}`], ["Mıknatıs", `${m.magUp ? "▲ " + fp(m.magUp.p) : "—"}  ${m.magDn ? "▼ " + fp(m.magDn.p) : ""}`], ["Sonuç", dir]];
  const h = rows.map(([k, v]) => `<div><span>${k}</span><em>${v}</em></div>`).join(""), r = el.querySelector(".mc-rows"); if (r._h !== h) { r._h = h; r.innerHTML = h; }
}
function drawMaps(ctx, o, X, Y, W, H, txt) {
  const cs = S.data.candles, stp = cs.length > 1 ? cs[1].time - cs[0].time : 900, snap = (t) => Math.floor(t / stp) * stp, wh = (S.wh && S.wh[S.sym]) || { big: [], liq: [] };
  if (o.liqmap) {
    const m = liqModel(), bw = W * 0.34, draw = (A, rgb) => { for (let b = 0; b < m.NB; b++) { const v = A[b] / m.mx; if (v < 0.05) continue; const y0 = Y(m.a0 + (b + 1) * m.st), y1 = Y(m.a0 + b * m.st); if (y0 == null || y1 == null) continue; ctx.fillStyle = `rgba(${rgb},${0.12 + 0.6 * v})`; const w = bw * Math.sqrt(v); ctx.fillRect(W - w, y0, w, Math.max(1.5, y1 - y0 - 0.5)); } };
    draw(m.Lg, "255,112,67"); draw(m.Sh, "38,198,160");
    if (m.pl != null) { const y = Y(m.pl); if (y != null) txt("Long tasfiye yoğunluğu " + fp(m.pl), W - bw - 6, y + 3, "rgba(255,138,101,.95)", 10, "right"); }
    if (m.ps != null) { const y = Y(m.ps); if (y != null) txt("Short tasfiye yoğunluğu " + fp(m.ps), W - bw - 6, y + 3, "rgba(77,208,196,.95)", 10, "right"); }
    wh.liq.forEach((e) => { const x = X(snap(e.t)), y = Y(e.p); if (y == null) return; const r = Math.min(15, 3 + Math.sqrt(e.usd / 15000)), c = e.side < 0 ? "255,112,67" : "38,198,160"; ctx.fillStyle = `rgba(${c},.35)`; ctx.strokeStyle = `rgba(${c},.95)`; ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill(); ctx.stroke(); if (r > 8) txt(usdS(e.usd), x, y - r - 3, `rgb(${c})`, 9, "center"); });
    txt("Tahmini seviyeler (hacim × kaldıraç); daireler = gerçekleşen tasfiyeler", 6, H - 24, "rgba(180,188,205,.6)", 9);
  }
  if (o.whales) {
    whaleModel().out.forEach((w) => { const x = X(w.t), y = Y(w.p); if (y == null || x < -20 || x > W + 20) return; const r = Math.min(17, 4 + (w.z - 2.2) * 3.2), c = w.side > 0 ? "80,225,195" : "242,80,95"; ctx.fillStyle = `rgba(${c},.34)`; ctx.strokeStyle = `rgba(${c},.95)`; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill(); ctx.stroke(); ctx.lineWidth = 1; });
    let nb = 0, ns = 0, ub = 0, us = 0; wh.big.forEach((e) => { const x = X(snap(e.t)), y = Y(e.p); if (e.side > 0) { nb++; ub += e.usd; } else { ns++; us += e.usd; } if (y == null) return; const r = Math.min(18, 4 + Math.sqrt(e.usd / 25000)), c = e.side > 0 ? "38,198,160" : "242,54,69"; ctx.strokeStyle = `rgba(${c},1)`; ctx.fillStyle = `rgba(${c},.3)`; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill(); ctx.stroke(); ctx.lineWidth = 1; });
    const net = ub - us; txt(`Balina akışı (oturum): ${net >= 0 ? "+" : "−"}${usdS(Math.abs(net))} · alım ${nb} · satım ${ns}`, 6, H - 10, net >= 0 ? "#26a69a" : "#ef5350", 10, "left", true);
  }
  if (o.pulse2) {
    const P = pulseModel().out; let prev = null, last = null;
    P.forEach((p) => { const x = X(p.t); if (prev != null && x >= -4 && x <= W + 4) { const a = Math.min(1, Math.abs(p.v) / 70); ctx.fillStyle = p.v >= 0 ? `rgba(8,153,129,${0.15 + 0.7 * a})` : `rgba(242,54,69,${0.15 + 0.7 * a})`; ctx.fillRect(prev, 3, Math.max(1, x - prev + 1), 5); } prev = x; last = p;
      if (p.x) { const cd = cs.find((c) => c.time === p.t); if (!cd) return; const y = Y(p.x > 0 ? cd.low : cd.high); if (y == null) return; ctx.fillStyle = p.x > 0 ? TV.up : TV.down; ctx.beginPath(); if (p.x > 0) { ctx.moveTo(x, y + 6); ctx.lineTo(x - 5, y + 15); ctx.lineTo(x + 5, y + 15); } else { ctx.moveTo(x, y - 6); ctx.lineTo(x - 5, y - 15); ctx.lineTo(x + 5, y - 15); } ctx.closePath(); ctx.fill(); } });
    if (last) { const v = last.v; txt(`PULSE v2β ${v >= 0 ? "+" : ""}${v.toFixed(0)} · ${v > 50 ? "güçlü yukarı" : v > 25 ? "yukarı" : v < -50 ? "güçlü aşağı" : v < -25 ? "aşağı" : "nötr"}`, 6, 22, v > 25 ? "#26a69a" : v < -25 ? "#ef5350" : TV.muted, 10, "left", true); }
  }
}
function currentPlan() {
  const ev = S.ana && S.ana.eval;
  if (ev && ev.state !== "BEKLE" && ev.plan) return Object.assign({}, ev.plan, { t: S.candleLast ? S.candleLast.time : ev.t, live: true, setup: ev.setup });
  const open = S.sigs.find((x) => x.sym === S.sym && x.tf === S.tf && x.status === "açık");
  if (open) return { side: open.side, entry: open.entry, stop: open.stop, tp1: open.tp1, tp2: open.tp2, risk: open.risk, r1: open.r1, r2: open.r2, t: open.ts, live: false, setup: open.setup };
  return null;
}
function drawPlan(ctx, p, X, Y, W, band, hline, txt) {
  const x0 = X(p.t), x1 = Math.min(W - 4, x0 + Math.max(160, W * 0.28)), yE = Y(p.entry), yS = Y(p.stop), y1 = Y(p.tp1), y2 = Y(p.tp2);
  if (yE == null || yS == null || y1 == null) return;
  const g = p.side === 1;
  band(x0, x1, yE, y2 == null ? y1 : y2, "rgba(8,153,129,.07)"); band(x0, x1, yE, y1, "rgba(8,153,129,.22)"); band(x0, x1, yE, yS, "rgba(242,54,69,.22)");
  [[p.entry, "#d1d4dc", []], [p.stop, TV.down, [5, 3]], [p.tp1, TV.up, [5, 3]], [p.tp2, "rgba(8,153,129,.7)", [2, 4]]].forEach(([v, c, d]) => hline(v, x0, W, c, d, 1.5));
  const lab = (y, s, c) => { ctx.font = "700 11px Trebuchet MS, Segoe UI"; const w = ctx.measureText(s).width + 10; ctx.fillStyle = c; ctx.fillRect(x1 - w, y - 8, w, 16); txt(s, x1 - w + 5, y + 4, "#fff", 11, "left", true); };
  lab(yS, `Stop −${dist(p.risk)}`, "rgba(242,54,69,.95)"); lab(y1, `Hedef 1 +${dist(Math.abs(p.tp1 - p.entry))} · ${p.r1.toFixed(1)}R`, "rgba(8,153,129,.95)");
  if (y2 != null) lab(y2, `Hedef 2 +${dist(Math.abs(p.tp2 - p.entry))} · ${p.r2.toFixed(1)}R`, "rgba(8,153,129,.7)");
  lab(yE, `${g ? "LONG" : "SHORT"} ${p.live ? "(canlı)" : ""} giriş ${fp(p.entry)}`, g ? "rgba(8,153,129,.95)" : "rgba(242,54,69,.95)");
}

/* ---------- açıklamalar / sağ panel ---------- */
function legend(p) {
  const c = p && p.seriesData ? p.seriesData.get(C.ser.candle) : null; const lc = c || (S.candleLast && { open: S.candleLast.open, high: S.candleLast.high, low: S.candleLast.low, close: S.candleLast.close });
  if (!lc) return;
  const a = S.ana && S.ana.eval;
  $("#legend").innerHTML = `<b>${NAMES[S.sym]}</b> · ${TF_LABEL[S.tf]} <span>A <b class="${cls(lc.close - lc.open)}">${fp(lc.open)}</b></span><span>Y <b class="${cls(lc.close - lc.open)}">${fp(lc.high)}</b></span><span>D <b class="${cls(lc.close - lc.open)}">${fp(lc.low)}</b></span><span>K <b class="${cls(lc.close - lc.open)}">${fp(lc.close)}</b></span>`
    + (a ? `<span>ADX <b>${a.adx.toFixed(0)}</b></span><span>ATR <b>${fp(a.atr)}</b></span>` : "");
}
const bar = (v, w = 130) => { const x = Math.max(-1, Math.min(1, v)), c = x >= 0 ? TV.up : TV.down; return `<div class="vbar" style="width:${w}px"><b style="background:${c};${x >= 0 ? "left:50%;" : `left:${50 + x * 50}%;`}width:${Math.abs(x) * 50}%"></b></div>`; };
function renderSig() {
  const el = $("#tab-sig"), a = S.ana, ev = a && a.eval;
  if (!ev) { setHtml(el, `<div class="empty">${S.reason || "Analiz hazırlanıyor…"}</div>`); return; }
  const cls2 = ev.state === "LONG" ? "L" : ev.state === "SHORT" ? "S" : "W";
  const risk = ev.agents.find((x) => x.name === "Risk");
  let h = `<div class="state"><span class="pill ${cls2}">${ev.state === "LONG" ? "LONG ▲" : ev.state === "SHORT" ? "SHORT ▼" : "BEKLE"}</span>
    <div class="meter"><div class="t"><span>Canlı analiz skoru ${ev.score >= 0 ? "+" : ""}${ev.score.toFixed(2)}</span><span>${ev.agree} ajan uyumlu</span></div>
    <div class="mbar"><b style="background:${ev.score >= 0 ? TV.up : TV.down};${ev.score >= 0 ? "left:50%" : `left:${50 + ev.score * 100}%`};width:${Math.abs(ev.score) * 100}%"></b><i style="left:calc(${50 + ev.score * 100}% - 1px)"></i></div>
    <div class="t" style="margin-top:6px"><span>${NAMES[S.sym]} · ${TF_LABEL[S.tf]}</span><span>fiyat ${fp(ev.price)}</span></div></div></div>`;
  if (ev.state === "BEKLE") {
    h += `<div class="box"><h4>Neden işlem yok?</h4><ul class="why">${ev.why_wait.map((x) => `<li>${x}</li>`).join("")}</ul></div>`;
  } else {
    const p = ev.plan, g = p.side === 1;
    const qty = S.sym === "EURUSD" ? `${(p.risk_usd / (p.risk * 10000 * 10)).toFixed(2)} lot` : `${p.qty >= 100 ? p.qty.toFixed(0) : p.qty >= 1 ? p.qty.toFixed(2) : p.qty.toFixed(4)} ${S.sym.replace("USDT", "")}`;
    h += `<div class="box"><h4>${ev.setup} · ${g ? "LONG" : "SHORT"} önerisi</h4>
      <div class="goal"><div class="stop"><div class="l">STOP</div><div class="v down">−${dist(p.risk)}</div><div class="l">${fp(p.stop)} · %${p.stop_pct.toFixed(2)}</div></div>
      <div class="tgt"><div class="l">HEDEF 1 (${p.tp1_basis})</div><div class="v up">+${dist(Math.abs(p.tp1 - p.entry))}</div><div class="l">${fp(p.tp1)} · ${p.r1.toFixed(1)}R</div></div></div>
      <table class="plan"><tr><td>Giriş (güncel fiyat)</td><td>${fp(p.entry)}</td></tr><tr><td>Hedef 2 (${p.tp2_basis})</td><td class="up">${fp(p.tp2)} · +${dist(Math.abs(p.tp2 - p.entry))} · ${p.r2.toFixed(1)}R</td></tr>
      <tr><td>Stop dayanağı</td><td class="mut" style="font-weight:400">${p.stop_basis} · ${p.stop_atr.toFixed(1)} ATR</td></tr>
      <tr><td>Risk tutarı <input class="num" id="riskusd" value="${S.risk}"> $</td><td>≈ ${qty}</td></tr></table>
      <div class="mini" style="margin-top:4px">Örnek: ${dist(p.risk)} stop, ${dist(Math.abs(p.tp1 - p.entry))} hedef ⇒ ${p.r1.toFixed(1)} kazanç : 1 kayıp. Pozisyon büyüklüğü, stop çalışırsa tam olarak ${p.risk_usd}$ kaybettirecek şekilde hesaplanır (komisyon/kayma hariç).</div></div>
      <div class="box"><h4>Neden bu işlem?</h4>${ev.reasons.map((r) => `<div><b>${r.icon} ${r.agent}</b><ul class="why">${r.pts.map((x) => `<li>${x}</li>`).join("")}</ul></div>`).join("")}</div>
      <div class="box"><h4>Ne kadar yanılabilir?</h4><div class="big-num"><span class="down">%${(ev.wrong.baseline_loss * 100).toFixed(0)}</span> <span class="mut" style="font-size:12px">stop ihtimali (avantajsız piyasa)</span></div>
      <div class="mini" style="margin:4px 0">${ev.wrong.text}</div>${measured(ev)}<div class="honest">${ev.invalid}</div></div>`;
  }
  if (risk) {
    h += `<div class="box"><h4>Risk <span class="risk-chip rk-${risk.label.split(" ")[0]}">${risk.label}</span> <span class="mut">(${risk.score}/100)</span></h4><ul class="why">${risk.why.map((x) => `<li>${x}</li>`).join("")}</ul>
      <div class="mini">ATR %${risk.atr_pct.toFixed(2)} · yüzdelik ${(risk.atr_pctile * 100).toFixed(0)} · kaldıraç ne olursa olsun stopta kayıp = seçtiğin risk tutarı, ama gap/kayma bunu aşabilir.</div></div>`;
  }
  h += `<div class="honest">Hiçbir strateji/ajan kombinasyonu geçmiş testlerde (2011-2026, çoklu-test düzeltmeli) kanıtlı avantaj göstermedi. Sinyal = bilgi; tavsiye değil. Gerçek para riski senin sorumluluğun.</div>`;
  setHtml(el, h, () => { const ri = $("#riskusd"); if (ri) ri.onchange = async () => { S.risk = parseFloat(ri.value) || 50; await api("/api/settings", { method: "POST", body: JSON.stringify({ risk_usd: S.risk }) }); loadAna(); }; });
}
/** Yerinde (flicker'sız) güncelleme: yeni HTML ile mevcut DOM'u karşılaştırıp sadece değişen metin/özellikleri yamar. Düğümler korunur: animasyon yeniden başlamaz, kaydırma/odak bozulmaz. */
function morph(a, b) {
  const ac = [...a.childNodes], bc = [...b.childNodes];
  for (let i = 0; i < bc.length; i++) {
    const x = ac[i], y = bc[i];
    if (!x) { a.appendChild(y.cloneNode(true)); continue; }
    if (x.nodeType !== y.nodeType || x.nodeName !== y.nodeName) { a.replaceChild(y.cloneNode(true), x); continue; }
    if (x.nodeType === 3 || x.nodeType === 8) { if (x.data !== y.data) x.data = y.data; continue; }
    if (x.nodeType === 1) {
      for (const at of [...x.attributes]) if (!y.hasAttribute(at.name)) x.removeAttribute(at.name);
      for (const at of [...y.attributes]) { if (x.nodeName === "INPUT" && at.name === "value" && document.activeElement === x) continue; if (x.getAttribute(at.name) !== at.value) x.setAttribute(at.name, at.value); }
      if (x.nodeName === "INPUT" && document.activeElement !== x && x.value !== y.getAttribute("value")) x.value = y.getAttribute("value") || "";
      morph(x, y);
    }
  }
  for (let i = ac.length - 1; i >= bc.length; i--) a.removeChild(ac[i]);
}
function setHtml(el, html, after) { if (el._h === html) return; el._h = html; const t = document.createElement("template"); t.innerHTML = html; morph(el, t.content); if (after) after(); }
function measured(ev) {
  const st = ev.wrong.measured, all = S.stats["*"];
  if (st && st.n >= 5) return `<div class="mini">Bu kurulum türünde botun KENDİ ölçümü: ${st.n} sinyal, hedefe ulaşan %${(st.win * 100).toFixed(0)} (%80 aralık ${(st.lo * 100).toFixed(0)}–${(st.hi * 100).toFixed(0)}), ortalama net ${st.avg_r.toFixed(2)}R ${st.n < 30 ? "· <b>örnek küçük, güvenilmez</b>" : ""}</div>`;
  return `<div class="mini">${all ? `Botun toplam ölçümü: ${all.n} sonuçlanmış sinyal, hedefe ulaşan %${(all.win * 100).toFixed(0)}, ort. net ${all.avg_r.toFixed(2)}R. ` : ""}Bu kurulum türü için henüz yeterli ölçüm yok: kazanma oranı BİLİNMİYOR.</div>`;
}
function renderAgents() {
  const el = $("#tab-agents"), ev = S.ana && S.ana.eval; if (!ev) { setHtml(el, '<div class="empty">Hazırlanıyor…</div>'); return; }
  let h = `<div class="box"><h4>Koordinatör</h4><div class="agent"><div class="hd"><b>Ağırlıklı skor</b>${bar(ev.score, 160)}<span class="${cls(ev.score)}">${ev.score >= 0 ? "+" : ""}${ev.score.toFixed(2)}</span></div>
    <div class="mini">Giriş koşulları: |skor| ≥ 0.25 · en az 3 ajan aynı yönde · ADX ≥ 16 (yatayda yalnız likidite süpürme / order flow dönüşü) · güçlü ters ajan yok · risk vetosu yok. Şu an: ${ev.state}${ev.why_wait.length ? " — " + ev.why_wait[0] : ""}</div></div></div>`;
  ev.agents.forEach((a) => {
    if (a.name === "Risk") { h += `<div class="box agent"><div class="hd"><b>${a.icon} Risk yöneticisi</b><span class="risk-chip rk-${a.label.split(" ")[0]}">${a.label}</span></div><ul class="why">${a.why.map((x) => `<li>${x}</li>`).join("")}</ul></div>`; return; }
    h += `<div class="box agent"><div class="hd"><b>${a.icon} ${a.name}</b>${bar(a.vote)}<span class="${cls(a.vote)}">${a.vote >= 0 ? "+" : ""}${a.vote.toFixed(2)}</span></div><div class="mini">güven ${(a.conf * 100).toFixed(0)}%</div><ul class="why">${a.why.map((x) => `<li>${x}</li>`).join("")}</ul></div>`;
  });
  setHtml(el, h);
}
function gauge(score, label, s) {
  const a = Math.PI * (1 - (score + 1) / 2), cx = 50, cy = 50, r = 38, x = cx + r * Math.cos(a), y = cy - r * Math.sin(a);
  const txt = score > 0.5 ? "Güçlü Al" : score > 0.15 ? "Al" : score < -0.5 ? "Güçlü Sat" : score < -0.15 ? "Sat" : "Nötr", c = score > 0.15 ? TV.up : score < -0.15 ? TV.down : TV.muted;
  return `<div class="gauge"><svg viewBox="0 0 100 58"><path d="M12 50 A38 38 0 0 1 88 50" fill="none" stroke="#2a2e39" stroke-width="7" stroke-linecap="round"/><path d="M12 50 A38 38 0 0 1 31 17" fill="none" stroke="${TV.down}" stroke-width="7" stroke-linecap="round" opacity=".6"/><path d="M69 17 A38 38 0 0 1 88 50" fill="none" stroke="${TV.up}" stroke-width="7" stroke-linecap="round" opacity=".6"/><line x1="${cx}" y1="${cy}" x2="${x}" y2="${y}" stroke="${c}" stroke-width="3" stroke-linecap="round"/><circle cx="${cx}" cy="${cy}" r="4" fill="${c}"/></svg><div class="gv" style="color:${c}">${txt}</div><div class="gl">${label}</div><div class="gl"><span class="down">${s.sell}</span> · ${s.neutral} · <span class="up">${s.buy}</span></div></div>`;
}
const IR = { shown: 0, prev: {}, e: {} };
function renderInd() {
  const el = $("#tab-ind"), a = S.ana && S.ana.ind; if (!a || !a.ma) { if (!el.querySelector("#ind-ring")) setHtml(el, '<div class="empty">Hazırlanıyor…</div>'); return; }
  if (!el.querySelector("#ind-ring")) { el._h = null; el.innerHTML = '<div class="indhero"><canvas id="ind-ring"></canvas><div class="indc"><b id="ic-b">—</b><span>META ÖZET</span><em id="ic-e"></em></div></div><div class="grpbars" id="ic-g"></div><div class="indgrp" id="ic-body"></div>'; el._ic = 1; }
  const all = a.sum.all, txt = all.score > 0.5 ? "Güçlü Al" : all.score > 0.15 ? "Al" : all.score < -0.5 ? "Güçlü Sat" : all.score < -0.15 ? "Sat" : "Nötr", col = all.score > 0.15 ? "var(--up)" : all.score < -0.15 ? "var(--down)" : "var(--muted)";
  const b = $("#ic-b", el); b.textContent = txt; b.style.color = col; $("#ic-e", el).textContent = `${all.sell} sat · ${all.neutral} nötr · ${all.buy} al`;
  const grp = (n, s) => `<div class="gb"><div class="t">${n}</div><div class="bar3"><i style="flex-grow:${s.sell};background:var(--down)"></i><i style="flex-grow:${s.neutral};background:var(--muted);opacity:.5"></i><i style="flex-grow:${s.buy};background:var(--up)"></i></div><div class="n"><span class="down">${s.sell}</span><span>${s.neutral}</span><span class="up">${s.buy}</span></div></div>`;
  setHtml($("#ic-g", el), grp("OSİLATÖR", a.sum.osc) + grp("META", a.sum.all) + grp("ORT. & TREND", a.sum.ma));
  const row = (r, i) => `<div class="vrow" style="--i:${i}"><span class="vn">${r.n}</span><span class="vv">${r.v}</span><span class="vp ${r.o > 0 ? "b" : r.o < 0 ? "s" : "n"}">${r.o > 0 ? "AL" : r.o < 0 ? "SAT" : "NÖTR"}</span></div>`;
  setHtml($("#ic-body", el), `<h4>Hareketli ortalamalar &amp; trend</h4>${a.ma.map(row).join("")}<h4>Osilatörler &amp; order flow</h4>${a.osc.map((r, i) => row(r, i + a.ma.length)).join("")}`);
}
TICKS.push((dt, t) => {                                   // konsensüs halkası: her gösterge halka üzerinde bir nöron, merkezde meta özet küresi
  const cv = $("#ind-ring"); if (!cv || !vis(cv) || !S.ana || !S.ana.ind || !S.ana.ind.ma) return; const w = cv.parentElement.clientWidth, h = 210, c = fitCanvas(cv, w, h), a = S.ana.ind, rows = [...a.ma, ...a.osc], sc = a.sum.all.score;
  const cx = w / 2, cy = h / 2, R = Math.min(w, h) * 0.44, up = "#26c6a0", dn = "#f2566a"; IR.shown += (sc - IR.shown) * Math.min(1, dt * 1.4); c.clearRect(0, 0, w, h);
  const bg = c.createRadialGradient(cx, cy, 4, cx, cy, R * 1.5); bg.addColorStop(0, "rgba(138,123,255,.10)"); bg.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = bg; c.fillRect(0, 0, w, h);
  c.lineCap = "round"; c.strokeStyle = "rgba(120,140,200,.18)"; c.lineWidth = 6; c.beginPath(); c.arc(cx, cy, R, 0, 6.3); c.stroke();
  const ang = IR.shown * Math.PI, a0 = -Math.PI / 2, col = sc >= 0 ? up : dn; c.strokeStyle = col; c.shadowColor = col; c.shadowBlur = 12; c.lineWidth = 6; c.beginPath(); c.arc(cx, cy, R, a0, a0 + ang, ang < 0); c.stroke(); c.shadowBlur = 0;
  const hx = cx + Math.cos(a0 + ang) * R, hy = cy + Math.sin(a0 + ang) * R, hg = c.createRadialGradient(hx, hy, 0, hx, hy, 16); hg.addColorStop(0, "rgba(255,255,255,.95)"); hg.addColorStop(0.35, col); hg.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = hg; c.fillRect(hx - 16, hy - 16, 32, 32);
  const N = rows.length, rr = R * 0.7, br = 1 + 0.04 * Math.sin(t * 1.6);
  rows.forEach((r, i) => { const key = r.n, v = r.o > 0 ? 1 : r.o < 0 ? -1 : 0; if (IR.prev[key] !== undefined && IR.prev[key] !== v) IR.e[key] = 1; IR.prev[key] = v; const e = IR.e[key] = (IR.e[key] || 0) * Math.pow(0.15, dt);
    const an = -Math.PI / 2 + (i / N) * 6.2832 + t * 0.07, x = cx + Math.cos(an) * rr * br, y = cy + Math.sin(an) * rr * br, cc = v > 0 ? up : v < 0 ? dn : "#7a8199";
    c.strokeStyle = cc; c.globalAlpha = v ? 0.16 + e * 0.5 : 0.06; c.lineWidth = 1; c.beginPath(); c.moveTo(cx, cy); c.lineTo(x, y); c.stroke(); c.globalAlpha = 1;
    const g = c.createRadialGradient(x, y, 0, x, y, 9 + e * 9); g.addColorStop(0, cc); g.addColorStop(1, "rgba(0,0,0,0)"); c.globalAlpha = v ? 0.55 + e * 0.4 : 0.25; c.fillStyle = g; c.fillRect(x - 18, y - 18, 36, 36); c.globalAlpha = 1; c.fillStyle = v ? "#fff" : cc; c.beginPath(); c.arc(x, y, 2.4 + e * 2, 0, 6.3); c.fill(); });
  const og = c.createRadialGradient(cx, cy, 0, cx, cy, R * 0.5 * br); og.addColorStop(0, sc > 0.15 ? "rgba(38,198,160,.38)" : sc < -0.15 ? "rgba(242,86,106,.38)" : "rgba(138,123,255,.32)"); og.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = og; c.beginPath(); c.arc(cx, cy, R * 0.5 * br, 0, 6.3); c.fill();
});
let AG = null, agSeen = null;
window.AGFIRE = (ev) => {
  const cv = $("#ag-graph canvas"); if (!cv || !ev) return;
  if (!AG) { const ids = ev.agents.map((_, i) => "a" + i), nodes = ids.map((id, i) => ({ id, x: (i + 0.5) / ids.length, y: 0.2, r: 4.5, col: "#8a7bff" })).concat([{ id: "hub", x: 0.5, y: 0.78, r: 8, col: "#ffb04a", label: "koordinatör" }]); AG = new NeuroGraph(cv, nodes, ids.map((i) => [i, "hub"]), { idle: false, curve: 0, labels: true }); }
  if (agSeen === ev) return; agSeen = ev; let k = 0;
  ev.agents.forEach((a, i) => { const col = a.name === "Risk" ? "#ff9800" : a.vote > 0.05 ? "#26c6a0" : a.vote < -0.05 ? "#f2566a" : "#8c96af", n = AG.byId["a" + i]; if (n) { n.label = a.name === "Risk" ? "Risk" : a.name.split(" ")[0].slice(0, 7); setTimeout(() => AG.fire("a" + i, col, 0.4 + Math.abs(a.vote), 0, "hub"), k * 110); k++; } });
  setTimeout(() => AG.fire("hub", ev.score > 0.15 ? "#26c6a0" : ev.score < -0.15 ? "#f2566a" : "#ffb04a", 1, 0), k * 110 + 650);
};
function renderHist() {
  const el = $("#tab-hist"), all = S.stats["*"];
  const sig = S.sigs;
  let h = `<div class="box"><h4>◉ Sinaps geçmişi · Nera sinyalleri (kâğıt üstü ölçüm)</h4>${all ? `<div>Sonuçlanan: <b>${all.n}</b> · hedefe ulaşan <b>%${(all.win * 100).toFixed(0)}</b> (%80 aralık ${(all.lo * 100).toFixed(0)}–${(all.hi * 100).toFixed(0)}) · ort. net <b class="${cls(all.avg_r)}">${all.avg_r.toFixed(2)}R</b> (komisyon dahil)</div>` : '<div class="mini">Henüz sonuçlanmış sinyal yok.</div>'}
    <div class="honest">Ölçüm, sinyalin sonrasını 1 dk mumlarla izler: stop mu hedef mi önce. Örnek küçükken oranlara güvenme.</div></div>`;
  if (!sig.length) h += '<div class="empty">Henüz sinaps (sinyal) yok. Sinyal, taranan aralıklarda (5m/15m/1H/4H) bir mum kapanınca koşullar sağlanırsa gelir.</div>';
  sig.forEach((x) => {
    const g = x.side === 1, stt = x.status === "açık" ? "açık" : x.status;
    const res = x.net_r != null ? `${x.net_r >= 0 ? "+" : ""}${x.net_r.toFixed(2)}R` : "";
    h += `<div class="sg" data-id="${x.id}"><div class="r1"><span class="chip ${g ? "L" : "S"}">${g ? "LONG" : "SHORT"}</span><b>${NAMES[x.sym]} · ${TF_LABEL[x.tf]}</b><span class="st-${stt}">${stt === "TP1" ? "✓ hedef" : stt === "SL" ? "✗ stop" : stt === "açık" ? "● açık" : "⏱ süre"} ${res}</span></div>
      <div class="mini">${dtm(x.ts)} · ${x.setup} · skor ${x.score >= 0 ? "+" : ""}${x.score.toFixed(2)} · risk ${x.risk_label}</div>
      <div class="mini">Giriş ${fp(x.entry, x.sym)} · Stop ${fp(x.stop, x.sym)} (−${dist(x.risk, x.sym)}) · Hedef ${fp(x.tp1, x.sym)} (+${dist(Math.abs(x.tp1 - x.entry), x.sym)}, ${x.r1.toFixed(1)}R)</div>
      <div class="mini">${(x.reasons || []).slice(0, 3).join(" · ")}</div></div>`;
  });
  setHtml(el, h, () => $$(".sg", el).forEach((e) => (e.onclick = () => { const x = S.sigs.find((s) => s.id == e.dataset.id); if (x) { S.sym = x.sym; S.tf = x.tf; localStorage.setItem("sym", x.sym); localStorage.setItem("tf", x.tf); markTop(); reload(true); if (window.MOBILE) window.MOBILE.mTab("chart"); } })));
}
function renderCal() {
  const el = $("#tab-cal"), now = Date.now() / 1000;
  const h = `<div class="box"><h4>Makro takvim (yerel saat)</h4><table class="t">${S.cal.map((e) => { const m = Math.round((e.t - now) / 60), s = m < 0 ? `${-m} dk önce` : m < 60 ? `${m} dk` : m < 1440 ? `${Math.floor(m / 60)} sa ${m % 60} dk` : `${Math.floor(m / 1440)} g ${Math.floor((m % 1440) / 60)} sa`; return `<tr><td>${e.name}</td><td>${new Date(e.t * 1000).toLocaleString("tr-TR", { weekday: "short", day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" })}</td><td class="${m >= 0 && m <= 60 ? "warn" : "mut"}">${s}</td></tr>`; }).join("")}</table>
    <div class="honest">Kaynak: federalreserve.gov (FOMC), bls.gov (CPI, NFP) planlanan tarihleri. Olaydan 20 dk önce ve 10 dk sonra yeni sinyal verilmez; risk skoru yükselir.</div></div>`;
  setHtml(el, h);
}
function renderTabs() { ({ sig: renderSig, agents: renderAgents, ind: renderInd, hist: renderHist, cal: renderCal })[S.tab](); }

/* ---------- order flow şeridi ---------- */
function renderFlow(f) {
  const el = $("#flow-card");
  if (!f) { el.innerHTML = `<div class="card-title">Order flow</div><div class="mini">${S.sym === "EURUSD" ? "EUR/USD spot FX: gerçek order flow verisi yok (delta VEKİL: mum içi konum)." : "Bağlanıyor…"}</div>`; drawFootprint(null); $("#big-card").innerHTML = ""; return; }
  const tot = f.buy5 + f.sell5, bp = tot ? f.buy5 / tot : 0.5, d5 = f.buy5 - f.sell5, d1 = f.cur_buy - f.cur_sell;
  el.innerHTML = `<div class="card-title">Canlı order flow · GERÇEK <small>(taker agresör)</small></div>
    <div class="kv"><span>Son 5 dk alış / satış</span><span><b class="up">${num(f.buy5)}</b> / <b class="down">${num(f.sell5)}</b></span></div><div class="bar"><i style="width:${bp * 100}%"></i></div>
    <div class="kv"><span>Delta 5 dk</span><b class="${cls(d5)}">${d5 >= 0 ? "+" : ""}${num(d5)}</b></div><div class="kv"><span>Delta bu dk</span><b class="${cls(d1)}">${d1 >= 0 ? "+" : ""}${num(d1)}</b></div>
    <div class="kv"><span>CVD (oturum)</span><b class="${cls(f.cvd)}">${f.cvd >= 0 ? "+" : ""}${num(f.cvd)}</b></div>
    <div class="kv"><span>Bid / Ask</span><span>${fp(f.bid)} (${num(f.bidq)}) / ${fp(f.ask)} (${num(f.askq)})</span></div><canvas id="cvdspark" height="34" style="width:100%"></canvas>`;
  const cvs2 = $("#cvdspark"); if (cvs2 && f.cvd_hist.length > 2) { cvs2.width = cvs2.clientWidth * 2; cvs2.height = 68; const c = cvs2.getContext("2d"), v = f.cvd_hist.map((x) => x[1]).concat([f.cvd]), mn = Math.min(...v), mx = Math.max(...v), rg = mx - mn || 1; c.strokeStyle = f.cvd >= v[0] ? TV.up : TV.down; c.lineWidth = 2; c.beginPath(); v.forEach((y, i) => { const px = (i / (v.length - 1)) * cvs2.width, py = 66 - ((y - mn) / rg) * 62; i ? c.lineTo(px, py) : c.moveTo(px, py); }); c.stroke(); }
  drawFootprint(f);
  const row = (x, kind) => `<div class="row"><span class="${x.side > 0 ? "up" : "down"}">${x.side > 0 ? "▲" : "▼"} ${hhmm(x.t)}</span><span>${fp(x.p)}</span><b>${num(x.usd)}$</b></div>`;
  $("#big-card").innerHTML = `<div class="col2"><div class="card-title">Büyük işlemler</div>${f.big.slice(0, 8).map(row).join("") || '<div class="mini">henüz yok</div>'}</div><div class="col2"><div class="card-title">Tasfiyeler</div>${f.liq.slice(0, 8).map((x) => `<div class="row"><span class="${x.side > 0 ? "up" : "down"}">${x.side > 0 ? "kısa" : "uzun"} ${hhmm(x.t)}</span><span>${fp(x.p)}</span><b>${num(x.usd)}$</b></div>`).join("") || '<div class="mini">henüz yok</div>'}</div>`;
}
function drawFootprint(f) {
  const c = $("#fp"), d = Math.min(window.devicePixelRatio || 1, IS_MOB_DPR), w = c.clientWidth, h = c.clientHeight; if (c.width !== Math.round(w * d)) { c.width = Math.round(w * d); c.height = Math.round(h * d); }
  const x = c.getContext("2d"); x.setTransform(d, 0, 0, d, 0, 0); x.clearRect(0, 0, w, h);
  if (!f || !f.fp.length) { x.fillStyle = TV.muted; x.font = "12px Trebuchet MS"; x.fillText(f ? "Veri toplanıyor…" : "—", 8, 18); return; }
  const cols = f.fp.slice(-8), allp = [...new Set(cols.flatMap((m) => m.bins.map((b) => b[0])))].sort((a, b) => b - a);
  const mid = f.price || allp[0]; let rows = allp.sort((a, b) => Math.abs(a - mid) - Math.abs(b - mid)).slice(0, 12).sort((a, b) => b - a);
  if (!rows.length) return;
  const rh = Math.max(12, Math.floor((h - 14) / rows.length)), cw = Math.floor((w - 62) / cols.length), mx = Math.max(...cols.flatMap((m) => m.bins.map((b) => b[1] + b[2]))) || 1;
  x.font = "10px Trebuchet MS"; x.textBaseline = "middle";
  rows.forEach((p, i) => { x.fillStyle = Math.abs(p - mid) < (f.step || 1) * 0.6 ? TV.yellow : TV.muted; x.textAlign = "right"; x.fillText(fp(p), 56, 8 + i * rh + rh / 2); });
  cols.forEach((m, ci) => {
    const bm = new Map(m.bins.map((b) => [b[0], b])); let poc = null, pv = 0; m.bins.forEach((b) => { if (b[1] + b[2] > pv) { pv = b[1] + b[2]; poc = b[0]; } });
    rows.forEach((p, i) => { const b = bm.get(p); const x0 = 62 + ci * cw, y0 = 8 + i * rh; if (!b) return; const lo = bm.get(rows[i + 1]), up = bm.get(rows[i - 1]); const bi = b[1] > 3 * ((lo && lo[2]) || 1e-12) && b[1] > 0, si = b[2] > 3 * ((up && up[1]) || 1e-12) && b[2] > 0;
      const iv = Math.min(1, (b[1] + b[2]) / mx), a = 0.12 + iv * 0.55; x.fillStyle = b[1] >= b[2] ? `rgba(8,153,129,${a})` : `rgba(242,54,69,${a})`; x.fillRect(x0 + 1, y0, cw - 2, rh - 1);
      if (bi || si) { x.strokeStyle = bi ? TV.up : TV.down; x.lineWidth = 1.5; x.strokeRect(x0 + 1.5, y0 + .5, cw - 3, rh - 2); }
      if (p === poc) { x.strokeStyle = TV.yellow; x.lineWidth = 1; x.strokeRect(x0 + .5, y0 - .5, cw - 1, rh); }
      x.fillStyle = "#e8eaed"; x.textAlign = "center"; x.fillText(`${num(b[2])}×${num(b[1])}`, x0 + cw / 2, y0 + rh / 2); });
    x.fillStyle = TV.muted; x.textAlign = "center"; x.fillText(hhmm(m.t), 62 + ci * cw + cw / 2, h - 5);
  });
}

/* ---------- şimşek animasyonu ---------- */
let audio = null;
/** Bildirim sesi: kısa yumuşak "zap" (şimşek çıtırtısı) + üç notalı çan arpeji (LONG yükselen, SHORT alçalan) + hafif alt gürleme + yankı. Sert gürültü yok. */
function bell(ctx, dest, f, t, dur) {
  [[1, 0.5], [2, 0.16], [3.01, 0.06]].forEach(([m, a]) => {
    const o = ctx.createOscillator(), g = ctx.createGain(); o.type = "sine"; o.frequency.value = f * m;
    g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(a, t + 0.008); g.gain.exponentialRampToValueAtTime(0.0008, t + dur);
    o.connect(g); g.connect(dest); o.start(t); o.stop(t + dur + 0.05);
  });
}
function thunder(side = 1) {
  if (window.Sound) { Sound.signal(side); return; }
  try {
    audio = audio || new (window.AudioContext || window.webkitAudioContext)(); const ctx = audio; if (ctx.state === "suspended") ctx.resume();
    const t0 = ctx.currentTime + 0.02, master = ctx.createGain(); master.gain.value = 0.5; master.connect(ctx.destination);
    const dl = ctx.createDelay(0.5), fb = ctx.createGain(), lp = ctx.createBiquadFilter(); dl.delayTime.value = 0.16; fb.gain.value = 0.3; lp.type = "lowpass"; lp.frequency.value = 3000;
    master.connect(dl); dl.connect(lp); lp.connect(fb); fb.connect(dl); lp.connect(ctx.destination);                       // yankı
    const len = Math.floor(ctx.sampleRate * 0.14), nb = ctx.createBuffer(1, len, ctx.sampleRate), d = nb.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 3);
    const ns = ctx.createBufferSource(), bp = ctx.createBiquadFilter(), zg = ctx.createGain(); ns.buffer = nb; bp.type = "bandpass"; bp.Q.value = 0.9; bp.frequency.setValueAtTime(5200, t0); bp.frequency.exponentialRampToValueAtTime(900, t0 + 0.12); zg.gain.value = 0.3;
    ns.connect(bp); bp.connect(zg); zg.connect(master); ns.start(t0);                                                      // zap
    (side < 0 ? [784, 523.25, 392] : [523.25, 659.25, 987.77]).forEach((f, i) => bell(ctx, master, f, t0 + 0.07 + i * 0.11, 0.6));      // arpej
    const sub = ctx.createOscillator(), sg = ctx.createGain(); sub.type = "sine"; sub.frequency.setValueAtTime(110, t0); sub.frequency.exponentialRampToValueAtTime(48, t0 + 0.5);
    sg.gain.setValueAtTime(0, t0); sg.gain.linearRampToValueAtTime(0.26, t0 + 0.03); sg.gain.exponentialRampToValueAtTime(0.001, t0 + 0.55); sub.connect(sg); sg.connect(master); sub.start(t0); sub.stop(t0 + 0.6);   // gürleme
  } catch (e) { /* ses yok */ }
}
/** Uygulama kapalı/askıdayken oluşmuş sinyal: animasyon yok, plan yok (fiyat çoktan değişti), sadece bilgi. */
function missedAlert(e) {
  const t = $("#toast"); t.className = "toast";
  t.innerHTML = `<div class="th">🕓 Kaçırılan sinyal · <span class="${e.side === 1 ? "up" : "down"}">${e.side === 1 ? "LONG ▲" : "SHORT ▼"}</span> · ${e.name} · ${TF_LABEL[e.tf]}</div>
    <div class="tg">Uygulama arka plandayken yaklaşık ${e.ago} dk önce oluştu. Fiyat o günden bu yana değişti: eski plan GEÇERSİZ olabilir, grafiğe bakıp yeniden değerlendir.</div>`;
  t.onclick = () => { t.classList.add("hidden"); S.sym = e.sym; S.tf = e.tf; markTop(); reload(true); setTab("sig"); };
  clearTimeout(t._h); t._h = setTimeout(() => t.classList.add("hidden"), 20000);
}
function lightning(ev) {
  const x = ev.sig, g = x.side === 1; DT.emit("signal", { side: x.side, sym: x.sym });
  const t = $("#toast"); t.className = "toast " + (g ? "L" : "S");
  t.innerHTML = `<div class="th">YENİ SİNYAL · <span class="${g ? "up" : "down"}">${g ? "LONG ▲" : "SHORT ▼"}</span> · ${ev.name} · ${TF_LABEL[x.tf]}</div>
    <div>Giriş <b>${fp(x.entry, x.sym)}</b> · Stop <b class="down">−${dist(x.risk, x.sym)}</b> (${fp(x.stop, x.sym)}) · Hedef <b class="up">+${dist(Math.abs(x.tp1 - x.entry), x.sym)}</b> (${fp(x.tp1, x.sym)}) · ${x.r1.toFixed(1)}R</div>
    <div class="tg">${x.setup} · skor ${x.score >= 0 ? "+" : ""}${x.score.toFixed(2)} · risk ${x.risk_label} · tavsiye değil, kanıtsız</div>`;
  t.onclick = () => { t.classList.add("hidden"); S.sym = x.sym; S.tf = x.tf; markTop(); reload(true); setTab("sig"); };
  clearTimeout(t._h); if (!S.demo) t._h = setTimeout(() => t.classList.add("hidden"), IS_MOBILE() ? 6000 : 9000);
  S.unseen++; badge(); const bb = $("#btn-hist"); bb.classList.remove("pulse"); void bb.offsetWidth; bb.classList.add("pulse");
  if (S.sound) thunder(x.side);
  try { if (navigator.vibrate) navigator.vibrate([180, 90, 180]); } catch (e) { /* desteklenmiyor */ }
  try {                                    // sayfa arka plandaysa (sekme/uygulama açık ama görünmüyor) sistem bildirimi
    if (document.hidden && "Notification" in window && Notification.permission === "granted") {
      const body = `${x.setup} · giriş ${fp(x.entry, x.sym)} · stop −${dist(x.risk, x.sym)} · hedef +${dist(Math.abs(x.tp1 - x.entry), x.sym)}`;
      const title = `${g ? "LONG" : "SHORT"} · ${ev.name} · ${TF_LABEL[x.tf]}`;
      if (navigator.serviceWorker && navigator.serviceWorker.ready) navigator.serviceWorker.ready.then((r) => r.showNotification(title, { body, tag: "dt-" + x.id, vibrate: [200, 100, 200] })).catch(() => new Notification(title, { body }));
      else new Notification(title, { body });
    }
  } catch (e) { /* bildirim izni yok */ }
}

/* ---------- döngüler ---------- */
async function loadAna() {
  const j = await api(`/api/analysis?sym=${S.sym}&tf=${S.tf}`);
  if (!j || !j.ready) { S.reason = j && j.reason ? j.reason : (!j && window.__apiErr ? "Motor hatası: " + window.__apiErr : ""); if (S.tab === "sig") renderSig(); return; }
  S.reason = "";
  if (j.stats) S.stats = j.stats; S.ana = j; S.risk = S.risk;
  const ev = j.event, b = $("#banner");
  if (ev && ev[0] >= -30 && ev[0] <= 120) { b.classList.remove("hidden"); b.textContent = `⚠ ${ev[1]} ${ev[0] >= 0 ? ev[0] + " dk sonra" : -ev[0] + " dk önce"} — oynaklık/spread artabilir, yeni sinyal çekingen verilir`; } else b.classList.add("hidden");
  if (S.tab === "sig" || S.tab === "ind" || S.tab === "agents") renderTabs(); legend(null); DT.emit("ana", j); if (j.eval && window.AGFIRE) AGFIRE(j.eval); { const sy = $("#syn"); if (sy) { sy.classList.remove("ping"); requestAnimationFrame(() => requestAnimationFrame(() => sy.classList.add("ping"))); } }
}
async function loadSigs() { const j = await api("/api/signals"); if (!j) return; S.sigs = j.sigs; S.stats = j.stats; markers(); if (S.tab === "hist") renderHist(); }
async function tick() {
  const j = await api(`/api/tick?sym=${S.sym}&tf=${S.tf}&since=${S.lastEv}`); if (!j) { $("#status-txt").textContent = "Motor hatası: " + String(window.__apiErr || "?").slice(0, 60); $("#dot").classList.remove("ok"); return; }
  S.tk = j; feedWh(j.flow); DT.emit("tick");
  if (!S.data && S.loadedKey !== "x" && !S._retry) { S._retry = true; reload(false).finally(() => (S._retry = false)); }       // ilk yükleme veri yetersizliğiyle başarısız olduysa yeniden dene
  SYMS.forEach((s) => { const w = j.watch[s]; if (!w) return; $("#px-" + s).textContent = w.price ? fp(w.price, s) : "—"; { const st = $(".symtab[data-s=\"" + s + "\"]"); if (st) st.classList.toggle("closed", !!w.closed); } const ch = $("#ch-" + s); ch.textContent = w.chg == null ? "" : (w.chg >= 0 ? "+" : "") + w.chg.toFixed(2) + "%"; ch.className = cls(w.chg);
    { const de = $("#dots-" + s), dh = SCAN.map((t) => `<i class="sdot ${w.states[t] === "LONG" ? "L" : w.states[t] === "SHORT" ? "S" : ""}" title="${TF_LABEL[t]}: ${w.states[t] || "—"}"></i>`).join(""); if (de && de._h !== dh) { de._h = dh; de.innerHTML = dh; } } });
  if (j.candle && S.data) {
    const c = j.candle, lastT = S.data.candles[S.data.candles.length - 1].time;
    if (c.time > lastT) { if (!S._loading) { S._loading = true; await loadChart(false); await loadAna(); S._loading = false; } }
    else { C.ser.candle.update({ time: loc(c.time), open: c.open, high: c.high, low: c.low, close: c.close }); C.ser.vol.update({ time: loc(c.time), value: c.volume, color: c.close >= c.open ? "rgba(8,153,129,.35)" : "rgba(242,54,69,.35)" }); S.candleLast = c; }
  }
  if (!IS_MOBILE() || window.__flowOpen) renderFlow(j.flow);          // telefonda akış sekmesi kapalıyken boşuna çizme (akıcılık)
  drawOverlay();
  j.events.forEach((e) => { if (e.missed) missedAlert(e); else lightning(e); S.lastEv = Math.max(S.lastEv, e.id); loadSigs(); });
  S.lastEv = Math.max(S.lastEv, j.last_ev && S.lastEv === 0 ? j.last_ev : S.lastEv);
  const age = j.ws_age; const ok = age != null && age < 20;
  $("#dot").classList.toggle("ok", ok); $("#status-txt").textContent = ok ? "Canlı" : (j.ready < 35 ? `Yükleniyor ${j.ready}/35` : "Akış bekleniyor");
}
async function init() {
  applyTheme0();
  buildTop(); buildMenu(); mk(); applyTheme();
  const showErr = (n, e) => { try { $("#status-txt").textContent = `Hata ${n}: ${String((e && e.message) || e).slice(0, 60)}`; $("#dot").classList.remove("ok"); console.error(n, e); } catch (x) { /* */ } };
  window.addEventListener("unhandledrejection", (ev) => showErr("söz", ev.reason)); window.addEventListener("error", (ev) => showErr("js", ev.error || ev.message));
  const guard = (f, n) => async () => { try { await f(); } catch (e) { showErr(n, e); } };
  setInterval(guard(tick, "tick"), IS_MOBILE() ? 1100 : 700); setInterval(guard(loadAna, "analiz"), IS_MOBILE() ? 3500 : 2500);      // başlatma beklemesinden bağımsız: veri/analiz akışı her durumda başlar
  const st = await api("/api/settings"); if (st) S.risk = st.risk_usd;
  S.cal = (await api("/api/calendar")) || [];
  const first = await api("/api/tick?sym=XAUUSDT&tf=15m&since=0"); if (first) S.lastEv = first.last_ev;     // eski olaylar için animasyon çalma
  const splash = $("#splash"), t0 = Date.now();
  const note = (txt, frac) => { if (splash) { $(".note", splash).textContent = txt; splash.style.setProperty("--p", Math.max(0.04, Math.min(1, frac))); } };
  for (;;) {                                  // veriler gelene dek bekle; 14 sn sonra elde olanla aç (eksik olan sembol nedenini kendisi söyler), en çok 45 sn
    const p = await api("/api/ping"), ready = p ? p.ready : 0, need = p ? p.need : 35, sec = (Date.now() - t0) / 1000, er = p && p.err ? Object.entries(p.err)[0] : null;
    note(`Piyasa verisi bağlanıyor… ${ready}/${need}` + (er && sec > 5 ? ` · ${er[0]}: ${er[1]}` : ""), ready / need);
    $("#loader").textContent = `Veri yükleniyor… ${ready}/${need}`;
    if (p && ready >= need) break; if (sec > 14 && ready >= 7) break; if (sec > 45) break;
    await new Promise((r) => setTimeout(r, 500));
  }
  note("Analiz hazırlanıyor…", 0.97);
  const Q = new URLSearchParams(location.search);          // geliştirme/test kısayolları
  if (Q.get("sym") && SYMS.includes(Q.get("sym"))) { S.sym = Q.get("sym"); markTop(); }
  if (Q.get("tf") && TFS.includes(Q.get("tf"))) { S.tf = Q.get("tf"); markTop(); }
  if (Q.get("demo")) S.demo = true;
  if (Q.get("all")) { Object.keys(S.opts).forEach((k) => (S.opts[k] = true)); S.opts.sr = S.opts.fib = true; buildMenu(); }
  if (Q.get("theme")) { S.theme = Q.get("theme"); applyTheme(); }
  try { await reload(true); } catch (e) { showErr("grafik", e); } try { await loadSigs(); } catch (e) { showErr("defter", e); }
  note("Hazır", 1);
  const wait = Math.max(0, 600 - (Date.now() - t0)); setTimeout(() => { if (window.Splash) Splash.finish(); else if (splash) { splash.classList.add("hide"); setTimeout(() => splash.remove(), 900); } }, wait); requestAnimationFrame(inkTo);        // açılış animasyonu en az ~2 sn görünür
  if (Q.get("tab")) setTab(Q.get("tab"));
  if (Q.get("demo")) setTimeout(() => { lightning({ name: NAMES[S.sym], sig: { sym: S.sym, tf: S.tf, side: 1, entry: S.candleLast.close, stop: S.candleLast.close - 10, tp1: S.candleLast.close + 15, risk: 10, r1: 1.5, setup: "Likidite süpürme + CHoCH dönüşü", score: 0.41, risk_label: "ORTA" } }); $("#bolt-layer").classList.add("freeze"); }, 1500);
  setInterval(loadSigs, 8000); setInterval(() => api("/api/ping"), 5000); setInterval(async () => { S.cal = (await api("/api/calendar")) || S.cal; if (S.tab === "cal") renderCal(); }, 30000);
  setInterval(drawOverlay, IS_MOBILE() ? 450 : 150); window.addEventListener("resize", () => { drawOverlay(); });       // kaydırma/yakınlaştırmada zaten aralık olayıyla anında çizilir
  C.main.timeScale().subscribeVisibleLogicalRangeChange(drawOverlay);
}
function applyTheme0() { setThemeClass(); }
DT.on("view", (v) => { if (v !== "market") return; setTimeout(() => { try { if (S.data) { const n = S.data.candles.length; C.main.timeScale().setVisibleLogicalRange({ from: Math.max(0, n - 130), to: n + 10 }); } else reload(true); window.dispatchEvent(new Event("resize")); drawOverlay(); } catch (e) { /* */ } }, 160); });
DT.on("palette", (p) => { TV.up = p.up; TV.down = p.dn; try { C.ser.candle.applyOptions({ upColor: p.up, downColor: p.dn, wickUpColor: p.up, wickDownColor: p.dn }); } catch (e) { /* */ } });
init();


