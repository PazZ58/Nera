"use strict";
/* Beyin kabuğu + Laboratuvar arayüzü. Hesaplama labcore.js (Web Worker) içinde; burada yalnız durum, görünüm ve olay köprüsü var. */
(function () {
const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
const IS_M = () => matchMedia("(max-width:900px)").matches;
const f1 = (x, d = 2) => (x == null || !isFinite(x) ? "—" : Number(x).toFixed(d)), pc = (x, d = 0) => (x == null || !isFinite(x) ? "—" : (x * 100).toFixed(d) + "%"), nf = (x) => Number(x || 0).toLocaleString("tr-TR");
const clk = () => new Date().toLocaleTimeString("tr-TR", { hour12: false }), esc = (s) => String(s).replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c]));
const med = (a) => { if (!a.length) return null; const b = a.slice().sort((x, y) => x - y); return b[Math.floor(b.length / 2)]; };
const LS = { get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } }, set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* dolu */ } } };
const spark = (a, col) => { if (!a.length) return ""; const mx = Math.max(...a, 1), n = a.length; return `<svg viewBox="0 0 100 20" preserveAspectRatio="none"><polyline fill="none" stroke="${col}" stroke-width="1.4" vector-effect="non-scaling-stroke" points="${a.map((v, i) => `${(i / Math.max(1, n - 1) * 100).toFixed(1)},${(19 - v / mx * 17).toFixed(1)}`).join(" ")}"/></svg>`; };

/* ---------------------------------------------------------------- durum */
const Lab = window.Lab = {
  w: null, meta: null, data: null, loadFrac: 0, loading: false, running: false, want: LS.get("nera_lab_want", !IS_M()),
  sym: LS.get("nera_lab_sym", "XAUUSDT"), tf: LS.get("nera_lab_tf", "15m"), days: LS.get("nera_lab_days", 90),
  cfg: Object.assign({ fee: 4, slip: 1, risk: 0.01, split: 0.65, delay: IS_M() ? 400 : 140 }, LS.get("nera_lab_cfg", {})),
  cnt: Object.assign({ idea: 0, test: 0, passIS: 0, passOOS: 0, rob: 0, cand: 0, kept: 0, rej: 0 }, LS.get("dt_lab_cnt", {})), base: Object.assign({ idea: 0, test: 0, passIS: 0, passOOS: 0, rob: 0, cand: 0, kept: 0, rej: 0 }, LS.get("dt_lab_cnt", {})), symMode: LS.get("nera_lab_symmode", "auto"), rot: 0, stats: {}, cloud: [], log: [], book: LS.get("dt_lab_book", []), rate: [], cur: null, sel: 1, err: "", lastTests: 0, live: {}, t0: Date.now(),
};
const TOT = LS.get("dt_lab_tot", { test: 0, kept: 0 });
function logAdd(tag, cls, txt) { Lab.log.unshift({ t: clk(), tag, cls, txt }); if (Lab.log.length > 250) Lab.log.length = 250; DT.emit("lab:log", Lab.log[0]); }
function toast(msg, col) { if (window.NeraNotify) { const s = String(msg), b = s.match(/<b>(.*?)<\/b>/); NeraNotify.push({ kind: "app", title: b ? b[1].replace(/<[^>]+>/g, "") : "Nera", html: b ? s.replace(b[0], "").replace(/^(\s*<br>)+/, "") : s, color: col }); return; } let t = $("#neo-toast"); if (!t) { t = document.createElement("div"); t.id = "neo-toast"; t.style.cssText = "position:fixed;right:18px;bottom:18px;z-index:80;max-width:360px;padding:11px 14px;border-radius:8px;background:#0e121b;border:1px solid #2a3148;border-left:3px solid var(--na);color:#d6dbea;font:12.5px/1.45 var(--font);box-shadow:0 10px 30px rgba(0,0,0,.55);transition:.35s;transform:translateY(20px);opacity:0;pointer-events:none"; document.body.appendChild(t); } t.style.borderLeftColor = col || "#35e0c4"; t.innerHTML = msg; t.style.opacity = 1; t.style.transform = "none"; clearTimeout(t._h); t._h = setTimeout(() => { t.style.opacity = 0; t.style.transform = "translateY(20px)"; }, 5500); }
Lab.toast = toast; Lab.logAdd = logAdd;

/* ---------------------------------------------------------------- gezinme */
let cur = "brain";
const OFFV = () => (window.NERA_EXP ? ["lab", "labsig", "book", "bt", "friends"] : window.LABOFF ? ["lab", "labsig", "book"] : []);          // strateji üretimi kapalı (Kanıt Lab var); deneysel sürümde ayrıca bt, friends
function go(v) {
  if (v === cur || OFFV().includes(v)) return; cur = v; document.body.dataset.view = v;
  $$(".view").forEach((e) => e.classList.toggle("active", e.id === "v-" + v)); $$(".rn").forEach((e) => e.classList.toggle("active", e.dataset.v === v)); document.body.classList.remove("rail-open");
  LM.clear(v); Sound.setView(v); if (v === "market") setTimeout(() => window.dispatchEvent(new Event("resize")), 60);
  $$("#mtab [data-v]").forEach((b) => b.classList.toggle("active", b.dataset.v === v || (b.dataset.v === "menu" && ["news", "bt", "kb", "xbot"].includes(v)))); $$("#mtop [data-v]").forEach((b) => b.classList.toggle("active", b.dataset.v === v)); const ms = $("#msheet"); if (ms) ms.classList.remove("open");
  DT.emit("view", v); refresh(true); try { sessionStorage.setItem("dt_view", v); } catch (e) { /* */ }
}
Lab.go = go; Lab.view = () => cur;
$$(".rn").forEach((b) => (b.onclick = () => go(b.dataset.v)));
$("#rail-fab").onclick = () => document.body.classList.toggle("rail-open");
$("#stage").addEventListener("click", () => document.body.classList.remove("rail-open"));

/* ---------------------------------------------------------------- worker */
function mk() {
  if (Lab.w || window.LABOFF) return; let w; try { w = new Worker("lab/labcore.js"); } catch (e) { Lab.err = "Worker açılamadı: " + e.message; logAdd("HATA", "bad", Lab.err); return; }
  Lab.w = w; w.onmessage = (e) => handle(e.data); w.onerror = (e) => { Lab.err = "Worker hatası: " + (e.message || "?"); logAdd("HATA", "bad", Lab.err); }; w.postMessage({ cmd: "meta" });
}
const ROT = ["XAUUSDT", "XAUUSDT", "XAGUSDT", "BTCUSDT", "ETHUSDT"];
async function isOpen(s) { try { const r = await fetch(`https://fapi.binance.com/fapi/v1/klines?symbol=${s}&interval=15m&limit=2`), j = await r.json(); return Date.now() - j[j.length - 1][0] < 50 * 60000; } catch (e) { return true; } }
async function autoPick() { for (let k = 0; k < ROT.length; k++) { const s = ROT[(Lab.rot + k) % ROT.length]; if (await isOpen(s)) { Lab.rot = (Lab.rot + k + 1) % ROT.length; return s; } } return "BTCUSDT"; }
async function load() { mk(); if (!Lab.w) return; if (Lab.symMode === "auto") { Lab.picking = true; const s = await autoPick(); Lab.picking = false; if (s !== Lab.sym) logAdd("LAB", "vio", `Otomatik sembol: ${s.replace("USDT", "")} (piyasası açık olan, altın öncelikli)`); Lab.sym = s; } Lab.loading = true; Lab.loadFrac = 0; Lab.err = ""; Lab.data = null; Lab.cur = null; Lab.base = Object.assign({}, Lab.cnt); logAdd("VERİ", "vio", `${Lab.sym} ${Lab.tf} · ${Lab.days} gün geçmiş veri indiriliyor (Binance Futures)…`); Lab.w.postMessage({ cmd: "load", sym: Lab.sym, tf: Lab.tf, days: Lab.days }); }
function startSearch() { if (!Lab.w || !Lab.data) return; Lab.running = true; Lab.w.postMessage({ cmd: "search", cfg: Object.assign({}, Lab.cfg, { lad: window.NeraBT ? NeraBT.ladCfg() : null }) }); }
function pause() { Lab.want = false; LS.set("nera_lab_want", false); Lab.running = false; if (Lab.w) Lab.w.postMessage({ cmd: "stop" }); logAdd("LAB", "mut", "Duraklatıldı."); }
function resume() { Lab.want = true; LS.set("nera_lab_want", true); if (!Lab.w || !Lab.data) load(); else startSearch(); }
function applyCfg() { LS.set("nera_lab_sym", Lab.sym); LS.set("nera_lab_tf", Lab.tf); LS.set("nera_lab_days", Lab.days); LS.set("nera_lab_cfg", Lab.cfg); if (Lab.w) Lab.w.postMessage({ cmd: "stop" }); Lab.running = false; setTimeout(load, 300); }
Lab.pause = pause; Lab.resume = resume; Lab.load = load; Lab.applyCfg = applyCfg;
document.addEventListener("visibilitychange", () => { if (!IS_M() || !Lab.w) return; if (document.hidden) { if (Lab.running) { Lab._bg = true; Lab.w.postMessage({ cmd: "stop" }); Lab.running = false; } } else if (Lab._bg) { Lab._bg = false; if (Lab.want && Lab.data) startSearch(); } });      // telefonda arka planda laboratuvar durur (pil)
const keyOf = (r) => r.sym + r.tf + JSON.stringify(r.g);
function handle(m) {
  switch (m.ev) {
    case "meta": Lab.meta = m; DT.emit("lab:meta", m); break;
    case "load": Lab.loadFrac = m.total ? m.n / m.total : 0; break;
    case "data": Lab.loading = false; Lab.data = m; logAdd("VERİ", "vio", `${nf(m.n)} mum yüklendi (${m.sym} ${m.tf}) · ${new Date(m.t0).toLocaleDateString("tr-TR")} → ${new Date(m.t1).toLocaleDateString("tr-TR")}`);
      LM.event("lab", { color: "#8a7bff", msg: "Veri yüklendi" }); DT.emit("lab:data", m); Lab.w.postMessage({ cmd: "seeds", gs: Lab.book.filter((b) => b.sym === m.sym && b.tf === m.tf).map((b) => b.g) }); if (Lab.want) startSearch(); break;
    case "log": logAdd((m.ag || "lab").toUpperCase(), "mut", m.txt); break;
    case "work": Lab.work = m; break;
    case "cand": { const r = m.r; Lab.cur = r; Lab.cloud.push(r); if (Lab.cloud.length > 260) Lab.cloud.shift(); TOT.test++; DT.emit("lab:cand", r);
      if (r.status === "rej-oos") logAdd("ELENDİ", "bad", `${r.name} — ${r.reason}`); else if (r.status === "rej-rob") logAdd("ELENDİ", "bad", `${r.name} — ${r.reason}`); else if (r.status === "cand") logAdd("ADAY", "warn", `${r.name} — ${r.reason}`); else if (r.status === "kept") logAdd("KALICI", "ok", `${r.name} — ${r.reason}`); else if (Lab.cnt.test % 40 === 0) logAdd("TEST", "mut", `${r.name} — ${r.reason}`);
      break; }
    case "keep": { setTimeout(() => { if (Lab.w) Lab.w.postMessage({ cmd: "seeds", gs: Lab.book.filter((b) => !Lab.data || (b.sym === Lab.data.sym && b.tf === Lab.data.tf)).map((b) => b.g) }); }, 100); const r = m.r, k = keyOf(r), i = Lab.book.findIndex((b) => keyOf(b) === k); if (i < 0) { Lab.book.unshift(r); if (Lab.book.length > 120) Lab.book.length = 120; LS.set("dt_lab_book", Lab.book); const kept = r.status === "kept"; if (kept) TOT.kept++;
        LM.event("lab", { color: kept ? "#35e0c4" : "#ffb04a", msg: r.name }); LM.event("book", { color: kept ? "#35e0c4" : "#ffb04a", msg: r.name }); const TL = window.NeraStrat ? NeraStrat.info(r) : null; if (kept && localStorage.getItem("nera_strat_notify") !== "0") toast(`<b>${TL ? TL.glyph + " " + TL.label + " · " + TL.code : kept ? "Kalıcı strateji" : "Aday strateji"}</b><br>${esc(r.name)}<br><span style="color:#8b92a8">OOS: ${r.oos.n} işlem · ort ${f1(r.oos.avgR)}R · Sharpe ${f1(r.oos.sh)}. Kâr garantisi değildir.</span>`, kept ? "#35e0c4" : "#ffb04a"); DT.emit("lab:book", r); } break; }
    case "stats": { const b = Lab.base; Lab.cnt = {}; for (const k in m.cnt) Lab.cnt[k] = m.cnt[k] + (b[k] || 0); } Lab.statsRaw = m.cnt; Lab.stats = m; Lab.rate.push(Lab.cnt.test - Lab.lastTests); Lab.lastTests = Lab.cnt.test; if (Lab.rate.length && Lab.rate[Lab.rate.length - 1] < 0) Lab.rate[Lab.rate.length - 1] = 0; if (Lab.rate.length > 40) Lab.rate.shift();
      if (Lab.cnt.test > 0 && Lab.cnt.test % 500 < 5 && !Lab._ms500) { Lab._ms500 = 1; LM.event("lab", { color: "#8a7bff", msg: `${Lab.cnt.test} test` }); logAdd("LAB", "vio", `${nf(Lab.cnt.test)} tarif test edildi.`); } else if (Lab.cnt.test % 500 > 50) Lab._ms500 = 0; LS.set("dt_lab_tot", TOT); LS.set("dt_lab_cnt", Lab.cnt); break;
    case "stopped": Lab.running = false; break;
    case "error": Lab.err = m.msg; Lab.loading = false; logAdd("HATA", "bad", `${m.cmd}: ${m.msg}`); break;
    case "live": (m.res || []).forEach((r, i) => { if (Lab._lk && Lab._lk[i]) Lab.live[Lab._lk[i]] = r; }); break;
    default: DT.emit("lab:msg", m);
  }
}
Lab.post = (o) => { mk(); if (Lab.w) Lab.w.postMessage(o); };

/* ---------------------------------------------------------------- BEYİN ekranı */
const SRC = [["mk", "Piyasa akışı", "Binance WS · canlı", "#35e0c4"], ["hist", "Geçmiş veri", "mum sayısı", "#8a7bff"], ["kb", "Bilgi bankası", "repolardan alınan tarifler", "#ffb04a"], ["sig", "Sinyal defteri", "ölçülen sinyaller", "#4dd0e1"]];
const OUT = [["idea", "Fikir", "üretilen tarif", "#8a7bff"], ["test", "Test", "geçmişte sınanan", "#35e0c4"], ["rej", "Elenen", "elekten geçemeyen", "#f2566a"]];
function buildBrain() { LM.feeds = []; }                         // kaynak/çıktı kartları yerine Kozmos gezegenleri (brain.js)
const tickHist = []; let tickN = 0, lastCnt = {};
const CH = (k, s) => { if (window.Cosmos && Cosmos.P.length) Cosmos.hot(k, s); };
DT.on("tick", () => { tickN++; if (tickN % 3 === 0) CH("mk", 0.6); });
DT.on("lab:cand", (r) => { CH("idea", 0.5); CH("test", 0.7); if (r && /^rej/.test(r.status)) CH("rej", 0.5); });
DT.on("lab:log", (l) => { if (l.tag === "VERİ") CH("hist", 1); });
DT.on("lab:meta", () => CH("kb", 1)); DT.on("signal", () => CH("sig", 1.2)); DT.on("labsig", () => CH("labsig", 1.4));
/* gezegen bilgisi: Kozmos etiketleri (kısa) ve odak kartı (tam) */
Lab.planetInfo = (k, short) => {
  const c = Lab.cnt, S = window.__S ? __S() : {}, LG = window.LabSig, fx = (x, d = 2) => (x == null || !isFinite(x) ? "—" : Number(x).toLocaleString("en-US", { maximumFractionDigits: d }));
  switch (k) {
    case "mk": { const v = nf(tickN); if (short) return { v }; const w = (S.tk && S.tk.watch) || {}; return { v, s: "tik", spark: `<div class="cc-sp">${spark(Lab.rate.length ? Lab.rate : [0, 0], "#35e0c4")}</div>`, rows: Object.entries(w).map(([s, x]) => [s.replace("USDT", ""), x.price ? fx(x.price, s === "EURUSD" ? 5 : 2) + (x.chg != null ? ` <i class="${x.chg >= 0 ? "na" : "down"}">${x.chg >= 0 ? "+" : ""}${x.chg.toFixed(2)}%</i>` : "") + (x.closed ? ' <i class="muted">kapalı</i>' : "") : "—"]), desc: "Binance Futures WebSocket akışı. Her tik yıldıza bir nöron darbesi gönderir; ajanlar, sinyal motoru ve sıcaklık haritası bu akıştan beslenir." }; }
    case "hist": { const d = Lab.data, v = d ? nf(d.n) : Lab.loading ? "%" + Math.round(Lab.loadFrac * 100) : "—"; if (short) return { v }; return { v, s: "mum", rows: d ? [["Sembol", d.sym], ["Aralık", d.tf], ["Başlangıç", new Date(d.t0).toLocaleDateString("tr-TR")], ["Bitiş", new Date(d.t1).toLocaleDateString("tr-TR")], ["Son fiyat", fx(d.last)]] : [["Durum", Lab.loading ? "indiriliyor" : "bekliyor"]], desc: "Laboratuvarın üzerinde strateji aradığı geçmiş mumlar (taker alış hacmi = gerçek delta). Son %35'i hiç görülmemiş sınav verisi olarak ayrılır." }; }
    case "kb": { const m = Lab.meta, v = m ? Object.keys(m.rec).length : "—"; if (short) return { v }; return { v, s: "tarif", rows: m ? Object.entries(m.rec).slice(0, 7).map(([kk, r]) => [r.tr, `<i class="muted">${r.src || kk}</i>`]) : [], desc: "Altı açık kaynak depodan ve eski bottan alınan giriş tarifleri, filtreler ve çıkış kuralları. Fikir gezegeni bunları birleştirip yeni tarifler üretir." }; }
    case "sig": { const a = S.sigs || [], v = a.length; if (short) return { v }; return { v, s: "sinyal", rows: a.slice(0, 6).map((x) => [`${(x.sym || "").replace("USDT", "")} ${x.tf}`, `<i class="${x.side > 0 ? "na" : "down"}">${x.side > 0 ? "LONG" : "SHORT"}</i> · ${x.status || ""}`]), desc: "Piyasa & Sinyal motorunun verdiği her sinyal kâğıt üstünde ölçülür (hedef mi stop mu). Gerçek emir yoktur." }; }
    case "idea": { const v = nf(c.idea); if (short) return { v }; return { v, s: "fikir", spark: `<div class="cc-sp">${spark(Lab.rate.length ? Lab.rate : [0, 0], "#8a7bff")}</div>`, rows: [["Hız", `${Lab.stats.rate || 0}/sn`], ["Şu an", Lab.cur ? esc(Lab.cur.name).slice(0, 46) : "—"], ["Toplam (tüm zamanlar)", nf(TOT.test)]], desc: "Üretici ajanlar tarifleri, filtreleri ve çıkışları evrimsel aramayla birleştirir; iyi sonuç verenler tohum olup benzerlerini doğurur." }; }
    case "test": { const v = nf(c.test); if (short) return { v }; return { v, s: "test", rows: [["IS'te yeterli", nf(c.passIS)], ["OOS'u geçen", nf(c.passOOS)], ["Dayanıklı", nf(c.rob)], ["Aday", nf(c.cand)], ["Kalıcı", nf(c.kept)], ["Şans sınırı (Sharpe)", Lab.stats.thr == null ? "—" : f1(Lab.stats.thr, 2)]], desc: "Her tarif komisyon + kayma dahil, bir sonraki mum açılışında dolumla sınanır. OOS ve şans sınırı (deflated Sharpe) elekleri burada." }; }
    case "rej": { const v = nf(c.rej); if (short) return { v }; const last = Lab.log.filter((l) => l.tag === "ELENDİ").slice(0, 3); return { v, s: "elenen", rows: [["Elenme oranı", c.test ? pc(c.rej / c.test) : "—"], ...last.map((l) => [l.t, esc(l.txt).slice(0, 52)])], desc: "Elekten geçemeyenler. Yüksek elenme oranı hata değil: şansla iyi görünen tariflerin izlemeye alınmasını engeller." }; }
    case "kar": { const I = window.Kanit && Kanit.info ? Kanit.info() : null, v = I ? I.v : "—"; if (short) return { v }; return { v, s: "ort. net R", rows: I ? I.rows : [], desc: "Sinyal motorunun gerçek sonuçları: her sinyal kâğıt üstünde ölçülür, maliyet XM spreadiyle düşülür. Ayrıntı: Kanıt Lab." }; }
    case "labsig": { const sm = LG ? LG.summary() : null, v = sm ? sm.live : "—"; if (short) return { v }; return { v, s: "aktif strateji", rows: sm ? [["★ Süpernova", sm.t.supernova], ["✦ Pulsar", sm.t.pulsar], ["◆ Nebula (gözlem)", sm.t.nebula], ["Şu an LONG", sm.L], ["Şu an SHORT", sm.S], ["Son sinyal", sm.last || "—"]] : [], desc: "Yalnız şans sınırını geçmiş, görülmemiş veride ve 180 günlük backtestte kârlı çıkmış stratejiler (Süpernova, Pulsar) canlı izlenir; yeni LONG/SHORT verdiklerinde özel bildirim gelir. Kâr garantisi yoktur." }; }
  }
  return null;
};
Lab.ticks = () => tickN;
function updBrain() {
  const c = Lab.cnt, S = window.S || {}, n = (id, v) => { const e = $("#" + id); if (e && e.textContent !== String(v)) e.textContent = v; };
  const k = [["Fikir", nf(c.idea), "tarif üretildi", ""], ["Test edilen", nf(c.test), `${Lab.stats.rate || 0}/sn hız`, "a"], ["Eleğe giren", nf(c.passIS), "IS'te yeterli", ""], ["OOS'u geçen", nf(c.passOOS), "hiç görülmemiş veri", "b"], ["Dayanıklı", nf(c.rob), "komşu parametre testi", ""], ["Aday", nf(c.cand), "şans sınırının altı", "c"], ["Kalıcı", nf(c.kept), "şans sınırını geçti", "a"], ["Defterde", nf(Lab.book.length), "kayıtlı strateji", ""]];
  const h = k.map(([l, v, s, cl]) => `<div class="kp ${cl}"><div class="l">${l}</div><div class="v">${v}</div><div class="s">${s}</div></div>`).join(""); const el = $("#bv-kpis"); if (el._h !== h) { el._h = h; el.innerHTML = h; }
  const w = Lab.work, now = Lab.loading ? `Geçmiş veri indiriliyor… %${Math.round(Lab.loadFrac * 100)}` : Lab.err ? "Hata: " + Lab.err : !Lab.data ? "Laboratuvar bekliyor" : Lab.running ? (Lab.cur ? `şu an: ${Lab.cur.name}` : "arama başlıyor…") : "laboratuvar duraklatıldı"; n("bv-now", now); const bs = $("#bv-start"); if (bs) { bs.style.display = Lab.running || Lab.loading ? "none" : ""; bs.onclick = resume; }
  n("cv-mk", nf(tickN)); n("cv-hist", Lab.data ? nf(Lab.data.n) : "—"); n("cv-kb", Lab.meta ? Object.keys(Lab.meta.rec).length : "—"); n("cv-sig", (S.sigs || []).length); n("cv-idea", nf(c.idea)); n("cv-test", nf(c.test)); n("cv-rej", nf(c.rej));
  const r = Lab.rate; for (const [kk, col] of [["mk", "#35e0c4"], ["hist", "#8a7bff"], ["kb", "#ffb04a"], ["sig", "#4dd0e1"], ["idea", "#8a7bff"], ["test", "#35e0c4"], ["rej", "#f2566a"]]) { const e = $("#cs-" + kk); if (e) { const s = spark(r.length ? r : [0, 0], col); if (e._h !== s) { e._h = s; e.innerHTML = s; } } }
  const lg = Lab.log.slice(0, 5).map((l) => `<span><b>${l.tag}</b>${esc(l.txt).slice(0, 90)}</span>`).join(""); const tk = $("#bv-log"); if (tk._h !== lg) { tk._h = lg; tk.innerHTML = lg || "<span><b>LAB</b>başlatılıyor…</span>"; }
}

/* ---------------------------------------------------------------- LABORATUVAR ekranı */
const FAM = { trend: ["ema_pb", "supert", "macd", "ema_x", "xr", "ny_cont"], brk: ["orb", "bb_sq", "donch", "volx", "asia_bo", "mom_brk"], rev: ["rsi_mr", "rsi2", "bb_rev", "vwap_rc", "of_div", "rn_rej", "vwap_band"], flow: ["delta", "of_flow", "of_abs", "of_stk", "prt", "vp"], ict: ["sweep", "fvg", "judas", "pdhl"], meta: ["tod"], reg: ["regime", "ens", "meta"] };
const GEN = [["trend", "Trend avcısı", "#4dd0e1"], ["brk", "Kırılım avcısı", "#ffb04a"], ["rev", "Geri dönüş avcısı", "#8a7bff"], ["flow", "Order flow avcısı", "#35e0c4"], ["ict", "ICT avcısı", "#f2566a"], ["meta", "Seans avcısı", "#ffd54a"], ["reg", "Meta & rejim ajanı", "#ff8ad8"], ["exit", "Çıkış ajanı (iz süren stop)", "#7dd3fc"], ["filt", "Filtre ajanı (HTF · oynaklık)", "#b5f27a"]];
const famOf = (rec, g) => (g && g.x && g.x.trail ? "exit" : g && g.f && (g.f.htf || g.f.vol) && !FAM.reg.includes(rec) ? "filt" : Object.keys(FAM).find((k) => FAM[k].includes(rec)) || "meta");
const STN = [
  ["data", "Veri", () => (Lab.data ? nf(Lab.data.n) + " mum" : Lab.loading ? "%" + Math.round(Lab.loadFrac * 100) : "—"), () => `${Lab.sym.replace("USDT", "")} ${Lab.tf} · ${Lab.days} gün`, () => `Binance Futures REST'ten ${Lab.days} günlük ${Lab.tf} mum + taker alış hacmi (gerçek delta) indirilir. Tüm testler aynı kopyayı paylaşır. Oluşan (kapanmamış) mum atılır. Veri: ${Lab.data ? new Date(Lab.data.t0).toLocaleDateString("tr-TR") + " → " + new Date(Lab.data.t1).toLocaleDateString("tr-TR") : "—"}.`],
  ["blocks", "Yapı taşları", () => (Lab.meta ? Object.keys(Lab.meta.rec).length + "" : "24"), () => "giriş tarifi + 5 filtre", () => "24 giriş tarifi: yeni sürümden ORB (day-trader-skill), EMA geri çekilme, RSI, Bollinger, Donchian, Supertrend, VWAP, likidite süpürme ve FVG (ICT), delta, MACD, seans, oynaklık; eski botlardan kümülatif delta, CVD uyumsuzluğu, emilim, baskı mumları, hacim profili, Print, X-Ray rejimi, EMA kesişimi, RSI(2), Bollinger dönüşü ve çok stratejili META oylama. Filtreler: ADX, trend, yatay rejim, seans, delta onayı."],
  ["queue", "Fikir kuyruğu", () => nf(Lab.cnt.idea), () => "evrimsel arama", () => "Arama genetik: ilk tarifler rastgele, sonra en iyi IS skorlu 12 tarifin tek parametresi değiştirilerek yenileri üretilir. Seçim YALNIZCA IS (görülen) verideki SQN skoruna bakar; OOS bölümü seçimde kullanılmaz. Aynı tarif iki kez test edilmez."],
  ["engine", "Motor", () => (Lab.stats.rate != null ? Lab.stats.rate + "/sn" : "—"), () => `maliyet: ${Lab.cfg.fee}+${Lab.cfg.slip} bps/yön`, () => `Olay tabanlı backtest: sinyal mum kapanışında üretilir, işlem bir SONRAKİ mumun açılışında dolar (ileri bakış yok). Aynı mumda hem stop hem hedef değerse stop sayılır (kötümser). Komisyon ${Lab.cfg.fee} bps + kayma ${Lab.cfg.slip} bps her yön. Getiri R cinsinden; hesap riski işlem başı %${(Lab.cfg.risk * 100).toFixed(1)}.`],
  ["sieve", "Elek", () => (Lab.cnt.test ? pc(Lab.cnt.passIS / Lab.cnt.test, 1) : "—"), () => "IS'ten geçen oran", () => `Aşama 1 (IS): en az 25 işlem, PF ≥ 1.10, ort. R > 0.03. Aşama 2 (OOS, hiç görülmemiş son ${pc(1 - Lab.cfg.split)}): en az 12 işlem, PF ≥ 1.10. Aşama 3: stop/hedef/zaman ±%20-25 oynatılınca 5 komşunun en az 3'ü kârlı kalmalı. IS ile OOS arasında 48 mumluk boşluk bırakılır.`],
  ["audit", "Denetim", () => nf(Lab.cnt.cand + Lab.cnt.kept), () => "aday + kalıcı", () => "Deflated Sharpe benzeri şans sınırı: N strateji denenince en iyisinin salt şansla ulaşacağı Sharpe hesaplanır; OOS Sharpe bunun üstünde olmalı. Ardından risk kapısı (day-trader-skill mantığı): ödül/risk, maks. düşüş, Monte Carlo ile %25 düşüş olasılığı, işlem sayısı. Geçemeyen 'aday' kalır."],
  ["book", "Defter", () => nf(Lab.book.length), () => `${Lab.cnt.kept} kalıcı · ${Lab.cnt.cand} aday`, () => "Geçenler Strateji Defteri'ne yazılır, yalnız izleme/analiz içindir: emir gönderilmez. Defterdeki stratejiler yüklü sembolde son kapanmış muma bakılarak canlı 'şimdi sinyal var mı' olarak işaretlenir ve Piyasa'daki sinyal panelinde görünür. Geçmişte geçmek gelecekte çalışacağını garanti etmez."],
];
const ST_COL = { "rej-is": "rgba(140,150,175,", "rej-oos": "rgba(255,150,60,", "rej-rob": "rgba(242,86,106,", cand: "rgba(255,176,74,", kept: "rgba(53,224,196," };

/* laboratuvar beyni: ortada küre, çevresinde strateji üreten ajanlar; her ajanın küçük bir ağı küreye bağlı */
const LB = { orb: null, ag: [], pulses: [], init() {
    this.orb = new Orb(null, { n: MOB ? 260 : 440, k: 3, spin: 0.09 }); let seed = 7; const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
    this.ag = GEN.map(([id, name, col], i) => { const nodes = []; for (let k = 0; k < 9; k++) { const a = rnd() * 6.28, r = k === 0 ? 0 : 14 + rnd() * 24; nodes.push({ x: Math.cos(a) * r, y: Math.sin(a) * r * 0.8, e: 0, f: -1 }); } const ed = []; for (let a = 1; a < nodes.length; a++) { ed.push([0, a]); if (a > 1 && rnd() < 0.7) ed.push([a, 1 + Math.floor(rnd() * (a - 1))]); } return { id, name, col, nodes, ed, cnt: 0, last: "", side: i < 5 ? -1 : 1, row: i < 5 ? i : i - 5, ph: rnd() * 6, hot: 0 }; });
    TICKS.push((dt, t) => this.frame(dt, t)); },
  fire(rec, status, g) { const a = this.ag.find((x) => x.id === famOf(rec, g)); if (!a) return; a.cnt++; const cv0 = $("#lb-brain"); if (!cv0 || !vis(cv0) || this.pulses.length > 24) return; a.hot = 1; a.last = Lab.meta && Lab.meta.rec[rec] ? Lab.meta.rec[rec].tr : rec; a.nodes.forEach((n, k) => (n.f = k * 0.05));
    const good = status === "kept" || status === "cand", pass = status !== "rej-is"; if (good || pass || Math.random() < 0.18) this.pulses.push({ a, t: -0.3, col: status === "kept" ? "#35e0c4" : status === "cand" ? "#ffb04a" : pass ? a.col : "#7d86a0", s: good ? 1.4 : pass ? 0.7 : 0.35 }); },
  frame(dt, t) {
    const cv = $("#lb-brain"); if (!cv || !vis(cv)) return; const p = cv.parentElement, w = p.clientWidth, h = p.clientHeight; if (w < 50) return; const c = fitCanvas(cv, w, h); c.clearRect(0, 0, w, h);
    const R = Math.min(h * 0.27, w * 0.11), cx = w / 2, cy = h / 2 - 8; this.orb.step(dt); this.orb.spin = Lab.running ? 0.1 : 0.04; this.orb.render(c, w, h, R, cx, cy);
    for (const a of this.ag) { const ax = cx + a.side * Math.min(w * 0.34, R * 3.3 + 40) + (a.row === 2 ? a.side * 40 : a.row === 1 || a.row === 3 ? a.side * 14 : 0), ay = h * (0.11 + 0.78 * (a.row + (a.side > 0 ? 0.5 : 0)) / 4) + Math.sin(t * 0.6 + a.ph) * 3; a.x = ax; a.y = ay; a.hot *= Math.pow(0.3, dt);
      for (const n of a.nodes) { if (n.f >= 0) { n.f -= dt; if (n.f < 0) { n.e = 1; n.f = -1; } } n.e *= Math.pow(0.08, dt); }
      if (Lab.running && Math.random() < dt * 1.6) { const n = a.nodes[Math.floor(Math.random() * a.nodes.length)]; n.e = Math.max(n.e, 0.5); }
      const at = this.orb.attach(ax - cx, ay - cy), tx = at.x, ty = at.y, mx = (ax + tx) / 2, c1 = { x: ax - a.side * 70, y: ay }, c2 = { x: tx + a.side * (R * 0.9 + 30), y: ty };
      const Bz = (u) => { const m = 1 - u; return { x: m * m * m * ax + 3 * m * m * u * c1.x + 3 * m * u * u * c2.x + u * u * u * tx, y: m * m * m * ay + 3 * m * m * u * c1.y + 3 * m * u * u * c2.y + u * u * u * ty }; };
      c.strokeStyle = rgba(a.col, 0.2 + a.hot * 0.35); c.lineWidth = 1.2; c.beginPath(); for (let i = 0; i <= 36; i++) { const q = Bz(i / 36); i ? c.lineTo(q.x, q.y) : c.moveTo(q.x, q.y); } c.stroke();
      for (let k = 0; k < 2; k++) { const u = ((t * 0.12 + k / 2 + a.ph) % 1), q = Bz(a.side > 0 ? 1 - u : u); c.fillStyle = rgba(a.col, 0.5); c.beginPath(); c.arc(q.x, q.y, 1.6, 0, 6.3); c.fill(); }
      a._B = Bz; a._at = at;
      const g = c.createRadialGradient(ax, ay, 0, ax, ay, 52); g.addColorStop(0, rgba(a.col, 0.12 + a.hot * 0.3)); g.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = g; c.fillRect(ax - 52, ay - 52, 104, 104);
      for (const [i, j] of a.ed) { const A = a.nodes[i], B = a.nodes[j], e = Math.max(A.e, B.e); c.strokeStyle = rgba(a.col, 0.18 + e * 0.6); c.lineWidth = 0.9 + e; c.beginPath(); c.moveTo(ax + A.x, ay + A.y); c.lineTo(ax + B.x, ay + B.y); c.stroke(); }
      a.nodes.forEach((n, k) => { const r = (k === 0 ? 4.2 : 2.6) * (1 + 0.1 * Math.sin(t * 2 + k + a.ph)) + n.e * 2.4; c.fillStyle = n.e > 0.25 ? "#fff" : rgba(a.col, 0.9); c.beginPath(); c.arc(ax + n.x, ay + n.y, r, 0, 6.3); c.fill(); });
      c.textAlign = "center"; c.fillStyle = "#c9d0e4"; c.font = '600 11px "Segoe UI",sans-serif'; c.fillText(w < 600 ? a.name.split(" ")[0] : a.name, ax, ay + 50); c.fillStyle = "#6f768c"; c.font = '10px "Cascadia Mono",Consolas,monospace'; c.fillText(w < 600 ? `${nf(a.cnt)}` : `${nf(a.cnt)} tarif${a.last ? " · " + a.last.slice(0, 20) : ""}`, ax, ay + 63); }
    for (let k = this.pulses.length - 1; k >= 0; k--) { const P = this.pulses[k]; P.t += dt / 0.9; if (P.t < 0) continue; const a = P.a; if (P.t >= 1) { this.pulses.splice(k, 1); this.orb.flare(a._at.i, P.s); continue; } const q = a._B(a.side > 0 ? 1 - P.t : P.t); const g = c.createRadialGradient(q.x, q.y, 0, q.x, q.y, 14 * P.s); g.addColorStop(0, "rgba(255,255,255,.95)"); g.addColorStop(0.35, rgba(P.col, 0.7)); g.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = g; c.fillRect(q.x - 16 * P.s, q.y - 16 * P.s, 32 * P.s, 32 * P.s); }
  },
};
/* istasyon animasyonları (piston, huni, konveyör…) */
const SA = { cd: Array.from({ length: 40 }, () => ({ o: 0, c: 0, h: 0, l: 0 })), x: 0, q: [], sv: [], ph: 0 };
(() => { let p = 100; for (const k of SA.cd) { const o = p; p += (Math.random() - 0.48) * 3; k.o = o; k.c = p; k.h = Math.max(o, p) + Math.random() * 1.5; k.l = Math.min(o, p) - Math.random() * 1.5; } })();
function saFrame(dt, t) {
  const act = Lab.running ? 1 : 0.15, rate = Lab.stats.rate || 4;
  $$(".sa").forEach((cv) => { if (!vis(cv)) return; const i = +cv.dataset.i, w = cv.parentElement.clientWidth - 22, h = 48; if (w < 20) return; const c = fitCanvas(cv, w, h); c.clearRect(0, 0, w, h);
    if (i === 0) { const sp = 14 * act + 2; SA.x += dt * sp; const cdw = w / 24; if (SA.x > cdw) { SA.x -= cdw; const l = SA.cd[SA.cd.length - 1], o = l.c, cl = o + (Math.random() - 0.48) * 3; SA.cd.push({ o, c: cl, h: Math.max(o, cl) + Math.random() * 1.5, l: Math.min(o, cl) - Math.random() * 1.5 }); SA.cd.shift(); }
      const v = SA.cd.slice(-26), lo = Math.min(...v.map((k) => k.l)), hi = Math.max(...v.map((k) => k.h)), Y = (z) => h - 4 - (z - lo) / (hi - lo || 1) * (h - 8); v.forEach((k, j) => { const x = j * cdw - SA.x + 2, up = k.c >= k.o; c.strokeStyle = c.fillStyle = up ? "#26c6a0" : "#f2566a"; c.globalAlpha = Lab.loading ? 0.3 + 0.7 * (j / v.length < Lab.loadFrac ? 1 : 0) : 0.85; c.beginPath(); c.moveTo(x + 2, Y(k.h)); c.lineTo(x + 2, Y(k.l)); c.stroke(); c.fillRect(x, Math.min(Y(k.o), Y(k.c)), 4, Math.max(1.5, Math.abs(Y(k.o) - Y(k.c)))); }); c.globalAlpha = 1; }
    else if (i === 1) { const cols = 12, rows = 3, s = Math.min(8, w / cols - 3), n = cols * rows, k = Math.floor((t * (1.5 + act * 3)) % (n * 1.4)); for (let a = 0; a < n; a++) { const on = a < k, fam = GEN[a % 6][2]; c.fillStyle = on ? fam : "#1b2133"; c.globalAlpha = on ? 0.9 : 1; c.fillRect(2 + (a % cols) * (s + 3), 4 + Math.floor(a / cols) * (s + 4), s, s); } c.globalAlpha = 1; }
    else if (i === 2) { if (Math.random() < dt * (2 + rate * act)) SA.q.push({ x: 0, col: GEN[Math.floor(Math.random() * 6)][2] }); for (let k = SA.q.length - 1; k >= 0; k--) { const q = SA.q[k]; q.x += dt * (30 + 40 * act); if (q.x > w) { SA.q.splice(k, 1); continue; } c.fillStyle = q.col; c.globalAlpha = 1 - q.x / w * 0.5; c.beginPath(); c.arc(q.x, h / 2 + Math.sin(q.x * 0.08) * 4, 3.2, 0, 6.3); c.fill(); } c.globalAlpha = 1; c.strokeStyle = "#232a3f"; c.beginPath(); c.moveTo(0, h / 2 + 8); c.lineTo(w, h / 2 + 8); c.stroke(); }
    else if (i === 3) { SA.ph += dt * (act * (3 + rate * 0.9) + 0.4); const cw = Math.min(26, w / 3.4); for (let p = 0; p < 3; p++) { const x = w / 2 + (p - 1) * (cw + 8) - cw / 2, ph = SA.ph + p * 2.1, y = 20 + Math.sin(ph) * 11; c.fillStyle = "#12172a"; c.strokeStyle = "#3a4366"; c.lineWidth = 1.2; c.fillRect(x, 8, cw, h - 10); c.strokeRect(x, 8, cw, h - 10);
        const hot = Lab.running ? 0.5 + 0.5 * Math.sin(ph) : 0.15, g = c.createLinearGradient(0, y, 0, y + 14); g.addColorStop(0, `rgba(255,${Math.round(150 + hot * 60)},60,.95)`); g.addColorStop(1, "rgba(255,120,40,.5)"); c.fillStyle = g; c.fillRect(x + 2, y, cw - 4, 14); c.fillStyle = "#6a7188"; c.fillRect(x + cw / 2 - 1.5, 2, 3, y - 2); if (Lab.running && Math.sin(ph) > 0.92) { const gg = c.createRadialGradient(x + cw / 2, 10, 0, x + cw / 2, 10, 14); gg.addColorStop(0, "rgba(255,200,100,.8)"); gg.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = gg; c.fillRect(x - 6, 0, cw + 12, 24); } } }
    else if (i === 4) { const mid = w / 2; c.fillStyle = "#12172a"; c.beginPath(); c.moveTo(mid - w * 0.4, 4); c.lineTo(mid + w * 0.4, 4); c.lineTo(mid + 7, h * 0.62); c.lineTo(mid + 7, h - 3); c.lineTo(mid - 7, h - 3); c.lineTo(mid - 7, h * 0.62); c.closePath(); c.fill(); c.strokeStyle = "#3a4366"; c.stroke();
      if (Math.random() < dt * (4 + rate * act)) SA.sv.push({ x: mid + (Math.random() - 0.5) * w * 0.6, y: 5, ok: Math.random() < Math.max(0.08, Lab.cnt.test ? Lab.cnt.passIS / Lab.cnt.test : 0.2), vx: 0 }); for (let k = SA.sv.length - 1; k >= 0; k--) { const q = SA.sv[k]; q.y += dt * 40; if (q.y < h * 0.55) q.x += (mid - q.x) * dt * 2.2; else if (!q.ok) { q.x += (q.x < mid ? -1 : 1) * dt * 46; } else q.x += (mid - q.x) * dt * 8; if (q.y > h || q.x < 0 || q.x > w) { SA.sv.splice(k, 1); continue; } c.fillStyle = q.ok ? "#35e0c4" : "#6b738c"; c.globalAlpha = q.ok ? 1 : Math.max(0.15, 1 - (q.y - h * 0.5) / (h * 0.6)); c.beginPath(); c.arc(q.x, q.y, 2.4, 0, 6.3); c.fill(); } c.globalAlpha = 1; }
    else if (i === 5) { const n = 12, bw = w / n; const sx = ((t * 0.5 * (act + 0.2)) % 1) * w; for (let k = 0; k < n; k++) { const bh = 8 + ((k * 7) % 5) * 5, x = k * bw + 2, d = Math.abs(sx - (x + bw / 2)); c.fillStyle = d < bw ? "#35e0c4" : "#232a3f"; c.fillRect(x, h - 6 - bh, bw - 5, bh); } c.strokeStyle = "rgba(53,224,196,.8)"; c.lineWidth = 1.5; c.beginPath(); c.moveTo(sx, 2); c.lineTo(sx, h - 3); c.stroke(); const g = c.createRadialGradient(sx, h / 2, 0, sx, h / 2, 18); g.addColorStop(0, "rgba(53,224,196,.35)"); g.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = g; c.fillRect(sx - 18, 0, 36, h); c.strokeStyle = "#8a7bff"; c.lineWidth = 1.5; c.beginPath(); c.arc(sx, 14, 7, 0, 6.3); c.moveTo(sx + 5, 19); c.lineTo(sx + 10, 25); c.stroke(); }
    else { const pages = Math.min(7, 1 + Math.ceil(Lab.book.length / 3)); for (let k = 0; k < pages; k++) { const y = h - 8 - k * 4.2; c.fillStyle = k === pages - 1 ? "#1d2336" : "#141a2a"; c.strokeStyle = "#3a4366"; c.lineWidth = 1; c.beginPath(); c.roundRect(w / 2 - 26 + k * 0.6, y - 5, 52, 8, 2); c.fill(); c.stroke(); } const fl = SA.flip || 0; if (fl > 0) { SA.flip -= dt * 1.2; c.fillStyle = "rgba(255,220,140," + fl + ")"; c.beginPath(); c.roundRect(w / 2 - 26 * (1 - Math.abs(Math.sin((1 - fl) * 3))), h - 8 - pages * 4.2 - 6, 52 * (1 - Math.abs(Math.sin((1 - fl) * 3))) + 1, 8, 2); c.fill(); } c.fillStyle = "#35e0c4"; c.font = '700 11px "Cascadia Mono",monospace'; c.textAlign = "center"; c.fillText("+" + Lab.cnt.kept + " / " + Lab.cnt.cand, w / 2 + 44, 14); c.textAlign = "left"; } });
}
TICKS.push(saFrame);
DT.on("wake", () => { LB.pulses.length = 0; SA.q.length = 0; SA.sv.length = 0; });
DT.on("lab:book", () => { SA.flip = 1; });
function buildLab() {
  const pg = $("#pg-lab"), opt = (a, v) => a.map((x) => `<option ${String(x) === String(v) ? "selected" : ""}>${x}</option>`).join("");
  pg.innerHTML = `<div class="eyebrow">Beyin · strateji fabrikası</div><h1>Laboratuvar</h1>
  <p class="lead">Kendi kendine strateji üretir, IS'te evrimleştirir, OOS'ta sınar. Çoğu tarif elenir.</p>
  <div class="panel"><div class="ph">Laboratuvar beyni <small>üretici ajanlar ve ağları</small><div class="sp"><span class="chip vio" id="lb-state">—</span></div></div><div class="lbrain" id="lb-brain-w" style="height:560px"><canvas id="lb-brain"></canvas><div class="cap" id="lb-cap">—</div></div></div>
  <div class="kpis" id="lb-kpis"></div>
  <div class="panel"><div class="ph">Akış <small>istasyona tıkla</small></div><div class="stations" id="lb-stn"></div><div class="stdet" id="lb-det"></div></div>
  <div class="panel nnhost" id="lb-nn"></div>
  <div class="two"><div class="panel"><div class="ph">Eleme hunisi <small>bu oturum</small></div><div class="pb fun" id="lb-fun"></div></div>
  <div class="panel"><div class="ph">Şans ve aşırı uyum <small>neden çoğu strateji elenir</small></div><div class="pb" id="lb-luck" style="font-size:12.5px;line-height:1.6;color:#aab1c4"></div></div></div>
  <div class="panel"><div class="ph">Getiri eğrileri <small>IS | OOS</small><div class="sp"><button class="btn" id="lb-c1">Renk: sonuca göre</button></div></div>
    <div id="cloud-wrap"><canvas id="cloud"></canvas></div>
    <div class="legend"><span><i style="background:#8c96af"></i>IS'te düştü</span><span><i style="background:#ff963c"></i>OOS'ta çöktü</span><span><i style="background:#f2566a"></i>kırılgan</span><span><i style="background:#ffb04a"></i>aday</span><span><i style="background:#35e0c4"></i>kalıcı</span><span><i style="background:#fff"></i>son test</span></div></div>
  <div class="panel"><div class="ph">Motor günlüğü <small>canlı</small></div><div class="log" id="lb-log"></div></div>
  <details class="panel"><summary class="ph" style="cursor:pointer">Laboratuvar ayarları</summary><div class="pb ctl">
    <label class="fld">Sembol<select id="lb-sym">${["AUTO|Otomatik (açık piyasa, altın öncelikli)", "XAUUSDT|Altın XAU", "XAGUSDT|Gümüş XAG", "BTCUSDT|BTC", "ETHUSDT|ETH"].map((x) => { const [v, n] = x.split("|"); return `<option value="${v}" ${(Lab.symMode === "auto" ? "AUTO" : Lab.sym) === v ? "selected" : ""}>${n}</option>`; }).join("")}</select></label>
    <label class="fld">Zaman<select id="lb-tf">${opt(["5m", "15m", "1h"], Lab.tf)}</select></label>
    <label class="fld">Geçmiş (gün)<select id="lb-days">${opt([30, 60, 90, 180, 365], Lab.days)}</select></label>
    <label class="fld">Komisyon bps/yön<input id="lb-fee" type="number" step="0.5" min="0" value="${Lab.cfg.fee}" style="width:90px"></label>
    <label class="fld">Kayma bps/yön<input id="lb-slip" type="number" step="0.5" min="0" value="${Lab.cfg.slip}" style="width:90px"></label>
    <label class="fld">Risk %/işlem<input id="lb-risk" type="number" step="0.25" min="0.1" value="${Lab.cfg.risk * 100}" style="width:90px"></label>
    <label class="fld">IS payı %<input id="lb-split" type="number" step="5" min="40" max="80" value="${Lab.cfg.split * 100}" style="width:80px"></label>
    <button class="btn pri" id="lb-go">Uygula ve yeniden yükle</button><button class="btn" id="lb-pause">Duraklat</button>
    <span class="muted" style="font-size:11px;max-width:300px">5 dk gibi kısa zamanlarda komisyon (≈0.1% gidiş-dönüş) ATR'nin büyük kısmını yer; çoğu tarif bu yüzden elenir.</span></div></details>`;
  const apply = () => { const sv = $("#lb-sym").value; Lab.symMode = sv === "AUTO" ? "auto" : "fixed"; LS.set("nera_lab_symmode", Lab.symMode); if (sv !== "AUTO") Lab.sym = sv; Lab.tf = $("#lb-tf").value; Lab.days = +$("#lb-days").value; Lab.cfg.fee = Math.max(0, +$("#lb-fee").value); Lab.cfg.slip = Math.max(0, +$("#lb-slip").value); Lab.cfg.risk = Math.max(0.001, +$("#lb-risk").value / 100); Lab.cfg.split = Math.min(0.8, Math.max(0.4, +$("#lb-split").value / 100)); Lab.want = true; LS.set("nera_lab_want", true); applyCfg(); };
  $("#lb-go").onclick = apply; $("#lb-pause").onclick = () => { if (Lab.running || Lab.loading) pause(); else resume(); }; $("#lb-c1").onclick = () => { cloudMode = 1 - cloudMode; $("#lb-c1").textContent = cloudMode ? "Renk: tek renk" : "Renk: sonuca göre"; };
  $("#lb-stn").innerHTML = STN.map((s, i) => `<div class="stn ${Lab.sel === i + 1 ? "sel" : ""}" data-i="${i + 1}"><div class="n"><i id="si-${i}"></i>İSTASYON 0${i + 1}</div><h4>${s[1]}</h4><canvas class="sa" data-i="${i}"></canvas><div class="big" id="sb-${i}">—</div><div class="sub" id="ss-${i}"></div></div>`).join("");
  $$(".stn", pg).forEach((e) => (e.onclick = () => { Lab.sel = +e.dataset.i; $$(".stn", pg).forEach((x) => x.classList.toggle("sel", x === e)); updLab(true); }));
  LB.init();
}
let cloudMode = 0;
DT.on("lab:cand", (r) => LB.fire(r.g.rec, r.status, r.g));
function drawCloud() {
  const cv = $("#cloud"); if (!cv) return; const wrap = cv.parentElement, w = wrap.clientWidth, h = wrap.clientHeight; if (w < 20) return; const c = fitCanvas(cv, w, h); c.fillStyle = "#080b11"; c.fillRect(0, 0, w, h);
  const sp = 0.52, X = (q, mark) => (q <= mark ? (q / Math.max(mark, 0.01)) * w * sp : w * sp + ((q - mark) / Math.max(1 - mark, 0.01)) * w * (1 - sp));
  const all = []; for (const r of Lab.cloud) if (r.curve) for (let i = 0; i < r.curve.length; i += 4) all.push(r.curve[i]); all.sort((a, b) => a - b); const lo = all.length ? all[Math.floor(all.length * 0.02)] : -3, hi = all.length ? all[Math.floor(all.length * 0.985)] : 3, pad = (hi - lo) * 0.08 || 1, Y = (v) => h - 24 - ((Math.max(lo - pad, Math.min(hi + pad, v)) - (lo - pad)) / (hi - lo + 2 * pad)) * (h - 48);
  c.fillStyle = "rgba(20,28,60,.35)"; c.fillRect(w * sp, 0, w * (1 - sp), h); c.strokeStyle = "rgba(120,140,200,.12)"; c.lineWidth = 1; for (let i = 1; i < 6; i++) { c.beginPath(); c.moveTo(0, h * i / 6); c.lineTo(w, h * i / 6); c.stroke(); }
  c.strokeStyle = "rgba(255,255,255,.35)"; c.setLineDash([4, 5]); c.beginPath(); c.moveTo(w * sp, 0); c.lineTo(w * sp, h); c.stroke(); c.setLineDash([]); c.fillStyle = "#6a7188"; c.font = '700 10px "Cascadia Mono",Consolas,monospace'; c.fillText("IN-SAMPLE (IS) · GÖRÜLEN", 12, 16); c.fillText("OUT-OF-SAMPLE (OOS) · HİÇ GÖRÜLMEMİŞ", w * sp + 12, 16);
  if (!Lab.cloud.length) { c.fillStyle = "#6f768c"; c.font = "13px sans-serif"; c.fillText(Lab.loading ? "Geçmiş veri indiriliyor…" : "Test sonuçları burada çizilecek", w / 2 - 110, h / 2); return; }
  const draw = (r, lw, col) => { const n = r.curve.length, last = r.status === "rej-is" ? Math.ceil(r.mark * n) : n; c.strokeStyle = col; c.lineWidth = lw; c.beginPath(); for (let i = 0; i < last; i++) { const x = X((i + 1) / n, r.mark), y = Y(r.curve[i]); i ? c.lineTo(x, y) : c.moveTo(x, y); } c.stroke(); };
  for (const r of Lab.cloud) { if (r === Lab.cur) continue; const col = cloudMode ? "rgba(138,123,255,.14)" : (ST_COL[r.status] || "rgba(140,150,175,") + (r.status === "kept" ? "0.95)" : r.status === "cand" ? "0.75)" : r.status === "rej-is" ? "0.10)" : "0.42)"); draw(r, r.status === "kept" ? 2 : r.status === "cand" ? 1.5 : 1, col); }
  if (Lab.cur && Lab.cur.curve) draw(Lab.cur, 2, "rgba(255,255,255,.95)");
}
function fitCanvas(cv, w, h) { const d = Math.min(IS_M() ? 1.25 : 2, devicePixelRatio || 1); w = Math.round(w); h = Math.round(h); if (cv._w !== w || cv._h !== h) { cv.width = w * d; cv.height = h * d; cv.style.width = w + "px"; cv.style.height = h + "px"; cv._w = w; cv._h = h; } const c = cv.getContext("2d"); c.setTransform(d, 0, 0, d, 0, 0); return c; }
Lab.fitCanvas = fitCanvas;
function updLab(force) {
  if (!$("#lb-kpis")) return; const c = Lab.cnt, st = Lab.stats, set = (id, v) => { const e = $("#" + id); if (e && e.textContent !== String(v)) e.textContent = v; };
  const sh = Lab.cloud.filter((r) => r.oos && r.is).map((r) => r.is.sh - r.oos.sh), mdSh = med(sh);
  const k = [["Çalışma", nf(c.test), "bu oturumdaki test", ""], ["OOS'u geçen", nf(c.passOOS), "kapalı kutuyu aşan", "b"], ["Kalıcı", nf(c.kept), "şans sınırını geçti", "a"], ["Sharpe düşüşü", mdSh == null ? "—" : f1(mdSh, 2), "IS→OOS medyan", "d"], ["Şans sınırı", st.thr == null ? "—" : f1(st.thr, 2), "OOS Sharpe gerekli eşik", "c"], ["Aşırı uyum riski", st.pbo == null ? "—" : pc(st.pbo), "PBO (iyi IS'in OOS'ta ortanca altı)", "d"]];
  const h = k.map(([l, v, s, cl]) => `<div class="kp ${cl}"><div class="l">${l}</div><div class="v">${v}</div><div class="s">${s}</div></div>`).join(""); const el = $("#lb-kpis"); if (el._h !== h) { el._h = h; el.innerHTML = h; }
  STN.forEach((s, i) => { set("sb-" + i, s[2]()); set("ss-" + i, s[3]()); const d = $("#si-" + i); if (d) d.className = i === 3 && Lab.running ? "run" : i === 0 && Lab.loading ? "run" : (i === 0 ? Lab.data : i === 1 ? Lab.meta : i === 2 ? c.idea : i === 4 ? c.test : i === 5 ? c.passOOS : Lab.book.length) ? "on" : ""; });
  const sel = STN[Lab.sel - 1], dh = `<div><h5>İSTASYON 0${Lab.sel} · ${sel[1].toUpperCase()}</h5>${esc(sel[4]())}</div><div><h5>ŞU AN</h5><span class="mono" style="font-size:11.5px">${Lab.cur ? esc(Lab.cur.name) + "<br>" + esc(Lab.cur.reason || "") : "—"}</span></div>`; const det = $("#lb-det"); if (det._h !== dh) { det._h = dh; det.innerHTML = dh; }
  set("lb-state", Lab.loading ? `veri %${Math.round(Lab.loadFrac * 100)}` : Lab.err ? "hata" : Lab.running ? "çalışıyor" : "duraklı"); const pb = $("#lb-pause"); if (pb) pb.textContent = Lab.running || Lab.loading ? "Duraklat" : "Devam et";
  set("lb-cap", Lab.cur ? "şu an: " + Lab.cur.name : Lab.err || "—");
  const fn = [["Fikir (üretilen)", c.idea, "#8a7bff"], ["IS'te yeterli", c.passIS, "#4dd0e1"], ["OOS'u geçen", c.passOOS, "#ffb04a"], ["Dayanıklı", c.rob, "#ff9800"], ["Aday + kalıcı", c.cand + c.kept, "#35e0c4"], ["Kalıcı", c.kept, "#26c6a0"]], mx = Math.max(1, c.idea);
  const fh = fn.map(([l, v, col]) => `<div class="r"><span>${l}</span><div class="bar2"><i style="width:${Math.max(0.4, v / mx * 100)}%;background:${col}"></i></div><span class="mono" style="text-align:right">${nf(v)}</span></div>`).join(""); const fe = $("#lb-fun"); if (fe._h !== fh) { fe._h = fh; fe.innerHTML = fh; }
  const lk = `<b>${nf(c.passIS)}</b> tarif OOS'a girdi. Bu kadar denemede salt şansla bile bir stratejinin yıllıklandırılmış Sharpe'ı <b class="nc">≈${st.thr == null ? "—" : f1(st.thr, 1)}</b>'e ulaşabilir; kalıcı sayılmak için OOS Sharpe'ın bunu aşması istenir. İyi IS'li tariflerin <b class="nb">${st.pbo == null ? "—" : pc(st.pbo)}</b>'i OOS'ta ortancanın altına düştü (PBO ~%50 ise IS skoru OOS'u hiç öngörmüyor demektir).<br><span class="muted">Kalıcı sayısı küçük kalırsa bu hata değil, dürüst sonuçtur. Elenen her tarif, yanlışlıkla izlemeye alınmayan bir tarif demektir.</span>`; const le = $("#lb-luck"); if (le._h !== lk) { le._h = lk; le.innerHTML = lk; }
  const lg = Lab.log.slice(0, 60).map((l) => `<div class="ln"><span class="tm">${l.t}</span><span class="tg ${l.cls}">${l.tag}</span><span>${esc(l.txt)}</span></div>`).join(""); const lo = $("#lb-log"); if (lo._h !== lg) { lo._h = lg; lo.innerHTML = lg; }
  drawCloud();
}

/* ---------------------------------------------------------------- STRATEJİ DEFTERİ */
function buildBook() { $("#pg-book").innerHTML = `<div class="eyebrow">Beyin · kayıtlı stratejiler</div><h1>Strateji Defteri</h1><p class="lead">Elekten geçen stratejiler. Emir gönderilmez; kâr garantisi yoktur.</p><div class="panel"><div class="ph">Şans sınırını geçen strateji ne olur?</div><div class="pb" style="font-size:12.5px;line-height:1.7;color:var(--text2)">1) Bu deftere yazılır ve bildirim gelir (ayarlardan kapatılır). 2) Yüklü sembolde son kapanmış muma bakılarak "şimdi AL/SAT sinyali var mı" işaretlenir; haber ters ise "haber ters" etiketi alır. 3) Backtest Stüdyosu onu otomatik olarak 180 günde yeniden test eder. 4) Arama motoru onu tohum olarak kullanıp benzerlerini üretir. 5) Sinyal Beyni onu "strateji defteri" üyesi olarak oylamaya katar. Hiçbir aşamada emir gönderilmez; gerçek parayla kullanma kararı sana aittir.</div></div><div class="panel bk-galp"><div class="ph">Strateji galaksisi <small>yanıp sönen = sinyal veriyor</small></div><div class="bk-gal"><canvas id="bk-gal"></canvas><div class="tier-leg" id="bk-leg"></div></div></div><div class="panel"><div class="ph">Kayıtlı stratejiler <small id="bk-n"></small><div class="sp"><button class="btn warn" id="bk-clear">Defteri temizle</button></div></div><div style="overflow:auto"><table class="tbl"><thead><tr><th>Strateji</th><th>Piyasa</th><th>IS</th><th>OOS</th><th>Sharpe</th><th>Şans eşiği</th><th>Durum</th><th>Şimdi</th><th></th></tr></thead><tbody id="bk-body"></tbody></table></div></div>`; $("#bk-clear").onclick = () => { if (confirm("Defterdeki tüm kayıtlar silinsin mi?")) { Lab.book = []; LS.set("dt_lab_book", []); updBook(true); } }; }
function updBook(force) {
  const b = $("#bk-body"); if (!b) return; $("#bk-n").textContent = `${Lab.book.length} kayıt`;
  const rows = Lab.book.map((r, i) => { const lv = Lab.live[keyOf(r)], here = Lab.data && Lab.data.sym === r.sym && Lab.data.tf === r.tf, now = !here ? '<span class="muted">veri: ' + r.sym.replace("USDT", "") + " " + r.tf + "</span>" : lv ? (lv.side > 0 ? '<span class="chip ok">AL şimdi</span>' : lv.side < 0 ? '<span class="chip bad">SAT şimdi</span>' : '<span class="muted">sinyal yok</span>') + (Lab.newsAdj && lv.side ? Lab.newsAdj(r.sym, lv.side) : "") : "…";
    const TL = window.NeraStrat ? NeraStrat.info(r) : { k: r.status === "kept" ? "pulsar" : "dust", glyph: "", label: r.status === "kept" ? "KALICI" : "ADAY", code: "" }, lsv = window.LabSig ? LabSig.stateOf(r) : null, now2 = lsv && lsv.side ? `<span class="chip ${lsv.side > 0 ? "ok" : "bad"} blink">${lsv.side > 0 ? "LONG" : "SHORT"} şimdi</span>` : now;
    return `<tr class="bkrow" style="--i:${i}"><td style="max-width:380px"><div class="sname"><span class="tier t-${TL.k}">${TL.glyph} ${TL.label}</span><b>${TL.code}</b></div>${esc(r.name)}<div class="muted" style="font-size:10.5px">${new Date(r.at).toLocaleString("tr-TR")} · dayanıklılık ${pc(r.rob)}</div></td><td>${r.sym.replace("USDT", "")} ${r.tf}</td><td>${r.is.n} · ${f1(r.is.avgR)}R</td><td class="${r.oos.avgR > 0 ? "na" : "down"}">${r.oos.n} · ${f1(r.oos.avgR)}R</td><td>${f1(r.oos.sh)}</td><td>${r.dsr ? f1(r.dsr.thr) : "—"}</td><td><span class="chip ${r.status === "kept" ? "ok" : "warn"}">${r.status === "kept" ? "KALICI" : "ADAY"}</span></td><td>${now2}</td><td style="white-space:nowrap"><button class="btn" data-bt="${i}">Backtest</button> <button class="btn" data-rm="${i}">Sil</button></td></tr>`; }).join("");
  const h = rows || `<tr><td colspan="9" class="empty2">Henüz kayıt yok. Laboratuvar çalıştıkça elekten geçenler burada birikir.</td></tr>`; if (b._h !== h || force) { b._h = h; b.innerHTML = h; $$("[data-bt]", b).forEach((e) => (e.onclick = () => { DT.emit("bt:open", Lab.book[+e.dataset.bt]); go("bt"); })); $$("[data-rm]", b).forEach((e) => (e.onclick = () => { Lab.book.splice(+e.dataset.rm, 1); LS.set("dt_lab_book", Lab.book); updBook(true); })); }
}
function pollLive() { if (!Lab.data || !Lab.w) return; const gs = Lab.book.filter((r) => r.sym === Lab.data.sym && r.tf === Lab.data.tf); if (!gs.length) return; const keys = gs.map(keyOf); Lab.w.postMessage({ cmd: "live", gs: gs.map((r) => r.g), rid: 1 }); Lab._lk = keys; }


/* ---------------------------------------------------------------- döngü */
function refresh(force) { if (cur === "brain") updBrain(); else if (cur === "lab") updLab(force); else if (cur === "book") updBook(force); DT.emit("refresh", cur); const s = $("#lab-state"), led = $("#lab-led"), mi = $("#lab-mini"); const tg = $("#lab-toggle"); if (tg) { const tx = Lab.running || Lab.loading ? "Duraklat" : "Devam et"; if (tg.textContent !== tx) tg.textContent = tx; } if (s) { s.textContent = Lab.loading ? "Lab veri yüklüyor" : Lab.running ? "Lab çalışıyor" : Lab.err ? "Lab hata" : "Lab beklemede"; led.classList.toggle("on", Lab.running); mi.textContent = `${nf(Lab.cnt.test)} test · ${Lab.cnt.kept} kalıcı`; } }
const ANI = {
  xbot: '<path class="i-pk" d="M7 20l3.2-16M17 20L13.8 4"/><path d="M8.4 15h7.2M9.2 11h5.6M10 7h4"/><circle class="i-eye" cx="12" cy="3.2" r="1.3"/><path class="i-ring" d="M4 20h16"/>',
  
  brain: '<circle class="i-ring" cx="12" cy="12" r="8.6"/><circle class="i-core" cx="12" cy="12" r="2.7"/><path class="i-ray" d="M12 3v4M12 17v4M3 12h4M17 12h4"/>',
  market: '<path d="M6 3v3M6 15v4M12 4v3M12 17v3M18 7v3M18 17v3"/><rect class="i-c1" x="4.2" y="6" width="3.6" height="9" rx="1"/><rect class="i-c2" x="10.2" y="7" width="3.6" height="10" rx="1"/><rect class="i-c3" x="16.2" y="10" width="3.6" height="7" rx="1"/>',
  lab: '<path d="M9 3h6M10 3v6l-5.5 9.5A2 2 0 0 0 6.2 21h11.6a2 2 0 0 0 1.7-2.5L14 9V3"/><circle class="i-b1" cx="10.4" cy="17.2" r="1.1"/><circle class="i-b2" cx="13.8" cy="17.6" r="0.9"/><circle class="i-b3" cx="12" cy="18" r="0.7"/>',
  news: '<path d="M4 5h13v14H6a2 2 0 0 1-2-2zM17 9h3v8a2 2 0 0 1-2 2"/><path class="i-l1" d="M8 9h6"/><path class="i-l2" d="M8 13h6"/><path class="i-l3" d="M8 16.5h4"/>',
  menu: '<circle class="i-d1" cx="5" cy="12" r="1.8"/><circle class="i-d2" cx="12" cy="12" r="1.8"/><circle class="i-d3" cx="19" cy="12" r="1.8"/>',
  set: '<g class="i-gear"><circle cx="12" cy="12" r="3"/><path d="M12 2.8v3M12 18.2v3M2.8 12h3M18.2 12h3M5.5 5.5l2.1 2.1M16.4 16.4l2.1 2.1M18.5 5.5l-2.1 2.1M7.6 16.4l-2.1 2.1"/></g>',
  friends: '<circle class="i-f1" cx="9" cy="8.5" r="3"/><circle class="i-f2" cx="17" cy="9.5" r="2.4"/><path d="M3.2 20c.4-3.4 2.6-5.3 5.8-5.3s5.4 1.9 5.8 5.3M15.5 14.6c.7-.3 1.4-.4 2.1-.4 2.1 0 3.6 1.5 4 4.6"/>' };
Object.assign(ANI, {
  kanit: '<path class="i-ring" d="M12 3l7 3v5c0 4.5-3 8-7 10-4-2-7-5.5-7-10V6z"/><path class="i-l1" d="M8.5 12l2.5 2.5 4.5-5"/>',
  office: '<circle class="i-f1" cx="12" cy="6" r="2.4"/><circle class="i-f2" cx="5.5" cy="17" r="2.4"/><circle class="i-f1" cx="18.5" cy="17" r="2.4"/><path class="i-l1" d="M10.8 8.1L6.7 14.9M13.2 8.1l4.1 6.8M8 17h8"/>',
  book: '<path d="M5 4h11a3 3 0 0 1 3 3v13H8a3 3 0 0 1-3-3z"/><path d="M5 17a3 3 0 0 1 3-3h11"/><path class="i-l1" d="M9 8h6"/>',
  bt: '<path d="M3 20h18"/><path class="i-l1" d="M5 16l4-5 4 3 6-8"/><path d="M15 6h4v4"/>',
  kb: '<path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v15H6.5A2.5 2.5 0 0 0 4 20.5z"/><path d="M4 20.5A2.5 2.5 0 0 0 6.5 23H20"/><path class="i-l1" d="M9 8h7"/><path class="i-l2" d="M9 12h7"/>',
  labsig: '<circle class="i-ring" cx="12" cy="12" r="9"/><path class="i-core" d="M12 6.5l1.5 3.6 3.9.3-3 2.5 1 3.8L12 14.6l-3.4 2.1 1-3.8-3-2.5 3.9-.3z"/><circle class="i-tw" cx="19.5" cy="5" r="1"/>' });
const HAL = {
  brain: '<path d="M12 7c-.8-2-2.2-3-4-2.8M12 7c.8-2 2.2-3 4-2.8"/><path class="i-pk" d="M12 7.2c-5.6-1.3-9.2 2-9.2 6.1 0 4.2 3.6 7.2 9.2 7.2s9.2-3 9.2-7.2c0-4.1-3.6-7.4-9.2-6.1z"/><path d="M12 7.2v13.3"/><path class="i-eye" d="M7.2 12.6l2.4 1.9-2.8.2zM16.8 12.6l-2.4 1.9 2.8.2z"/><path class="i-eye" d="M8.4 17.4c1.6 1.4 5.6 1.4 7.2 0"/>',
  market: '<g class="i-bat"><path d="M12 9.5C10.8 6.8 8 5 3 5.4c1.4 1.5 1.8 3.2 1.5 4.9 1.3-.7 2.6-.4 3.6 1 .8-1.2 2-1.6 3.9-1.8zM12 9.5c1.2-2.7 4-4.5 9-4.1-1.4 1.5-1.8 3.2-1.5 4.9-1.3-.7-2.6-.4-3.6 1-.8-1.2-2-1.6-3.9-1.8z"/></g><circle cx="12" cy="12.5" r="2"/><path d="M11 10.5l-.5-1.6M13 10.5l.5-1.6"/>',
  lab: '<path d="M5 10h14M6.3 10c-.7 6 1.6 9.5 5.7 9.5s6.4-3.5 5.7-9.5"/><path d="M8 19.5l-1 2M16 19.5l1 2"/><circle class="i-b1" cx="10" cy="7" r="1.1"/><circle class="i-b2" cx="14" cy="7.5" r="0.9"/><circle class="i-b3" cx="12" cy="6" r="0.7"/>',
  news: '<path d="M20 14.5A8.5 8.5 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/><path class="i-tw" d="M16 5v3M14.5 6.5h3"/>',
  office: '<path d="M12 3c1 5 1.8 8 3 11H9c1.2-3 2-6 3-11z"/><path d="M4 18c2-2 5-3 8-3s6 1 8 3c-2 2-5 3-8 3s-6-1-8-3z"/><path class="i-l1" d="M9.5 13.5h5"/>',
  friends: '<g class="i-gh"><path d="M5 20V11a7 7 0 0 1 14 0v9l-2.3-1.8L14.3 20 12 18.2 9.7 20l-2.4-1.8z"/><circle cx="9.5" cy="11" r="1.1"/><circle cx="14.5" cy="11" r="1.1"/></g>',
  set: '<path d="M12 3a7.5 7.5 0 0 0-7.5 7.5c0 2.6 1.3 4.4 3 5.3V19h9v-3.2c1.7-.9 3-2.7 3-5.3A7.5 7.5 0 0 0 12 3z"/><circle class="i-eye" cx="9" cy="11" r="1.6"/><circle class="i-eye" cx="15" cy="11" r="1.6"/><path d="M10.5 19v2M13.5 19v2"/>',
  menu: '<g class="i-sp"><circle cx="12" cy="13" r="3"/><path d="M12 10V2M9.5 11.5L5 8 3 6M14.5 11.5L19 8l2-2M9 14l-5 1-1.5 3M15 14l5 1 1.5 3"/></g>',
  book: '<path d="M5 4h11a3 3 0 0 1 3 3v13H8a3 3 0 0 1-3-3z"/><path class="i-tw" d="M12 8l1 2 2 .3-1.5 1.4.4 2L12 12.7 10.1 13.7l.4-2L9 10.3 11 10z"/>',
  bt: '<path d="M7 3h10M7 21h10M8 3c0 5 4 5 4 9s-4 4-4 9M16 3c0 5-4 5-4 9s4 4 4 9"/><path class="i-l1" d="M10 18h4"/>',
  kb: '<path d="M9 21h6V10H9zM12 10V8"/><path class="i-flame" d="M12 3c2 2 2.4 4 0 5.2-2.4-1.2-2-3.2 0-5.2z"/>',
  labsig: '<path d="M5 21l2-6M19 21l-2-6M7 15h10"/><path class="i-pk" d="M12 3a6 6 0 0 1 6 6c0 2.6-1.6 4.5-3.2 5.6H9.2C7.6 13.5 6 11.6 6 9a6 6 0 0 1 6-6z"/><circle class="i-eye" cx="10" cy="9" r="1"/><circle class="i-eye" cx="14" cy="9" r="1"/>' };
const isHal = () => document.body.classList.contains("theme-halloween");
function renderIcons() { const m = document.body.className.match(/theme-(\w+)/), th = m ? m[1] : "dark", set = th === "halloween" ? HAL : (window.THEME_ICONS && THEME_ICONS[th]) || ANI; $$("svg[data-ic]").forEach((s) => { const k = s.dataset.ic, h = set[k] || ANI[k] || ""; if (s._h !== h) { const first = s._h === undefined; s._h = h; s.innerHTML = h; if (!first) { s.classList.remove("ic-in"); void s.getBoundingClientRect(); s.classList.add("ic-in"); } } }); bats(th === "halloween"); if (window.themeFx) themeFx(th); }
function bats(on) { let b = $("#bats"); if (!on) { if (b) b.remove(); return; } if (b) return; b = document.createElement("div"); b.id = "bats"; b.innerHTML = [1, 2, 3, 4].map((n) => `<svg class="bat b${n}" viewBox="0 0 40 20"><path d="M20 10C17 4 11 1 1 2c3 3 4 6 3 10 3-1.5 5-1 7 2 1.6-2.2 4-3 9-3zM20 10c3-6 9-9 19-8-3 3-4 6-3 10-3-1.5-5-1-7 2-1.6-2.2-4-3-9-3z"/></svg>`).join(""); document.body.appendChild(b); }
DT.on("theme", () => renderIcons());
function mobileShell() {                                      // telefon: uygulama gibi alt sekme çubuğu, üstte Nera + sağda arkadaşlar/ayarlar, "Daha" menüsü
  document.body.classList.add("mnav"); const top = document.createElement("div"); top.id = "mtop"; top.appendChild($(".rail-brand"));
  const right = document.createElement("div"); right.className = "mtr"; right.innerHTML = ["friends", "set"].map((k) => `<button data-v="${k}" aria-label="${k}"><svg viewBox="0 0 24 24" data-ic="${k}"></svg></button>`).join(""); top.appendChild(right); document.body.appendChild(top);
  const tab = document.createElement("nav"); tab.id = "mtab"; tab.innerHTML = [["brain", "Beyin"], ["market", "Piyasa"], window.LABOFF ? ["kanit", "Kanıt"] : ["lab", "Lab"], ["office", "Ofis"], ["menu", "Daha"]].map(([k, n]) => `<button data-v="${k}"><svg viewBox="0 0 24 24" data-ic="${k}"></svg><span>${n}</span></button>`).join(""); document.body.appendChild(tab);
  const sh = document.createElement("div"); sh.id = "msheet"; sh.innerHTML = `<div class="bk"></div><div class="sh">${[["xbot", "XM Nera", "PC'deki XM işlemlerini canlı izle ve yönet"], ...(window.LABOFF ? [] : [["labsig", "Lab Sinyalleri", "testten geçen stratejilerin canlı sinyalleri"], ["book", "Strateji Defteri", "kayıtlı stratejiler"]]), ["news", "Haber", "haber görüşü ve akış"], ["bt", "Backtest Stüdyosu", "otomatik geçmiş testi"], ["kb", "Bilgi Bankası", "repolar ve platformlar"]].map(([k, n, d]) => `<button data-v="${k}"><svg viewBox="0 0 24 24" data-ic="${k}"></svg><div class="tx"><b>${n}</b><span>${d}</span></div><i class="rb"></i></button>`).join("")}</div>`; document.body.appendChild(sh);
  const tick = () => { try { if (navigator.vibrate) navigator.vibrate(8); if (window.Sound) Sound.tone(560, 0.05, 0.16); } catch (e) { /* */ } };
  $$("#mtab button").forEach((b) => (b.onclick = () => { tick(); if (b.dataset.v === "menu") { sh.classList.toggle("open"); return; } go(b.dataset.v); }));
  $$("#mtop .mtr button").forEach((b) => (b.onclick = () => { tick(); go(b.dataset.v); }));
  $$("#msheet .sh button").forEach((b) => (b.onclick = () => { tick(); go(b.dataset.v); })); $(".bk", sh).onclick = () => sh.classList.remove("open");
  $$("#mtab [data-v]").forEach((b) => b.classList.toggle("active", b.dataset.v === cur));
}
function boot() {
  if (matchMedia("(max-width:900px)").matches) mobileShell();
  $$(".rn").forEach((b) => { const s = b.querySelector("svg"); if (s) s.dataset.ic = b.dataset.v; }); renderIcons();
  document.body.dataset.view = cur; buildBrain(); buildLab(); buildBook(); refresh(true); window.toggleFS = () => { try { if (document.fullscreenElement) document.exitFullscreen(); else document.documentElement.requestFullscreen(); } catch (e) { /* desteklenmiyor */ } }; $("#fs-toggle").onclick = () => toggleFS(); addEventListener("keydown", (e) => { if (e.key === "F11") { e.preventDefault(); toggleFS(); } }); $("#bv-snd").onclick = $("#snd-toggle").onclick = () => Sound.toggle(); DT.on("sound", () => { const x = Sound.on ? "Ses: açık" : "Ses: kapalı"; $("#bv-snd").textContent = x; $("#snd-toggle").textContent = x; }); DT.emit("sound"); $("#lab-toggle").onclick = () => { if (Lab.running || Lab.loading) pause(); else resume(); $("#lab-toggle").textContent = Lab.running || Lab.loading ? "Duraklat" : "Devam et"; };
  setInterval(() => refresh(false), 450); setInterval(() => { if (cur === "lab") drawCloud(); }, 260); setInterval(pollLive, 30000); setInterval(() => { if (Lab.symMode === "auto" && Lab.want && Lab.running && !Lab.loading) load(); }, 25 * 60 * 1000); setTimeout(pollLive, 8000);
  if (Lab.want) setTimeout(load, 2500); else mk();
  const v = (() => { try { return sessionStorage.getItem("dt_view"); } catch (e) { return null; } })(); if (new URLSearchParams(location.search).get("view")) go(new URLSearchParams(location.search).get("view")); else if (v && v !== "brain") go(v);
}
window.addEventListener("DOMContentLoaded", boot);
/* sinyal olayı: Piyasa menüsüne nöron bağı */
DT.on("signal", (e) => LM.event("market", { color: e && e.side < 0 ? "#f2566a" : "#26c6a0", msg: "Yeni sinyal" }));
})();








