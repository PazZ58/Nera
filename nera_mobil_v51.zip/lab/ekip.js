"use strict";
/* Nera · Ekip Beyni (#v-team). 3 bilgisayardaki Claude Code hesaplarına tek promptu bölüp dağıtır; her şey Obsidian tarzı 3B bir bilgi grafiğinde görünür:
   hesaplar, dağıtımlar, görevler, fikirler, #etiketler ve [[bağlantılar]] düğümdür. Veri: NeraNet odası ekip_<kod>, durum fold() ile olaylardan türetilir
   (ekip/olay.py ile aynı kural, biri değişirse öbürü de). Olaylar: dispatch, plan, approve, claim, prog, done, fail, hb, mode, start, idea. Ajan: ekip/ajan.py.
   Renkler tuvalin kendi (.ek-stage) --na/--nb/--nc değişkenlerinden okunur, yani her temaya uyar. */
(function () {
const $ = (s, r = document) => r.querySelector(s);
const esc = (s) => String(s == null ? "" : s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const ONLINE_MS = 60000, LSg = (k, d) => { try { return localStorage.getItem(k) || d; } catch (e) { return d; } };
let code = LSg("nera_ekip", ""), close = null, EV = {}, S = null, sigs = {}, timer = 0;

function fold(events, now) {
  const R = { members: {}, tasks: {}, plans: {}, disp: {}, ideas: [] }, M = R.members, T = R.tasks;
  const mem = (u) => (M[u] = M[u] || { mode: "elle", busy: "", seen: 0, repo: "", on: false });
  events.slice().sort((a, b) => (a.t || 0) - (b.t || 0)).forEach((e) => {
    const k = e.k, u = e.u || "", t = e.t || 0;
    if (k === "hb") Object.assign(mem(u), { seen: t, busy: e.busy || "", mode: e.mode || "elle", repo: e.repo || "" });
    else if (k === "mode") mem(e.to || "").mode = e.auto ? "auto" : "elle";
    else if (k === "dispatch") R.disp[e.id] = { id: e.id, prompt: e.prompt || "", u, t };
    else if (k === "plan") R.plans[e.id] = { id: e.id, parts: e.parts || [], u, approved: false };
    else if (k === "approve") { const p = R.plans[e.id]; if (p && !p.approved) { p.approved = true; p.parts.forEach((q) => { T[q.pid] = T[q.pid] || { pid: q.pid, title: q.title || "", body: q.body || "", to: q.to || "", plan: p.id, st: "bekliyor", start: false, prog: "", pct: 0, sum: "", branch: "", t }; }); } }
    else if (k === "idea") R.ideas.push({ text: e.text || "", u, t });
    else {
      const tk = T[e.pid]; if (!tk) return;
      if (k === "start") tk.start = true;
      else if (k === "claim" && tk.st === "bekliyor" && u === tk.to) tk.st = "calisiyor";
      else if (k === "prog" && tk.st === "calisiyor" && u === tk.to) { tk.prog = e.line || ""; tk.pct = e.pct || 0; }
      else if ((k === "done" || k === "fail") && (tk.st === "bekliyor" || tk.st === "calisiyor") && u === tk.to) { tk.st = k === "done" ? "bitti" : "hata"; tk.sum = e.sum || e.err || ""; tk.branch = e.branch || ""; }
    }
  });
  Object.values(M).forEach((m) => { m.on = now - m.seen < ONLINE_MS; });
  return R;
}

const topic = () => "ekip_" + code.toLowerCase().replace(/[^a-z0-9_]/g, "");
const send = (ev, key) => window.NeraNet.pub(topic(), Object.assign({ u: window.NeraNet.user() }, ev), key ? { key } : undefined).catch((e) => toast(e.message));
const toast = (m) => { const t = $("#ek-msg"); if (t) { t.textContent = m; setTimeout(() => { if (t.textContent === m) t.textContent = ""; }, 4000); } };
function connect() {
  if (close) close(); close = null; EV = {}; S = null; sigs = {};
  if (!code || !window.NeraNet || !window.NeraNet.on()) return;
  close = window.NeraNet.listen([[topic(), Date.now() - 7 * 864e5]], (o) => { try { const e = JSON.parse(o.message); e.t = o.time; EV[String(o.id).split(":")[0]] = e; schedule(); } catch (x) { /* */ } });
}
function schedule() { if (timer) return; timer = setTimeout(() => { timer = 0; S = fold(Object.values(EV), Date.now()); render(); }, 250); }
function names() {
  const me = window.NeraNet.user(), n = Object.keys((S && S.members) || {}).filter((u) => u);
  n.sort((a, b) => (S.members[b].on - S.members[a].on) || a.localeCompare(b));
  if (me && !n.includes(me)) n.unshift(me);
  return n.slice(0, 3);
}

/* ---- renkler: tuvalin kendi değişkenlerinden (tema/palet değişince güncellenir) */
let PAL = ["#35e0c4", "#8a7bff", "#ffb04a"], palT = 0;
const rgb = (c) => { c = String(c).trim(); let m = c.match(/^#([0-9a-f]{3,8})$/i); if (m) { let h = m[1]; if (h.length < 6) h = h.replace(/./g, "$&$&"); return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)]; } m = c.match(/\d+/g); return m ? m.slice(0, 3).map(Number) : [200, 200, 220]; };
const rgba = (c, a) => { const q = rgb(c); return `rgba(${q[0]},${q[1]},${q[2]},${a})`; };
function readPal(t) { if (t - palT < 1500) return; palT = t; const st = getComputedStyle($("#ek-stage") || document.body); PAL = ["--na", "--nb", "--nc"].map((v, i) => st.getPropertyValue(v).trim() || PAL[i]); }

/* ---- grafik düğümleri (Obsidian mantığı: her şey düğüm, [[...]] ve #... bağ) */
const G = { nodes: new Map(), edges: [], sel: "", hov: "", q: "", first: true, prev: new Map() };
const KIND = { own: 105, src: 130, plan: 100, by: 120, ref: 115, ctx: 150 };
const SIZE = { member: 14, dispatch: 9, task: 7.5, idea: 6, tag: 4.5 };
function buildGraph() {
  const want = new Map(), edges = [], ns = names(), mi = (u) => Math.max(0, ns.indexOf(u));
  const add = (id, o) => want.set(id, Object.assign({ id }, o));
  ns.forEach((u, i) => add("m:" + u, { type: "member", title: u, ci: i, m: S.members[u] || { mode: "elle", on: false }, anchor: i }));
  const disp = Object.values(S.disp).sort((a, b) => b.t - a.t).slice(0, 8);
  disp.forEach((d) => { add("d:" + d.id, { type: "dispatch", title: d.prompt.slice(0, 40) || "dağıtım", text: d.prompt, ci: mi(d.u), u: d.u, t: d.t }); if (want.has("m:" + d.u)) edges.push(["d:" + d.id, "m:" + d.u, "src"]); });
  const ideas = S.ideas.slice(-40);
  Object.values(S.tasks).sort((a, b) => b.t - a.t).slice(0, 40).forEach((t) => {
    add("t:" + t.pid, { type: "task", title: t.title || t.pid, text: t.body, ci: mi(t.to), task: t });
    if (want.has("m:" + t.to)) edges.push(["t:" + t.pid, "m:" + t.to, "own"]); if (want.has("d:" + t.plan)) edges.push(["t:" + t.pid, "d:" + t.plan, "plan"]);
  });
  const lookup = (x) => { x = x.toLowerCase(); for (const [id, n] of want) if (n.type !== "tag" && n.title.toLowerCase().includes(x)) return id; return null; };
  ideas.forEach((i) => {
    const id = "i:" + i.t + ":" + i.u; add(id, { type: "idea", title: i.text.slice(0, 40), text: i.text, ci: mi(i.u), u: i.u, t: i.t });
    if (want.has("m:" + i.u)) edges.push([id, "m:" + i.u, "by"]);
  });
  ideas.forEach((i) => {
    const id = "i:" + i.t + ":" + i.u;
    (i.text.match(/\[\[[^\]]+\]\]/g) || []).forEach((w) => { const x = w.slice(2, -2), tg = lookup(x) || ("g:[[" + x.toLowerCase() + "]]"); if (!want.has(tg)) add(tg, { type: "tag", title: "[[" + x + "]]", ghost: true, ci: 0 }); if (tg !== id) edges.push([id, tg, "ref"]); });
    (i.text.match(/#[\p{L}\d_]+/gu) || []).forEach((h) => { const tg = "g:" + h.toLowerCase(); if (!want.has(tg)) add(tg, { type: "tag", title: h, ci: 0 }); edges.push([id, tg, "ref"]); });
  });
  Object.values(S.tasks).forEach((t) => { if (!want.has("t:" + t.pid)) return; ideas.filter((i) => i.t < t.t).slice(-3).forEach((i) => edges.push(["i:" + i.t + ":" + i.u, "t:" + t.pid, "ctx"])); });
  /* mevcut düğümlerin konumunu koru; yenileri bağlı olanın yanında doğur */
  const nb = {}; edges.forEach(([a, b]) => { (nb[a] = nb[a] || []).push(b); (nb[b] = nb[b] || []).push(a); });
  for (const id of [...G.nodes.keys()]) if (!want.has(id)) G.nodes.delete(id);
  const pulses = [];
  want.forEach((w, id) => {
    let n = G.nodes.get(id); const sig = JSON.stringify([w.task && [w.task.st, w.task.pct, w.task.prog], w.m && [w.m.on, w.m.mode], w.title]);
    if (!n) {
      const f = (nb[id] || []).map((x) => G.nodes.get(x)).find(Boolean), r = () => (Math.random() - 0.5) * 60, a = (w.anchor || 0) * 2.09 + 0.5;
      n = { x: f ? f.x + r() : w.type === "member" ? Math.cos(a) * 130 : r() * 3, y: f ? f.y + r() : w.type === "member" ? Math.sin(a) * 60 : r() * 3, z: f ? f.z + r() : w.type === "member" ? (w.anchor - 1) * 90 : r() * 3, vx: 0, vy: 0, vz: 0, born: performance.now() };
      G.nodes.set(id, n);
    }
    Object.assign(n, w); n.r = SIZE[w.type];
    if (G.prev.get(id) !== sig && !G.first) (nb[id] || []).slice(0, 5).forEach((o) => pulses.push([o, id]));
    G.prev.set(id, sig);
  });
  G.edges = edges.filter(([a, b]) => G.nodes.has(a) && G.nodes.has(b)); G.first = false; pulses.forEach(([a, b]) => pulse(a, b));
}

/* ---- 3B kamera + kuvvet yerleşimi + beyin kabuğu */
const CAM = { yaw: 0.5, pitch: -0.3, zoom: 1, idle: 0, drag: null };
let PS = [], cv, cx, W = 0, H = 0, shell = null, last = 0;
function pulse(a, b) { PS.push({ a, b, t0: performance.now(), d: 900 + Math.random() * 500 }); if (PS.length > 60) PS.shift(); }
function mkShell() {
  const n = 260, p = [];
  for (let i = 0; i < n; i++) { const y = 1 - (i / (n - 1)) * 2, r = Math.sqrt(1 - y * y), a = i * 2.39996; p.push({ x: Math.cos(a) * r * 330, y: y * 270, z: Math.sin(a) * r * 330, ph: Math.random() * 7 }); }
  p.forEach((q, i) => { q.l = p.map((o, j) => [j, (o.x - q.x) ** 2 + (o.y - q.y) ** 2 + (o.z - q.z) ** 2]).filter((o) => o[0] !== i).sort((a, b) => a[1] - b[1]).slice(0, 2).map((o) => o[0]); });
  return p;
}
function step() {
  const N = [...G.nodes.values()]; if (!N.length) return;
  N.forEach((a) => {
    let fx = -a.x * 0.006, fy = -a.y * 0.008, fz = -a.z * 0.006;
    if (a.type === "member") { const t = (a.anchor || 0) * 2.09 + 0.5; fx += (Math.cos(t) * 190 - a.x) * 0.012; fy += (Math.sin(t) * 80 - a.y) * 0.012; fz += (((a.anchor || 0) - 1) * 120 - a.z) * 0.012; }
    for (const b of N) { if (a === b) continue; const dx = a.x - b.x, dy = a.y - b.y, dz = a.z - b.z, d2 = dx * dx + dy * dy + dz * dz + 40, f = (a.r + b.r) * 16 / d2; fx += dx * f; fy += dy * f; fz += dz * f; }
    a.fx = fx; a.fy = fy; a.fz = fz;
  });
  G.edges.forEach(([i, j, k]) => { const a = G.nodes.get(i), b = G.nodes.get(j), dx = b.x - a.x, dy = b.y - a.y, dz = b.z - a.z, d = Math.sqrt(dx * dx + dy * dy + dz * dz) + 0.01, f = (d - KIND[k]) * 0.012 / d; a.fx += dx * f; a.fy += dy * f; a.fz += dz * f; b.fx -= dx * f; b.fy -= dy * f; b.fz -= dz * f; });
  N.forEach((a) => { a.vx = (a.vx + a.fx) * 0.86; a.vy = (a.vy + a.fy) * 0.86; a.vz = (a.vz + a.fz) * 0.86; const sp = Math.hypot(a.vx, a.vy, a.vz); if (sp > 8) { a.vx *= 8 / sp; a.vy *= 8 / sp; a.vz *= 8 / sp; } a.x += a.vx; a.y += a.vy; a.z += a.vz; });
}
const proj = (x, y, z) => { const cy = Math.cos(CAM.yaw), sy = Math.sin(CAM.yaw), cp = Math.cos(CAM.pitch), sp = Math.sin(CAM.pitch), x1 = x * cy + z * sy, z1 = -x * sy + z * cy, y1 = y * cp - z1 * sp, z2 = y * sp + z1 * cp, s = 760 / (760 + z2) * CAM.zoom * Math.min(W, H) / 430; return [W / 2 + x1 * s, H / 2 + y1 * s, z2, s]; };
function loop(t) {
  requestAnimationFrame(loop);
  if (document.body.dataset.view !== "team" || !cv || !cv.offsetWidth) return;
  readPal(t);
  const dpr = Math.min(window.devicePixelRatio || 1, 1.5), w = cv.offsetWidth, h = cv.offsetHeight;
  if (W !== w || H !== h) { W = w; H = h; cv.width = w * dpr; cv.height = h * dpr; }
  if (!shell) shell = mkShell();
  if (!CAM.drag && t - CAM.idle > 3000) CAM.yaw += 0.0016;
  if (S && t - last > 700) { last = t; const e = G.edges[Math.floor(Math.random() * G.edges.length)]; if (e) pulse(e[0], e[1]); }
  step(); cx.setTransform(dpr, 0, 0, dpr, 0, 0); cx.clearRect(0, 0, W, H);
  const lo = "lighter", br = 1 + Math.sin(t / 1100) * 0.05;
  /* çekirdek parıltısı */
  const cg = cx.createRadialGradient(W / 2, H / 2, 0, W / 2, H / 2, Math.min(W, H) * 0.5 * br); cg.addColorStop(0, rgba(PAL[1], 0.22)); cg.addColorStop(0.45, rgba(PAL[0], 0.07)); cg.addColorStop(1, "rgba(0,0,0,0)"); cx.fillStyle = cg; cx.fillRect(0, 0, W, H);
  /* beyin kabuğu: derinlik veren soluk nöron ağı */
  const sp = shell.map((q) => proj(q.x, q.y, q.z));
  cx.lineWidth = 0.6; shell.forEach((q, i) => q.l.forEach((j) => { const a = sp[i], b = sp[j], al = 0.05 + 0.1 * (1 - (a[2] + 330) / 660); cx.strokeStyle = rgba(PAL[1], Math.max(0.02, al)); cx.beginPath(); cx.moveTo(a[0], a[1]); cx.lineTo(b[0], b[1]); cx.stroke(); }));
  cx.globalCompositeOperation = lo; shell.forEach((q, i) => { const a = sp[i], d = 1 - (a[2] + 330) / 660, tw = 0.5 + 0.5 * Math.sin(t / 600 + q.ph); cx.fillStyle = rgba(PAL[0], (0.1 + 0.35 * d) * (0.5 + tw * 0.5)); cx.beginPath(); cx.arc(a[0], a[1], 0.9 + 1.4 * d, 0, 7); cx.fill(); }); cx.globalCompositeOperation = "source-over";
  /* düğümlerin ekran konumu */
  const P = new Map(); G.nodes.forEach((n, id) => P.set(id, proj(n.x, n.y, n.z)));
  const focus = G.sel || G.hov, nbr = new Set(); if (focus) G.edges.forEach(([a, b]) => { if (a === focus) nbr.add(b); if (b === focus) nbr.add(a); });
  const q = G.q.toLowerCase(), dim = (id, n) => (q ? !(n.title + " " + (n.text || "")).toLowerCase().includes(q) : focus && id !== focus && !nbr.has(id));
  /* bağlar */
  G.edges.forEach(([i, j, k]) => {
    const a = P.get(i), b = P.get(j), A = G.nodes.get(i), B = G.nodes.get(j), on = focus && (i === focus || j === focus), d = Math.min(1, Math.max(0.15, 1 - ((a[2] + b[2]) / 2 + 260) / 620));
    cx.strokeStyle = rgba(PAL[B.ci % 3] || PAL[0], (on ? 0.85 : 0.14 + 0.3 * d) * (dim(i, A) && dim(j, B) ? 0.25 : 1)); cx.lineWidth = on ? 1.6 : k === "ref" ? 0.8 : 1.1; cx.setLineDash(k === "ref" || k === "ctx" ? [3, 4] : []); cx.beginPath(); cx.moveTo(a[0], a[1]); cx.lineTo(b[0], b[1]); cx.stroke();
  }); cx.setLineDash([]);
  /* nabızlar */
  PS = PS.filter((p) => t < p.t0 + p.d && G.nodes.has(p.a) && G.nodes.has(p.b));
  cx.globalCompositeOperation = lo; PS.forEach((p) => { const a = P.get(p.a), b = P.get(p.b), f = (t - p.t0) / p.d, x = a[0] + (b[0] - a[0]) * f, y = a[1] + (b[1] - a[1]) * f, c = PAL[G.nodes.get(p.b).ci % 3], g = cx.createRadialGradient(x, y, 0, x, y, 9); g.addColorStop(0, rgba(c, 1)); g.addColorStop(1, rgba(c, 0)); cx.fillStyle = g; cx.beginPath(); cx.arc(x, y, 9, 0, 7); cx.fill(); }); cx.globalCompositeOperation = "source-over";
  /* düğümler (uzaktan yakına) */
  const order = [...G.nodes.entries()].sort((a, b) => P.get(b[0])[2] - P.get(a[0])[2]);
  order.forEach(([id, n]) => {
    const p = P.get(id), s = p[3], age = Math.max(0, Math.min(1, (t - (n.born || 0)) / 700)), r = n.r * s * (0.4 + 0.6 * age) * (n.type === "member" && n.m.on ? 1 + Math.sin(t / 420) * 0.06 : 1), c = n.ghost || n.type === "tag" ? "#8a93a8" : PAL[n.ci % 3] || PAL[0];
    const tk = n.task, bad = tk && tk.st === "hata", col = bad ? "#ff5a6e" : n.type === "dispatch" ? "#ffffff" : c, a = dim(id, n) ? 0.2 : 1, depth = 0.55 + 0.45 * (1 - (p[2] + 300) / 700);
    cx.globalAlpha = Math.max(0.1, a * Math.min(1, depth)); cx.globalCompositeOperation = lo;
    const g = cx.createRadialGradient(p[0], p[1], 0, p[0], p[1], r * 3.2); g.addColorStop(0, rgba(col, n.type === "member" ? 0.7 : 0.45)); g.addColorStop(1, rgba(col, 0)); cx.fillStyle = g; cx.beginPath(); cx.arc(p[0], p[1], r * 3.2, 0, 7); cx.fill(); cx.globalCompositeOperation = "source-over";
    cx.fillStyle = tk && tk.st === "bekliyor" ? rgba(col, 0.25) : n.type === "member" && !n.m.on ? rgba(col, 0.3) : col; cx.beginPath(); cx.arc(p[0], p[1], r, 0, 7); cx.fill();
    if (tk && (tk.st === "bekliyor" || tk.st === "calisiyor")) { cx.strokeStyle = col; cx.lineWidth = 1.5; cx.beginPath(); cx.arc(p[0], p[1], r + 2.5, -Math.PI / 2, -Math.PI / 2 + (tk.st === "calisiyor" ? Math.max(0.05, tk.pct / 100) * 6.283 : 6.283)); cx.stroke(); }
    if (id === G.sel || id === G.hov) { cx.strokeStyle = "#fff"; cx.lineWidth = 1.5; cx.beginPath(); cx.arc(p[0], p[1], r + 5, 0, 7); cx.stroke(); }
    const lab = n.type === "member" || n.type === "dispatch" || id === G.sel || id === G.hov || (focus && nbr.has(id)) || (q && !dim(id, n)) || (p[3] > 1.02 && n.type !== "tag");
    if (lab && a > 0.5) { cx.fillStyle = "#e8f1ff"; cx.font = (n.type === "member" ? "700 12px" : "11px") + " system-ui"; cx.textAlign = "center"; cx.fillText(n.title.slice(0, 26), p[0], p[1] + r + 14); }
    cx.globalAlpha = 1; n.sx = p[0]; n.sy = p[1]; n.sr = r + 6;
  });
}
function pick(x, y) { let best = "", bd = 1e9; G.nodes.forEach((n, id) => { const d = Math.hypot(n.sx - x, n.sy - y); if (d < n.sr + 4 && d < bd) { bd = d; best = id; } }); return best; }

/* ---- DOM: bölüm imzası değişmedikçe yeniden çizilmez (titreme olmasın) */
function put(id, html) { if (sigs[id] === html) return; sigs[id] = html; const el = $("#" + id); if (el) el.innerHTML = html; }
function info() {
  const el = $("#ek-info"), n = G.nodes.get(G.sel); if (!el) return; el.hidden = !n; if (!n) return;
  const rel = [...new Set(G.edges.filter(([a, b]) => a === G.sel || b === G.sel).map(([a, b]) => (a === G.sel ? b : a)))].map((id) => G.nodes.get(id));
  const T = { member: "Hesap", dispatch: "Dağıtım", task: "Görev", idea: "Fikir", tag: n.ghost ? "Bağlantı (henüz not yok)" : "Etiket" }[n.type], tk = n.task;
  put("ek-info", `<button class="ek-x" data-f="">✕</button><small>${T}</small><h3>${esc(n.title)}</h3>
    ${n.type === "member" ? `<p>${n.m.on ? "çevrimiçi" : "çevrimdışı (ajan çalışmıyor)"} · ${n.m.mode === "auto" ? "Otomatik" : "Elle"}</p>` : ""}
    ${tk ? `<p><b>${{ bekliyor: "Bekliyor", calisiyor: "Çalışıyor", bitti: "Bitti", hata: "Hata" }[tk.st]}</b> · ${esc(tk.to)}</p>${tk.prog && tk.st === "calisiyor" ? `<p class="ek-m">${esc(tk.prog)}</p>` : ""}${tk.st === "bekliyor" ? `<button class="btn pri" data-start="${esc(tk.pid)}" ${tk.start ? "disabled" : ""}>${tk.start ? "Sırada" : "Başlat"}</button>` : ""}${tk.sum ? `<p class="ek-m">${esc(tk.sum)}</p>` : ""}${tk.branch ? `<p class="ek-m">dal: ${esc(tk.branch)}</p>` : ""}` : ""}
    ${n.text && n.type !== "tag" ? `<p class="ek-body">${esc(n.text).replace(/\[\[([^\]]+)\]\]|#[\p{L}\d_]+/gu, (m) => `<i>${m}</i>`)}</p>` : ""}
    ${rel.length ? `<small>Bağlantılar</small><div class="ek-rel">${rel.map((r) => `<button data-f="${esc(r.id)}"><i style="background:${PAL[r.ci % 3]}"></i>${esc(r.title.slice(0, 28))}</button>`).join("")}</div>` : ""}`);
}
function render() {
  const pg = $("#pg-team"); if (!pg || !S) return;
  const ns = names(), me = window.NeraNet.user();
  buildGraph();
  put("ek-cards", ns.map((u, i) => {
    const m = S.members[u] || { mode: "elle", on: false }, cur = Object.values(S.tasks).find((t) => t.to === u && t.st === "calisiyor"), w = Object.values(S.tasks).filter((t) => t.to === u && t.st === "bekliyor").length;
    return `<div class="ek-card" style="--c:var(--${["na", "nb", "nc"][i]})" data-f="m:${esc(u)}"><div class="ek-h"><i class="ek-led ${m.on ? "on" : ""}"></i><b>${esc(u)}</b>${u === me ? "<em>sen</em>" : ""}<label class="ek-sw" title="Otomatik: sıra gelen görevi kendi başına yapar. Elle: yalnız Başlat'a basınca."><input type="checkbox" data-mode="${esc(u)}" ${m.mode === "auto" ? "checked" : ""}><span>${m.mode === "auto" ? "Otomatik" : "Elle"}</span></label></div>
      ${cur ? `<div class="ek-bar"><i style="width:${cur.pct}%"></i></div><small>${esc(cur.title)} · ${esc(cur.prog || "başladı")}</small>` : `<small>${m.on ? (w ? w + " görev bekliyor" : "boşta") : "çevrimdışı"}</small>`}</div>`;
  }).join("") || `<div class="ek-empty">Ajan yok: her bilgisayarda <code>python ekip/ajan.py run</code></div>`);
  put("ek-plans", Object.values(S.plans).filter((p) => !p.approved).map((p) => `<div class="ek-plan"><b>Bölme önerisi</b> <small>${esc((S.disp[p.id] || {}).prompt || "").slice(0, 120)}</small>${p.parts.map((q) => `<div class="ek-part"><span class="ek-to">${esc(q.to)}</span><div><b>${esc(q.title)}</b><p>${esc(q.body)}</p></div></div>`).join("")}<button class="btn pri" data-ok="${esc(p.id)}">Onayla ve dağıt</button></div>`).join(""));
  const lg = $("#ek-count"); if (lg) lg.textContent = `${G.nodes.size} düğüm · ${G.edges.length} bağ`;
  sigs["ek-info"] = null; info();
}

function build() {
  const pg = $("#pg-team"); if (!pg || $("#ek-root")) return;
  pg.innerHTML = `<div id="ek-root"><h1>Ekip Beyni</h1><p class="lead">Hesaplar, görevler ve fikirler tek canlı grafikte. Sürükle: döndür · tekerlek: yakınlaş · düğüme dokun: ayrıntı. Fikirde <b>[[bağlantı]]</b> ve <b>#etiket</b> kullan.</p>
    <div class="panel ek-top"><input id="ek-code" class="ek-in" placeholder="Takım kodu (herkeste aynı)" value="${esc(code)}"><button class="btn" id="ek-conn">Bağlan</button><input id="ek-q" class="ek-in" placeholder="Grafikte ara…"><span id="ek-msg" class="ek-msg"></span></div>
    <div id="ek-lock" class="ek-empty" hidden>Önce Arkadaşlar ekranından Nera hesabınla giriş yap.</div>
    <div id="ek-stage" class="ek-stage"><canvas id="ek-cv"></canvas><div id="ek-cards" class="ek-cards"></div><div id="ek-info" class="ek-info" hidden></div><div class="ek-leg"><span id="ek-count"></span><i class="l1"></i>hesap <i class="l2"></i>görev <i class="l3"></i>fikir <i class="l4"></i>etiket</div></div>
    <div id="ek-plans"></div>
    <div class="panel ek-send"><textarea id="ek-prompt" class="ek-in" rows="2" placeholder="Yapılacak işi yaz; üç parçaya bölünür, önizlemede onaylarsın."></textarea><button class="btn pri" id="ek-go">Dağıt</button></div>
    <div class="panel ek-send"><input id="ek-idea" class="ek-in" placeholder="Fikir bırak — [[görev adı]] ile bağla, #etiket ekle"><button class="btn" id="ek-isend">Fikri gönder</button></div></div>`;
  cv = $("#ek-cv"); cx = cv.getContext("2d");
  $("#ek-conn").onclick = () => { code = $("#ek-code").value.trim(); try { localStorage.setItem("nera_ekip", code); } catch (e) { /* */ } G.first = true; connect(); lock(); };
  $("#ek-q").oninput = (e) => { G.q = e.target.value.trim(); };
  $("#ek-go").onclick = () => { const v = $("#ek-prompt").value.trim(); if (!v || !code) return toast("Önce takım koduyla bağlan ve bir prompt yaz"); send({ k: "dispatch", id: Math.random().toString(36).slice(2, 8), prompt: v }); $("#ek-prompt").value = ""; toast("Gönderildi: ajan bölüyor…"); };
  const idea = () => { const v = $("#ek-idea").value.trim(); if (v) { send({ k: "idea", text: v }); $("#ek-idea").value = ""; } };
  $("#ek-isend").onclick = idea; $("#ek-idea").onkeydown = (e) => { if (e.key === "Enter") idea(); };
  pg.addEventListener("click", (e) => { const b = e.target.closest("[data-ok],[data-start],[data-f]"); if (!b || e.target.closest("label")) return; if (b.dataset.ok) send({ k: "approve", id: b.dataset.ok }); else if (b.dataset.start) send({ k: "start", pid: b.dataset.start }); else { G.sel = b.dataset.f; info(); } });
  pg.addEventListener("change", (e) => { const c = e.target.closest("[data-mode]"); if (c) send({ k: "mode", to: c.dataset.mode, auto: c.checked }); });
  /* kamera: sürükle = döndür, tekerlek = yakınlaş, kısa dokunuş = seç */
  let down = null;
  cv.addEventListener("pointerdown", (e) => { cv.setPointerCapture(e.pointerId); down = { x: e.clientX, y: e.clientY, m: false }; CAM.drag = true; });
  cv.addEventListener("pointermove", (e) => { const r = cv.getBoundingClientRect(); if (down) { const dx = e.clientX - down.x, dy = e.clientY - down.y; if (Math.abs(dx) + Math.abs(dy) > 3) down.m = true; CAM.yaw += dx * 0.006; CAM.pitch = Math.max(-1.3, Math.min(1.3, CAM.pitch + dy * 0.006)); down.x = e.clientX; down.y = e.clientY; } else G.hov = pick(e.clientX - r.left, e.clientY - r.top); });
  cv.addEventListener("pointerup", (e) => { const r = cv.getBoundingClientRect(); if (down && !down.m) { G.sel = pick(e.clientX - r.left, e.clientY - r.top); sigs["ek-info"] = null; info(); } down = null; CAM.drag = null; CAM.idle = performance.now(); });
  cv.addEventListener("pointerleave", () => { G.hov = ""; });
  cv.addEventListener("wheel", (e) => { e.preventDefault(); CAM.zoom = Math.max(0.5, Math.min(2.6, CAM.zoom * (e.deltaY < 0 ? 1.1 : 0.9))); CAM.idle = performance.now(); }, { passive: false });
  requestAnimationFrame(loop);
}
function lock() { const l = $("#ek-lock"); if (l) l.hidden = !!(window.NeraNet && window.NeraNet.on()); }
window.NeraEkip = { fold, _G: G, _inject: (evs) => { EV = {}; evs.forEach((e, i) => { EV["x" + i] = e; }); S = fold(evs, Date.now()); sigs = {}; render(); } };
document.addEventListener("DOMContentLoaded", build);
if (document.readyState !== "loading") build();
if (window.DT) window.DT.on("view", (v) => { if (v === "team") { build(); lock(); if (!close) connect(); } });
})();
