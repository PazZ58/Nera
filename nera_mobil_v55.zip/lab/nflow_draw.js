"use strict";
/* NeraFlow ekranı: arayüz ve çizim (veri katmanı lab/nflow.js). Dört pano: footprint mum grafiği, ısı haritası, DOM merdiveni, işlem şeridi.
   Flowsurface'ten kod alınmadı; pano türleri ve davranışı örnek alınarak sıfırdan yazıldı. */
(function () {
const N = window.NFX; if (!N) return;
const $ = (s, r = document) => r.querySelector(s);
const GREEN = "#34c38f", RED = "#ef5f67", GOLD = "#e6b84c", BG = "#0b0d12", GRID = "rgba(255,255,255,.06)", TXT = "#aab1c4", TXT2 = "#6f778a";
const MONO = "11px 'Fira Code', ui-monospace, Consolas, monospace", MONO9 = "9.5px 'Fira Code', ui-monospace, Consolas, monospace";
const FP = { bw: 96, off: 0, vo: 0, vz: 1, mx: -1, my: -1, drag: null };
const HM = { img: null, w: 0, h: 0, ver: -1, t: 0, mx: -1, my: -1 };
const pad2 = (x) => String(x).padStart(2, "0");
const hms = (T) => { const d = new Date(T); return pad2(d.getHours()) + ":" + pad2(d.getMinutes()) + ":" + pad2(d.getSeconds()); };
const hm = (t) => { const d = new Date(t * 1000); return pad2(d.getHours()) + ":" + pad2(d.getMinutes()); };
const fq = (q) => (q >= 1e6 ? (q / 1e6).toFixed(2) + "m" : q >= 1e4 ? (q / 1e3).toFixed(1) + "k" : q >= 1e3 ? (q / 1e3).toFixed(2) + "k" : q >= 100 ? q.toFixed(0) : q >= 10 ? q.toFixed(1) : q >= 1 ? q.toFixed(2) : q > 0 ? q.toFixed(3) : "0");
const dec = (x) => Math.max(0, Math.min(6, Math.ceil(-Math.log10(x) - 1e-9)));
const pf = (p, st) => p.toFixed(dec(st));
const gOf = () => Math.max(1, N.mult[N.sym] || 10);

function fit(cv) {
  const r = cv.parentNode.getBoundingClientRect(), hh = cv.parentNode.querySelector(".nf-ph"), top = hh ? hh.offsetHeight : 0;
  const w = Math.max(60, Math.floor(r.width)), h = Math.max(60, Math.floor(r.height - top)), d = Math.min(window.devicePixelRatio || 1, 2);
  if (cv.width !== Math.floor(w * d) || cv.height !== Math.floor(h * d)) { cv.width = Math.floor(w * d); cv.height = Math.floor(h * d); cv.style.width = w + "px"; cv.style.height = h + "px"; }
  const x = cv.getContext("2d"); x.setTransform(d, 0, 0, d, 0, 0); x.clearRect(0, 0, w, h); x.textBaseline = "middle";
  return { x, w, h };
}
function msg(c, t) { c.x.fillStyle = TXT2; c.x.font = MONO; c.x.textAlign = "center"; c.x.fillText(t, c.w / 2, c.h / 2); c.x.textAlign = "left"; }
function niceStep(range, rows) {
  const raw = range / rows, p = Math.pow(10, Math.floor(Math.log10(raw))), f = raw / p;
  return (f < 1.5 ? 1 : f < 3 ? 2 : f < 7 ? 5 : 10) * p;
}
function axis(x, w, plotW, top, plotH, lo, hi, step, px) {
  x.font = MONO9; x.textAlign = "left";
  const ns = niceStep(hi - lo, Math.max(3, plotH / 46)), d = dec(Math.min(ns, step));
  for (let p = Math.ceil(lo / ns) * ns; p <= hi; p += ns) {
    const y = top + (hi - p) / (hi - lo) * plotH;
    x.strokeStyle = GRID; x.beginPath(); x.moveTo(0, y + 0.5); x.lineTo(plotW, y + 0.5); x.stroke();
    x.fillStyle = TXT2; x.fillText(p.toFixed(d), plotW + 6, y);
  }
  if (px) {
    const y = top + (hi - px) / (hi - lo) * plotH;
    if (y >= top && y <= top + plotH) {
      x.setLineDash([3, 3]); x.strokeStyle = "rgba(230,184,76,.7)"; x.beginPath(); x.moveTo(0, y + 0.5); x.lineTo(plotW, y + 0.5); x.stroke(); x.setLineDash([]);
      x.fillStyle = GOLD; x.fillRect(plotW, y - 8, w - plotW, 16); x.fillStyle = "#14110a"; x.font = "bold " + MONO9; x.fillText(px.toFixed(d), plotW + 6, y);
    }
  }
}

/* ---------------------------------------------------------------- footprint */
function drawFp() {
  const cv = $("#nf-fp canvas"), c = fit(cv), x = c.x, H = N.H;
  if (!H) return msg(c, "Bağlanıyor…");
  const tf = N.tf, arr = N.list(H, tf);
  if (!arr.length) return msg(c, "Mumlar yükleniyor…");
  const tick = N.tick[N.sym], g = gOf(), gp = g * tick, axW = 66, profW = 90, botH = 44, top = 8;
  const plotW = c.w - axW - profW, plotH = c.h - botH - top, bw = FP.bw, gap = 6, colW = bw + gap, tfs = N.TFS[tf];
  const maxOff = Math.max(0, arr.length - 3);
  FP.off = Math.max(-2, Math.min(maxOff, FP.off));
  const lastIdx = arr.length - 1 - Math.floor(FP.off), frac = FP.off - Math.floor(FP.off);
  const nvis = Math.ceil(plotW / colW) + 2, first = Math.max(0, lastIdx - nvis + 1);
  const vis = [];
  let lo = Infinity, hi = -Infinity, clo = Infinity, chi = -Infinity;
  for (let i = first; i <= lastIdx; i++) { const b = arr[i], o = N.ohlc(b); vis.push({ b, o, i }); if (o.h > hi) hi = o.h; if (o.l < lo) lo = o.l; if (b.cells.size) { if (o.h > chi) chi = o.h; if (o.l < clo) clo = o.l; } }
  if (!isFinite(lo)) return msg(c, "Veri yok");
  /* footprint hücresi olan mumlar varsa fiyat aralığı onlara göre (hücreler okunur kalır); eski yalnız-mum kayıtları kenarda kırpılır */
  if (isFinite(clo)) { lo = clo; hi = chi; }
  const rg = Math.max((hi - lo) * 1.08, gp * 12), mid = (hi + lo) / 2 + FP.vo, r2 = rg * FP.vz, lo2 = mid - r2 / 2, hi2 = mid + r2 / 2;
  FP.rg = r2;
  const yOf = (p) => top + (hi2 - p) / (hi2 - lo2) * plotH, rh = gp / (hi2 - lo2) * plotH;
  x.save(); x.beginPath(); x.rect(0, 0, plotW, c.h); x.clip();
  axis(x, c.w, plotW, top, plotH, lo2, hi2, gp, null);
  const prof = new Map();
  let hov = null;
  vis.forEach(({ b, o, i }) => {
    const bx = plotW - colW * (lastIdx - i + 1) + gap / 2 + frac * colW;
    if (bx + bw < 0 || bx > plotW) return;
    const full = b.t * 1000 >= H.cov, part = !full && b.t * 1000 + tfs * 1000 > H.cov && b.cells.size > 0, has = b.cells.size > 0;
    if (FP.mx >= bx - gap / 2 && FP.mx < bx + bw + gap / 2) hov = { b, o, full, part };
    const cw = has ? bw - 12 : 0;
    if (has) {
      const grp = new Map();
      b.cells.forEach((v, k) => { const gk = Math.floor(k / g); let e = grp.get(gk); if (!e) grp.set(gk, (e = [0, 0])); e[0] += v[0]; e[1] += v[1]; });
      let mxT = 0, pocK = null;
      grp.forEach((v, gk) => { const t = v[0] + v[1]; if (t > mxT) { mxT = t; pocK = gk; } let p = prof.get(gk); if (!p) prof.set(gk, (p = [0, 0])); p[0] += v[0]; p[1] += v[1]; });
      grp.forEach((v, gk) => {
        const y = yOf((gk + 1) * gp); if (y > top + plotH || y + rh < top) return;
        const t = v[0] + v[1], k = Math.pow(t / mxT, 0.75), dl = v[0] - v[1];
        x.fillStyle = (dl >= 0 ? "rgba(52,195,143," : "rgba(239,95,103,") + (0.10 + 0.55 * k).toFixed(3) + ")";
        x.fillRect(bx, y + 0.5, cw, Math.max(1, rh - 1));
        if (rh >= 10 && bw >= 74) {
          const dn = grp.get(gk - 1), up = grp.get(gk + 1), rq = (100 + N.cfg.imb) / 100;
          const bi = dn && v[0] > 0 && dn[1] > 0 && v[0] > dn[1] * rq, si = up && v[1] > 0 && up[0] > 0 && v[1] > up[0] * rq;
          x.font = MONO9; x.textAlign = "left"; x.fillStyle = si ? "#ff8a91" : "rgba(235,238,245,.82)"; if (si) x.font = "bold " + MONO9; x.fillText(fq(v[1]), bx + 3, y + rh / 2);
          x.textAlign = "right"; x.font = bi ? "bold " + MONO9 : MONO9; x.fillStyle = bi ? "#6ff0b8" : "rgba(235,238,245,.82)"; x.fillText(fq(v[0]), bx + cw - 3, y + rh / 2); x.textAlign = "left";
        }
      });
      if (pocK !== null) { x.strokeStyle = GOLD; x.lineWidth = 1; x.strokeRect(bx + 0.5, yOf((pocK + 1) * gp) + 0.5, cw, Math.max(1, rh - 1)); }
    }
    const cx = bx + cw + (has ? 4 : bw / 2 - 3), up = o.c >= o.o, col = up ? GREEN : RED;
    x.strokeStyle = col; x.fillStyle = col; x.beginPath(); x.moveTo(cx + 3.5, yOf(o.h)); x.lineTo(cx + 3.5, yOf(o.l)); x.stroke();
    const yo = yOf(o.o), yc = yOf(o.c); x.fillRect(cx, Math.min(yo, yc), 7, Math.max(1, Math.abs(yo - yc)));
    if (part) { x.setLineDash([3, 3]); x.strokeStyle = "rgba(230,184,76,.7)"; x.strokeRect(bx + 0.5, top + 0.5, bw - 1, plotH - 1); x.setLineDash([]); x.fillStyle = GOLD; x.font = MONO9; x.fillText("kısmi", bx + 3, top + 8); }
    const tt = N.totals(b, full), dl = tt.buy - tt.sell;
    x.font = MONO9; x.textAlign = "center"; x.fillStyle = dl >= 0 ? GREEN : RED; x.fillText((dl >= 0 ? "+" : "") + fq(dl), bx + bw / 2, top + plotH + 9);
    x.fillStyle = TXT; x.fillText(fq(tt.v), bx + bw / 2, top + plotH + 21); x.fillStyle = TXT2; x.fillText(hm(b.t), bx + bw / 2, top + plotH + 34); x.textAlign = "left";
  });
  if (FP.my >= top && FP.my <= top + plotH && FP.mx >= 0 && FP.mx <= plotW) { x.strokeStyle = "rgba(255,255,255,.25)"; x.setLineDash([2, 3]); x.beginPath(); x.moveTo(0, FP.my + 0.5); x.lineTo(plotW, FP.my + 0.5); x.stroke(); x.setLineDash([]); }
  x.restore();
  x.font = MONO9; x.fillStyle = TXT2; x.textAlign = "right"; x.fillText("Δ", plotW - 4, top + plotH + 9); x.fillText("hacim", plotW - 4, top + plotH + 21); x.textAlign = "left";
  /* sağ: görünen hacim profili */
  let pm = 0; prof.forEach((v) => { pm = Math.max(pm, v[0] + v[1]); });
  const px0 = plotW + axW;
  prof.forEach((v, gk) => { const y = yOf((gk + 1) * gp); if (y > top + plotH || y + rh < top) return; const wS = (v[1] / pm) * (profW - 8), wB = (v[0] / pm) * (profW - 8); x.fillStyle = "rgba(239,95,103,.55)"; x.fillRect(px0, y + 0.5, wS, Math.max(1, rh - 1)); x.fillStyle = "rgba(52,195,143,.55)"; x.fillRect(px0 + wS, y + 0.5, wB, Math.max(1, rh - 1)); });
  const lastO = vis.length ? vis[vis.length - 1].o : null, px = H.px || (lastO && lastO.c);
  x.save(); x.beginPath(); x.rect(plotW, 0, axW, c.h); x.clip(); axis(x, c.w, plotW, top, plotH, lo2, hi2, gp, px); x.restore();
  if (FP.my >= top && FP.my <= top + plotH && FP.mx >= 0 && FP.mx <= plotW) { const p = hi2 - (FP.my - top) / plotH * (hi2 - lo2); x.fillStyle = "#2b3040"; x.fillRect(plotW, FP.my - 8, axW, 16); x.fillStyle = "#fff"; x.font = MONO9; x.fillText(pf(p, gp), plotW + 6, FP.my); }
  /* başlık satırı */
  x.font = MONO; x.fillStyle = TXT; x.fillText(`${N.sym.replace("USDT", "")}USDT PERP · ${tf} · grup ${pf(gp, gp)} · Binance vadeli`, 8, top + 10);
  const cvT = H.cov === Infinity ? "yok" : Math.round((Date.now() - H.cov) / 60000) + " dk", back = H.backErr ? "sınırlandı (" + H.backErr + "), sonra yeniden dener" : H.backDone ? "tamam" : "iniyor " + H.pages + "/80";
  x.font = MONO9; x.fillStyle = TXT2; x.fillText(`işlem verisi: son ${cvT} · geçmiş ${back}`, 8, top + 24);
  if (hov) { const o = hov.o, tt = N.totals(hov.b, hov.full); x.fillStyle = TXT; x.fillText(`${hm(hov.b.t)}  A ${pf(o.o, gp)}  Y ${pf(o.h, gp)}  D ${pf(o.l, gp)}  K ${pf(o.c, gp)}  hacim ${fq(tt.v)}  Δ ${fq(tt.buy - tt.sell)}${hov.full ? "" : "  (hacim: Binance mumu)"}`, 8, top + 38); }
}

/* ---------------------------------------------------------------- ısı haritası */
function heatImage(H, cols, plotW, plotH, lo, hi, tick) {
  const need = HM.ver !== H.ver || HM.w !== plotW || HM.h !== plotH || Date.now() - HM.t > 700;
  if (!need && HM.img) return HM.img;
  const cv = HM.cv || (HM.cv = document.createElement("canvas")); cv.width = plotW; cv.height = plotH;
  const cx = cv.getContext("2d"), im = cx.createImageData(plotW, plotH), D = im.data, win = N.win * 1000, now = cols[cols.length - 1].T, scale = Math.max(H.cmax * 2.2, 1e-9);
  const row = new Float32Array(plotH);
  for (let px = 0; px < plotW; px++) {
    const T = now - (plotW - 1 - px) / plotW * win;
    let lo2 = 0, hi2 = cols.length - 1;
    while (lo2 < hi2) { const m = (lo2 + hi2) >> 1; if (cols[m].T < T) lo2 = m + 1; else hi2 = m; }
    const col = cols[lo2]; if (!col || Math.abs(col.T - T) > 2500) continue;
    row.fill(0);
    for (let j = 0; j < col.K.length; j++) {
      const y = Math.floor((hi - col.K[j] * tick) / (hi - lo) * plotH); if (y < 0 || y >= plotH) continue;
      const q = col.Q[j]; if (Math.abs(q) > Math.abs(row[y])) row[y] = q;
    }
    for (let y = 0; y < plotH; y++) {
      const q = row[y]; if (!q) continue;
      const t = Math.min(1, Math.pow(Math.abs(q) / scale, 0.55)), o = (y * plotW + px) * 4;
      if (q > 0) { D[o] = 11 + 35 * t; D[o + 1] = 13 + 177 * t; D[o + 2] = 18 + 122 * t; } else { D[o] = 11 + 228 * t; D[o + 1] = 13 + 82 * t; D[o + 2] = 18 + 85 * t; }
      D[o + 3] = 255;
    }
  }
  cx.putImageData(im, 0, 0); HM.img = cv; HM.ver = H.ver; HM.w = plotW; HM.h = plotH; HM.t = Date.now();
  return cv;
}
function drawHeat() {
  const cv = $("#nf-hm canvas"), c = fit(cv), x = c.x, H = N.H;
  if (!H) return msg(c, "Bağlanıyor…");
  const cols = H.cols;
  if (cols.length < 3) return msg(c, H.dready ? "Isı haritası birikiyor…" : "Emir defteri kuruluyor…");
  const axW = 66, bookW = 76, botH = 16, plotW = c.w - axW - bookW, plotH = c.h - botH, win = N.win * 1000, now = cols[cols.length - 1].T, tick = N.tick[N.sym], g = gOf(), gp = g * tick;
  let lo = Infinity, hi = -Infinity;
  for (let i = cols.length - 1; i >= 0 && cols[i].T >= now - win; i--) { const m = cols[i]; if (m.bb < lo) lo = m.bb; if (m.ba > hi) hi = m.ba; }
  const last = cols[cols.length - 1], pd = Math.max((hi - lo) * 0.6, last.mid * 0.0012);
  lo -= pd; hi += pd;
  x.drawImage(heatImage(H, cols, plotW, plotH, lo, hi, tick), 0, 0);
  const yOf = (p) => (hi - p) / (hi - lo) * plotH, xOf = (T) => plotW - 1 - (now - T) / win * plotW;
  x.save(); x.beginPath(); x.rect(0, 0, plotW, plotH); x.clip();
  /* orta fiyat çizgisi */
  x.strokeStyle = "rgba(235,238,245,.85)"; x.lineWidth = 1; x.beginPath();
  let started = false;
  for (let i = 0; i < cols.length; i++) { const m = cols[i]; if (m.T < now - win) continue; const px = xOf(m.T), py = yOf(m.mid); if (!started) { x.moveTo(px, py); started = true; } else x.lineTo(px, py); }
  x.stroke();
  /* işlem noktaları: 500 ms × fiyat satırı toplamı; yarıçap toplam $ ile büyür, büyük işlem eşiğini (Ayarlar) aşanlar halkayla işaretlenir */
  const big = N.cfg.big, flt = N.cfg.dot;
  for (let i = H.dots.length - 1; i >= 0; i--) {
    const b = H.dots[i]; if (b.T < now - win) continue; const u = b.B + b.S; if (u < flt) continue;
    const px = xOf(b.T), py = yOf(b.k * tick), buy = b.B >= b.S, r = 1.6 + 14 * Math.sqrt(Math.min(1, u / big));
    x.fillStyle = buy ? "rgba(52,195,143,.6)" : "rgba(239,95,103,.6)"; x.beginPath(); x.arc(px, py, r, 0, 6.283); x.fill();
    if (u >= big) { x.strokeStyle = buy ? "#6ff0b8" : "#ff8a91"; x.lineWidth = 1.5; x.stroke(); x.lineWidth = 1; }
  }
  x.restore();
  if (HM.mx >= 0 && HM.mx <= plotW && HM.my >= 0 && HM.my <= plotH) { x.strokeStyle = "rgba(255,255,255,.25)"; x.setLineDash([2, 3]); x.beginPath(); x.moveTo(0, HM.my + 0.5); x.lineTo(plotW, HM.my + 0.5); x.stroke(); x.setLineDash([]); }
  /* sağ: anlık defter çubukları */
  const bx = plotW + axW, scale = Math.max(H.cmax * 3, 1e-9);
  x.fillStyle = "rgba(255,255,255,.03)"; x.fillRect(bx, 0, bookW, plotH);
  H.bids.forEach((q, k) => { const p = k * tick, y = yOf(p); if (y < 0 || y > plotH) return; x.fillStyle = "rgba(52,195,143,.55)"; x.fillRect(bx, y, Math.min(bookW - 4, q / scale * (bookW - 4)), Math.max(1, plotH / ((hi - lo) / tick))); });
  H.asks.forEach((q, k) => { const p = k * tick, y = yOf(p); if (y < 0 || y > plotH) return; x.fillStyle = "rgba(239,95,103,.55)"; x.fillRect(bx, y, Math.min(bookW - 4, q / scale * (bookW - 4)), Math.max(1, plotH / ((hi - lo) / tick))); });
  /* eksenler */
  x.save(); x.beginPath(); x.rect(plotW, 0, axW, c.h); x.clip(); axis(x, c.w, plotW, 0, plotH, lo, hi, gp, H.px || last.mid); x.restore();
  x.font = MONO9; x.fillStyle = TXT2; x.textAlign = "center";
  const sp = win > 400000 ? 120000 : win > 150000 ? 60000 : 30000;
  for (let T = Math.floor((now - win) / sp) * sp + sp; T < now; T += sp) { const px = xOf(T); x.fillText(hms(T).slice(0, 5) + (sp < 60000 ? ":" + pad2(new Date(T).getSeconds()) : ""), px, plotH + 8); x.strokeStyle = GRID; x.beginPath(); x.moveTo(px + 0.5, 0); x.lineTo(px + 0.5, plotH); x.stroke(); }
  x.textAlign = "left"; x.font = MONO; x.fillStyle = TXT; x.fillText(`${N.sym.replace("USDT", "")}USDT PERP · derinlik ısı haritası · ${N.win / 60} dk`, 8, 12);
  x.font = MONO9; x.fillStyle = TXT2; x.fillText(`defter: ${H.bids.size + H.asks.size} seviye · yeniden kurma ${H.resyncs} · büyük işlem ≥ ${fq(N.cfg.big)} $`, 8, 26);
}

/* ---------------------------------------------------------------- DOM merdiveni */
function drawDom() {
  const cv = $("#nf-dom canvas"), c = fit(cv), x = c.x, H = N.H;
  if (!H || !H.dready) return msg(c, "Emir defteri kuruluyor…");
  const bk = N.bestBook(H); if (!bk) return msg(c, "Defter boş");
  const tick = N.tick[N.sym], g = gOf(), gp = g * tick, rowH = 16, head = 20, n = Math.max(6, Math.floor((c.h - head) / rowH)), mid = Math.floor((bk.bb + bk.ba) / 2 / g);
  const bg = new Map(), ag = new Map(), tb = new Map(), ts = new Map();
  H.bids.forEach((q, k) => { const gk = Math.floor(k / g); bg.set(gk, (bg.get(gk) || 0) + q); });
  H.asks.forEach((q, k) => { const gk = Math.floor(k / g); ag.set(gk, (ag.get(gk) || 0) + q); });
  const now = Date.now();
  for (let i = H.trades.length - 1; i >= 0; i--) { const t = H.trades[i]; if (now - t.T > 60000) break; const gk = Math.floor(Math.round(t.p / tick) / g); (t.sell ? ts : tb).set(gk, ((t.sell ? ts : tb).get(gk) || 0) + t.q); }
  let mx = 1e-9, mt = 1e-9;
  for (let i = -n; i <= n; i++) { mx = Math.max(mx, bg.get(mid + i) || 0, ag.get(mid + i) || 0); mt = Math.max(mt, tb.get(mid + i) || 0, ts.get(mid + i) || 0); }
  const w = c.w, c1 = w * 0.17, c2 = w * 0.39, c3 = w * 0.61, c4 = w * 0.83;
  x.font = MONO9; x.fillStyle = TXT2; x.textAlign = "center"; x.fillText("sat 1dk", c1 / 2, 10); x.fillText("alış", (c1 + c2) / 2, 10); x.fillText("fiyat", (c2 + c3) / 2, 10); x.fillText("satış", (c3 + c4) / 2, 10); x.fillText("al 1dk", (c4 + w) / 2, 10);
  const rows = Math.floor((c.h - head) / rowH), half = Math.floor(rows / 2);
  for (let r = 0; r < rows; r++) {
    const gk = mid + half - r, y = head + r * rowH, yc = y + rowH / 2, bq = bg.get(gk) || 0, aq = ag.get(gk) || 0, sv = ts.get(gk) || 0, bv = tb.get(gk) || 0;
    if (sv) { x.fillStyle = "rgba(239,95,103,.5)"; const bwid = sv / mt * c1; x.fillRect(c1 - bwid, y + 1, bwid, rowH - 2); }
    if (bq) { x.fillStyle = "rgba(52,195,143,.45)"; const bwid = bq / mx * (c2 - c1); x.fillRect(c2 - bwid, y + 1, bwid, rowH - 2); }
    if (aq) { x.fillStyle = "rgba(239,95,103,.45)"; x.fillRect(c3, y + 1, aq / mx * (c4 - c3), rowH - 2); }
    if (bv) { x.fillStyle = "rgba(52,195,143,.5)"; x.fillRect(c4, y + 1, bv / mt * (w - c4), rowH - 2); }
    const isB = gk === Math.floor(bk.bb / g), isA = gk === Math.floor(bk.ba / g);
    if (isB || isA) { x.fillStyle = "rgba(255,255,255,.07)"; x.fillRect(0, y, w, rowH); }
    x.font = MONO9; x.textAlign = "left"; x.fillStyle = TXT; if (sv) x.fillText(fq(sv), 3, yc);
    x.textAlign = "right"; if (bq) x.fillText(fq(bq), c2 - 3, yc); x.textAlign = "left"; if (aq) x.fillText(fq(aq), c3 + 3, yc);
    x.textAlign = "right"; if (bv) x.fillText(fq(bv), w - 3, yc);
    x.textAlign = "center"; x.fillStyle = isB ? GREEN : isA ? RED : "#d5d9e4"; x.font = (isB || isA ? "bold " : "") + MONO9; x.fillText(pf(gk * gp, gp), (c2 + c3) / 2, yc);
  }
  x.textAlign = "left";
}

/* ---------------------------------------------------------------- işlem şeridi */
function drawTs() {
  const cv = $("#nf-ts canvas"), c = fit(cv), x = c.x, H = N.H;
  if (!H) return msg(c, "Bağlanıyor…");
  const rowH = 15, tick = N.tick[N.sym], d = dec(tick), n = Math.floor((c.h - 18) / rowH), thr = N.cfg.big;
  x.font = MONO9; x.fillStyle = TXT2; x.textAlign = "left"; x.fillText("zaman", 4, 9); x.textAlign = "center"; x.fillText("fiyat", c.w * 0.55, 9); x.textAlign = "right"; x.fillText("miktar", c.w - 4, 9);
  if (!H.trades.length) { x.textAlign = "center"; x.fillText("işlem bekleniyor…", c.w / 2, c.h / 2); x.textAlign = "left"; return; }
  for (let i = 0; i < n && i < H.trades.length; i++) {
    const t = H.trades[H.trades.length - 1 - i], y = 18 + i * rowH, yc = y + rowH / 2, big = t.usd >= thr;
    if (big) { x.fillStyle = t.sell ? "rgba(239,95,103,.18)" : "rgba(52,195,143,.18)"; x.fillRect(0, y, c.w, rowH); }
    x.font = (big ? "bold " : "") + MONO9; x.fillStyle = t.sell ? RED : GREEN;
    x.textAlign = "left"; x.fillText(hms(t.T), 4, yc); x.textAlign = "center"; x.fillText(t.p.toFixed(d), c.w * 0.55, yc); x.textAlign = "right"; x.fillText(fq(t.q), c.w - 4, yc);
  }
  x.textAlign = "left";
}

/* ---------------------------------------------------------------- arayüz */
function head() {
  const el = $("#nf-syms"); if (!el) return;
  el.innerHTML = N.SY.map(([s, n]) => { const t = N.tk[s], ch = t && t.open ? (t.last / t.open - 1) * 100 : null, d = dec(N.tick[s] * 10); return `<button data-s="${s}" class="${s === N.sym ? "on" : ""}"><i>${n}</i><b>${t ? t.last.toFixed(Math.min(d, 3)) : "—"}</b><em class="${ch == null ? "" : ch >= 0 ? "up" : "dn"}">${ch == null ? "" : (ch >= 0 ? "+" : "") + ch.toFixed(2) + "%"}</em></button>`; }).join("");
  const st = $("#nf-st"), live = Date.now() - N.ok < 6000, H = N.H;
  if (st) st.innerHTML = `<i class="${live ? "ok" : ""}"></i>${live ? "canlı" : "bağlanıyor"}${H ? ` · defter ${H.dready ? "senkron" : "kuruluyor"} · işlem ${H.cnt}` : ""}`;
}
function fillSteps() {
  const sel = $("#nf-step"); if (!sel) return; const tk = N.tick[N.sym];
  sel.innerHTML = N.MULTS.map((m) => `<option value="${m}" ${m === N.mult[N.sym] ? "selected" : ""}>×${m} (${pf(m * tk, tk)})</option>`).join("");
}
function build() {
  const pg = $("#pg-nflow"); if (!pg || pg._b) return; pg._b = 1;
  pg.innerHTML = `<div class="nf-top"><div><div class="eyebrow">Binance vadeli · canlı</div><h1>NeraFlow</h1></div><div class="nf-syms" id="nf-syms"></div><span class="nf-st" id="nf-st"></span></div>
  <div class="nf-cfg" id="nf-cfg" hidden>
    <b>Ayarlar <small>varsayılanlar Flowsurface'in varsayılanlarıdır</small></b>
    <label>Footprint dengesizlik eşiği (%)<input type="number" id="nf-c-imb" min="0" step="10"></label>
    <label>Büyük işlem eşiği ($)<input type="number" id="nf-c-big" min="10000" max="25000000" step="10000"></label>
    <label>Isı haritası en küçük işlem ($)<input type="number" id="nf-c-dot" min="0" step="1000"></label>
    <button class="btn" id="nf-c-reset">Varsayılana dön</button>
  </div>
  <div class="nf-grid">
    <div class="nf-pane" id="nf-fp"><div class="nf-ph"><b>Footprint</b><label>mum<select id="nf-tf">${Object.keys(N.TFS).map((k) => `<option ${k === N.tf ? "selected" : ""}>${k}</option>`).join("")}</select></label><label>fiyat grubu<select id="nf-step"></select></label><span class="nf-hint">sürükle: kaydır · tekerlek: yakınlaştır · çift tık: sıfırla</span></div><canvas></canvas></div>
    <div class="nf-pane" id="nf-hm"><div class="nf-ph"><b>Isı haritası</b><label>pencere<select id="nf-win">${[[120, "2 dk"], [300, "5 dk"], [600, "10 dk"]].map(([v, n]) => `<option value="${v}" ${v === N.win ? "selected" : ""}>${n}</option>`).join("")}</select></label><span class="nf-hint">yeşil: alış emirleri · kırmızı: satış emirleri · nokta: işlem (halka: büyük işlem)</span></div><canvas></canvas></div>
    <div class="nf-side"><div class="nf-pane" id="nf-dom"><div class="nf-ph"><b>DOM</b></div><canvas></canvas></div><div class="nf-pane" id="nf-ts"><div class="nf-ph"><b>İşlem şeridi</b></div><canvas></canvas></div></div>
  </div>`;
  head(); fillSteps();
  const cfgEl = $("#nf-cfg"), CF = { imb: "#nf-c-imb", big: "#nf-c-big", dot: "#nf-c-dot" }, CD = { imb: 200, big: 2500000, dot: 0 };
  const fillCfg = () => Object.keys(CF).forEach((k) => { $(CF[k]).value = N.cfg[k]; }); fillCfg();
  Object.keys(CF).forEach((k) => { $(CF[k]).onchange = (e) => { let v = +e.target.value; if (!isFinite(v)) v = CD[k]; if (k === "big") v = Math.max(10000, Math.min(25000000, v)); N.cfg[k] = Math.max(0, v); N.saveCfg(); fillCfg(); if (N.H) N.H.ver++; }; });
  $("#nf-c-reset").onclick = () => { Object.assign(N.cfg, CD); N.saveCfg(); fillCfg(); if (N.H) N.H.ver++; };
  N.toggleCfg = () => { cfgEl.hidden = !cfgEl.hidden; };
  pg.addEventListener("click", (e) => { const b = e.target.closest("#nf-syms button"); if (b && b.dataset.s !== N.sym) { N.setSym(b.dataset.s); FP.off = 0; FP.vo = 0; FP.vz = 1; fillSteps(); head(); } });
  $("#nf-tf").onchange = (e) => { N.tf = e.target.value; try { localStorage.setItem("nf_tf", N.tf); } catch (er) { /* */ } FP.off = 0; FP.vo = 0; FP.vz = 1; };
  $("#nf-step").onchange = (e) => { N.mult[N.sym] = +e.target.value; try { localStorage.setItem("nf_mult_" + N.sym, e.target.value); } catch (er) { /* */ } FP.vo = 0; FP.vz = 1; if (N.H) N.H.ver++; };
  $("#nf-win").onchange = (e) => { N.win = +e.target.value; try { localStorage.setItem("nf_win", String(N.win)); } catch (er) { /* */ } };
  const fcv = $("#nf-fp canvas"), hcv = $("#nf-hm canvas");
  const pos = (cv, e) => { const r = cv.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; };
  fcv.addEventListener("mousedown", (e) => { const [px, py] = pos(fcv, e); FP.drag = { px, py, off: FP.off, vo: FP.vo }; });
  window.addEventListener("mouseup", () => { FP.drag = null; });
  fcv.addEventListener("mousemove", (e) => {
    const [px, py] = pos(fcv, e); FP.mx = px; FP.my = py;
    if (FP.drag) { FP.off = FP.drag.off + (px - FP.drag.px) / (FP.bw + 6); const H = N.H; if (H) FP.vo = FP.drag.vo + (py - FP.drag.py) * (FP.rg || 0) / Math.max(1, fcv.clientHeight - 52); }
  });
  fcv.addEventListener("mouseleave", () => { FP.mx = FP.my = -1; });
  fcv.addEventListener("wheel", (e) => { e.preventDefault(); if (e.ctrlKey || e.shiftKey) FP.vz = Math.max(0.3, Math.min(4, FP.vz * (e.deltaY > 0 ? 1.1 : 0.9))); else FP.bw = Math.max(40, Math.min(240, FP.bw * (e.deltaY > 0 ? 0.92 : 1.09))); }, { passive: false });
  fcv.addEventListener("dblclick", () => { FP.off = 0; FP.vo = 0; FP.vz = 1; FP.bw = 96; });
  hcv.addEventListener("mousemove", (e) => { const [px, py] = pos(hcv, e); HM.mx = px; HM.my = py; });
  hcv.addEventListener("mouseleave", () => { HM.mx = HM.my = -1; });
}
let k = 0;
function tick() {
  if (document.body.dataset.view !== "nflow" || document.hidden) return;
  k++;
  if ($("#pg-nflow") && $("#pg-nflow").classList.contains("nf-cloudmode")) { build(); if (k % 5 === 0) head(); return; }
  build();
  if (!N.ui) N.start();
  try {
    if (k % 2 === 0) drawFp();
    if (k % 3 === 0) drawHeat();
    if (k % 3 === 1) { drawDom(); drawTs(); }
    if (k % 5 === 0) head();
  } catch (e) { N.err = String(e && e.stack || e).slice(0, 400); }
}
setInterval(tick, 100);
window.DT && window.DT.on("view", (v) => { if (v === "nflow") setTimeout(tick, 30); });
})();
