"use strict";
/* NeraFlow: canlı veri bulutu + akış olayları. Ultron'un ilk uyanış sahnesindeki gibi nefes alan, 3 boyutlu parçacık bulutu; gerçek akışa tepki verir:
   - alış/satış baskısı (son işlemler) bulutun rengini temanın üst/alt rengine kaydırır
   - işlem hızı nefes hızını ve parıltıyı sürer; işlemler bulutun içine akan kıvılcımlar olarak girer (yeşil alış, kırmızı satış)
   - defter dengesi (alış/satış duvarı kütlesi) bulutu hafifçe yukarı/aşağı eğer
   - büyük işlem, tasfiye, yığılı dengesizlik, delta patlaması: halka dalgası + düğümler arasında sinyal darbeleri + ayrı bildirim (NeraNotify kind "nflow")
   Bunlar "akış olayı"dır: ölçümlerimizde (21. tur, footprint testi) yön tahmini yaptığı görülmedi. İşlem sinyaline, ajanlara veya bota BAĞLI DEĞİL; yalnız bilgi ve görsel.
   Renkler temadan (--na, --nb, --up, --down) okunur; tuval her temada koyu "ada"dır. Kod orijinal, dış kütüphane yok. */
(function () {
const N = window.NFX; if (!N) return;
const $ = (s, r = document) => r.querySelector(s);
const NAME = { BTCUSDT: "BTC", ETHUSDT: "ETH", XAUUSDT: "Altın", XAGUSDT: "Gümüş" };
const css = (v, d) => { try { return getComputedStyle(document.body).getPropertyValue(v).trim() || d; } catch (e) { return d; } };
const rgb = (c) => { c = String(c).trim(); if (c[0] === "#") { if (c.length === 4) c = "#" + c[1] + c[1] + c[2] + c[2] + c[3] + c[3]; const n = parseInt(c.slice(1), 16); return [n >> 16 & 255, n >> 8 & 255, n & 255]; } const m = c.match(/\d+(\.\d+)?/g); return m ? [+m[0], +m[1], +m[2]] : [53, 224, 196]; };
const mix = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
const money = (u) => (u >= 1e6 ? (u / 1e6).toFixed(2).replace(".", ",") + " mn $" : Math.round(u / 1e3) + " bin $");
N.events = []; N.pressure = 0.5; N.act = 0; N.imb = 0;

/* ---------------------------------------------------------------- bulut */
const C = { cv: null, x: null, w: 0, h: 0, yaw: 0.6, pitch: 0.32, vy: 0.0012, drag: null, t: 0, pts: [], links: [], spr: {}, key: "", fx: [], sparks: [], pulses: [], core: 0, last: 0, pal: null, reduced: matchMedia("(prefers-reduced-motion: reduce)").matches && localStorage.getItem("nf_fx") !== "1" };
const NP = 2800, NNODE = 90;
function build() {
  C.pts = []; const puffs = C.puffs = [];
  /* gövde: çekirdeğe yakın, birbirine karışan geniş kümeler (tek bütün bulut); çevresinde daha seyrek kollar */
  for (let i = 0; i < 16; i++) { const th = Math.random() * 6.283, ph = Math.acos(2 * Math.random() - 1), r = 0.1 + 0.55 * Math.pow(Math.random(), 1.25); puffs.push({ c: [r * Math.sin(ph) * Math.cos(th) * 1.25, r * Math.cos(ph) * 0.8, r * Math.sin(ph) * Math.sin(th)], b: null, s: 0.2 + 0.2 * Math.random(), ph: Math.random() * 6.283, x: 0, y: 0, z: 0, f: 1 }); puffs[i].b = puffs[i].c; }
  const g = () => (Math.random() + Math.random() + Math.random() - 1.5) / 1.5;
  for (let i = 0; i < NP; i++) { const p = puffs[i % puffs.length]; C.pts.push({ b: [p.c[0] + g() * p.s, p.c[1] + g() * p.s * 0.9, p.c[2] + g() * p.s], ph: Math.random() * 6.283, sz: 0.55 + Math.random() * 1.7, mix: Math.random(), tag: Math.random(), x: 0, y: 0, z: 0, f: 1 }); }
  /* ağ düğümleri: ilk NNODE parçacık; her düğüm en yakın 3 düğüme bağlanır (CBM Lens benzeri ağ) */
  C.links = []; const seen = new Set();
  for (let i = 0; i < NNODE; i++) { const a = C.pts[i].b, d = []; for (let j = 0; j < NNODE; j++) if (j !== i) { const b = C.pts[j].b; d.push([Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]), j]); } d.sort((u, v) => u[0] - v[0]); d.slice(0, 3).forEach(([, j]) => { const k = i < j ? i + "-" + j : j + "-" + i; if (!seen.has(k)) { seen.add(k); C.links.push([i, j]); } }); }
}
function sprite(c, sz) { const k = c.join(",") + sz; if (C.spr[k]) return C.spr[k]; const cv = document.createElement("canvas"); cv.width = cv.height = sz; const x = cv.getContext("2d"), g = x.createRadialGradient(sz / 2, sz / 2, 0, sz / 2, sz / 2, sz / 2); g.addColorStop(0, `rgba(${c.map(Math.round)},0.95)`); g.addColorStop(0.35, `rgba(${c.map(Math.round)},0.38)`); g.addColorStop(1, `rgba(${c.map(Math.round)},0)`); x.fillStyle = g; x.fillRect(0, 0, sz, sz); return (C.spr[k] = cv); }
function palette() {
  const key = [css("--na", "#35e0c4"), css("--nb", "#8a7bff"), css("--nc", "#ffb04a"), css("--up", "#26c6a0"), css("--down", "#f2566a")].join("|");
  if (key === C.key) return; C.key = key; C.spr = {}; const [a, b, c, u, d] = key.split("|").map(rgb);
  C.pal = { a, b, c, u, d, grad: Array.from({ length: 10 }, (_, i) => mix(a, b, i / 9)) };
}
function resize() {
  const cv = C.cv, pg = cv.parentNode, r = pg.getBoundingClientRect(), d = Math.min(window.devicePixelRatio || 1, 1.6);
  const w = Math.max(200, Math.floor(r.width)), h = Math.max(200, Math.floor(r.height));
  if (C.w !== w || C.h !== h || C.d !== d) { C.w = w; C.h = h; C.d = d; cv.width = Math.floor(w * d); cv.height = Math.floor(h * d); cv.style.width = w + "px"; cv.style.height = h + "px"; }
}
function proj(p, S, cx, cy, br, off) {
  const cyw = Math.cos(C.yaw), syw = Math.sin(C.yaw), cp = Math.cos(C.pitch), sp = Math.sin(C.pitch), t = C.t;
  const a = 0.018, bx = p.b[0] * br + Math.sin(t * 0.5 + p.ph) * a, by = p.b[1] * br + Math.cos(t * 0.43 + p.ph * 1.3) * a + off, bz = p.b[2] * br + Math.sin(t * 0.37 + p.ph * 0.7) * a;
  const x1 = bx * cyw + bz * syw, z1 = -bx * syw + bz * cyw, y1 = by * cp - z1 * sp, z2 = by * sp + z1 * cp, f = 2.7 / (2.7 + z2);
  p.x = cx + x1 * S * f; p.y = cy + y1 * S * f; p.z = z2; p.f = f;
}
function frame(now) {
  requestAnimationFrame(frame);
  if (document.body.dataset.view !== "nflow" || document.hidden || !C.cv) return;
  const dt = Math.min(0.05, (now - (C.last || now)) / 1000); C.last = now; C.t += dt;
  resize(); palette();
  const x = C.x, w = C.w, h = C.h, d = C.d, P = C.pal, S = Math.min(w, h) * 0.46, cx = w / 2, cy = h * 0.46;
  x.setTransform(d, 0, 0, d, 0, 0); x.globalCompositeOperation = "source-over"; x.clearRect(0, 0, w, h);
  const H = N.H, buy = N.pressure, ten = Math.abs(buy - 0.5) * 2, act = N.act;
  /* nefes: yavaş ana salınım + hızlı ince titreşim; işlem hızı arttıkça sıklaşır */
  const f0 = 0.1 + act * 0.22; C.core += dt * f0 * 6.283;
  const br = 1 + 0.07 * Math.sin(C.core) + 0.018 * Math.sin(C.core * 2.7 + 1) - 0.05 * act;
  const off = -N.imb * 0.1;
  if (!C.drag && !C.reduced) C.yaw += C.vy * (1 + act * 1.6) * (dt * 60); else if (C.reduced) C.yaw = 0.6 + Math.sin(C.t * 0.1) * 0.05;
  C.pitch += ((0.3 + N.imb * -0.06 - C.pitch) * Math.min(1, dt * 2));
  for (let i = 0; i < C.pts.length; i++) proj(C.pts[i], S / 0.92, cx, cy, br, off);
  for (let i = 0; i < C.puffs.length; i++) proj(C.puffs[i], S / 0.92, cx, cy, br, off);
  x.globalCompositeOperation = "lighter";
  /* çekirdek parıltısı */
  const core = mix(P.a, P.b, 0.5 + 0.5 * Math.sin(C.t * 0.15)), cs = S * (0.9 + 0.1 * Math.sin(C.core)), gr = x.createRadialGradient(cx, cy + off * S, 0, cx, cy + off * S, cs);
  gr.addColorStop(0, `rgba(${core.map(Math.round)},${0.2 + act * 0.18})`); gr.addColorStop(0.5, `rgba(${core.map(Math.round)},0.05)`); gr.addColorStop(1, "rgba(0,0,0,0)"); x.fillStyle = gr; x.fillRect(0, 0, w, h);
  /* sis: her kümenin yumuşak, büyük parıltısı; nefesle büyür küçülür */
  for (let i = 0; i < C.puffs.length; i++) { const q = C.puffs[i], rr = q.s * S * 1.9 * q.f * (1 + 0.1 * Math.sin(C.core + q.ph)), c = mix(P.a, P.b, (i % 7) / 6); x.globalAlpha = (0.07 + 0.05 * Math.sin(C.core + q.ph) + act * 0.05) * (q.z < 0 ? 1.15 : 0.9); x.drawImage(sprite(c, 64), q.x - rr, q.y - rr, rr * 2, rr * 2); }
  x.globalAlpha = 1;
  /* parçacıklar: derinliğe göre sıralanmadan, ekleme karışımıyla */
  const tintC = buy > 0.5 ? P.u : P.d, sc = S / 300;
  for (let i = 0; i < C.pts.length; i++) {
    const p = C.pts[i], depth = Math.max(0, Math.min(1, 0.5 - p.z * 0.4)), tinted = p.tag < ten * 0.9;
    const col = tinted ? tintC : P.grad[Math.min(9, Math.floor(((p.mix + 0.2 * Math.sin(C.t * 0.2 + p.ph)) % 1 + 1) % 1 * 10))];
    const s = (p.sz * 4.2 * sc * p.f) * (1 + 0.5 * act), spr = sprite(col, 32);
    x.globalAlpha = (0.16 + 0.5 * depth) * (0.78 + 0.22 * Math.sin(C.t * 1.3 + p.ph * 3)) * (tinted ? 1 : 0.9);
    x.drawImage(spr, p.x - s, p.y - s, s * 2, s * 2);
  }
  x.globalAlpha = 1;
  /* ağ çizgileri ve darbeler */
  x.lineWidth = 1;
  for (let k = 0; k < C.links.length; k++) { const a = C.pts[C.links[k][0]], b = C.pts[C.links[k][1]], al = 0.07 + 0.1 * Math.max(0, Math.min(1, 0.5 - (a.z + b.z) * 0.2)); x.strokeStyle = `rgba(${P.a.map(Math.round)},${al.toFixed(3)})`; x.beginPath(); x.moveTo(a.x, a.y); x.lineTo(b.x, b.y); x.stroke(); }
  for (let i = 0; i < NNODE; i++) { const p = C.pts[i], s = (6 + 3 * Math.sin(C.t * 1.1 + p.ph)) * sc * p.f; x.globalAlpha = 0.55; x.drawImage(sprite(P.grad[(i * 3) % 10], 32), p.x - s, p.y - s, s * 2, s * 2); }
  x.globalAlpha = 1;
  for (let i = C.pulses.length - 1; i >= 0; i--) {
    const u = C.pulses[i]; u.t += dt * u.v; if (u.t >= 1) { if (u.hops > 0) { u.hops--; const nx = C.links.filter((l) => l[0] === u.to || l[1] === u.to); const l = nx[Math.floor(Math.random() * nx.length)]; if (l) { u.from = u.to; u.to = l[0] === u.to ? l[1] : l[0]; u.t = 0; } else C.pulses.splice(i, 1); } else C.pulses.splice(i, 1); continue; }
    const a = C.pts[u.from], b = C.pts[u.to], px = a.x + (b.x - a.x) * u.t, py = a.y + (b.y - a.y) * u.t, s = 13 * sc * a.f;
    x.drawImage(sprite(u.c, 32), px - s, py - s, s * 2, s * 2);
  }
  /* akış kıvılcımları: işlemler kenardan çekirdeğe akar */
  for (let i = C.sparks.length - 1; i >= 0; i--) {
    const s = C.sparks[i]; s.t += dt / s.life; if (s.t >= 1) { C.sparks.splice(i, 1); continue; }
    const e = s.t * s.t * (3 - 2 * s.t), r = s.in ? 1 - e : e, px = cx + s.dx * S * (0.12 + 0.95 * r), py = cy + s.dy * S * (0.12 + 0.95 * r) + off * S, sz = (4 + s.m * 7) * sc * (1 - 0.5 * e);
    x.globalAlpha = Math.sin(Math.PI * Math.min(1, s.t * 1.05)) * 0.9; x.drawImage(sprite(s.c, 32), px - sz, py - sz, sz * 2, sz * 2);
  }
  x.globalAlpha = 1;
  /* halka dalgaları (olaylar) */
  for (let i = C.fx.length - 1; i >= 0; i--) {
    const e = C.fx[i]; e.t += dt / e.life; if (e.t >= 1) { C.fx.splice(i, 1); continue; }
    const r = S * (0.25 + 1.0 * (e.side >= 0 ? e.t : 1 - e.t * 0.4)) * e.k, al = (1 - e.t) * 0.75;
    x.strokeStyle = `rgba(${e.c.map(Math.round)},${al.toFixed(3)})`; x.lineWidth = 2 + 3 * (1 - e.t); x.beginPath(); x.ellipse(cx, cy + off * S, r, r * (0.28 + 0.5 * Math.abs(Math.sin(C.pitch))), 0, 0, 6.283); x.stroke();
    x.lineWidth = 1;
  }
  x.globalCompositeOperation = "source-over";
}
/* dış tetikleyiciler */
function burst(side, kind, k) {
  const P = C.pal || { u: [38, 198, 160], d: [242, 86, 106], a: [53, 224, 196] }, c = kind === "liq" ? [255, 190, 90] : side > 0 ? P.u : P.d;
  C.fx.push({ t: 0, life: kind === "liq" ? 1.5 : 2.1, c, side: kind === "liq" ? 1 : side, k: k || 1 }); if (C.fx.length > 8) C.fx.shift();
  for (let i = 0; i < 4; i++) { const a = Math.floor(Math.random() * NNODE), l = C.links.filter((q) => q[0] === a || q[1] === a)[0]; if (l) C.pulses.push({ from: l[0], to: l[1], t: Math.random() * 0.4, v: 1.1 + Math.random() * 0.8, hops: 4 + Math.floor(Math.random() * 4), c }); }
  if (C.pulses.length > 40) C.pulses.splice(0, 10);
}
N.burst = burst;
function spark(side, usd) {
  if (C.sparks.length > 260) return; const P = C.pal; if (!P) return; const a = Math.random() * 6.283, el = (Math.random() - 0.5) * 1.6, dx = Math.cos(a) * Math.cos(el), dy = Math.sin(el) * 0.8 + Math.sin(a) * Math.cos(el) * 0.35;
  C.sparks.push({ t: 0, life: 0.9 + Math.random() * 0.9, dx, dy, in: true, m: Math.min(1, Math.log10(Math.max(10, usd)) / 6.5), c: side > 0 ? P.u : P.d });
}

/* ---------------------------------------------------------------- veri → bulut */
const E = { seenT: 0, last: {}, barKey: "", stacked: {}, dMin: "", tradeN: 0, rate: 1, base: 0, liqSeen: 0, lastPush: 0, trI: 0 };
function tickData() {
  const H = N.H; if (!H) return;
  const now = Date.now(), tr = H.trades;
  /* baskı: son 60 sn (en çok son 600 işlem) alış payı (hacme göre) */
  let b = 0, s = 0, n60 = 0;
  for (let i = tr.length - 1; i >= 0; i--) { const t = tr[i]; if (now - t.T > 60000) break; (t.sell ? (s += t.usd) : (b += t.usd)); n60++; }
  const p = b + s > 0 ? b / (b + s) : 0.5; N.pressure += (p - N.pressure) * 0.25;
  const rate = n60 / 60; E.rate += (rate - E.rate) * 0.3; E.base = E.base ? E.base + (E.rate - E.base) * 0.02 : E.rate;
  N.act = Math.max(0, Math.min(1, Math.tanh((E.rate / Math.max(0.2, E.base) - 1) * 0.8) * 0.5 + 0.35));
  N.rate = E.rate;
  if (H.dready) { const bk = N.bestBook(H), tk = N.tick[H.sym]; if (bk) { const lim = Math.round(bk.bb * 0.002); let bm = 0, am = 0; H.bids.forEach((q, k) => { if (bk.bb - k <= lim) bm += q; }); H.asks.forEach((q, k) => { if (k - bk.ba <= lim) am += q; }); N.imb += ((bm + am ? (bm - am) / (bm + am) : 0) - N.imb) * 0.2; } }
  /* son 1 sn'deki işlemler: bulutun içine akan kıvılcımlar */
  for (let i = tr.length - 1; i >= 0; i--) { const t = tr[i]; if (t.T <= E.trI) break; if (Math.random() < Math.min(1, 0.15 + Math.log10(Math.max(10, t.usd)) / 7)) spark(t.sell ? -1 : 1, t.usd); }
  if (tr.length) E.trI = tr[tr.length - 1].T;
}
/* ---------------------------------------------------------------- akış olayları */
function emit(type, side, title, body) {
  const t = Date.now(), key = type + side, cd = type === "whale" ? 20000 : 60000;
  if (E.last[key] && t - E.last[key] < cd) return; E.last[key] = t;
  const ev = { t, type, side, title, body, sym: N.sym }; N.events.unshift(ev); if (N.events.length > 40) N.events.pop();
  burst(side, type === "liq" ? "liq" : "x", type === "whale" ? 1.15 : 1);
  if (window.NeraNotify && t - E.lastPush > 8000) { E.lastPush = t; NeraNotify.push({ kind: "nflow", title, body, cls: side > 0 ? "nf-b" : side < 0 ? "nf-s" : "", onClick: () => { try { Lab.go("nflow"); } catch (e) { /* */ } } }); }
  hud(true);
}
function tickEvents() {
  const H = N.H; if (!H) return; const sym = H.sym, nm = NAME[sym] || sym, d = N.tick[sym], big = N.cfg.big;
  /* büyük işlem: tek işlem, Ayarlar'daki büyük işlem eşiğini (varsayılan 2.500.000 $, Flowsurface varsayılanı) aşıyorsa */
  for (let i = H.bigs.length - 1; i >= 0; i--) { const b = H.bigs[i]; if (b.T <= E.seenT) break; emit("whale", b.sell ? -1 : 1, `${b.sell ? "Büyük satış" : "Büyük alış"} · ${nm}`, `${money(b.usd)} tek işlem @ ${b.p.toFixed(Math.max(0, Math.ceil(-Math.log10(d))))} · akış olayı, tahmin değil`); }
  if (H.bigs.length) E.seenT = H.bigs[H.bigs.length - 1].T;
  /* tasfiye: Binance zorunlu kapanış akışı, aynı eşik */
  for (let i = H.liqs.length - 1; i >= 0; i--) { const l = H.liqs[i]; if (l.T <= E.liqSeen) break; if (l.usd >= big) emit("liq", l.sell ? -1 : 1, `${l.sell ? "Uzun tasfiye" : "Kısa tasfiye"} · ${nm}`, `${money(l.usd)} zorunlu kapanış · akış olayı, tahmin değil`); }
  if (H.liqs.length) E.liqSeen = H.liqs[H.liqs.length - 1].T;
}
/* ---------------------------------------------------------------- HUD + kip */
const fq = (q) => (Math.abs(q) >= 1e6 ? (q / 1e6).toFixed(2) + "m" : Math.abs(q) >= 1e3 ? (q / 1e3).toFixed(1) + "k" : Math.abs(q) >= 10 ? q.toFixed(0) : q.toFixed(2));
function hud(force) {
  const el = $("#nf-hud"); if (!el) return; const H = N.H, tk = N.tk[N.sym];
  if (!H) { el.innerHTML = ""; return; }
  const m1 = N.list(H, "1m"), c1 = m1[m1.length - 1], dl = c1 && c1.cells.size ? c1.B - c1.S : null, ch = tk && tk.open ? (tk.last / tk.open - 1) * 100 : null, pr = Math.round(N.pressure * 100);
  const ev = N.events.slice(0, 3).map((e) => `<span class="nf-ev ${e.side > 0 ? "b" : e.side < 0 ? "s" : ""}"><i></i>${e.title.split(" · ")[0]}<em>${Math.max(0, Math.round((Date.now() - e.t) / 1000))} sn</em></span>`).join("");
  el.innerHTML = `<div class="nf-h"><span>Fiyat</span><b>${H.px ? H.px.toFixed(Math.max(0, Math.min(3, Math.ceil(-Math.log10(N.tick[N.sym] * 10))))) : "—"}</b><em class="${ch == null ? "" : ch >= 0 ? "up" : "dn"}">${ch == null ? "" : (ch >= 0 ? "+" : "") + ch.toFixed(2) + "%"}</em></div>
  <div class="nf-h wide"><span>Baskı (son dakika)</span><div class="nf-gauge"><i style="width:${pr}%"></i></div><b>alış %${pr} · satış %${100 - pr}</b></div>
  <div class="nf-h"><span>Δ 1 dk</span><b class="${dl == null ? "" : dl >= 0 ? "up" : "dn"}">${dl == null ? "—" : (dl >= 0 ? "+" : "") + fq(dl)}</b></div>
  <div class="nf-h"><span>İşlem / sn</span><b>${(N.rate || 0).toFixed(1)}</b></div>
  <div class="nf-h"><span>Defter dengesi</span><b class="${N.imb >= 0 ? "up" : "dn"}">${N.imb >= 0 ? "alış" : "satış"} %${Math.round(Math.abs(N.imb) * 100)}</b></div>
  <div class="nf-evs">${ev || '<span class="nf-ev none">olay bekleniyor</span>'}</div>`;
}
function ui() {
  const pg = $("#pg-nflow"); if (!pg || pg._fx) return; if (!$(".nf-top", pg)) return; pg._fx = 1;
  const cv = document.createElement("canvas"); cv.id = "nf-cloud"; pg.prepend(cv); C.cv = cv; C.x = cv.getContext("2d");
  const hd = document.createElement("div"); hd.id = "nf-hud"; $(".nf-top", pg).after(hd);
  const sw = document.createElement("button"); sw.className = "btn nf-mode"; sw.textContent = "Bulut"; sw.title = "Panelleri gizle, yalnız bulutu göster"; $("#nf-st", pg).before(sw);
  const cg = document.createElement("button"); cg.className = "btn nf-mode"; cg.textContent = "Ayarlar"; cg.onclick = () => N.toggleCfg && N.toggleCfg(); sw.before(cg);
  const set = (on) => { pg.classList.toggle("nf-cloudmode", on); sw.textContent = on ? "Paneller" : "Bulut"; try { localStorage.setItem("nf_cloud", on ? "1" : "0"); } catch (e) { /* */ } };
  sw.onclick = () => set(!pg.classList.contains("nf-cloudmode")); try { if (localStorage.getItem("nf_cloud") === "1") set(true); } catch (e) { /* */ }
  const pos = (e) => [e.clientX, e.clientY];
  cv.addEventListener("pointerdown", (e) => { C.drag = { p: pos(e), yaw: C.yaw, pitch: C.pitch }; cv.setPointerCapture(e.pointerId); });
  cv.addEventListener("pointermove", (e) => { if (!C.drag) return; C.yaw = C.drag.yaw + (e.clientX - C.drag.p[0]) * 0.006; C.pitch = Math.max(-0.9, Math.min(0.9, C.drag.pitch + (e.clientY - C.drag.p[1]) * 0.005)); });
  const up = () => { C.drag = null; }; cv.addEventListener("pointerup", up); cv.addEventListener("pointercancel", up);
  cv.addEventListener("dblclick", () => { C.yaw = 0.6; C.pitch = 0.32; });
  build(); hud();
}
setInterval(() => { ui(); if (!C.cv) return; try { tickData(); tickEvents(); if (document.body.dataset.view === "nflow") hud(); } catch (e) { N.fxErr = String(e && e.stack || e).slice(0, 300); } }, 1000);
requestAnimationFrame(frame);
})();
