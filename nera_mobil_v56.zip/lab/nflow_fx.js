"use strict";
/* NeraFlow: canlı veri bulutu + akış olayları. Ultron'un ilk uyanış sahnesindeki gibi nefes alan, 3 boyutlu parçacık bulutu; gerçek akışa tepki verir:
   - alış/satış baskısı (son işlemler) bulutun rengini temanın üst/alt rengine kaydırır
   - işlem hızı nefes hızını ve parıltıyı sürer; işlemler bulutun içine akan kıvılcımlar olarak girer (yeşil alış, kırmızı satış)
   - defter dengesi (alış/satış duvarı kütlesi) bulutu hafifçe yukarı/aşağı eğer
   - büyük işlem, tasfiye, yığılı dengesizlik, delta patlaması: halka dalgası + düğümler arasında sinyal darbeleri + ayrı bildirim (NeraNotify kind "nflow")
   Bunlar "akış olayı"dır: ölçümlerimizde (21. tur, footprint testi) yön tahmini yaptığı görülmedi. İşlem sinyaline, ajanlara veya bota BAĞLI DEĞİL; yalnız bilgi ve görsel.
   Renkler temadan (--na, --nb, --up, --down) okunur; tuval her temada koyu "ada"dır. Kod orijinal, dış kütüphane yok. */
(function () {
const N = window.NFX; if (!N) return;
const $ = (s, r = document) => r.querySelector(s);
const NAME = { BTCUSDT: "BTC", ETHUSDT: "ETH", XAUUSDT: "Altın", XAGUSDT: "Gümüş" };
const css = (v, d) => { try { return getComputedStyle(document.body).getPropertyValue(v).trim() || d; } catch (e) { return d; } };
const rgb = (c) => { c = String(c).trim(); if (c[0] === "#") { if (c.length === 4) c = "#" + c[1] + c[1] + c[2] + c[2] + c[3] + c[3]; const n = parseInt(c.slice(1), 16); return [n >> 16 & 255, n >> 8 & 255, n & 255]; } const m = c.match(/\d+(\.\d+)?/g); return m ? [+m[0], +m[1], +m[2]] : [53, 224, 196]; };
const mix = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
const money = (u) => (u >= 1e6 ? (u / 1e6).toFixed(2).replace(".", ",") + " mn $" : Math.round(u / 1e3) + " bin $");
N.events = []; N.pressure = 0.5; N.act = 0; N.imb = 0;

/* ---------------------------------------------------------------- veri → bulut */
const E = { seenT: 0, last: {}, barKey: "", stacked: {}, dMin: "", tradeN: 0, rate: 1, base: 0, liqSeen: 0, lastPush: 0, trI: 0 };
function tickData() {
  const H = N.H; if (!H) return;
  const now = Date.now(), tr = H.trades;
  /* baskı: son 60 sn (en çok son 600 işlem) alış payı (hacme göre) */
  let b = 0, s = 0, n60 = 0;
  for (let i = tr.length - 1; i >= 0; i--) { const t = tr[i]; if (now - t.T > 60000) break; (t.sell ? (s += t.usd) : (b += t.usd)); n60++; }
  const p = b + s > 0 ? b / (b + s) : 0.5; N.pressure += (p - N.pressure) * 0.25;
  const rate = n60 / 60; E.rate += (rate - E.rate) * 0.3; E.base = E.base ? E.base + (E.rate - E.base) * 0.02 : E.rate;
  N.act = Math.max(0, Math.min(1, Math.tanh((E.rate / Math.max(0.2, E.base) - 1) * 0.8) * 0.5 + 0.35));
  N.rate = E.rate;
  if (H.dready) { const bk = N.bestBook(H), tk = N.tick[H.sym]; if (bk) { const lim = Math.round(bk.bb * 0.002); let bm = 0, am = 0; H.bids.forEach((q, k) => { if (bk.bb - k <= lim) bm += q; }); H.asks.forEach((q, k) => { if (k - bk.ba <= lim) am += q; }); N.imb += ((bm + am ? (bm - am) / (bm + am) : 0) - N.imb) * 0.2; } }
}
/* ---------------------------------------------------------------- akış olayları */
function emit(type, side, title, body) {
  const t = Date.now(), key = type + side, cd = type === "whale" ? 20000 : 60000;
  if (E.last[key] && t - E.last[key] < cd) return; E.last[key] = t;
  const ev = { t, type, side, title, body, sym: N.sym }; N.events.unshift(ev); if (N.events.length > 40) N.events.pop();
  if (window.NeraFlowCloud) NeraFlowCloud.shock(side, type === "liq" ? "liq" : "x");
  if (window.NeraNotify && t - E.lastPush > 8000) { E.lastPush = t; NeraNotify.push({ kind: "nflow", title, body, cls: side > 0 ? "nf-b" : side < 0 ? "nf-s" : "", onClick: () => { try { Lab.go("nflow"); } catch (e) { /* */ } } }); }
  hud(true);
}
function tickEvents() {
  const H = N.H; if (!H) return; const sym = H.sym, nm = NAME[sym] || sym, d = N.tick[sym], big = N.cfg.big;
  /* büyük işlem: tek işlem, Ayarlar'daki büyük işlem eşiğini (varsayılan 2.500.000 $, Flowsurface varsayılanı) aşıyorsa */
  for (let i = H.bigs.length - 1; i >= 0; i--) { const b = H.bigs[i]; if (b.T <= E.seenT) break; emit("whale", b.sell ? -1 : 1, `${b.sell ? "Büyük satış" : "Büyük alış"} · ${nm}`, `${money(b.usd)} tek işlem @ ${b.p.toFixed(Math.max(0, Math.ceil(-Math.log10(d))))} · akış olayı, tahmin değil`); }
  if (H.bigs.length) E.seenT = H.bigs[H.bigs.length - 1].T;
  /* tasfiye: Binance zorunlu kapanış akışı, aynı eşik */
  for (let i = H.liqs.length - 1; i >= 0; i--) { const l = H.liqs[i]; if (l.T <= E.liqSeen) break; if (l.usd >= big) emit("liq", l.sell ? -1 : 1, `${l.sell ? "Uzun tasfiye" : "Kısa tasfiye"} · ${nm}`, `${money(l.usd)} zorunlu kapanış · akış olayı, tahmin değil`); }
  if (H.liqs.length) E.liqSeen = H.liqs[H.liqs.length - 1].T;
}
/* ---------------------------------------------------------------- HUD + kip */
const fq = (q) => (Math.abs(q) >= 1e6 ? (q / 1e6).toFixed(2) + "m" : Math.abs(q) >= 1e3 ? (q / 1e3).toFixed(1) + "k" : Math.abs(q) >= 10 ? q.toFixed(0) : q.toFixed(2));
function hud(force) {
  const el = $("#nf-hud"); if (!el) return; const H = N.H, tk = N.tk[N.sym];
  if (!H) { el.innerHTML = ""; return; }
  const m1 = N.list(H, "1m"), c1 = m1[m1.length - 1], dl = c1 && c1.cells.size ? c1.B - c1.S : null, ch = tk && tk.open ? (tk.last / tk.open - 1) * 100 : null, pr = Math.round(N.pressure * 100);
  const ev = N.events.slice(0, 3).map((e) => `<span class="nf-ev ${e.side > 0 ? "b" : e.side < 0 ? "s" : ""}"><i></i>${e.title.split(" · ")[0]}<em>${Math.max(0, Math.round((Date.now() - e.t) / 1000))} sn</em></span>`).join("");
  el.innerHTML = `<div class="nf-h"><span>Fiyat</span><b>${H.px ? H.px.toFixed(Math.max(0, Math.min(3, Math.ceil(-Math.log10(N.tick[N.sym] * 10))))) : "—"}</b><em class="${ch == null ? "" : ch >= 0 ? "up" : "dn"}">${ch == null ? "" : (ch >= 0 ? "+" : "") + ch.toFixed(2) + "%"}</em></div>
  <div class="nf-h wide"><span>Baskı (son dakika)</span><div class="nf-gauge"><i style="width:${pr}%"></i></div><b>alış %${pr} · satış %${100 - pr}</b></div>
  <div class="nf-h"><span>Δ 1 dk</span><b class="${dl == null ? "" : dl >= 0 ? "up" : "dn"}">${dl == null ? "—" : (dl >= 0 ? "+" : "") + fq(dl)}</b></div>
  <div class="nf-h"><span>İşlem / sn</span><b>${(N.rate || 0).toFixed(1)}</b></div>
  <div class="nf-h"><span>Defter dengesi</span><b class="${N.imb >= 0 ? "up" : "dn"}">${N.imb >= 0 ? "alış" : "satış"} %${Math.round(Math.abs(N.imb) * 100)}</b></div>
  <div class="nf-evs">${ev || '<span class="nf-ev none">olay bekleniyor</span>'}</div>`;
}
function ui() {
  const pg = $("#pg-nflow"); if (!pg || pg._fx) return; if (!$(".nf-top", pg)) return; pg._fx = 1;
  const hd = document.createElement("div"); hd.id = "nf-hud"; $(".nf-top", pg).after(hd);
  const sw = document.createElement("button"); sw.className = "btn nf-mode"; sw.textContent = "Bulut"; sw.title = "Panelleri gizle, yalnız bulutu göster"; $("#nf-st", pg).before(sw);
  const cg = document.createElement("button"); cg.className = "btn nf-mode"; cg.textContent = "Ayarlar"; cg.onclick = () => N.toggleCfg && N.toggleCfg(); sw.before(cg);
  const set = (on) => { pg.classList.toggle("nf-cloudmode", on); sw.textContent = on ? "Paneller" : "Bulut"; try { localStorage.setItem("nf_cloud", on ? "1" : "0"); } catch (e) { /* */ } };
  sw.onclick = () => set(!pg.classList.contains("nf-cloudmode")); try { if (localStorage.getItem("nf_cloud") === "1") set(true); } catch (e) { /* */ }
  hud();
}
setInterval(() => { ui(); if (!$("#nf-hud")) return; try { tickData(); tickEvents(); if (document.body.dataset.view === "nflow") hud(); } catch (e) { N.fxErr = String(e && e.stack || e).slice(0, 300); } }, 1000);
})();
