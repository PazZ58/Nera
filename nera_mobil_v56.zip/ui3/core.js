"use strict";
/* NERA 3 · çekirdek: TEK zamanlayıcı, hareket eğrileri, azaltılmış hareket, kalite kademesi, Lenis yöneticisi, ekran geçişi.
   Kural: tüm sürekli çizim döngüleri NeraUI.tick ile kaydolur (tek requestAnimationFrame). Görünmeyen ekranın döngüsü çalışmaz, sekme gizliyken hiçbiri çalışmaz.
   Tek requestAnimationFrame'i GSAP ticker'ı tutar; NeraUI.tick döngüleri onun içinde sırayla çalışır (ikinci bir rAF yok). Veri/iş mantığına dokunmaz. */
(function () {
const U = (window.NeraUI = window.NeraUI || {});
const get = (k, d) => { try { return localStorage.getItem(k) || d; } catch (e) { return d; } };
const gs = window.gsap;
/* ---- hareket ayarı: azaltılmış hareket (sistem) ya da Ayarlar'dan zorla (nera_fx: 1 aç, 0 kapat) */
U.reduced = () => get("nera_fx", "") === "0" || (matchMedia("(prefers-reduced-motion: reduce)").matches && get("nera_fx", "") !== "1");
U.mobile = () => matchMedia("(max-width:900px)").matches;
/* ---- eğriler: linear ve varsayılan ease yasak */
if (gs) {
  const plug = [window.CustomEase, window.Flip, window.ScrollTrigger, window.SplitText, window.Observer, window.DrawSVGPlugin].filter(Boolean);
  if (plug.length) gs.registerPlugin(...plug);
  if (window.CustomEase) { CustomEase.create("nera.out", "0.16,1,0.3,1"); CustomEase.create("nera.inOut", "0.76,0,0.24,1"); CustomEase.create("nera.spring", "0.34,1.56,0.64,1"); }
  gs.defaults({ ease: window.CustomEase ? "nera.out" : "power3.out", duration: 0.6 });
}
/* ---- tek zamanlayıcı */
const L = [], LEN = new Set();
let last = 0, ema = 16, started = false;
U.tick = (fn, opt = {}) => { const it = { fn, view: opt.view || null, fps: opt.fps || 0, acc: 0 }; L.push(it); if (!started) { started = true; if (gs && gs.ticker) gs.ticker.add(() => step(performance.now())); else requestAnimationFrame(function l(n) { requestAnimationFrame(l); step(n); }); } return () => { const i = L.indexOf(it); if (i >= 0) L.splice(i, 1); }; };
function step(now) {
  if (document.hidden) { last = now; return; }
  const dt = Math.min(100, now - (last || now)); last = now; ema += (dt - ema) * 0.05; U.frameMs = ema;
  LEN.forEach((l) => { try { l.raf(now); } catch (e) { /* */ } });
  const v = document.body.dataset.view;
  for (let i = 0; i < L.length; i++) {
    const it = L[i];
    if (it.view && (Array.isArray(it.view) ? !it.view.includes(v) : it.view !== v)) continue;
    if (it.fps) { it.acc += dt; if (it.acc < 1000 / it.fps - 1) continue; it.acc = 0; }
    try { it.fn(now, dt); } catch (e) { console.error(e); }
  }
}
if (gs && gs.ticker) gs.ticker.lagSmoothing(0);
/* ---- kalite kademesi: auto/high/low (nera_q). Ağır sahneler U.q() değerine göre parçacık sayısı/çözünürlük seçer */
U.q = () => { const m = get("nera_q", "auto"); if (m === "high") return 0; if (m === "low") return 2; return U.qAuto || 0; };
setInterval(() => { if (document.hidden || get("nera_q", "auto") !== "auto") return; const f = 1000 / Math.max(1, U.frameMs || 16); const lv = f < 30 ? 2 : f < 48 ? 1 : 0; if (lv > (U.qAuto || 0)) U.qAuto = lv; }, 4000);
/* ---- Lenis: kaydırılan alanlara yumuşak kaydırma. Tuval/grafik üstünde tekerlek o alana aitse data-lenis-prevent */
U.scroll = {
  attach(wrapper, opt = {}) {
    if (!window.Lenis || !wrapper || wrapper._lenis || U.reduced() || U.mobile()) return null;
    try {
      const l = new window.Lenis(Object.assign({ wrapper, content: opt.content || wrapper.firstElementChild || wrapper, lerp: 0.1, smoothWheel: true, autoRaf: false }, opt));
      if (window.ScrollTrigger) l.on("scroll", () => ScrollTrigger.update());
      wrapper._lenis = l; LEN.add(l); U.lenisCount = LEN.size; return l;
    } catch (e) { return null; }
  },
  detach(wrapper) { const l = wrapper && wrapper._lenis; if (!l) return; LEN.delete(l); try { l.destroy(); } catch (e) { /* */ } wrapper._lenis = null; U.lenisCount = LEN.size; },
  count: () => LEN.size,
};
/* ekran girince o ekranın kaydırma alanı + iç kaydırma alanları (listeler, sekmeler, açılır menüler) Lenis alır */
const INNER = ".tab, .dropdown, #fr-msgs, .ms, .cos-card, #xn-log, .ph + .pb";
U.scroll.enterView = (view) => {
  LEN.forEach((l) => { const w = l.options && l.options.wrapper; if (w && w !== view && !view.contains(w)) U.scroll.detach(w); });
  if (!view) return;
  const cs = getComputedStyle(view); if (cs.overflowY === "auto" || cs.overflowY === "scroll") U.scroll.attach(view);
  view.querySelectorAll(INNER).forEach((el) => { const o = getComputedStyle(el).overflowY; if ((o === "auto" || o === "scroll") && el.scrollHeight > el.clientHeight + 4) U.scroll.attach(el, { content: el.firstElementChild || el }); });
};
/* ---- ekran girişi: başlık SplitText ile satır maskeli açılır, bölümler katman katman gelir (yalnız transform + opacity) */
U.enter = (v) => {
  const view = document.getElementById("v-" + v); if (!view) return;
  U.scroll.enterView(view);
  if (!gs || U.reduced()) return;
  const h = view.querySelector(".pg h1, .u3-title");
  if (h && window.SplitText) {
    try { if (!h._sp) h._sp = SplitText.create(h, { type: "words", mask: "words" }); gs.fromTo(h._sp.words, { yPercent: 115 }, { yPercent: 0, duration: 0.95, stagger: 0.06, ease: "nera.out", overwrite: true }); } catch (e) { /* */ }
  }
  const kids = [...view.querySelectorAll(".pg > *")].filter((e) => !e.contains(h) && e.offsetParent !== null && !e.matches("canvas")).slice(0, 12);
  /* çizgi: başlık altı ince kural DrawSVG ile çizilir */
  if (h && window.DrawSVGPlugin) {
    let r = h.parentNode.querySelector(".u3-rule");
    if (!r) { h.insertAdjacentHTML("afterend", '<svg class="u3-rule" viewBox="0 0 400 4" preserveAspectRatio="none" aria-hidden="true"><path d="M0 2H400" fill="none" stroke="currentColor" stroke-width="1" vector-effect="non-scaling-stroke"/></svg>'); r = h.parentNode.querySelector(".u3-rule"); }
    gs.fromTo(r.firstElementChild, { drawSVG: "0%" }, { drawSVG: "100%", duration: 1.1, ease: "nera.inOut", delay: 0.25, overwrite: true });
  }
  /* ekran altında kalan bölümler kaydırdıkça ScrollTrigger ile gelir */
  if (window.ScrollTrigger && !view._st && /auto|scroll/.test(getComputedStyle(view).overflowY) && view.scrollHeight > view.clientHeight + 40) {
    view._st = 1;
    view.querySelectorAll(".pg > *").forEach((e, i) => { if (i < 12 || e.matches("canvas,svg")) return; ScrollTrigger.create({ trigger: e, scroller: view, start: "top 94%", once: true, onEnter: () => gs.fromTo(e, { autoAlpha: 0, y: 24 }, { autoAlpha: 1, y: 0, duration: 0.7, ease: "nera.out", clearProps: "transform,opacity,visibility" }) }); gs.set(e, { autoAlpha: 0 }); });
  }
  if (kids.length) gs.fromTo(kids, { autoAlpha: 0, y: 16 }, { autoAlpha: 1, y: 0, duration: 0.7, stagger: 0.05, delay: 0.08, ease: "nera.out", clearProps: "transform,opacity,visibility", overwrite: "auto" });
};
/* ---- ekran geçişi: View Transitions (Chromium) + GSAP; yoksa ya da sekme gizliyse doğrudan */
U.transition = (fn, v) => {
  let done = false; const run = () => { if (!done) { done = true; fn(); } };
  if (U.reduced() || document.hidden || !document.startViewTransition) { run(); setTimeout(() => U.enter(v), 30); return; }
  const t = document.startViewTransition(run); setTimeout(run, 450);
  t.finished.finally(() => {}); t.ready.then(() => U.enter(v)).catch(() => U.enter(v));
};
/* ---- DT köprüsü: ilk açılışta ekran girişini bir kez çalıştır */
window.addEventListener("load", () => setTimeout(() => U.enter(document.body.dataset.view || "brain"), 1200));
})();
