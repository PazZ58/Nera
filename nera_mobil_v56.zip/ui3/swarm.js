"use strict";
/* NERA 3 · Swarm motoru: tek WebGL tuvali (#u3-stage), iki sahne (swarm = açılış + Beyin, flow = NeraFlow bulutu), bloom, GPU parçacıklar.
   Gather · 聚 by DAO dilinden esinlendi (toplanma, dağılma, tarama, iz, bağ); kod kopyalanmadı, shader'lar bu projeye özgü.
   Derinlik haritası: "Nera" yazısı Instrument Serif italik ile tuvale çizilir, bulanıklaştırılmış alfa yükseklik haritası olur; parçacıklar yazı piksellerine yerleşir (z = yükseklik).
   Veriye/iş mantığına dokunmaz; yalnız çizer. Three.js r160 (vendor/three.module.min.js + vendor/three/postprocessing) tembel yüklenir. */
(function () {
const U = window.NeraUI; if (!U || !document.body.classList.contains("u3")) return;
const BASE = document.currentScript && document.currentScript.src;
const MOB = /Android|iPhone|iPad/i.test(navigator.userAgent) || !!window.Capacitor;
const S = (window.NeraSwarm = { ready: false, failed: false, mode: "none", layer: "page", dx: 0, dy: 0, w: 1, h: 1, bloom: 0.72, qd: 0, cbs: [] });
const css = (v, d) => { try { return getComputedStyle(document.body).getPropertyValue(v).trim() || d; } catch (e) { return d; } };
const rnd = (a, b) => a + Math.random() * (b - a);
S.available = !MOB && (() => { try { const c = document.createElement("canvas"); return !!(c.getContext("webgl2") || c.getContext("webgl")); } catch (e) { return false; } })();
const COUNT = [60000, 36000, 14000], FCOUNT = [34000, 20000, 8000], PR = [1.75, 1.25, 1];

/* ---------------------------------------------------------------- shader'lar */
const VS_SWARM = `uniform float uT,uGather,uMix,uScan,uScatter,uPx,uTint;uniform vec3 uC1,uC2,uInk;attribute vec3 aLogo,aSphere,aScat;attribute vec2 aR;varying vec3 vC;varying float vA;
void main(){float s=aR.x,s2=aR.y;float dg=s*.42;float g=smoothstep(dg,dg+.58,uGather);g=g*g*(3.-2.*g);
vec3 drift=vec3(sin(uT*.35+s*40.),cos(uT*.31+s*55.),sin(uT*.27+s*70.))*.22;vec3 pS=aScat+drift*(1.-g*.9);vec3 pL=mix(pS,aLogo,g);
pL+=vec3(sin(uT*1.1+s*30.),cos(uT*.9+s*20.),sin(uT*1.3+s*10.))*.016*g;
float dm=s2*.45;float m=smoothstep(dm,dm+.55,uMix);vec3 mid=mix(pL,aSphere,m);float arc=sin(m*3.14159);mid+=vec3(0.,arc*.9*(s-.5),arc*1.2*(s2-.5));
float br=1.+(.05*sin(uT*.7+s*6.28)+.035*sin(uT*1.9))*m;vec3 p=mid*br;p+=normalize(aSphere+vec3(.001))*uScatter*(.4+s2)*1.1*m;
vec4 mv=modelViewMatrix*vec4(p,1.);gl_Position=projectionMatrix*mv;float scan=exp(-pow((aLogo.x-uScan)*2.4,2.))*g*(1.-m);
gl_PointSize=uPx*(.5+s*.95)*(1.+scan*2.2)*(7./-mv.z);vec3 col=mix(uC1,uC2,s2);col=mix(uInk,col,uTint);vC=col*(1.+scan*1.6);vA=(.34+.5*s)*(.6+.4*g)*(1.+scan);}`;
const VS_FLOW = `uniform float uT,uBuy,uSpeed,uImb,uMelt,uBreath,uPx;uniform vec4 uShock[3];uniform vec3 uBase1,uBase2,uUp,uDown;attribute vec4 aP;attribute vec2 aR;attribute float aTrail;varying vec3 vC;varying float vA;
void main(){float r=aP.x,th=aP.y,w=aP.z,yy=aP.w,s=aR.x,tag=aR.y;float tt=uT-aTrail*.09;float ang=th+tt*uSpeed*w;float rr=r*(1.+.06*sin(tt*uBreath+r*2.));
vec3 p=vec3(cos(ang)*rr,yy,sin(ang)*rr);p+=.16*vec3(sin(p.y*2.3+tt*.7+s*6.),sin(p.z*1.9-tt*.5),sin(p.x*2.1+tt*.6+s*4.));
float tl=uImb*.35;p=vec3(p.x*cos(tl)-p.y*sin(tl),p.x*sin(tl)+p.y*cos(tl),p.z);p.y-=uMelt*(.4+1.6*s*s)*(.5+.5*sin(ang*2.+s*9.));
for(int i=0;i<3;i++){float rad=uShock[i].x,st=uShock[i].y;if(st>.001){float d=length(p)-rad;p+=normalize(p+vec3(.0001))*exp(-d*d*6.)*st*(.4+tag);}}
vec4 mv=modelViewMatrix*vec4(p,1.);gl_Position=projectionMatrix*mv;gl_PointSize=uPx*(.55+.9*s)*(1.-aTrail*.3)*(8./-mv.z);
vec3 base=mix(uBase1,uBase2,s)*.7;float amt=abs(uBuy-.5)*2.;vec3 tint=mix(uDown,uUp,step(.5,uBuy));float k=clamp(amt*2.2,0.,1.)*(.45+.55*tag);vC=mix(base,tint,k);vA=(.5+.6*s)*(1.-aTrail*.45)*(.45+.55*smoothstep(3.8,.3,length(p)));}`;
const FS = `varying vec3 vC;varying float vA;uniform float uLight;void main(){float r=length(gl_PointCoord-.5);if(r>.5)discard;float a=smoothstep(.5,0.,r);gl_FragColor=vec4(vC,a*a*vA);}`;

/* ---------------------------------------------------------------- yükleme */
S.init = () => {
  if (S.initP) return S.initP;
  S.initP = (async () => {
    if (!S.available) { S.failed = true; return false; }
    try {
      const v = (p) => import(new URL("../vendor/three/" + p, BASE).href);
      const [T, ec, rp, ub] = await Promise.all([import("three"), v("postprocessing/EffectComposer.js"), v("postprocessing/RenderPass.js"), v("postprocessing/UnrealBloomPass.js")]);
      /* shader renkleri zaten ekran değeri: renk yönetimini kapat, çıkış doğrusal (yoksa bloom hattı sRGB'yi ikinci kez kodlar: siyah gri olur, renkler solar) */
      T.ColorManagement.enabled = false;
      S.T = T; S.EffectComposer = ec.EffectComposer; S.RenderPass = rp.RenderPass; S.UnrealBloomPass = ub.UnrealBloomPass;
      const cv = document.createElement("canvas"); cv.id = "u3-stage"; document.body.prepend(cv); S.cv = cv;
      S.r = new T.WebGLRenderer({ canvas: cv, antialias: false, alpha: false, powerPreference: "high-performance" });
      S.r.outputColorSpace = T.LinearSRGBColorSpace;
      S.palette(true); S.size(); addEventListener("resize", () => S.size());
      S.tex = null; S.ready = true; return true;
    } catch (e) { S.failed = true; S.err = String(e && e.message || e); return false; }
  })();
  return S.initP;
};
const col = (T, c, d) => new T.Color(css(c, d));
S.palette = (force) => {
  const T = S.T; if (!T) return; const key = ["--u3-acc", "--u3-acc2", "--u3-up", "--u3-down", "--u3-bg", "--u3-ink"].map((k) => css(k, "")).join("|"); if (!force && key === S.pkey) return; S.pkey = key;
  S.light = document.body.classList.contains("theme-light");
  S.c = { acc: col(T, "--u3-acc", "#c8ff3d"), acc2: col(T, "--u3-acc2", "#ff4fd8"), up: col(T, "--u3-up", "#2fd3a1"), down: col(T, "--u3-down", "#ff5878"), bg: col(T, "--u3-bg", "#050505"), ink: col(T, "--u3-ink", "#e9ecef") };
  S.r.setClearColor(S.c.bg, 1);
  if (S.swarm) { S.swarm.u.uC1.value.copy(S.c.acc); S.swarm.u.uC2.value.copy(S.c.acc2); S.swarm.u.uInk.value.copy(S.light ? S.c.ink : new T.Color("#ffffff")); S.swarm.mat.blending = S.light ? T.NormalBlending : T.AdditiveBlending; S.swarm.mat.needsUpdate = true; }
  if (S.flow) { const u = S.flow.u; u.uBase1.value.copy(S.c.acc); u.uBase2.value.copy(S.c.acc2); u.uUp.value.copy(S.c.up); u.uDown.value.copy(S.c.down); S.flow.mat.blending = S.light ? T.NormalBlending : T.AdditiveBlending; S.flow.mat.needsUpdate = true; }
};
S.size = () => {
  if (!S.r) return; const q = U.q(), w = innerWidth, h = innerHeight; S.w = w; S.h = h;
  S.r.setPixelRatio(Math.min(devicePixelRatio || 1, PR[q])); S.r.setSize(w, h, false); S.cv.style.width = w + "px"; S.cv.style.height = h + "px";
  if (S.composer) S.composer.setSize(w, h);
  ["swarm", "flow"].forEach((k) => { if (S[k]) { S[k].cam.aspect = w / h; S[k].cam.updateProjectionMatrix(); S[k].u.uPx.value = 3.6 * Math.min(devicePixelRatio || 1, PR[q]); } });
  S.shift(S.dx, S.dy);
};
/* sahnenin ekrandaki merkezini (piksel) kaydır: sayfa düzenindeki alana hizalama */
S.shift = (dx, dy) => { S.dx = dx; S.dy = dy; ["swarm", "flow"].forEach((k) => { if (S[k]) { const c = S[k].cam; c.setViewOffset(S.w, S.h, -dx, -dy, S.w, S.h); } }); };
S.centerOn = (el) => { const r = el && el.getBoundingClientRect(); if (!r || r.width < 10) return S.shift(0, 0); S.shift(r.left + r.width / 2 - S.w / 2, r.top + r.height / 2 - S.h / 2); };

/* ---------------------------------------------------------------- logo derinlik haritası → parçacık hedefleri */
function logoPoints(N) {
  const W = 1024, H = 360, cv = document.createElement("canvas"); cv.width = W; cv.height = H; const x = cv.getContext("2d", { willReadFrequently: true });
  x.fillStyle = "#000"; x.fillRect(0, 0, W, H); x.fillStyle = "#fff"; x.font = 'italic 400 330px "Instrument Serif", Georgia, serif'; x.textAlign = "center"; x.textBaseline = "alphabetic"; x.fillText("Nera", W / 2, H * 0.8);
  const a = x.getImageData(0, 0, W, H).data, cand = [];
  for (let y = 0; y < H; y += 2) for (let xx = 0; xx < W; xx += 2) if (a[(y * W + xx) * 4] > 140) cand.push(xx, y);
  const cb = document.createElement("canvas"); cb.width = W; cb.height = H; const bx = cb.getContext("2d", { willReadFrequently: true }); bx.filter = "blur(14px)"; bx.drawImage(cv, 0, 0);
  const b = bx.getImageData(0, 0, W, H).data, out = new Float32Array(N * 3), n = cand.length / 2;
  for (let i = 0; i < N; i++) {
    const k = Math.floor(Math.random() * n) * 2, px = cand[k] + Math.random() * 2, py = cand[k + 1] + Math.random() * 2, hgt = b[(Math.floor(py) * W + Math.floor(px)) * 4] / 255;
    out[i * 3] = (px - W / 2) / W * 8.2; out[i * 3 + 1] = -(py - H * 0.5) / W * 8.2 + 0.1; out[i * 3 + 2] = (hgt - 0.35) * 1.4 + (Math.random() - 0.5) * 0.06;
  }
  return out;
}

/* ---------------------------------------------------------------- sahne: swarm (açılış + Beyin çekirdeği) */
S.buildSwarm = async () => {
  if (S.swarm) return S.swarm; await S.init(); if (!S.ready) return null; const T = S.T, q = U.q(), N = COUNT[q];
  try { await document.fonts.load('italic 330px "Instrument Serif"'); } catch (e) { /* yedek yazı tipi */ }
  const logo = logoPoints(N), sph = new Float32Array(N * 3), scat = new Float32Array(N * 3), seed = new Float32Array(N * 2), ga = Math.PI * (3 - Math.sqrt(5));
  for (let i = 0; i < N; i++) {
    const y = 1 - (i / (N - 1)) * 2, rr = Math.sqrt(1 - y * y), th = ga * i, R = 1.55 * (0.92 + Math.random() * 0.16); sph[i * 3] = Math.cos(th) * rr * R; sph[i * 3 + 1] = y * R; sph[i * 3 + 2] = Math.sin(th) * rr * R;
    const u = rnd(-1, 1), t2 = rnd(0, 6.283), qq = Math.sqrt(1 - u * u), d = rnd(3, 9); scat[i * 3] = qq * Math.cos(t2) * d * 1.5; scat[i * 3 + 1] = u * d * 0.8; scat[i * 3 + 2] = qq * Math.sin(t2) * d - 2; seed[i * 2] = Math.random(); seed[i * 2 + 1] = Math.random();
  }
  const g = new T.BufferGeometry(); g.setAttribute("position", new T.BufferAttribute(new Float32Array(N * 3), 3)); g.setAttribute("aLogo", new T.BufferAttribute(logo, 3)); g.setAttribute("aSphere", new T.BufferAttribute(sph, 3)); g.setAttribute("aScat", new T.BufferAttribute(scat, 3)); g.setAttribute("aR", new T.BufferAttribute(seed, 2));
  const u = { uT: { value: 0 }, uGather: { value: 0 }, uMix: { value: 0 }, uScan: { value: -5 }, uScatter: { value: 0 }, uPx: { value: 3.6 * Math.min(devicePixelRatio || 1, PR[q]) }, uTint: { value: 0.15 }, uC1: { value: new T.Color() }, uC2: { value: new T.Color() }, uInk: { value: new T.Color("#fff") }, uLight: { value: 0 } };
  const mat = new T.ShaderMaterial({ uniforms: u, vertexShader: VS_SWARM, fragmentShader: FS, transparent: true, depthWrite: false, blending: T.AdditiveBlending });
  const pts = new T.Points(g, mat); pts.frustumCulled = false; const scene = new T.Scene(); scene.add(pts);
  const cam = new T.PerspectiveCamera(40, S.w / S.h, 0.1, 200); cam.position.set(0, 0, 9.6);
  S.swarm = { scene, cam, pts, u, mat, N }; S.palette(true); S.size(); return S.swarm;
};
/* ---------------------------------------------------------------- sahne: flow (NeraFlow bulutu) */
S.buildFlow = async () => {
  if (S.flow) return S.flow; await S.init(); if (!S.ready) return null; const T = S.T, q = U.q(), N = FCOUNT[q], M = N * 3;
  const aP = new Float32Array(M * 4), aR = new Float32Array(M * 2), aT = new Float32Array(M);
  for (let i = 0; i < N; i++) {
    /* sarmal galaksi: 3 kol, yoğun çekirdek, ince disk */
    const bulge = Math.random() < 0.14, r = bulge ? 0.12 + 0.55 * Math.random() : 0.45 + 3.1 * Math.pow(Math.random(), 0.85), arm = Math.floor(Math.random() * 3), th = bulge ? rnd(0, 6.283) : arm * 2.0944 + r * 1.15 + (Math.random() - 0.5) * (0.9 / (0.5 + r * 0.45)), w = 0.55 / Math.pow(r + 0.4, 0.62), yy = bulge ? (Math.random() - 0.5) * 0.9 : (Math.random() - 0.5) * (0.12 + 0.2 * r), s = Math.random(), tag = Math.random();
    for (let k = 0; k < 3; k++) { const j = i * 3 + k; aP[j * 4] = r; aP[j * 4 + 1] = th; aP[j * 4 + 2] = w; aP[j * 4 + 3] = yy; aR[j * 2] = s; aR[j * 2 + 1] = tag; aT[j] = k; }
  }
  const g = new T.BufferGeometry(); g.setAttribute("position", new T.BufferAttribute(new Float32Array(M * 3), 3)); g.setAttribute("aP", new T.BufferAttribute(aP, 4)); g.setAttribute("aR", new T.BufferAttribute(aR, 2)); g.setAttribute("aTrail", new T.BufferAttribute(aT, 1));
  const u = { uT: { value: 0 }, uBuy: { value: 0.5 }, uSpeed: { value: 1 }, uImb: { value: 0 }, uMelt: { value: 0 }, uBreath: { value: 0.7 }, uPx: { value: 3.6 * Math.min(devicePixelRatio || 1, PR[q]) }, uShock: { value: [new T.Vector4(0, 0, 0, 0), new T.Vector4(0, 0, 0, 0), new T.Vector4(0, 0, 0, 0)] }, uBase1: { value: new T.Color() }, uBase2: { value: new T.Color() }, uUp: { value: new T.Color() }, uDown: { value: new T.Color() }, uLight: { value: 0 } };
  const mat = new T.ShaderMaterial({ uniforms: u, vertexShader: VS_FLOW, fragmentShader: FS, transparent: true, depthWrite: false, blending: T.AdditiveBlending });
  const pts = new T.Points(g, mat); pts.frustumCulled = false; const scene = new T.Scene(); scene.add(pts);
  const cam = new T.PerspectiveCamera(42, S.w / S.h, 0.1, 200); cam.position.set(0, 2.2, 9.5); cam.lookAt(0, 0, 0);
  S.flow = { scene, cam, pts, u, mat, N, shocks: [] }; S.palette(true); S.size(); return S.flow;
};

/* ---------------------------------------------------------------- çizim */
S.setMode = (m) => { S.mode = m; if (S.cv) S.cv.style.visibility = m === "none" && S.layer === "page" ? "hidden" : "visible"; };
S.setLayer = (l) => { S.layer = l; if (S.cv) S.cv.dataset.layer = l; document.body.classList.toggle("u3-splash", l === "splash"); S.setMode(S.mode); };
S.draw = (sc, dt) => {
  const q = U.q(), T = S.T;
  if (q < 2 && !S.light) {
    if (!S.composer) { S.composer = new S.EffectComposer(S.r); S.rp = new S.RenderPass(sc.scene, sc.cam); S.bp = new S.UnrealBloomPass(new T.Vector2(S.w / 2, S.h / 2), S.bloom, 0.6, 0.32); S.composer.addPass(S.rp); S.composer.addPass(S.bp); S.composer.setSize(S.w, S.h); }
    S.rp.scene = sc.scene; S.rp.camera = sc.cam; S.bp.strength = S.bloom; S.composer.render(dt);
  } else S.r.render(sc.scene, sc.cam);
};
S.frame = (now, dtMs) => {
  if (!S.ready || S.mode === "none") return; const dt = Math.min(0.05, dtMs / 1000); S.palette();
  const sc = S.mode === "swarm" ? S.swarm : S.mode === "flow" ? S.flow : null; if (!sc) return;
  sc.u.uT.value += dt; S.cbs.forEach((f) => { try { f(S.mode, dt, now); } catch (e) { /* */ } });
  S.draw(sc, dt);
};
U.tick(S.frame);
document.addEventListener("visibilitychange", () => {});
})();
