"use strict";
/* Nera · beyin: 3B nefes alan nöron küresi, sol menüden küreye uzanan olay bağları, panel içi nöron grafikleri, sinyal "sinaps patlaması", ortam sesi.
   Tek rAF döngüsü; görünmeyen çizimler atlanır. */
/* masaüstü: önemli ayarlar/kayıtlar uygulama klasörüne de yedeklenir (nera_kayit.json). Port ya da tarayıcı profili değişse bile profil fotoğrafı, tema, defter kaybolmaz. */
(function () {
  if (location.protocol !== "http:" || !/^(127\.0\.0\.1|localhost)$/.test(location.hostname)) return;
  const KEYS = ["nera_prof", "nera_fr_users", "nera_fr_chat", "nera_lastread", "nera_prof_bak", "nera_fr_gchat", "nera_lastread_g", "nera_fr_first", "nera_fr_hid", "nera_pool_st", "nera_pool_done", "nera_cue", "nera_ntf", "theme", "nera_pal", "nera_pal_prev", "nera_snd", "nera_lnk", "nera_tint", "opts", "sym", "tf", "pane2", "sound", "dt_lab_book", "dt_lab_tot", "dt_lab_cnt", "nera_seen_v", "nera_bot_pair", "nera_bt", "nera_bt_days", "nera_bt_cfg", "nera_ls_hist", "nera_ls_st", "nera_strat_notify", "nera_ls_notify", "nera_lab_sym", "nera_lab_tf", "nera_lab_days", "nera_lab_cfg", "nera_lab_symmode", "nera_lab_want", "nera_cn_sym", "nera_upd_url"];
  try { const x = new XMLHttpRequest(); x.open("GET", "/api/store", false); x.send(); if (x.status === 200) { const j = JSON.parse(x.responseText || "{}"); for (const k of KEYS) if (typeof j[k] === "string" && localStorage.getItem(k) == null) localStorage.setItem(k, j[k]); } } catch (e) { /* sunucu eski sürüm */ }
  // yalnız değişen anahtarlar gider. sendBeacon 64 KB üstünü sessizce reddeder (defter + sohbet büyüyünce yedek dururdu): normal istek, kapanışta küçük parça beacon
  const last = {}; const diff = () => { const o = {}; for (const k of KEYS) { const v = localStorage.getItem(k); if (v != null && last[k] !== v) o[k] = v; } return o; };
  const push = (beacon) => { try { const o = diff(), ks = Object.keys(o); if (!ks.length) return; const s = JSON.stringify(o);
    if (beacon === true && navigator.sendBeacon) { const small = {}; let n = 2; for (const k of ks.sort((a, b) => o[a].length - o[b].length)) { if (n + o[k].length > 60000) break; small[k] = o[k]; n += o[k].length + k.length + 6; } if (navigator.sendBeacon("/api/store", new Blob([JSON.stringify(small)], { type: "application/json" }))) Object.assign(last, small); return; }
    fetch("/api/store", { method: "POST", body: s }).then((r) => { if (r.ok) Object.assign(last, o); }).catch(() => {}); } catch (e) { /* */ } };
  setInterval(push, 15000); setTimeout(push, 4000); addEventListener("pagehide", () => push(true)); window.NERA_SAVE = push;
})();
const DT = window.DT = { _l: {}, on(e, f) { (this._l[e] = this._l[e] || []).push(f); }, emit(e, d) { (this._l[e] || []).forEach((f) => { try { f(d); } catch (x) { console.error(x); } }); } };
// satır giriş animasyonları yalnız bir ekrana girince oynar; sonra "settled": canlı güncellenen listeler her yenilemede kayıp durmaz (gidip gelme)
DT.on("view", () => { document.body.classList.remove("settled"); clearTimeout(DT._st); DT._st = setTimeout(() => document.body.classList.add("settled"), 1400); }); setTimeout(() => document.body.classList.add("settled"), 4000);
const TICKS = [];
window.NAPI = async (path, opt) => { try { if (window.LOCAL_API) return await window.LOCAL_API(path, opt); const r = await fetch(path, opt); return await r.json(); } catch (e) { return null; } };       // masaüstü: yerel sunucu · mobil: tarayıcı içi motor
let _last = performance.now();
// mobil: kullanılırken tam akıcı; 60 sn dokunulmazsa 30 kare/sn (pil). Masaüstü sınırsız
const LOOP_MOB = matchMedia("(max-width:900px)").matches; let _touch = performance.now(); ["pointerdown", "touchstart", "wheel", "keydown"].forEach((e) => addEventListener(e, () => (_touch = performance.now()), { passive: true }));
const _step = (now) => { if (document.hidden) { _last = now; return; } if (LOOP_MOB && now - _touch > 60000 && now - _last < 31) return; const dt = Math.min(0.1, (now - _last) / 1000); _last = now; for (const f of TICKS) { try { f(dt, now / 1000); } catch (x) { console.error(x); } } };
if (window.NeraUI) NeraUI.tick(_step); else (function loop(now) { requestAnimationFrame(loop); _step(now); })(performance.now());
const vis = (el) => { if (!el || !el.isConnected) return false; let p = el; for (let i = 0; i < 9 && p && p !== document.body; i++) { const cl = p.classList; if (cl) { if (cl.contains("hidden")) return false; if (cl.contains("view")) return cl.contains("active"); } p = p.parentElement; } return true; };            // düzen hesaplatmadan görünürlük
function fitCanvas(cv, w, h, maxd) { const d = Math.min(maxd || DPRMAX, window.devicePixelRatio || 1); w = Math.round(w); h = Math.round(h); if (cv._w !== w || cv._h !== h || cv._d !== d) { cv.width = w * d; cv.height = h * d; cv.style.width = w + "px"; cv.style.height = h + "px"; cv._w = w; cv._h = h; cv._d = d; } const c = cv.getContext("2d"); c.setTransform(d, 0, 0, d, 0, 0); return c; }
const rgba = (hex, a) => { const n = parseInt(hex.slice(1), 16); return `rgba(${n >> 16},${(n >> 8) & 255},${n & 255},${a})`; };
const MOB = matchMedia("(max-width:900px)").matches, DPRMAX = MOB ? 1.25 : 2;
const PALDEF = { a: "#35e0c4", b: "#8a7bff", c: "#ffb04a", up: "#26c6a0", dn: "#f2566a" };
let PAL = Object.assign({}, PALDEF); try { Object.assign(PAL, JSON.parse(localStorage.getItem("nera_pal") || "{}")); } catch (e) { /* varsayılan */ }
let CA = PAL.a, CB = PAL.b, CC = PAL.c, CUP = PAL.up, CDN = PAL.dn;
const hex2 = (h) => { const n = parseInt(h.slice(1), 16); return [n >> 16, (n >> 8) & 255, n & 255]; };
function applyPalette(p, save = true) { PAL = Object.assign({}, PALDEF, p || {}); CA = PAL.a; CB = PAL.b; CC = PAL.c; CUP = PAL.up; CDN = PAL.dn; const s = document.body.style; s.setProperty("--na", PAL.a); s.setProperty("--nb", PAL.b); s.setProperty("--nc", PAL.c); s.setProperty("--up", PAL.up); s.setProperty("--down", PAL.dn); s.setProperty("--blue", PAL.a); if (save) try { localStorage.setItem("nera_pal", JSON.stringify(PAL)); } catch (e) { /* */ } DT.emit("palette", PAL); }
window.HAL_PAL = { a: "#ff8a1f", b: "#a35cff", c: "#7bff6a", up: "#9bdc5b", dn: "#ff4d4d" };
window.THEME_PAL = { halloween: window.HAL_PAL, neon: { a: "#ff2bd6", b: "#22d3ee", c: "#faff5c", up: "#3dffb0", dn: "#ff3d71" }, ocean: { a: "#38bdf8", b: "#2dd4bf", c: "#a5b4fc", up: "#34d399", dn: "#fb7185" }, forest: { a: "#6ee7a0", b: "#d9c36a", c: "#7dd3fc", up: "#86efac", dn: "#f87171" }, sunset: { a: "#ff7a59", b: "#ff4fa0", c: "#ffd166", up: "#7bdcb5", dn: "#ff5a5f" }, matrix: { a: "#22ff66", b: "#00c2a0", c: "#b6ff6a", up: "#22ff66", dn: "#ff4040" } };
window.applyPalette = applyPalette; window.getPalette = () => PAL; window.PALDEF = PALDEF;
const ORBS = [];
const LSget = (k, d) => { try { const v = localStorage.getItem(k); return v == null ? d : v; } catch (e) { return d; } };

/* ---------------------------------------------------------------- küre (3B, sürüklenir, nefes alır) */
class Orb {
  constructor(cv, o) {
    ORBS.push(this); this.tint = null; this.tk = 0; this.cv = cv; this.n = o.n; this.big = !!o.big; this.ry = Math.random() * 6; this.rx = 0.38; this.vy = 0; this.vx = 0; this.drag = false; this.spin = o.spin || 0.07; this.P = []; this.nb = []; this.en = new Float32Array(o.n); this.fl = []; this.waves = []; this.wt = 0.6; this.heat = 0; this.t = Math.random() * 7; this.dust = [];
    const g = Math.PI * (3 - Math.sqrt(5)); for (let i = 0; i < o.n; i++) { const y = 1 - 2 * (i + 0.5) / o.n, r = Math.sqrt(1 - y * y), th = i * g; this.P.push([Math.cos(th) * r, y, Math.sin(th) * r]); }
    for (let i = 0; i < o.n; i++) { const d = []; for (let j = 0; j < o.n; j++) if (j !== i) { const a = this.P[i], b = this.P[j]; d.push([(a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2 + (a[2] - b[2]) ** 2, j]); } d.sort((a, b) => a[0] - b[0]); this.nb.push(d.slice(0, o.k || 3).map((x) => x[1])); }
    for (let i = 0; i < (o.big ? 90 : 24); i++) this.dust.push({ a: Math.random() * 6.28, r: 1.22 + Math.random() * 0.9, s: (0.04 + Math.random() * 0.14) * (Math.random() < 0.5 ? -1 : 1), y: (Math.random() - 0.5) * 1.3, z: 0.5 + Math.random() });
    this.scr = new Float32Array(o.n * 3);
  }
  get breath() { return 0.5 + 0.5 * Math.sin(this.t * 2 * Math.PI / 7); }
  proj(R, cx, cy) {
    const ca = Math.cos(this.ry), sa = Math.sin(this.ry), ct = Math.cos(this.rx), st = Math.sin(this.rx);
    for (let i = 0; i < this.n; i++) { const p = this.P[i], x = p[0] * ca + p[2] * sa, z0 = -p[0] * sa + p[2] * ca, y = p[1] * ct - z0 * st, z = p[1] * st + z0 * ct; this.scr[i * 3] = cx + x * R; this.scr[i * 3 + 1] = cy - y * R; this.scr[i * 3 + 2] = z; }
  }
  attach(dirx, diry) {
    let best = -9, bi = 0; const m = Math.hypot(dirx, diry) || 1; dirx /= m; diry /= m; const cx = this._cx, cy = this._cy, R = this._R || 1;
    for (let i = 0; i < this.n; i++) { const z = this.scr[i * 3 + 2]; if (z < 0.05) continue; const x = (this.scr[i * 3] - cx) / R, y = (this.scr[i * 3 + 1] - cy) / R, sc = x * dirx + y * diry + z * 0.15; if (sc > best) { best = sc; bi = i; } }
    return { i: bi, x: this.scr[bi * 3], y: this.scr[bi * 3 + 1] };
  }
  flare(i, s = 1) { this.fl.push({ i, t: 0, s }); this.spawnWave(i, 1.4 * s); }
  spawnWave(i, power = 1) { const p = this.P[i]; this.waves.push({ p, t: 0, sp: 1.0 + 0.25 * power, pw: Math.min(1.3, 0.6 + 0.4 * power) }); }
  step(dt) {
    this.t += dt; this.tk += ((this.tint && performance.now() < this.tint.until ? 1 : 0) - this.tk) * Math.min(1, dt * 2.2);
    if (!this.drag) { this.ry += (this.spin + this.vy) * dt; this.rx += this.vx * dt; this.vy *= Math.pow(0.12, dt); this.vx *= Math.pow(0.12, dt); this.rx += (0.38 - this.rx) * Math.min(1, dt * 0.35); }
    this.rx = Math.max(-1.25, Math.min(1.25, this.rx));
    this.wt -= dt; if (this.wt <= 0) { this.wt = (this.big ? 2.6 : 3.8) + Math.random() * 1.4; this.spawnWave(Math.floor(Math.random() * this.n), 0.6 + this.heat); if (this.onbeat) this.onbeat(); }
    this.en.fill(0);
    for (let k = this.waves.length - 1; k >= 0; k--) { const w = this.waves[k]; w.t += dt; if (w.t > 3.4) { this.waves.splice(k, 1); continue; } const front = w.sp * w.t, fade = (1 - w.t / 3.4) * w.pw;
      for (let i = 0; i < this.n; i++) { const q = this.P[i], dd = Math.acos(Math.max(-1, Math.min(1, q[0] * w.p[0] + q[1] * w.p[1] + q[2] * w.p[2]))) - front, e = Math.exp(-(dd * dd) / 0.05) * fade; if (e > this.en[i]) this.en[i] = e; } }
    this.heat *= Math.pow(0.4, dt);
    for (let k = this.fl.length - 1; k >= 0; k--) { this.fl[k].t += dt; if (this.fl[k].t > 1.5) this.fl.splice(k, 1); }
  }
  render(c, w, h, R0, cx, cy) {
    const b = this.breath, R = R0 * (1 + 0.03 * Math.sin((this.t * 2 * Math.PI) / 7 - 1.2)); this._cx = cx; this._cy = cy; this._R = R; this.proj(R, cx, cy); const S = this.scr, big = this.big;
    const k = this.tk * 0.9, tc = this.tint ? this.tint.rgb : [0, 0, 0], mx = (a) => a.map((v, i) => Math.round(v + (tc[i] - v) * k)), cA = mx(hex2(CA)), cB = mx(hex2(CB)), cN = mx([188, 208, 255]), cH = mx(hex2(CA).map((v) => Math.round(v + (255 - v) * 0.55))), q = (a, al) => `rgba(${a[0]},${a[1]},${a[2]},${al})`;
    for (let r = 0; r < 3; r++) { const ph = ((this.t / 7) + r / 3) % 1, rr = R * (1.08 + ph * (big ? 0.75 : 0.28)); c.strokeStyle = q(cB, (1 - ph) * (big ? 0.13 : 0.1) * (0.5 + this.heat + k)); c.lineWidth = 1; c.beginPath(); c.arc(cx, cy, rr, 0, 6.3); c.stroke(); }
    const g = c.createRadialGradient(cx, cy, R * 0.15, cx, cy, R * (1.3 + 0.06 * b)); g.addColorStop(0, q(cB, 0.09 + b * 0.06 + this.heat * 0.1 + k * 0.16)); g.addColorStop(0.62, q(cA, 0.045 + b * 0.03 + k * 0.05)); g.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = g; c.fillRect(cx - R * 2.2, cy - R * 2.2, R * 4.4, R * 4.4);
    const back = [], front = []; for (const d of this.dust) { d.a += d.s * 0.016; const x = Math.cos(d.a) * d.r, z = Math.sin(d.a) * d.r, px = cx + x * R, py = cy + (d.y + Math.sin(this.t * 0.4 + d.a) * 0.03) * R; (z < 0 ? back : front).push([px, py, d.z]); }
    c.fillStyle = q(cN, 0.28); for (const p of back) { c.globalAlpha = 0.45; c.beginPath(); c.arc(p[0], p[1], 0.7 * p[2], 0, 6.3); c.fill(); } c.globalAlpha = 1;
    c.lineCap = "round"; const lw = big ? 0.8 : 0.6, hot = [], bins = [new Path2D(), new Path2D(), new Path2D()], nb = this.nb, en = this.en, N = this.n;
    for (let i = 0; i < N; i++) { const z = S[i * 3 + 2], xi = S[i * 3], yi = S[i * 3 + 1];
      for (const j of nb[i]) { if (j < i) continue; const e = en[i] > en[j] ? en[i] : en[j]; if (e > 0.2) { hot.push(i, j, e); continue; } const z2 = (z + S[j * 3 + 2]) * 0.5, bn = bins[z2 < -0.25 ? 0 : z2 < 0.3 ? 1 : 2]; bn.moveTo(xi, yi); bn.lineTo(S[j * 3], S[j * 3 + 1]); } }
    c.lineWidth = lw; const al = big ? [0.08, 0.15, 0.26] : [0.1, 0.18, 0.3]; bins.forEach((bn, i) => { c.strokeStyle = q(cB, al[i] + k * 0.1); c.stroke(bn); });
    for (let i = 0; i < hot.length; i += 3) { const a = hot[i], bb = hot[i + 1], e = hot[i + 2]; c.strokeStyle = q(cH, Math.min(1, 0.35 + e * 0.8)); c.lineWidth = lw + e * 1.3; c.beginPath(); c.moveTo(S[a * 3], S[a * 3 + 1]); c.lineTo(S[bb * 3], S[bb * 3 + 1]); c.stroke(); }
    const nbins = [new Path2D(), new Path2D(), new Path2D()], rb = big ? [0.7, 1.0, 1.4] : [0.55, 0.8, 1.0], hn = [];
    for (let i = 0; i < N; i++) { const z = S[i * 3 + 2], e = en[i]; if (e > 0.2) { hn.push(i); continue; } const kk = z < -0.25 ? 0 : z < 0.3 ? 1 : 2, r = rb[kk] * (1 + 0.1 * b); nbins[kk].moveTo(S[i * 3] + r, S[i * 3 + 1]); nbins[kk].arc(S[i * 3], S[i * 3 + 1], r, 0, 6.3); }
    const na = [0.28, 0.5, 0.8]; nbins.forEach((pp, i) => { c.fillStyle = q(cN, na[i]); c.fill(pp); });
    for (const i of hn) { const e = en[i], r = (big ? 1.4 : 1) * (1 + 0.1 * b) + e * (big ? 2.8 : 1.4); c.fillStyle = q(cH, 0.5 + Math.min(1, e) * 0.5); c.beginPath(); c.arc(S[i * 3], S[i * 3 + 1], r, 0, 6.3); c.fill(); }
    c.fillStyle = q(cN, 0.5); for (const p of front) { c.beginPath(); c.arc(p[0], p[1], 0.9 * p[2], 0, 6.3); c.fill(); }
    for (const f of this.fl) { const x = S[f.i * 3], y = S[f.i * 3 + 1], a = Math.max(0, 1 - f.t / 1.5), rr = (big ? 26 : 12) + f.t * (big ? 90 : 30); const gg = c.createRadialGradient(x, y, 0, x, y, rr); gg.addColorStop(0, "rgba(255,255,255," + 0.75 * a * f.s + ")"); gg.addColorStop(0.25, q(cA, 0.45 * a * f.s)); gg.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = gg; c.fillRect(x - rr, y - rr, rr * 2, rr * 2); }
  }
  draw(w, h, R, cx, cy) { const c = fitCanvas(this.cv, w, h); c.clearRect(0, 0, w, h); this.render(c, w, h, R, cx, cy); }
}

/* ---------------------------------------------------------------- ses: sürekli ortam + nöron notaları + sinyal */
const Sound = window.Sound = {
  ctx: null, on: LSget("nera_snd", "1") !== "0", started: false, view: "brain",
  ctxOk() { try { if (!this.ctx) { const A = window.AudioContext || window.webkitAudioContext; this.ctx = new A(); } if (this.ctx.state === "suspended") this.ctx.resume().catch(() => {}); return this.ctx.state === "running"; } catch (e) { return false; } },
  tone(f, vol = 0.2, dur = 1.8, type = "sine", delay = 0) { if (!this.ctxOk()) return; const c = this.ctx, t = c.currentTime + delay, o = c.createOscillator(), g = c.createGain(); o.type = type; o.frequency.value = f; g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(vol, t + 0.025); g.gain.exponentialRampToValueAtTime(0.0008, t + dur); o.connect(g); g.connect(c.destination); if (this.echo) g.connect(this.echo); o.start(t); o.stop(t + dur + 0.05); },
  intro() { if (!this.on || !this.ctxOk()) return; const c = this.ctx, t = c.currentTime; const sw = (f0, f1, ty, vol, d) => { const o = c.createOscillator(), g = c.createGain(); o.type = ty; o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(f1, t + d); g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + d * 0.62); g.gain.exponentialRampToValueAtTime(0.0001, t + d * 1.25); o.connect(g); g.connect(c.destination); o.start(t); o.stop(t + d * 1.3); };
    sw(62, 190, "sine", 0.16, 3.6); sw(124, 380, "triangle", 0.05, 3.6); const len = c.sampleRate * 4, buf = c.createBuffer(1, len, c.sampleRate), d = buf.getChannelData(0); let b0 = 0; for (let i = 0; i < len; i++) { b0 = 0.97 * b0 + 0.03 * (Math.random() * 2 - 1); d[i] = b0 * 4; }
    const ns = c.createBufferSource(); ns.buffer = buf; const bp = c.createBiquadFilter(); bp.type = "bandpass"; bp.Q.value = 1.2; bp.frequency.setValueAtTime(240, t); bp.frequency.exponentialRampToValueAtTime(2600, t + 3.4); const ng = c.createGain(); ng.gain.setValueAtTime(0.0001, t); ng.gain.exponentialRampToValueAtTime(0.07, t + 2.2); ng.gain.exponentialRampToValueAtTime(0.0001, t + 4); ns.connect(bp); bp.connect(ng); ng.connect(c.destination); ns.start(t);
    [[1.0, 659.3], [1.5, 880], [2.0, 784], [2.5, 1046.5], [2.9, 987.8]].forEach(([dl, f]) => this.tone(f, 0.05, 1.6, "sine", dl)); },
  land() { if (!this.on || !this.ctxOk()) return; const c = this.ctx, t = c.currentTime, o = c.createOscillator(), g = c.createGain(); o.type = "sine"; o.frequency.setValueAtTime(90, t); o.frequency.exponentialRampToValueAtTime(34, t + 0.9); g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.28, t + 0.04); g.gain.exponentialRampToValueAtTime(0.0001, t + 1.1); o.connect(g); g.connect(c.destination); o.start(t); o.stop(t + 1.2); [392, 523.3, 659.3, 784, 1046.5].forEach((f, i) => this.tone(f, 0.07, 2.4, "sine", 0.1 + i * 0.13)); },
  start() {
    if (this.started || !this.on) return; if (!this.ctxOk()) return;
    const c = this.ctx; this.started = true;
    const m = this.master = c.createGain(); m.gain.value = 0; m.connect(c.destination); const lp = c.createBiquadFilter(); lp.type = "lowpass"; lp.frequency.value = 520; lp.Q.value = 0.6; lp.connect(m); this.lp = lp;
    const dr = this.drone = c.createGain(); dr.gain.value = 0.5; dr.connect(lp);
    [[55, "sine", 0], [82.4, "triangle", -6], [110.2, "sine", 7], [164.8, "sine", -4]].forEach(([f, ty, det], i) => { const o = c.createOscillator(); o.type = ty; o.frequency.value = f; o.detune.value = det; const g = c.createGain(); g.gain.value = [0.55, 0.22, 0.2, 0.07][i]; o.connect(g); g.connect(dr); o.start(); });
    const lfo = c.createOscillator(); lfo.frequency.value = 1 / 7; const lg = c.createGain(); lg.gain.value = 0.22; lfo.connect(lg); lg.connect(dr.gain); lfo.start();                // ses, küre nefesiyle aynı 7 sn'lik döngüde dalgalanır
    const lfo2 = c.createOscillator(); lfo2.frequency.value = 1 / 7; const lg2 = c.createGain(); lg2.gain.value = 180; lfo2.connect(lg2); lg2.connect(lp.frequency); lfo2.start();
    const len = c.sampleRate * 3, buf = c.createBuffer(1, len, c.sampleRate), d = buf.getChannelData(0); let b0 = 0; for (let i = 0; i < len; i++) { b0 = 0.985 * b0 + 0.015 * (Math.random() * 2 - 1); d[i] = b0 * 5; }
    const ns = c.createBufferSource(); ns.buffer = buf; ns.loop = true; const bp = c.createBiquadFilter(); bp.type = "bandpass"; bp.frequency.value = 900; bp.Q.value = 0.7; const ng = c.createGain(); ng.gain.value = 0.05; ns.connect(bp); bp.connect(ng); ng.connect(m); ns.start();
    const dl = this.echo = c.createDelay(1); dl.delayTime.value = 0.42; const fb = c.createGain(); fb.gain.value = 0.38; const ef = c.createBiquadFilter(); ef.type = "lowpass"; ef.frequency.value = 1800; dl.connect(ef); ef.connect(fb); fb.connect(dl); const eo = c.createGain(); eo.gain.value = 0.5; ef.connect(eo); eo.connect(m);
    this.apply(true); DT.emit("sound", true);
  },
  apply(slow) { if (!this.master) return; const t = this.ctx.currentTime, target = this.on ? 0.14 * (this.view === "brain" ? 1 : 0.35) : 0; this.master.gain.cancelScheduledValues(t); this.master.gain.setTargetAtTime(target, t, slow ? 2.5 : 0.8); },
  toggle() { this.on = !this.on; try { localStorage.setItem("nera_snd", this.on ? "1" : "0"); } catch (e) { /* */ } if (this.on) { this.start(); if (this.ctx && this.ctx.state === "suspended") this.ctx.resume(); } this.apply(); DT.emit("sound", this.on); },
  setView(v) { this.view = v; this.apply(); },
  note(f, vel = 0.5, dur = 1.6, type = "sine") { if (!this.started || !this.on) return; const c = this.ctx, t = c.currentTime, o = c.createOscillator(), g = c.createGain(); o.type = type; o.frequency.value = f; g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(0.16 * vel * (this.view === "brain" ? 1 : 0.5), t + 0.02); g.gain.exponentialRampToValueAtTime(0.0008, t + dur); o.connect(g); g.connect(this.master); g.connect(this.echo); o.start(t); o.stop(t + dur + 0.05); },
  beat() { const sc = [220, 261.6, 329.6, 392, 440, 523.3, 659.3]; this.note(sc[Math.floor(Math.random() * sc.length)], 0.35, 2.2); },
  linkOn: LSget("nera_lnk", "1") !== "0",
  link(col) { if (!this.linkOn) return; this.note(col === CC ? 392 : 523.3, 0.6, 1.5); setTimeout(() => this.note(col === CC ? 523.3 : 784, 0.5, 1.8), 130); },
  signal(side) { const up = side > 0, seq = up ? [392, 493.9, 587.3, 784] : [784, 622.3, 466.2, 349.2]; seq.forEach((f, i) => { this.tone(f, 0.2, 2.2, "triangle", i * 0.1); this.tone(f * 2, 0.05, 1.6, "sine", i * 0.1 + 0.03); }); },
};
(function () { const go = () => { Sound.start(); if (Sound.started) ["pointerdown", "keydown", "touchstart"].forEach((e) => removeEventListener(e, go, true)); }; ["pointerdown", "keydown", "touchstart"].forEach((e) => addEventListener(e, go, true)); addEventListener("load", () => setTimeout(() => Sound.start(), 400)); })();

/* ---------------------------------------------------------------- bağ yöneticisi (sol menü → küre) + sinyal patlaması */
const LM = {
  cv: null, links: new Map(), feeds: [], bursts: [], bigBox: null, miniBox: null,
  init() { this.cv = document.getElementById("neuro"); },
  target(from) {
    const bigOn = this.bigBox && vis(this.bigBox.cv) && this.bigBox.R > 30, tb = document.querySelector('#mtab [data-v="brain"]'), mob = tb && tb.getClientRects().length > 0;
    if (mob && !bigOn) { const r = tb.getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + 5, i: 0, tab: true, orb: { heat: 0, flare: () => { tb.classList.add("hit"); setTimeout(() => tb.classList.remove("hit"), 750); } } }; }
    const o = bigOn ? this.bigBox : this.miniBox; if (!o) return null;
    const r = o.cv.getBoundingClientRect(), cx = r.left + o.cx, cy = r.top + o.cy, a = o.orb.attach(from.x - cx, from.y - cy); return { x: r.left + a.x, y: r.top + a.y, i: a.i, orb: o.orb };
  },
  navEl(key) { const m = document.getElementById("mtab"); if (m && m.getClientRects().length) return m.querySelector(`[data-v="${key}"]`) || m.querySelector('[data-v="menu"]'); return document.querySelector(`.rn[data-v="${key}"]`); },
  event(key, o = {}) {
    const el = this.navEl(key); if (!el) return; if (document.body.dataset.view === key) return; let L = this.links.get(key);
    if (!L) { L = { key, el, born: performance.now() / 1000, n: 0, col: o.color || CA, pulses: [], nextRev: 0, flash: 0 }; this.links.set(key, L); el.classList.add("glow"); }
    L.n++; L.col = o.color || L.col; L.msg = o.msg; L.pulses.push({ dir: 1, t: 0 }); L.nextRev = 1.0; L.dying = 0; el.classList.add("glow");
    const b = el.querySelector(".rb"); if (b) b.classList.add("on"); const it = document.querySelector(`#msheet [data-v="${key}"] .rb`); if (it) it.classList.add("on"); Sound.link(L.col);
  },
  clear(key) { const L = this.links.get(key); if (!L) return; L.dying = 1; const it = document.querySelector(`#msheet [data-v="${key}"] .rb`); if (it) it.classList.remove("on"); const menuBtn = L.el.matches('#mtab [data-v="menu"]'); if (menuBtn && document.querySelector("#msheet .rb.on")) return; L.el.classList.remove("glow"); const b = L.el.querySelector(".rb"); if (b) b.classList.remove("on"); },
  burst(side) {
    const mt = document.querySelector('#mtab [data-v="market"]'), mob = mt && mt.getClientRects().length > 0, m = this.miniBox; if (!mob && !m) return; const W = innerWidth, H = innerHeight, col = side > 0 ? CUP : CDN, fib = []; let ox, oy;
    if (mob) { const r = mt.getBoundingClientRect(); ox = r.left + r.width / 2; oy = r.top + 6; } else { const r = m.cv.getBoundingClientRect(); ox = r.left + 22; oy = r.top + 22; }
    const nF = mob ? 9 : 12, base = mob ? -Math.PI / 2 : 0, spread = mob ? 1.1 : 1.1;
    for (let k = 0; k < nF; k++) { const ang = base - spread + (2 * spread * k) / (nF - 1) + (Math.random() - 0.5) * 0.12; const pts = [[ox, oy]]; let x = ox, y = oy, a = ang, len = 0; const max = 140 + Math.random() * Math.min(W, H) * 0.45;
      while (len < max) { a += (Math.random() - 0.5) * 0.5; const s = 12 + Math.random() * 12; x += Math.cos(a) * s; y += Math.sin(a) * s; len += s; pts.push([x, y]); if (x > W + 20 || x < -20 || y < -20 || y > H + 20) break; }
      fib.push(pts); if (Math.random() < 0.55 && pts.length > 6) { const j2 = 3 + Math.floor(Math.random() * (pts.length - 5)); const bp = [pts[j2].slice()]; let bx = pts[j2][0], by = pts[j2][1], ba = ang + (Math.random() < 0.5 ? -1 : 1) * (0.6 + Math.random() * 0.5); for (let q2 = 0; q2 < 5 + Math.random() * 5; q2++) { ba += (Math.random() - 0.5) * 0.5; bx += Math.cos(ba) * 14; by += Math.sin(ba) * 14; bp.push([bx, by]); } fib.push(bp); } }
    this.bursts.push({ t: 0, fib, col, ox, oy });
  },
  frame(dt, t) {
    const cv = this.cv; if (!cv) return; const idle = !this.links.size && !this.bursts.length && !((this.feeds.length || (this.efeeds && this.efeeds.length)) && this.bigBox && vis(this.bigBox.cv)); if (idle) { if (this._drawn) { cv.getContext("2d").clearRect(0, 0, cv.width, cv.height); this._drawn = false; } return; } this._drawn = true; const c = fitCanvas(cv, innerWidth, innerHeight); c.clearRect(0, 0, innerWidth, innerHeight);
    for (const f of this.feeds) this.drawFeed(c, f, dt, t); for (const f of this.efeeds || []) this.drawFeed(c, f, dt, t);
    for (const [k, L] of this.links) {
      if (L.dying) { L.dying -= dt * 2.5; if (L.dying <= 0) { this.links.delete(k); continue; } }
      const r = L.el.getBoundingClientRect(), mob = !!L.el.closest("#mtab"), p0 = mob ? { x: r.left + r.width / 2, y: r.top + 4 } : { x: r.right - 6, y: r.top + r.height / 2 }, p1 = this.target(p0); if (!p1) continue;
      const age = t - L.born, grow = Math.min(1, age / 0.9), fade = L.dying ? Math.max(0, L.dying) : 1, dx = p1.x - p0.x, dy = p1.y - p0.y;
      const c1 = mob && p1.tab ? { x: p0.x, y: Math.min(p0.y, p1.y) - 80 } : mob ? { x: p0.x, y: p0.y - Math.abs(dy) * 0.5 - 30 } : { x: p0.x + Math.abs(dx) * 0.5 + 30, y: p0.y }, c2 = mob && p1.tab ? { x: p1.x, y: Math.min(p0.y, p1.y) - 80 } : mob ? { x: p1.x + (p0.x < p1.x ? -1 : 1) * 30, y: p1.y + Math.abs(dy) * 0.4 + 20 } : { x: p1.x - Math.abs(dx) * 0.4 - 20, y: p1.y };
      const B = (u) => { const m = 1 - u, w = Math.sin(u * Math.PI * 4 + t * 2.2) * 2.4 * Math.sin(u * Math.PI); return { x: m * m * m * p0.x + 3 * m * m * u * c1.x + 3 * m * u * u * c2.x + u * u * u * p1.x + w * 0.4, y: m * m * m * p0.y + 3 * m * m * u * c1.y + 3 * m * u * u * c2.y + u * u * u * p1.y + w }; };
      const N = 46, end = Math.round(N * grow); c.save(); c.globalAlpha = fade; c.lineCap = "round";
      c.strokeStyle = rgba(L.col, 0.22); c.lineWidth = 1.4; c.shadowColor = L.col; c.shadowBlur = 8 + 6 * Math.sin(t * 3); c.beginPath(); for (let i = 0; i <= end; i++) { const q = B(i / N); i ? c.lineTo(q.x, q.y) : c.moveTo(q.x, q.y); } c.stroke(); c.shadowBlur = 0;
      for (let i = 2; i < end; i += 5) { const q = B(i / N); c.fillStyle = rgba(L.col, 0.55); c.beginPath(); c.arc(q.x, q.y, 1.6, 0, 6.3); c.fill(); }
      if (grow >= 1) { L.nextRev -= dt; if (L.nextRev <= 0) { L.pulses.push({ dir: -1, t: 0 }); L.nextRev = 2.1; } }
      for (let k2 = L.pulses.length - 1; k2 >= 0; k2--) {
        const P = L.pulses[k2]; P.t += dt / (P.dir > 0 ? 0.85 : 1.25); if (P.t >= 1) { L.pulses.splice(k2, 1); if (P.dir > 0) { p1.orb.flare(p1.i, 1); p1.orb.heat = 1; } else { L.flash = 1; } continue; }
        const u = P.dir > 0 ? P.t : 1 - P.t, tr = 0.22 * Math.min(1, grow + 0.2); for (let s = 0; s < 14; s++) { const uu = P.dir > 0 ? u - tr * s / 14 : u + tr * s / 14; if (uu < 0 || uu > 1) continue; const q = B(uu), a = (1 - s / 14); c.fillStyle = rgba(P.dir > 0 ? "#ffffff" : L.col, a * 0.9); c.beginPath(); c.arc(q.x, q.y, 3.2 * a + 0.6, 0, 6.3); c.fill(); }
        const h = B(u), gg = c.createRadialGradient(h.x, h.y, 0, h.x, h.y, 16); gg.addColorStop(0, rgba("#ffffff", 0.95)); gg.addColorStop(0.3, rgba(L.col, 0.6)); gg.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = gg; c.fillRect(h.x - 16, h.y - 16, 32, 32);
      }
      if (L.flash > 0) { L.flash -= dt * 1.4; const a = Math.max(0, L.flash), rr = 10 + (1 - a) * 26; c.strokeStyle = rgba(L.col, a * 0.8); c.lineWidth = 2; c.beginPath(); c.arc(p0.x, p0.y, rr, 0, 6.3); c.stroke(); }
      c.restore();
    }
    for (let k = this.bursts.length - 1; k >= 0; k--) {
      const B = this.bursts[k]; B.t += dt; if (B.t > 2.1) { this.bursts.splice(k, 1); continue; } const grow = Math.min(1, B.t / 0.95), fade = (B.t < 0.9 ? 1 : Math.max(0, 1 - (B.t - 0.9) / 1.2)) * 0.6;
      c.save(); c.lineCap = "round"; c.lineJoin = "round"; c.shadowColor = B.col; c.shadowBlur = 14; c.globalAlpha = fade;
      for (const f of B.fib) { const n = Math.max(2, Math.round(f.length * grow)); c.strokeStyle = rgba(B.col, 0.75); c.lineWidth = 1.7; c.beginPath(); for (let i = 0; i < n; i++) i ? c.lineTo(f[i][0], f[i][1]) : c.moveTo(f[i][0], f[i][1]); c.stroke(); if (grow < 1) { const hd = f[n - 1], gg = c.createRadialGradient(hd[0], hd[1], 0, hd[0], hd[1], 12); gg.addColorStop(0, "rgba(255,255,255,.95)"); gg.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = gg; c.fillRect(hd[0] - 12, hd[1] - 12, 24, 24); } }
      c.shadowBlur = 0; const rr = B.t * 300; c.strokeStyle = rgba(B.col, Math.max(0, 0.5 - B.t * 0.4)); c.lineWidth = 1.5; c.beginPath(); c.arc(B.ox, B.oy, rr, 0, 6.3); c.stroke(); c.restore();
    }
  },
  drawFeed(c, f, dt, t) {
    const o = this.bigBox; if (!o || !vis(o.cv)) return; const W = innerWidth, H = innerHeight; let p0, vert = false;
    if (f.pt) { vert = f.pt[1] < 0 || f.pt[1] > 1; p0 = { x: f.pt[0] * W, y: f.pt[1] < 0 ? (MOB ? 58 : 50) : f.pt[1] > 1 ? H - (MOB ? 96 : 40) : f.pt[1] * H }; }
    else { if (!f.el || !f.el.isConnected) return; const r = f.el.getBoundingClientRect(); if (r.width < 2) return; p0 = { x: f.side < 0 ? r.right : r.left, y: r.top + r.height / 2 }; }
    const rc = o.cv.getBoundingClientRect(), a = o.orb.attach(p0.x - (rc.left + o.cx), p0.y - (rc.top + o.cy)), p1 = { x: rc.left + a.x, y: rc.top + a.y }, dx = p1.x - p0.x, dy = p1.y - p0.y, col = f.ci != null ? [CA, CB, CC][f.ci % 3] : (f.col || CB);
    const c1 = vert ? { x: p0.x, y: p0.y + dy * 0.5 } : { x: p0.x + dx * 0.5, y: p0.y }, c2 = vert ? { x: p1.x, y: p1.y - dy * 0.2 } : { x: p1.x - dx * 0.2, y: p1.y };
    const B = (u) => { const m = 1 - u; return { x: m * m * m * p0.x + 3 * m * m * u * c1.x + 3 * m * u * u * c2.x + u * u * u * p1.x, y: m * m * m * p0.y + 3 * m * m * u * c1.y + 3 * m * u * u * c2.y + u * u * u * p1.y }; };
    c.strokeStyle = rgba(col, 0.14 + (f.hot || 0) * 0.3); c.lineWidth = 1; c.beginPath(); for (let i = 0; i <= 30; i++) { const q = B(i / 30); i ? c.lineTo(q.x, q.y) : c.moveTo(q.x, q.y); } c.stroke();
    f.ph = (f.ph == null ? Math.random() : f.ph) + dt * (0.14 + (f.hot || 0) * 0.6); f.hot = Math.max(0, (f.hot || 0) - dt * 0.6);
    for (let k = 0; k < 4; k++) { let u = (f.ph + k / 4) % 1; if (f.side > 0) u = 1 - u; const q = B(u), fa = Math.sin(u * Math.PI); c.fillStyle = rgba(col, (0.25 + (f.hot || 0) * 0.4) + 0.4 * fa); c.beginPath(); c.arc(q.x, q.y, 1.4 + fa * 1.2 + (f.hot || 0) * 1.4, 0, 6.3); c.fill(); }
  },
};
TICKS.push((dt, t) => LM.frame(dt, t));
DT.on("signal", (e) => { LM.burst(e && e.side); LM.event("market", { color: e && e.side < 0 ? CDN : CUP, msg: "Yeni sinyal" }); });

/* ---------------------------------------------------------------- KOZMOS: beyin çekirdeği = 3B güneş sistemi.
   Merkezde yıldız olarak beyin küresi (Orb); kaynaklar ve çıktılar gezegen; her gezegen yıldıza nöron bağıyla bağlı, veri bu bağlarda akar.
   Sürükle: kamerayı döndür · gezegene dokun: kamera akıcı biçimde ona uçar · ‹ › gezegenler arası geçiş · boşluğa/yıldıza dokun: sisteme dön. */
const themeName = () => { const m = document.body.className.match(/theme-(\w+)/); return m ? m[1] : "dark"; };
const Cosmos = window.Cosmos = {
  cv: null, orb: null, SR: 1.32, P: [], pu: [], stars: [], fx: [], fxTh: "", t: 0, focus: null, hover: null, zoom: 1, idle: 0,
  cam: { tx: 0, ty: 0, tz: 0, D: 12, yaw: 0.7, pitch: 0.3, ox: 0, oy: 0 }, last: { x: 0, y: 0, z: 0 }, spd: 0,
  DEF: [                                                         // anahtar, ad, rol (-1 kaynak → yıldız, +1 yıldız → çıktı), renk, yarıçap, yörünge, hız, eğim, halka, uydu
    ["mk", "Piyasa Akışı", -1, () => CA, 0.17, 2.05, 0.22, 0.10, 0, 1],
    ["hist", "Geçmiş Veri", -1, () => CB, 0.22, 2.42, 0.17, -0.16, 1, 0],
    ["kb", "Bilgi Bankası", -1, () => CC, 0.15, 2.78, 0.14, 0.2, 0, 2],
    ["sig", "Sinyal Defteri", -1, () => "#4dd0e1", 0.14, 3.12, 0.12, -0.08, 0, 1],
    ["idea", "Fikir", 1, () => CB, 0.16, 3.46, 0.1, 0.15, 0, 0],
    ["test", "Test", 1, () => CA, 0.21, 3.82, 0.085, -0.19, 1, 2],
    ["rej", "Elenen", 1, () => "#f2566a", 0.13, 4.17, 0.072, 0.07, 0, 0],
    ["labsig", "Lab Sinyalleri", 1, () => "#ffd166", 0.19, 4.55, 0.062, -0.12, 1, 3],
  ],
  init(cv, orb) {
    this.cv = cv; this.orb = orb; const r = (a, b) => a + Math.random() * (b - a);
    if (document.getElementById("splash")) this.introT = performance.now() + 1e9;       // açılış perdesi kalkarken başlar (Splash → startIntro)
    DT.on("splash-done", () => { if (this.introT > performance.now()) this.startIntro(2600); });
    DT.on("view", (v) => { if (v === "brain" && this.introP() >= 1) this.startIntro(1700); });
    this.P = this.DEF.map(([k, n, role, col, pr, orbit, sp, inc, ring, moons], i) => ({ k, n, role, col, pr, orbit, sp, inc, ring, moons, a: i * 2.39 + r(0, 0.6), ph: r(0, 6), e: 0, sx: 0, sy: 0, ss: 0, sd: 0, w: [0, 0, 0], ma: r(0, 6), spin: r(0, 6) }));
    for (let i = 0; i < (MOB ? 150 : 280); i++) { const u = r(-1, 1), th = r(0, 6.283), q = Math.sqrt(1 - u * u); this.stars.push({ d: [q * Math.cos(th), u, q * Math.sin(th)], s: r(0.4, 1.5), ph: r(0, 6), c: Math.random() < 0.15 ? 1 : 0 }); }
    let down = null; cv.style.cursor = "grab"; cv.style.touchAction = "none";
    cv.addEventListener("pointerdown", (e) => { down = { x: e.clientX, y: e.clientY, lx: e.clientX, ly: e.clientY, m: 0 }; try { cv.setPointerCapture(e.pointerId); } catch (x) { /* */ } Sound.start(); });
    cv.addEventListener("pointermove", (e) => { const rc = cv.getBoundingClientRect(), mx = e.clientX - rc.left, my = e.clientY - rc.top;
      if (down) { const dx = e.clientX - down.lx, dy = e.clientY - down.ly; down.m += Math.abs(dx) + Math.abs(dy); down.lx = e.clientX; down.ly = e.clientY; if (down.m > 6) { cv.style.cursor = "grabbing"; this.cam.yaw -= dx * 0.006; this.cam.pitch = Math.max(0.08, Math.min(1.25, this.cam.pitch + dy * 0.004)); this.idle = 4; } return; }
      const h = this.hit(mx, my); this.hover = h; cv.style.cursor = h ? "pointer" : "grab"; });
    const up = (e) => { if (!down) return; const moved = down.m > 6; down = null; cv.style.cursor = "grab"; if (moved) return; const rc = cv.getBoundingClientRect(), h = this.hit(e.clientX - rc.left, e.clientY - rc.top); this.go(h ? h.k : null); };
    cv.addEventListener("pointerup", up); cv.addEventListener("pointercancel", () => { down = null; });
    cv.addEventListener("wheel", (e) => { if (this.focus) return; e.preventDefault(); this.zoom = Math.max(0.7, Math.min(1.7, this.zoom * (e.deltaY > 0 ? 0.92 : 1.08))); }, { passive: false });
    addEventListener("keydown", (e) => { if (document.body.dataset.view !== "brain" || /input|textarea|select/i.test((e.target && e.target.tagName) || "")) return; if (e.key === "ArrowRight") this.step(1); else if (e.key === "ArrowLeft") this.step(-1); else if (e.key === "Escape") this.go(null); });
    this.ui();
  },
  ui() {
    const core = this.cv.parentElement; let u = core.querySelector("#cos-ui"); if (u) return; u = document.createElement("div"); u.id = "cos-ui";
    u.innerHTML = `<div class="cos-nav"><button data-k="" class="on">◎ Sistem</button>${this.P.map((p) => `<button data-k="${p.k}" style="--pc:${p.col()}"><i></i>${p.n}</button>`).join("")}</div><div class="cos-card" id="cos-card"></div>`;
    core.appendChild(u); u.querySelectorAll(".cos-nav button").forEach((b) => (b.onclick = () => this.go(b.dataset.k || null)));
    DT.on("palette", () => u.querySelectorAll(".cos-nav button[data-k]").forEach((b) => { const p = this.P.find((x) => x.k === b.dataset.k); if (p) b.style.setProperty("--pc", p.col()); }));
  },
  go(k) {
    const p = k ? this.P.find((x) => x.k === k) : null; if (p === this.focus) { if (!p) return; } this.focus = p; this.idle = p ? 0 : 3;
    const u = document.getElementById("cos-ui"); if (u) { u.querySelectorAll(".cos-nav button").forEach((b) => b.classList.toggle("on", (b.dataset.k || null) === (k || null))); u.classList.toggle("focus", !!p); }
    if (p) { p.e = 1; this.card(true); try { Sound.tone(392 + this.P.indexOf(p) * 55, 0.06, 1.4, "sine"); Sound.tone(784 + this.P.indexOf(p) * 110, 0.025, 1.1, "sine", 0.08); } catch (e) { /* */ } } else this.card(true);
  },
  step(d) { const i = this.focus ? this.P.indexOf(this.focus) : d > 0 ? -1 : 0, n = this.P.length; this.go(this.P[(i + d + n) % n].k); },
  card(force) {
    const el = document.getElementById("cos-card"); if (!el) return; const p = this.focus; if (!p) { el.classList.remove("show"); el._k = null; return; }
    const now = performance.now(); if (!force && now - (this._cu || 0) < 300) return; this._cu = now;
    const inf = (window.Lab && Lab.planetInfo && Lab.planetInfo(p.k)) || { v: "—", s: "", rows: [], desc: "" }, rows = inf.rows || [], vh = `${inf.v}<span>${inf.s || ""}</span>`;
    if (force || el._k !== p.k || el._n !== rows.length) {               // yapı yalnız odak değişince kurulur; sonra değerler yerinde güncellenir (animasyonlar baştan başlamasın)
      el._k = p.k; el._n = rows.length;
      el.innerHTML = `<div class="cc-h" style="--pc:${p.col()}"><i></i><div><small>${p.role < 0 ? "KAYNAK · yıldıza veri taşır" : "ÇIKTI · yıldızdan beslenir"}</small><b>${p.n}</b></div><button class="cc-x" data-a="x" aria-label="Sisteme dön">✕</button></div>
      <div class="cc-v">${vh}</div><div class="cc-spw">${inf.spark || ""}</div><div class="cc-rows">${rows.map(([l, v], i) => `<div style="--i:${i}"><span>${l}</span><b>${v}</b></div>`).join("")}</div><p>${inf.desc || ""}</p>
      <div class="cc-nav"><button data-a="p">‹ önceki</button><button data-a="x">◎ sistem</button><button data-a="n">sonraki ›</button></div>`;
      el.querySelectorAll("[data-a]").forEach((b) => (b.onclick = () => (b.dataset.a === "x" ? this.go(null) : this.step(b.dataset.a === "n" ? 1 : -1))));
      el.classList.remove("show"); void el.offsetWidth; el.classList.add("show"); return;
    }
    const v = el.querySelector(".cc-v"); if (v && v._h !== vh) { v._h = vh; v.innerHTML = vh; } const sw = el.querySelector(".cc-spw"); if (sw && sw._h !== inf.spark) { sw._h = inf.spark; sw.innerHTML = inf.spark || ""; }
    el.querySelectorAll(".cc-rows > div").forEach((d, i) => { const r = rows[i]; if (!r) return; const hh = `<span>${r[0]}</span><b>${r[1]}</b>`; if (d._h !== hh) { d._h = hh; d.innerHTML = hh; } });
  },
  hot(k, s = 1) {                                                // gezegen başına en çok ~1,8 sn'de bir darbe (laboratuvar saniyede onlarca tarif dener; hepsi top olarak akmasın)
    const p = this.P.find((x) => x.k === k); if (!p) return; p.e = Math.min(0.9, p.e + 0.25 * s); const now = performance.now();
    if (now - (p.lastPu || 0) < (s >= 1.2 ? 600 : 1800) || this.pu.filter((q) => q.p === p).length >= 2) return; p.lastPu = now; this.pu.push({ p, u: 0, dir: p.role < 0 ? 1 : -1, s: Math.min(1, s) }); },
  hit(x, y) { let best = null, bd = 1e9; for (const p of this.P) { const r = Math.max(16, p.pr * p.ss * 1.4), d = Math.hypot(p.sx - x, p.sy - y); if (d < r && d < bd) { bd = d; best = p; } } return best; },
  base(w, h) { const ext = 4.75, mob = w < 700; return Math.max(20, Math.min(w * (mob ? 0.48 : 0.42) / ext, h * 0.4 / (ext * Math.sin(this.cam.pitch) + 1.5))); },
  layout(w, h) { const s0 = this.base(w, h) * this.zoom; LM.bigBox.cx = w / 2; LM.bigBox.cy = h / 2; LM.bigBox.R = s0 * this.SR; },
  introT: null, introMs: 3000,
  startIntro(ms = 3000) { this.introT = performance.now(); this.introMs = ms; },
  introP() { return this.introT == null ? 1 : Math.max(0, Math.min(1, (performance.now() - this.introT) / this.introMs)); },
  frame(dt, t, w, h, noStar) {
    const cv = this.cv, c = fitCanvas(cv, w, h), cam = this.cam, P = this.P; c.clearRect(0, 0, w, h); this.t += dt; const tt = this.t, mob = w < 700, it = this.introP();
    P.forEach((p, i) => { const q = Math.max(0, Math.min(1, (it * 1.35 - i * 0.07) / 0.75)); p.ie = it >= 1 ? 1 : 1 - Math.pow(1 - q, 3); });     // giriş: gezegenler yıldızdan sarmal çizerek yörüngelerine açılır
    for (const p of P) { p.a += p.sp * dt * 0.32; const ie = p.ie, rr = p.orbit * (0.2 + 0.8 * ie), aa = p.a + (1 - ie) * 2.2; p.w = [Math.cos(aa) * rr, Math.sin(aa + p.ph) * p.inc * rr, Math.sin(aa) * rr]; p.ma += dt * 0.9; p.spin += dt * 0.25; p.e *= Math.pow(0.35, dt); }
    const s0 = this.base(w, h), F = s0 * 12, f = this.focus; if (!this.idle) cam.yaw += dt * (f ? 0.012 : 0.035); else this.idle = Math.max(0, this.idle - dt);
    const g = f ? { x: f.w[0], y: f.w[1], z: f.w[2], D: F * f.pr / (Math.min(w, h) * (mob ? 0.2 : 0.17)), ox: mob ? 0 : -w * 0.16, oy: mob ? -h * 0.14 : 0 } : { x: 0, y: 0, z: 0, D: 12 / this.zoom, ox: 0, oy: 0 };
    const k = 1 - Math.exp(-dt * 2.3); cam.tx += (g.x - cam.tx) * k; cam.ty += (g.y - cam.ty) * k; cam.tz += (g.z - cam.tz) * k; cam.D += (g.D - cam.D) * k; cam.ox += (g.ox - cam.ox) * k; cam.oy += (g.oy - cam.oy) * k;
    const mv = Math.hypot(cam.tx - this.last.x, cam.ty - this.last.y, cam.tz - this.last.z) / Math.max(dt, 0.001) + Math.abs(cam.D - (this.lastD || cam.D)) / Math.max(dt, 0.001) * 0.25; this.spd += (Math.min(6, mv) - this.spd) * Math.min(1, dt * 6); this.last = { x: cam.tx, y: cam.ty, z: cam.tz }; this.lastD = cam.D;
    const cyw = Math.cos(cam.yaw), syw = Math.sin(cam.yaw), cp = Math.cos(cam.pitch), spp = Math.sin(cam.pitch), CX = w / 2 + cam.ox, CY = h / 2 + cam.oy;
    const pr = (x, y, z) => { x -= cam.tx; y -= cam.ty; z -= cam.tz; const x1 = x * cyw - z * syw, z1 = x * syw + z * cyw, y2 = y * cp + z1 * spp, z2 = -y * spp + z1 * cp, d = cam.D + z2; if (d < 0.15) return null; const s = F / d; return [CX + x1 * s, CY - y2 * s, s, d]; };
    c.globalAlpha = 0.25 + 0.75 * it; this.bg(c, w, h, tt, dt, pr, cam); c.globalAlpha = 1;
    const st = pr(0, 0, 0), R = st ? st[2] * this.SR : 0; LM.bigBox.cx = st ? st[0] : w / 2; LM.bigBox.cy = st ? st[1] : h / 2; LM.bigBox.R = R;
    const sd = st ? st[3] : 99;
    for (const p of P) { const q = pr(p.w[0], p.w[1], p.w[2]); if (q) { p.sx = q[0]; p.sy = q[1]; p.ss = q[2]; p.sd = q[3]; } else p.ss = 0; }
    const orbitPath = (p, near) => { const N = 96; c.beginPath(); let on = false; for (let i = 0; i <= N; i++) { const a = (i / N) * 6.2832, q = pr(Math.cos(a) * p.orbit, Math.sin(a + p.ph) * p.inc * p.orbit, Math.sin(a) * p.orbit); if (!q || (q[3] < sd) !== near) { on = false; continue; } on ? c.lineTo(q[0], q[1]) : c.moveTo(q[0], q[1]); on = true; } };
    const drawOrbits = (near) => { for (const p of P) { orbitPath(p, near); const fo = (f === p ? 0.5 : this.hover === p ? 0.35 : 0.13) * p.ie; if (fo < 0.005) continue; c.strokeStyle = rgba(p.col(), fo * (f && f !== p ? 0.5 : 1)); c.lineWidth = f === p ? 1.4 : 1; c.setLineDash(p.role < 0 ? [] : [2, 5]); c.stroke(); } c.setLineDash([]); };
    const link = (p) => { const L = Math.hypot(...p.w) || 1, sw = [p.w[0] / L * this.SR * 1.02, p.w[1] / L * this.SR * 1.02, p.w[2] / L * this.SR * 1.02], lift = 0.35 + p.orbit * 0.12, cw = [(p.w[0] + sw[0]) / 2, (p.w[1] + sw[1]) / 2 + lift, (p.w[2] + sw[2]) / 2]; const pts = []; for (let i = 0; i <= 24; i++) { const u = i / 24, m = 1 - u, x = m * m * p.w[0] + 2 * m * u * cw[0] + u * u * sw[0], y = m * m * p.w[1] + 2 * m * u * cw[1] + u * u * sw[1], z = m * m * p.w[2] + 2 * m * u * cw[2] + u * u * sw[2], q = pr(x, y, z); if (q) pts.push(q); } p.lk = pts; return pts; };
    const drawLink = (p) => { if (p.ie < 0.05) return; const pts = link(p); if (pts.length < 2) return; const col = p.col(), a = ((f && f !== p ? 0.08 : 0.18) + p.e * 0.4) * p.ie; c.strokeStyle = rgba(col, a); c.lineWidth = 1 + p.e; c.beginPath(); pts.forEach((q, i) => (i ? c.lineTo(q[0], q[1]) : c.moveTo(q[0], q[1]))); c.stroke();
      for (let i = 2; i < pts.length - 1; i += 3) { const q = pts[i], fl = (Math.sin(tt * 2.4 - i * 0.5 + p.ph) + 1) / 2; c.fillStyle = rgba(col, 0.2 + 0.5 * fl * (0.4 + p.e)); c.beginPath(); c.arc(q[0], q[1], 1 + fl * 1.2, 0, 6.3); c.fill(); } };
    const drawPlanet = (p) => { if (!p.ss || p.ie < 0.02) return; const x = p.sx, y = p.sy, r = Math.max(1, p.pr * p.ss * p.ie), col = p.col(), rgb = hex2(col), lt = rgb.map((v) => Math.round(v + (255 - v) * 0.55)), dk = rgb.map((v) => Math.round(v * 0.22)), qq = (a, al) => `rgba(${a[0]},${a[1]},${a[2]},${al})`, dim = f && f !== p ? 0.55 : 1;
      const dx = (st ? st[0] : w / 2) - x, dy = (st ? st[1] : h / 2) - y, dl = Math.hypot(dx, dy) || 1, lx = dx / dl, ly = dy / dl;
      const gl = c.createRadialGradient(x, y, r * 0.6, x, y, r * (2.6 + p.e * 1.5)); gl.addColorStop(0, qq(rgb, (0.22 + p.e * 0.35) * dim)); gl.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = gl; c.fillRect(x - r * 4.2, y - r * 4.2, r * 8.4, r * 8.4);
      const ringPts = (front) => { if (!p.ring) return; c.beginPath(); let on = false; for (let i = 0; i <= 48; i++) { const a = (i / 48) * 6.2832, rr = p.pr * 1.85, q = pr(p.w[0] + Math.cos(a) * rr, p.w[1] + Math.sin(a) * rr * 0.28, p.w[2] + Math.sin(a) * rr * 0.96); if (!q || (q[3] < p.sd) !== front) { on = false; continue; } on ? c.lineTo(q[0], q[1]) : c.moveTo(q[0], q[1]); on = true; } c.strokeStyle = qq(lt, 0.5 * dim); c.lineWidth = Math.max(1, r * 0.12); c.stroke(); };
      ringPts(false);
      const bd = c.createRadialGradient(x + lx * r * 0.45, y + ly * r * 0.45, r * 0.08, x, y, r); bd.addColorStop(0, qq(lt, dim)); bd.addColorStop(0.45, qq(rgb, 0.95 * dim)); bd.addColorStop(1, qq(dk, dim)); c.fillStyle = bd; c.beginPath(); c.arc(x, y, r, 0, 6.3); c.fill();
      if (r > 9) { c.save(); c.beginPath(); c.arc(x, y, r, 0, 6.3); c.clip(); c.strokeStyle = qq(lt, 0.16 * dim); c.lineWidth = 1; for (let b = -2; b <= 2; b++) { c.beginPath(); c.ellipse(x, y + b * r * 0.34 + Math.sin(p.spin + b) * r * 0.04, r * Math.sqrt(Math.max(0.05, 1 - (b * 0.34) ** 2)), r * 0.09, 0, 0, 6.3); c.stroke(); } for (let j = 0; j < 7; j++) { const a = p.spin * 1.4 + j * 0.9, xx = x + Math.cos(a) * r * 0.7, yy = y + Math.sin(a * 1.3) * r * 0.55; if (Math.cos(a) < -0.2) continue; c.fillStyle = qq(lt, 0.5 * dim); c.beginPath(); c.arc(xx, yy, Math.max(0.8, r * 0.05), 0, 6.3); c.fill(); } c.restore(); }
      ringPts(true);
      for (let m = 0; m < p.moons; m++) { const a = p.ma * (1 + m * 0.35) + m * 2.1, rr = p.pr * (2.2 + m * 0.55), q = pr(p.w[0] + Math.cos(a) * rr, p.w[1] + Math.sin(a) * rr * 0.35, p.w[2] + Math.sin(a) * rr); if (!q) continue; c.fillStyle = qq(lt, 0.85 * dim); c.beginPath(); c.arc(q[0], q[1], Math.max(1.2, p.pr * 0.22 * q[2]), 0, 6.3); c.fill(); }
      if (f === p || this.hover === p) { c.strokeStyle = qq(lt, 0.7); c.setLineDash([3, 5]); c.lineDashOffset = -tt * 14; c.lineWidth = 1.2; c.beginPath(); c.arc(x, y, r * 1.55 + 3, 0, 6.3); c.stroke(); c.setLineDash([]); }
    };
    const label = (p) => { if (!p.ss || p.ie < 0.6) return; const r = Math.max(2.5, p.pr * p.ss), inf = window.Lab && Lab.planetInfo ? Lab.planetInfo(p.k, true) : null, al = (f && f !== p ? 0.35 : 0.95) * Math.max(0.35, Math.min(1, 9 / p.sd * 1.4)) * (st && p.sd > sd && Math.hypot(p.sx - st[0], p.sy - st[1]) < R * 1.15 ? 0.15 : 1) * Math.min(1, (p.ie - 0.6) / 0.4); if (f === p) return;
      c.textAlign = "center"; c.fillStyle = rgba("#c3cbe0", al * 0.8); c.font = `600 ${mob ? 9 : 10}px Consolas,monospace`; c.fillText(p.n.toLocaleUpperCase("tr-TR"), p.sx, p.sy + r + 15); if (inf) { c.fillStyle = rgba("#ffffff", al); c.font = `700 ${mob ? 12 : 15}px "Segoe UI",sans-serif`; c.fillText(inf.v, p.sx, p.sy + r + (mob ? 30 : 33)); } };
    const order = P.slice().sort((a, b) => b.sd - a.sd), far = order.filter((p) => p.sd >= sd), near = order.filter((p) => p.sd < sd);
    drawOrbits(false); far.forEach(drawLink); far.forEach(drawPlanet);
    if (st && !noStar) { this.orb.render(c, w, h, R, st[0], st[1]); }
    drawOrbits(true); near.forEach(drawLink); near.forEach(drawPlanet); P.forEach(label);
    this.idleP = (this.idleP || 0) - dt; if (this.idleP <= 0) { this.idleP = 2.2 + Math.random() * 2; this.hot(P[Math.floor(Math.random() * P.length)].k, 0.35); }
    for (let i = this.pu.length - 1; i >= 0; i--) { const q = this.pu[i], p = q.p, L = p.lk; q.u += dt / 2.6; if (q.u >= 1) { this.pu.splice(i, 1); if (q.dir > 0) { this.orb.heat = Math.min(1, this.orb.heat + 0.3 * q.s); if (q.s > 0.6) this.orb.spawnWave(Math.floor(Math.random() * this.orb.n), 0.8); } else p.e = Math.min(1.2, p.e + 0.6 * q.s); continue; } if (!L || L.length < 2) continue;
      const u = q.dir > 0 ? q.u : 1 - q.u, fi = u * (L.length - 1), i0 = Math.floor(fi), a = L[i0], b = L[Math.min(L.length - 1, i0 + 1)], fr = fi - i0, x = a[0] + (b[0] - a[0]) * fr, y = a[1] + (b[1] - a[1]) * fr, rr = 5 + 7 * q.s, gg = c.createRadialGradient(x, y, 0, x, y, rr); gg.addColorStop(0, "rgba(255,255,255,.95)"); gg.addColorStop(0.35, rgba(p.col(), 0.7)); gg.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = gg; c.fillRect(x - rr, y - rr, rr * 2, rr * 2); }
    if (f) this.card(false);
  },
  bg(c, w, h, tt, dt, pr, cam) {
    const th = themeName(), A = hex2(CA), B = hex2(CB), q = (a, al) => `rgba(${a[0]},${a[1]},${a[2]},${al})`;
    const n1 = c.createRadialGradient(w * (0.22 + 0.04 * Math.sin(tt * 0.05)), h * 0.3, 0, w * 0.22, h * 0.3, w * 0.5); n1.addColorStop(0, q(B, 0.09)); n1.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = n1; c.fillRect(0, 0, w, h);
    const n2 = c.createRadialGradient(w * 0.8, h * (0.72 + 0.04 * Math.cos(tt * 0.04)), 0, w * 0.8, h * 0.72, w * 0.45); n2.addColorStop(0, q(A, 0.07)); n2.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = n2; c.fillRect(0, 0, w, h);
    const sp = this.spd, streak = Math.min(1, Math.max(0, (sp - 0.6) / 3));
    for (const s of this.stars) { const p = pr(s.d[0] * 34 + cam.tx, s.d[1] * 34 + cam.ty, s.d[2] * 34 + cam.tz); if (!p) continue; const tw = 0.35 + 0.65 * (0.5 + 0.5 * Math.sin(tt * (1 + s.s) + s.ph)), r = s.s * (0.5 + p[2] * 0.012); c.fillStyle = s.c ? q(A, 0.75 * tw) : `rgba(220,228,255,${0.6 * tw})`;
      if (streak > 0.02) { const dx = p[0] - (w / 2 + cam.ox), dy = p[1] - (h / 2 + cam.oy); c.strokeStyle = c.fillStyle; c.lineWidth = r; c.beginPath(); c.moveTo(p[0], p[1]); c.lineTo(p[0] - dx * 0.08 * streak, p[1] - dy * 0.08 * streak); c.stroke(); } else { c.beginPath(); c.arc(p[0], p[1], r, 0, 6.3); c.fill(); } }
    if (th !== this.fxTh) { this.fxTh = th; this.fx = []; }
    const fx = this.fx, rnd = Math.random, mob = w < 700;
    if (th === "neon") { c.strokeStyle = "rgba(255,43,214,.16)"; c.lineWidth = 1; const off = (tt * 0.6) % 1; for (let i = -9; i <= 9; i++) { const a = pr(i, -2.2, -9), b = pr(i, -2.2, 9); if (a && b) { c.beginPath(); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); c.stroke(); } } for (let j = -9; j <= 9; j++) { const z = j + off, a = pr(-9, -2.2, z), b = pr(9, -2.2, z); if (a && b) { c.beginPath(); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); c.stroke(); } } }
    else if (th === "matrix") { if (!fx.length) for (let i = 0; i < (mob ? 14 : 30); i++) fx.push({ x: rnd() * w, y: rnd() * h, v: 30 + rnd() * 70, n: 6 + Math.floor(rnd() * 10) }); c.font = "12px Consolas,monospace"; c.textAlign = "center"; for (const d of fx) { d.y += d.v * dt; if (d.y - d.n * 14 > h) { d.y = -10; d.x = rnd() * w; } for (let i = 0; i < d.n; i++) { c.fillStyle = `rgba(34,255,102,${(i ? 0.22 : 0.6) * (1 - i / d.n)})`; c.fillText(String.fromCharCode(0x30a0 + ((i * 7 + Math.floor(tt * 8 + d.x)) % 90)), d.x, d.y - i * 14); } } }
    else if (th === "ocean") { if (!fx.length) for (let i = 0; i < (mob ? 16 : 34); i++) fx.push({ x: rnd() * w, y: rnd() * h, r: 1.5 + rnd() * 5, v: 12 + rnd() * 30, ph: rnd() * 6 }); for (const b of fx) { b.y -= b.v * dt; if (b.y < -10) { b.y = h + 10; b.x = rnd() * w; } const x = b.x + Math.sin(tt * 1.2 + b.ph) * 6; c.strokeStyle = "rgba(125,220,255,.28)"; c.lineWidth = 1; c.beginPath(); c.arc(x, b.y, b.r, 0, 6.3); c.stroke(); c.fillStyle = "rgba(255,255,255,.35)"; c.beginPath(); c.arc(x - b.r * 0.35, b.y - b.r * 0.35, b.r * 0.22, 0, 6.3); c.fill(); } }
    else if (th === "forest") { if (!fx.length) for (let i = 0; i < (mob ? 14 : 28); i++) fx.push({ x: rnd() * w, y: rnd() * h, a: rnd() * 6, ph: rnd() * 6 }); for (const b of fx) { b.a += (rnd() - 0.5) * dt * 2; b.x += Math.cos(b.a) * 14 * dt; b.y += Math.sin(b.a) * 10 * dt; if (b.x < 0 || b.x > w || b.y < 0 || b.y > h) { b.x = rnd() * w; b.y = rnd() * h; } const bl = Math.max(0, Math.sin(tt * 1.6 + b.ph)), g = c.createRadialGradient(b.x, b.y, 0, b.x, b.y, 9); g.addColorStop(0, `rgba(220,255,140,${0.8 * bl})`); g.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = g; c.fillRect(b.x - 9, b.y - 9, 18, 18); } }
    else if (th === "sunset") { const g = c.createLinearGradient(0, h * 0.55, 0, h); g.addColorStop(0, "rgba(0,0,0,0)"); g.addColorStop(1, "rgba(255,110,70,.12)"); c.fillStyle = g; c.fillRect(0, h * 0.55, w, h * 0.45); if (!fx.length) for (let i = 0; i < (mob ? 16 : 32); i++) fx.push({ x: rnd() * w, y: rnd() * h, v: 8 + rnd() * 22, ph: rnd() * 6 }); for (const b of fx) { b.y -= b.v * dt; b.x += Math.sin(tt + b.ph) * 8 * dt; if (b.y < -5) { b.y = h + 5; b.x = rnd() * w; } c.fillStyle = `rgba(255,${150 + Math.round(60 * Math.sin(tt * 3 + b.ph))},90,${0.35 + 0.3 * Math.sin(tt * 2 + b.ph)})`; c.beginPath(); c.arc(b.x, b.y, 1.4, 0, 6.3); c.fill(); } }
    else { if (th === "halloween") { const mx = w * 0.88, my = h * 0.16, mr = Math.min(w, h) * 0.06, g = c.createRadialGradient(mx, my, mr * 0.5, mx, my, mr * 3); g.addColorStop(0, "rgba(255,170,60,.22)"); g.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = g; c.fillRect(mx - mr * 3, my - mr * 3, mr * 6, mr * 6); c.fillStyle = "rgba(255,196,110,.55)"; c.beginPath(); c.arc(mx, my, mr, 0, 6.3); c.fill(); c.fillStyle = "rgba(19,10,26,.95)"; c.beginPath(); c.arc(mx + mr * 0.42, my - mr * 0.18, mr * 0.9, 0, 6.3); c.fill(); }
      if (rnd() < dt * 0.35 && fx.length < 3) fx.push({ x: rnd() * w, y: rnd() * h * 0.4, vx: 260 + rnd() * 260, vy: 90 + rnd() * 120, l: 0 });
      for (let i = fx.length - 1; i >= 0; i--) { const s = fx[i]; s.l += dt; s.x += s.vx * dt; s.y += s.vy * dt; if (s.l > 1.4) { fx.splice(i, 1); continue; } const a = Math.sin((s.l / 1.4) * Math.PI), col = th === "halloween" ? "255,150,60" : th === "light" ? "120,140,220" : "200,220,255"; const g = c.createLinearGradient(s.x, s.y, s.x - s.vx * 0.18, s.y - s.vy * 0.18); g.addColorStop(0, `rgba(${col},${0.8 * a})`); g.addColorStop(1, "rgba(0,0,0,0)"); c.strokeStyle = g; c.lineWidth = 1.6; c.beginPath(); c.moveTo(s.x, s.y); c.lineTo(s.x - s.vx * 0.18, s.y - s.vy * 0.18); c.stroke(); } }
  },
};

/* küre örnekleri */
const BRAIN = { big: null, mini: null };
function initOrbs() {
  LM.init(); LM.efeeds = [];   // ekran kenarından gelen uzun bağlar kaldırıldı; yalnız kart→küre ve küre→çıktı bağları kalır
  const bc = document.getElementById("orb-big"), mc = document.getElementById("orb-mini");
  if (bc) { const orb = new Orb(bc, { n: MOB ? 420 : 780, k: 3, big: true, spin: 0.06 }); LM.bigBox = { cv: bc, orb, cx: 0, cy: 0, R: 0 }; BRAIN.big = orb; orb.onbeat = () => Sound.beat();
    Cosmos.init(bc, orb);
    TICKS.push((dt, t) => { if (!vis(bc)) return; const p = bc.parentElement, w = p.clientWidth, h = p.clientHeight; if (window.Splash && Splash.active) { if (Splash.st === "tween") Cosmos.frame(dt, t, w, h, true); else Cosmos.layout(w, h); return; } if (window.NERA_3D) return; orb.step(dt); Cosmos.frame(dt, t, w, h); }); }
  if (mc) { const orb = new Orb(mc, { n: MOB ? 90 : 130, k: 3, spin: 0.3 }); LM.miniBox = { cv: mc, orb, cx: 22, cy: 22, R: 19 }; BRAIN.mini = orb; let skip = 0;
    TICKS.push((dt) => { skip += dt; if (skip < 0.033 || !vis(mc)) return; orb.step(skip); skip = 0; orb.draw(44, 44, 17, 22, 22); }); }
}

/* ---------------------------------------------------------------- panel içi nöron grafiği */
const GRAPHS = [];
class NeuroGraph {
  constructor(cv, nodes, edges, o = {}) { GRAPHS.push(this); this.cv = cv; this.N = nodes.map((n) => Object.assign({ e: 0, col: CA }, n)); this.E = edges; this.pu = []; this.o = o; this.idle = 0; this.byId = Object.fromEntries(this.N.map((n) => [n.id, n])); this.adj = {}; edges.forEach(([a, b]) => { (this.adj[a] = this.adj[a] || []).push(b); (this.adj[b] = this.adj[b] || []).push(a); });
    TICKS.push((dt, t) => this.frame(dt, t)); }
  setData(nodes, edges) { this.N = nodes.map((n) => Object.assign({ e: 0, col: CA }, n)); this.E = edges; this.pu = []; this.byId = Object.fromEntries(this.N.map((n) => [n.id, n])); this.adj = {}; edges.forEach(([a, b]) => { (this.adj[a] = this.adj[a] || []).push(b); (this.adj[b] = this.adj[b] || []).push(a); }); }
  fire(id, col, p = 1, hops = 1, dirOnly) {
    const n = this.byId[id]; if (!n) return; n.e = Math.min(1.4, n.e + p); n.col = col || n.col; if (!vis(this.cv) || this.pu.length > 80) return;
    for (const b of (dirOnly ? [dirOnly] : this.adj[id] || [])) this.pu.push({ a: id, b, t: 0, col: col || n.col, p, hops });
  }
  frame(dt, t) {
    const cv = this.cv; if (!vis(cv)) return; if (this.o.pre) this.o.pre(this); const w = cv.parentElement.clientWidth, h = this.o.h || cv.parentElement.clientHeight; if (w < 10 || h < 10) return; const c = fitCanvas(cv, w, h); c.clearRect(0, 0, w, h);
    this.idle -= dt; if (this.idle <= 0 && this.o.idle !== false) { this.idle = 0.5 + Math.random() * 0.9; const n = this.N[Math.floor(Math.random() * this.N.length)]; this.fire(n.id, n.col, 0.35, 0); }
    const X = (n) => n.px != null ? n.px : 20 + n.x * (w - 40), Y = (n) => n.py != null ? n.py : 16 + n.y * (h - 32); this.pos = (n) => ({ x: X(n), y: Y(n) });
    for (const [a, b] of this.E) { const A = this.byId[a], B = this.byId[b]; if (!A || !B) continue; const mx = (X(A) + X(B)) / 2, my = (Y(A) + Y(B)) / 2 + (this.o.curve || 0) * ((X(B) - X(A)) > 0 ? -1 : 1); c.strokeStyle = rgba("#7a8cff", 0.12 + 0.22 * Math.max(A.e, B.e)); c.lineWidth = 1; c.beginPath(); c.moveTo(X(A), Y(A)); c.quadraticCurveTo(mx, my, X(B), Y(B)); c.stroke(); }
    for (let k = this.pu.length - 1; k >= 0; k--) { const P = this.pu[k]; P.t += dt / (this.o.dur || 0.55); const A = this.byId[P.a], B = this.byId[P.b]; if (!A || !B) { this.pu.splice(k, 1); continue; }
      if (P.t >= 1) { this.pu.splice(k, 1); B.e = Math.min(1.3, B.e + 0.55 * P.p); if (P.hops > 0) for (const nb of this.adj[P.b] || []) if (nb !== P.a && Math.random() < 0.6) this.pu.push({ a: P.b, b: nb, t: 0, col: P.col, p: P.p * 0.6, hops: P.hops - 1 }); continue; }
      const mx = (X(A) + X(B)) / 2, my = (Y(A) + Y(B)) / 2 + (this.o.curve || 0) * ((X(B) - X(A)) > 0 ? -1 : 1), u = P.t, m = 1 - u, x = m * m * X(A) + 2 * m * u * mx + u * u * X(B), y = m * m * Y(A) + 2 * m * u * my + u * u * Y(B);
      const g = c.createRadialGradient(x, y, 0, x, y, 9); g.addColorStop(0, rgba("#ffffff", 0.9 * P.p)); g.addColorStop(0.4, rgba(P.col, 0.5 * P.p)); g.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = g; c.fillRect(x - 9, y - 9, 18, 18); }
    for (const n of this.N) { n.e *= Math.pow(0.12, dt); const x = X(n), y = Y(n), r = ((n.r || 5) + n.e * 4) * (1 + 0.06 * Math.sin(t * 1.7 + (n.x || 0) * 9)); const g = c.createRadialGradient(x, y, 0, x, y, r * 3.2); g.addColorStop(0, rgba(n.col, 0.18 + n.e * 0.6)); g.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = g; c.fillRect(x - r * 3.2, y - r * 3.2, r * 6.4, r * 6.4);
      c.fillStyle = n.e > 0.2 ? "#ffffff" : rgba(n.col, 0.9); c.beginPath(); c.arc(x, y, r * 0.55 + n.e * 1.5, 0, 6.3); c.fill(); c.lineWidth = 1.2; c.strokeStyle = rgba(n.col, 0.4 + n.e * 0.5); c.beginPath(); c.arc(x, y, r, 0, 6.3); c.stroke();
      if (n.label && this.o.labels !== false) { c.fillStyle = rgba("#aab3c9", 0.85); c.font = '600 10px "Segoe UI",sans-serif'; c.textAlign = "center"; c.fillText(n.label, x, y + r + 12); } }
  }
}
const Splash = window.Splash = {
  active: true, st: "run", want: false, t0: 0, tw0: 0, feeds: null,
  init() { this.el = document.getElementById("splash"); this.cv = document.getElementById("splash-cv"); if (!this.el || !this.cv) { this.active = false; return; } this.t0 = performance.now(); setTimeout(() => Sound.intro(), 250); TICKS.push(() => this.frame()); },
  finish() { this.want = true; setTimeout(() => { if (this.active) { this.active = false; if (this.el) this.el.remove(); DT.emit("splash-done"); } }, 12000); },      // çizim döngüsü takılırsa açılış perdesi yine de kalkar
  mk(W, H) {                                                    // yazılar kürenin (halka dahil) hemen altından başlar
                                                    // kenarlardan küreye, küreden kenarlara dolu bir bağ ağı
    const E = []; const ys = MOB ? [0.16, 0.34, 0.52, 0.7, 0.86] : [0.12, 0.24, 0.36, 0.48, 0.6, 0.72, 0.84, 0.94], xs = MOB ? [0.25, 0.75] : [0.14, 0.3, 0.46, 0.62, 0.78, 0.9];
    ys.forEach((y, k) => { E.push([0, y, k % 2 ? 1 : -1], [1, y, k % 2 ? -1 : 1]); }); xs.forEach((x, k) => { E.push([x, 0, k % 2 ? -1 : 1], [x, 1, k % 2 ? 1 : -1]); });
    this.feeds = E.map(([fx, fy, s], i) => ({ x: fx * W, y: fy * H, side: s, vert: fy === 0 || fy === 1, delay: 0.25 + i * 0.07, ph: (i * 0.37) % 1, ci: i }));
  },
  text(t, k) {                                                  // yazılar: girişte süzülerek belirir, bekleyince nefes alır/parlar, çıkarken küreye doğru yükselip dağılır
    const el = this.el, ww = el.querySelector(".sp-word"), ss = el.querySelector(".sp-sub"), bb = el.querySelector(".sp-bar"), nn = el.querySelector(".note"); if (!ww) return;
    const cl = (x) => Math.min(1, Math.max(0, x)), eo = (x) => 1 - Math.pow(1 - cl(x), 3), ei = (x) => cl(x) * cl(x), glow = rgba(CA, 0.3 + 0.18 * Math.sin(t * 2.2));
    const inW = eo((t - 0.5) / 2.4), inS = eo((t - 1.9) / 1.3), inB = eo((t - 2.3) / 1.0), inN = eo((t - 2.6) / 1.0);
    const xw = ei(k / 0.55), xs = ei((k - 0.04) / 0.5), xb = ei((k - 0.1) / 0.45), xn = ei((k - 0.14) / 0.4);       // çıkış aşamaları (kademeli)
    const bob = (ph, a) => Math.sin(t * 1.3 + ph) * a;
    ww.style.opacity = inW * (1 - xw); ww.style.letterSpacing = (1.2 - 0.65 * inW + 0.5 * xw) + "em";
    ww.style.transform = `translateY(${((1 - inW) * 28 + bob(0, 3.2) * inW - xw * 46).toFixed(1)}px) scale(${(0.94 + 0.06 * inW + 0.08 * xw).toFixed(3)})`;
    ww.style.filter = `blur(${(12 * (1 - inW) + 10 * xw).toFixed(1)}px) drop-shadow(0 0 ${(20 * inW).toFixed(0)}px ${glow})`; ww.style.backgroundPosition = (50 + 50 * Math.sin(t * 0.9)) + "% 0";
    if (ss) { ss.style.opacity = inS * (1 - xs); ss.style.letterSpacing = (0.55 - 0.25 * inS + 0.35 * xs) + "em"; ss.style.transform = `translateY(${((1 - inS) * 16 + bob(1.7, 2) * inS - xs * 34).toFixed(1)}px)`; ss.style.filter = `blur(${(6 * (1 - inS) + 6 * xs).toFixed(1)}px)`; }
    if (bb) { bb.style.opacity = inB * (1 - xb); bb.style.transform = `translateY(${((1 - inB) * 12 - xb * 26).toFixed(1)}px) scaleX(${(0.5 + 0.5 * inB + 0.3 * xb).toFixed(3)})`; }
    if (nn) { nn.style.opacity = inN * (1 - xn) * (0.75 + 0.25 * Math.sin(t * 3)); nn.style.transform = `translateY(${((1 - inN) * 10 + bob(2.6, 1.4) * inN - xn * 22).toFixed(1)}px)`; }
  },
  frame() {
    if (!this.active) return; const now = performance.now(), t = (now - this.t0) / 1000, W = innerWidth, H = innerHeight, c = fitCanvas(this.cv, W, H, 1), orb = BRAIN.big; c.clearRect(0, 0, W, H); if (!orb) return; if (!this.feeds || this.fw !== W || this.fh !== H) { this.fw = W; this.fh = H; this.mk(W, H); }
    if (this.want && this.st === "run" && t >= 4.4) { this.st = "tween"; this.tw0 = now; this.el.classList.add("out"); Sound.land(); if (window.Cosmos) Cosmos.startIntro(3400); }
    // küre baştan beyindeki yıldızın yerinde ve boyutunda: açılış bittiğinde yer/boyut değişmez, yalnız perde kalkar ve gezegenler yörüngelerine süzülür
    // büyük küre ekranın ortasında doğar; perde kalkarken beyindeki yıldızın yerine ve boyutuna süzülür.
    // Hedef her karede Kozmos'un o anki yıldız izdüşümünden okunur (LM.bigBox): iniş noktası ve boyut kusursuz eşleşir, sonra aynı küreyi Kozmos çizer.
    const S0 = Math.min(W, H) * (MOB ? 0.34 : 0.3), sx = W / 2, sy = H * 0.37, z = Math.min(1, t / 2.6), ez = 1 - Math.pow(1 - z, 3), sR = S0 * (0.5 + 0.5 * ez);
    { const sb = Math.round(sy + S0 * 1.22 + 20); if (sb !== this._sb) { this._sb = sb; this.el.style.setProperty("--sb", sb + "px"); } }
    let cx = sx, cy = sy, R = sR, k = 0;
    if (this.st === "tween") {
      k = Math.min(1, (now - this.tw0) / 3400); const e = k < 0.5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2, b = LM.bigBox, rc = b && b.cv ? b.cv.getBoundingClientRect() : null, ok = rc && rc.width > 120 && b.R > 8;
      const tx = ok ? rc.left + b.cx : sx, ty = ok ? rc.top + b.cy : sy, tR = ok ? b.R : sR, arc = Math.sin(e * Math.PI) * Math.min(W, H) * 0.05;
      cx = sx + (tx - sx) * e; cy = sy + (ty - sy) * e - arc; R = sR + (tR - sR) * e; this.el.style.setProperty("--bgA", String(Math.max(0, 1 - e * 1.1)));
    }    orb.step(Math.min(0.05, (now - (this._l || now)) / 1000 || 0.016)); this._l = now; if (orb.waves.length < 2 && this.st === "run" && Math.random() < 0.05) orb.spawnWave(Math.floor(Math.random() * orb.n), 1.1);
    orb.render(c, W, H, R, cx, cy);
    this.text(t, k);
    c.save(); c.lineCap = "round"; const fa = 1 - k;
    for (const f of this.feeds) {
      const g0 = Math.min(1, Math.max(0, (t - f.delay) / 1.5)), g = 1 - Math.pow(1 - g0, 3); if (g <= 0.001) continue; const a = orb.attach(f.x - cx, f.y - cy), p0 = { x: f.x, y: f.y }, p1 = { x: a.x, y: a.y }, dx = p1.x - p0.x, dy = p1.y - p0.y, col = [CA, CB, CC][f.ci % 3];
      const c1 = f.vert ? { x: p0.x, y: p0.y + dy * 0.5 } : { x: p0.x + dx * 0.5, y: p0.y }, c2 = f.vert ? { x: p1.x, y: p1.y - dy * 0.2 } : { x: p1.x - dx * 0.2, y: p1.y };
      const B = (u) => { const m = 1 - u; return { x: m * m * m * p0.x + 3 * m * m * u * c1.x + 3 * m * u * u * c2.x + u * u * u * p1.x, y: m * m * m * p0.y + 3 * m * m * u * c1.y + 3 * m * u * u * c2.y + u * u * u * p1.y }; };
      c.globalAlpha = fa; c.strokeStyle = rgba(col, 0.2 + 0.2 * g); c.lineWidth = 1.1; c.beginPath(); const N = 36, end = Math.max(2, Math.round(N * g)); for (let i = 0; i <= end; i++) { const q = B(Math.min(1, i / N)); i ? c.lineTo(q.x, q.y) : c.moveTo(q.x, q.y); } c.stroke();
      const gg = c.createRadialGradient(p0.x, p0.y, 0, p0.x, p0.y, 10); gg.addColorStop(0, rgba(col, 0.7 * g)); gg.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = gg; c.fillRect(p0.x - 10, p0.y - 10, 20, 20);
      if (g >= 0.98) for (let d = 0; d < 4; d++) { let u = (t * 0.16 + f.ph + d / 4) % 1; if (f.side > 0) u = 1 - u; const q = B(u), fl = Math.sin(u * Math.PI); c.fillStyle = rgba(col, 0.3 + 0.55 * fl); c.beginPath(); c.arc(q.x, q.y, 1.3 + fl * 1.4, 0, 6.3); c.fill(); }
    }
    c.restore(); c.globalAlpha = 1;
    const pr = parseFloat(this.el.style.getPropertyValue("--p")) || 0.05; c.save(); c.globalAlpha = 1 - k; c.lineWidth = 2; c.strokeStyle = "rgba(120,140,200,.2)"; c.beginPath(); c.arc(cx, cy, R * 1.22, 0, 6.3); c.stroke(); c.strokeStyle = CA; c.beginPath(); c.arc(cx, cy, R * 1.22, -Math.PI / 2, -Math.PI / 2 + pr * 6.2832); c.stroke(); c.restore();
    if (k >= 1) { this.active = false; this.el.remove(); DT.emit("splash-done"); }
  },
};
window.addEventListener("DOMContentLoaded", () => { initOrbs(); Splash.init(); drawFav(); });

/* pencere / sekme simgesi: temanın renkleriyle çizilen Nera logosu (masaüstünde uygulama penceresinin ve görev çubuğunun simgesi olur) */
function drawFav() {
  try {
    const S = 64, cv = document.createElement("canvas"); cv.width = cv.height = S; const c = cv.getContext("2d"), bg = getComputedStyle(document.body).getPropertyValue("--deep").trim() || "#0b0f1a";
    c.fillStyle = bg; c.beginPath(); if (c.roundRect) c.roundRect(0, 0, S, S, 14); else c.rect(0, 0, S, S); c.fill();
    const g = c.createRadialGradient(S * 0.4, S * 0.38, 2, S / 2, S / 2, S * 0.3); g.addColorStop(0, CA); g.addColorStop(1, CB); c.fillStyle = g; c.beginPath(); c.arc(S / 2, S / 2, S * 0.27, 0, 6.3); c.fill();
    c.strokeStyle = "rgba(255,255,255,.45)"; c.lineWidth = 1; [-0.5, 0, 0.5].forEach((k) => { c.beginPath(); c.ellipse(S / 2, S / 2 + k * S * 0.27, S * 0.27 * Math.sqrt(1 - k * k), S * 0.055, 0, 0, 6.3); c.stroke(); });
    c.save(); c.translate(S / 2, S / 2); c.rotate(-0.38); const rg = c.createLinearGradient(-S * 0.45, 0, S * 0.45, 0); rg.addColorStop(0, CB); rg.addColorStop(1, CC); c.strokeStyle = rg; c.lineWidth = 3.4; c.beginPath(); c.ellipse(0, 0, S * 0.46, S * 0.13, 0, 0, 6.3); c.stroke();
    c.fillStyle = CC; c.beginPath(); c.arc(S * 0.36, -S * 0.08, 3.6, 0, 6.3); c.fill(); c.restore();
    const l = document.getElementById("nfav"); if (l) l.href = cv.toDataURL("image/png");
  } catch (e) { /* tuval yok */ }
}
DT.on("palette", drawFav); DT.on("theme", () => setTimeout(drawFav, 60));

document.addEventListener("visibilitychange", () => { if (!document.hidden) { GRAPHS.forEach((g) => (g.pu.length = 0)); LM.bursts.length = 0; _last = performance.now(); DT.emit("wake"); } });

DT.on("signal", (e) => { if (!e || !e.side || localStorage.getItem("nera_tint") === "0") return; const rgb = hex2(e.side > 0 ? CUP : CDN), until = performance.now() + 15000; ORBS.forEach((o) => (o.tint = { rgb, until })); });
