"use strict";
/* NERA 3 · açılış: ayrı perde yok, TEK sahne. Dağınık parçacıklar (Drift) derinlik haritasına göre "Nera" yazısına toplanır (Gather), bir ışık çizgisi geçer (Scan),
   yazı küreye dönüşür (Melt/Morph), kamera geri çekilir ve aynı sahne Beyin ekranının çekirdeği olarak kalır.
   Sözleşme eski Splash ile aynı: window.Splash.finish() (veri hazır), DT "splash-done". Veri yükleme paralel sürer, sahne veri beklemez (en geç 3,4 sn + veri). Atlama yok: her açılışta tam oynar. */
(function () {
const U = window.NeraUI, S = window.NeraSwarm; if (!U || !S || !document.body.classList.contains("u3")) return;
const el = document.getElementById("splash"), gs = window.gsap, shell = document.getElementById("shell");
/* brain.js eski Splash'i "const Splash" ile tanımlar; çıplak "Splash" (app.js) o nesneye bakar. Bu yüzden nesneyi DEĞİŞTİRMEK yerine yerinde yeniden tanımlarım. */
const Sp = (window.Splash = window.Splash || {});
Object.assign(Sp, { active: true, st: "run", want: false, init() {}, frame() {}, finish() { Sp.want = true; if (Sp.tl && Sp.tl.progress() >= 1) Sp.end(); } });
let ended = false;
const done = () => { if (ended) return; ended = true; Sp.active = false; if (el) el.remove(); if (shell) { shell.style.opacity = ""; shell.style.visibility = ""; } try { DT.emit("splash-done"); } catch (e) { /* */ } };
if (!el || !gs || U.reduced()) { done(); return; }
/* telefon: hafif sürüm, WebGL yok; "Nera" yazısı süzülerek açılır, çizgi çizilir, sonra perde kalkar */
if (U.mobile() || !S.available) {
  const w = document.createElement("div"); w.className = "sp-m"; w.innerHTML = '<span>Nera</span><i></i>'; el.prepend(w);
  const sp = w.firstChild, ln = w.lastChild, rest = [el.querySelector(".sp-sub"), el.querySelector(".note")].filter(Boolean);
  gs.set(el, { background: "#050505" }); gs.set(rest, { opacity: 0 });
  gs.timeline({ onComplete: () => { gs.to(el, { opacity: 0, duration: 0.5, onComplete: done }); } })
    .fromTo(sp, { opacity: 0, y: 24, filter: "blur(10px)" }, { opacity: 1, y: 0, filter: "blur(0px)", duration: 1.1, ease: "nera.out" })
    .fromTo(ln, { scaleX: 0 }, { scaleX: 1, duration: 0.9, ease: "nera.inOut" }, 0.5)
    .to(rest, { opacity: 1, duration: 0.5, stagger: 0.1 }, 0.9).to({}, { duration: 0.5 });
  Object.assign(Sp, { finish() {} });
  return;
}

if (shell) shell.style.opacity = "0";
S.setLayer("splash");
Sp.end = () => {
  if (ended) return; Sp.st = "tween";
  /* devir: tuval sayfanın arkasına iner, küre Beyin çekirdeğinin ortasına süzülür, kabuk görünür olur */
  S.setLayer("page");
  const core = document.getElementById("bv-core"), p = { dx: S.dx, dy: S.dy }, view = document.body.dataset.view;
  if (view === "brain" && core) { const r = core.getBoundingClientRect(); S.tweening = true; gs.to(p, { dx: r.left + r.width / 2 - S.w / 2, dy: r.top + r.height / 2 - S.h / 2, duration: 1.3, ease: "nera.inOut", onUpdate: () => S.shift(p.dx, p.dy), onComplete: () => { S.tweening = false; } }); }
  if (shell) gs.fromTo(shell, { opacity: 0 }, { opacity: 1, duration: 0.9, delay: 0.15, ease: "nera.out", onComplete: () => { shell.style.opacity = ""; } });
  gs.to(el, { opacity: 0, duration: 0.5, ease: "nera.out", onComplete: () => { done(); } });
  setTimeout(() => { U.enter(view || "brain"); if (window.NeraBrain3) NeraBrain3.enter(); }, 250);
};
S.buildSwarm().then((sw) => {
  if (!sw) { done(); return; }
  const u = sw.u, cam = sw.cam;
  S.setMode("swarm"); u.uGather.value = 0; u.uMix.value = 0; u.uTint.value = 0.15; u.uScan.value = -5; cam.position.set(0, 0.1, 9.8); cam.lookAt(0, 0, 0); S.shift(0, 0);
  sw.pts.rotation.set(0, 0, 0);
  const sub = el.querySelector(".sp-sub"), note = el.querySelector(".note"), bar = el.querySelector(".sp-bar");
  [sub, note, bar].forEach((e) => e && gs.set(e, { opacity: 0, y: 10 }));
  const tl = (Sp.tl = gs.timeline({ onComplete: () => { if (Sp.want) Sp.end(); } }));
  tl.to(u.uGather, { value: 1, duration: 1.9, ease: "nera.out" }, 0.1)
    .to(cam.position, { z: 8.7, duration: 3.2, ease: "nera.inOut" }, 0)
    .to(u.uTint, { value: 0.5, duration: 1.2, ease: "nera.out" }, 1.1)
    .fromTo(u.uScan, { value: -4.6 }, { value: 4.6, duration: 1.2, ease: "nera.inOut" }, 1.3)
    .to([sub, bar, note].filter(Boolean), { opacity: 1, y: 0, duration: 0.8, stagger: 0.12, ease: "nera.out" }, 1.1)
    .addLabel("morph", 2.15)
    .to(u.uMix, { value: 1, duration: 1.25, ease: "nera.inOut" }, "morph")
    .to(u.uTint, { value: 1, duration: 1.1, ease: "nera.out" }, "morph")
    .to(cam.position, { z: 10.6, duration: 1.3, ease: "nera.inOut" }, "morph")
    .to([sub, bar, note].filter(Boolean), { opacity: 0, y: -8, duration: 0.5, stagger: 0.05 }, "morph");
  setTimeout(() => { if (!ended) { Sp.want = true; if (tl.progress() >= 1) Sp.end(); } }, 12000);
}).catch((e) => { console.error("splash", e); done(); });
/* sahne hiç açılamazsa perde yine de kalkar */
setTimeout(() => { if (!S.ready && !S.swarm) done(); }, 8000);
})();
