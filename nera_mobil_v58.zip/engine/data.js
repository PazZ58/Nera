/* DayTrader Pro (mobil) · veri katmanı (tarayıcı/telefon içinde): Binance Futures REST + WebSocket (gerçek taker akışı), EUR/USD Yahoo (yalnız CORS'suz ortamda: APK).
   Sadece okur. Emir yok. API anahtarı yok. pro/pro_data.py'nin karşılığı. */
export const BF = "https://fapi.binance.com";
export const SYMS = ["BTCUSDT", "ETHUSDT", "XAUUSDT", "XAGUSDT", "EURUSD"];
export const NAMES = { BTCUSDT: "BTC/USDT", ETHUSDT: "ETH/USDT", XAUUSDT: "Altın XAU", XAGUSDT: "Gümüş XAG", EURUSD: "EUR/USD" };
export const BF_SYMS = SYMS.filter((s) => s !== "EURUSD");
export const TFS = ["1m", "5m", "15m", "30m", "1h", "4h", "1d"];
export const TF_SEC = { "1m": 60, "5m": 300, "15m": 900, "30m": 1800, "1h": 3600, "4h": 14400, "1d": 86400 };
const YH = { "1m": ["1m", "5d"], "5m": ["5m", "30d"], "15m": ["15m", "30d"], "30m": ["30m", "30d"], "1h": ["1h", "180d"], "1d": ["1d", "3y"] };
export const REFRESH = { "1m": 3, "5m": 6, "15m": 12, "30m": 20, "1h": 25, "4h": 40, "1d": 90 };
export const hasFlow = (sym) => sym !== "EURUSD";
export const MAXBARS = 1500;

export function niceStep(x) {
  if (!(x > 0)) return 1.0;
  const e = 10 ** Math.floor(Math.log10(x));
  for (const m of [1, 2, 5, 10]) if (x <= m * e) return m * e;
  return 10 * e;
}

export class Flow {
  constructor() { this.price = this.bid = this.ask = this.bidq = this.askq = null; this.t = 0; this.step = null; this.minutes = new Map(); this.cvd = 0; this.cvd_hist = []; this.big = []; this.liq = []; this.notional = []; this.big_thr = null; this.ntr = 0; }
  onTrade(p, q, sell, tMs) {
    this.price = p; this.t = tMs / 1000; this.ntr++;
    if (this.step === null) this.step = niceStep(p * 0.0002);
    const m = Math.floor(tMs / 60000) * 60;
    let b = this.minutes.get(m);
    if (!b) {
      b = { buy: 0, sell: 0, bins: new Map(), n: 0 }; this.minutes.set(m, b);
      while (this.minutes.size > 400) this.minutes.delete(this.minutes.keys().next().value);
      this.cvd_hist.push([m, this.cvd]); if (this.cvd_hist.length > 720) this.cvd_hist.shift();
    }
    const k = Number((Math.round(p / this.step) * this.step).toFixed(8));
    let cell = b.bins.get(k); if (!cell) { cell = [0, 0]; b.bins.set(k, cell); }
    if (sell) { b.sell += q; cell[1] += q; this.cvd -= q; } else { b.buy += q; cell[0] += q; this.cvd += q; }
    b.n++;
    const nt = p * q; this.notional.push(nt); if (this.notional.length > 3000) this.notional.shift();
    if (this.ntr % 250 === 0 && this.notional.length > 500) { const s = [...this.notional].sort((a, c) => a - c); this.big_thr = s[Math.floor(0.997 * (s.length - 1))]; }
    if (this.big_thr && nt >= this.big_thr) { this.big.push({ t: tMs / 1000, side: sell ? -1 : 1, q, p, usd: nt }); if (this.big.length > 120) this.big.shift(); }
  }
}

/* spot altın/gümüş/avro hafta sonu kapalı: Cuma 21:00 → Pazar 22:00 UTC */
export const SPOT_CLOSED = ["XAUUSDT", "XAGUSDT", "EURUSD"];
const nthSun = (y, m, n) => { const f = new Date(Date.UTC(y, m - 1, 1)).getUTCDay(); return Date.UTC(y, m - 1, 1 + (7 - f) % 7 + 7 * (n - 1)); };
const nyOff = (ms) => { const y = new Date(ms).getUTCFullYear(); return ms >= nthSun(y, 3, 2) + 7 * 3600e3 && ms < nthSun(y, 11, 1) + 6 * 3600e3 ? -4 : -5; };
// spot altın/gümüş/avro kapalı mı (New York saatiyle): hafta sonu Cuma 17:00 → Pazar 18:00 + her gün 17:00–18:00 arası
export function weekendTs(ts) { const ms = ts * 1000, g = new Date(ms + nyOff(ms) * 3600e3), wd = g.getUTCDay(), h = g.getUTCHours(); return wd === 6 || (wd === 5 && h >= 17) || (wd === 0 && h < 18) || (wd >= 1 && wd <= 4 && h === 17); }
function dropWeekend(d) { const keep = d.ts.map((t) => !weekendTs(t)); const f = (a) => a.filter((_, i) => keep[i]); return { ts: f(d.ts), open: f(d.open), high: f(d.high), low: f(d.low), close: f(d.close), volume: f(d.volume), tbv: f(d.tbv) }; }

async function getJson(url, timeoutMs = 15000) {
  const ac = typeof AbortController !== "undefined" ? new AbortController() : null, tm = ac ? setTimeout(() => ac.abort(), timeoutMs) : null;      // takılan istek zinciri durdurmasın
  try {
    const r = await fetch(url, { headers: { Accept: "application/json" }, signal: ac ? ac.signal : undefined });
    if (!r.ok) throw new Error("HTTP " + r.status);
    return await r.json();
  } finally { if (tm) clearTimeout(tm); }
}

export async function fetchBf(sym, tf, limit) {
  const a = await getJson(`${BF}/fapi/v1/klines?symbol=${sym}&interval=${tf}&limit=${limit}`);
  return { ts: a.map((x) => Math.floor(x[0] / 1000)), open: a.map((x) => +x[1]), high: a.map((x) => +x[2]), low: a.map((x) => +x[3]), close: a.map((x) => +x[4]), volume: a.map((x) => +x[5]), tbv: a.map((x) => +x[9]) };
}

/* Forex Factory haftalık takvimi; APK'da CORS'suz yerel HTTP */
export async function fetchFF() {
  const url = "https://nfs.faireconomy.media/ff_calendar_thisweek.json", NATIVE = globalThis.Capacitor && globalThis.Capacitor.Plugins && globalThis.Capacitor.Plugins.CapacitorHttp;
  if (!NATIVE) return getJson(url);
  const r = await NATIVE.get({ url, readTimeout: 15000, connectTimeout: 10000 }); if (r.status >= 400) throw new Error("HTTP " + r.status);
  return typeof r.data === "string" ? JSON.parse(r.data) : r.data;
}

export async function fetchYh(tf) {
  const [iv, rng] = YH[tf], url = `https://query1.finance.yahoo.com/v8/finance/chart/EURUSD=X?interval=${iv}&range=${rng}`;
  const NATIVE = globalThis.Capacitor && globalThis.Capacitor.Plugins && globalThis.Capacitor.Plugins.CapacitorHttp;      // APK: CORS'suz yerel HTTP (Yahoo CORS vermez)
  let body;
  if (NATIVE) { const r = await NATIVE.get({ url, headers: { "User-Agent": "Mozilla/5.0" }, readTimeout: 15000, connectTimeout: 10000 }); if (r.status >= 400) throw new Error("HTTP " + r.status); body = typeof r.data === "string" ? JSON.parse(r.data) : r.data; }
  else body = await getJson(url);
  const j = body.chart.result[0], q = j.indicators.quote[0], sec = TF_SEC[tf] || 60;
  // Yahoo oluşan son mumu son TİK zamanıyla damgalar (ör. 08:32:25): çubuk başına hizala ve aynı çubukta birleştir (çakışan sahte mum olmasın)
  const out = { ts: [], open: [], high: [], low: [], close: [], volume: [], tbv: [] };
  j.timestamp.forEach((t0, i) => {
    if ([q.open[i], q.high[i], q.low[i], q.close[i]].some((x) => x === null || x === undefined)) return;
    const k = out.ts.length - 1, t = tf === "1d" ? (k >= 0 && t0 - out.ts[k] < 20 * 3600 ? out.ts[k] : t0) : Math.floor(t0 / sec) * sec;      // günlükte gün başı damgası korunur
    if (k >= 0 && out.ts[k] === t) { out.high[k] = Math.max(out.high[k], q.high[i]); out.low[k] = Math.min(out.low[k], q.low[i]); out.close[k] = q.close[i]; out.volume[k] += q.volume[i] || 0; return; }
    out.ts.push(t); out.open.push(q.open[i]); out.high.push(q.high[i]); out.low.push(q.low[i]); out.close.push(q.close[i]); out.volume.push(q.volume[i] || 0); out.tbv.push(NaN);
  });
  const n = out.ts.length;
  if (tf === "1d" && n >= 2 && (out.ts[n - 1] - out.ts[n - 2]) % 86400 !== 0) {            // oluşan günlük mum tik zamanıyla damgalı: gün ızgarasına oturt
    let t = out.ts[n - 2] + 86400 * Math.floor((out.ts[n - 1] - out.ts[n - 2]) / 86400); if (t === out.ts[n - 2]) t += 86400; out.ts[n - 1] = t;
  }
  return out;
}

function resample4h(h1) {
  const out = { ts: [], open: [], high: [], low: [], close: [], volume: [], tbv: [] }; let cur = -1;
  h1.ts.forEach((t, i) => {
    const b = Math.floor(t / 14400) * 14400;
    if (b !== cur) { cur = b; out.ts.push(b); out.open.push(h1.open[i]); out.high.push(h1.high[i]); out.low.push(h1.low[i]); out.close.push(h1.close[i]); out.volume.push(h1.volume[i]); out.tbv.push(NaN); }
    else { const k = out.ts.length - 1; out.high[k] = Math.max(out.high[k], h1.high[i]); out.low[k] = Math.min(out.low[k], h1.low[i]); out.close[k] = h1.close[i]; out.volume[k] += h1.volume[i]; }
  });
  return out;
}

function merge(old, nw, cap) {
  if (!old) return nw;
  const m = new Map(); const put = (d) => d.ts.forEach((t, i) => m.set(t, [d.open[i], d.high[i], d.low[i], d.close[i], d.volume[i], d.tbv[i]]));
  put(old); put(nw);
  const ts = [...m.keys()].sort((a, b) => a - b).slice(-cap), g = (k) => ts.map((t) => m.get(t)[k]);
  return { ts, open: g(0), high: g(1), low: g(2), close: g(3), volume: g(4), tbv: g(5) };
}

export class Market {
  constructor(opts = {}) { this.skipEur = !!opts.skipEur; this.df = new Map(); this.lastFetch = new Map(); this.flow = {}; BF_SYMS.forEach((s) => (this.flow[s] = new Flow())); this.err = {}; this.wsOk = 0; this.timers = []; this.sockets = []; this.stopped = false; this.version = 0; }
  key(s, t) { return s + "|" + t; }
  get(sym, tf) { return this.df.get(this.key(sym, tf)) || null; }
  price(sym) { if (SPOT_CLOSED.includes(sym) && weekendTs(Date.now() / 1000)) { const d = this.get(sym, "1m"); return d && d.close.length ? d.close[d.close.length - 1] : null; }      // kapalı piyasa: fiyat son kapanışta donar
    if (sym === "EURUSD") { const d = this.get("EURUSD", "1m"); return d && d.close.length ? d.close[d.close.length - 1] : null; } return this.flow[sym].price; }
  spread(sym) { const f = this.flow[sym]; return f && f.bid && f.ask ? f.ask - f.bid : null; }
  async load(sym, tf, limit) {
    let d;
    if (sym === "EURUSD") { if (tf === "4h") { const h1 = this.get("EURUSD", "1h") || (await fetchYh("1h")); d = resample4h(h1); } else d = await fetchYh(tf); d = dropWeekend(d); }
    else { d = await fetchBf(sym, tf, limit); if (SPOT_CLOSED.includes(sym)) d = dropWeekend(d); }      // hafta sonu perpetual mumları grafiğe/analize girmez
    this.df.set(this.key(sym, tf), merge(this.get(sym, tf), d, MAXBARS));
    this.lastFetch.set(this.key(sym, tf), Date.now() / 1000); this.version++;
  }
  start() {
    for (const sym of SYMS) {
      if (sym === "EURUSD" && this.skipEur) continue;         // arka plan servisinde Yahoo (CORS'suz) yok
      let busy = false;
      const step = async () => {
        if (busy || this.stopped) return; busy = true; const now = Date.now() / 1000;
        for (const tf of TFS) {
          const k = this.key(sym, tf), need = !this.df.has(k);
          if (!need && now - (this.lastFetch.get(k) || 0) < REFRESH[tf] * (sym === "EURUSD" ? 4 : 1)) continue;
          try { await this.load(sym, tf, need ? 1000 : 6); delete this.err[k]; } catch (e) { this.err[k] = String(e.message || e).slice(0, 80); this.lastFetch.set(k, Date.now() / 1000 + 5); }
        }
        busy = false;
      };
      step(); this.timers.push(setInterval(step, 1000));
    }
    this.openWs();
    if (typeof document !== "undefined") document.addEventListener("visibilitychange", () => { if (!document.hidden) this.lastFetch.clear(); });   // arka plandan dönünce her şey tazelenir
  }
  openWs() {
    const m = "wss://fstream.binance.com/market/stream?streams=" + [...BF_SYMS.map((s) => s.toLowerCase() + "@aggTrade"), "!forceOrder@arr"].join("/");
    const p = "wss://fstream.binance.com/public/stream?streams=" + BF_SYMS.map((s) => s.toLowerCase() + "@bookTicker").join("/");
    const on = (ev) => {
      try {
        const msg = JSON.parse(ev.data), d = msg.data, st = msg.stream; this.wsOk = Date.now() / 1000;
        if (st.endsWith("@aggTrade")) this.flow[d.s].onTrade(+d.p, +d.q, !!d.m, d.T);
        else if (st.endsWith("@bookTicker")) { const f = this.flow[d.s]; f.bid = +d.b; f.ask = +d.a; f.bidq = +d.B; f.askq = +d.A; if (f.price === null) f.price = (f.bid + f.ask) / 2; }
        else if (st.startsWith("!forceOrder")) { const o = d.o; if (this.flow[o.s]) { const q = +(o.z || o.q), px = +(o.ap || o.p), f = this.flow[o.s]; f.liq.push({ t: d.E / 1000, side: o.S === "SELL" ? -1 : 1, q, p: px, usd: px * q }); if (f.liq.length > 150) f.liq.shift(); } }
      } catch (e) { /* bozuk mesaj */ }
    };
    const loop = (url, tag) => {
      if (this.stopped) return;
      let ws; try { ws = new WebSocket(url); } catch (e) { this.err["ws_" + tag] = String(e).slice(0, 60); setTimeout(() => loop(url, tag), 4000); return; }
      this.sockets.push(ws);
      ws.onmessage = on; ws.onclose = () => setTimeout(() => loop(url, tag), 3000); ws.onerror = () => { this.err["ws_" + tag] = "bağlantı hatası"; try { ws.close(); } catch (e) { /* yoksay */ } };
      ws.onopen = () => delete this.err["ws_" + tag];
    };
    loop(m, "market"); loop(p, "public");
  }
  stop() { this.stopped = true; this.timers.forEach(clearInterval); this.sockets.forEach((s) => { try { s.close(); } catch (e) { /* yoksay */ } }); }
}
