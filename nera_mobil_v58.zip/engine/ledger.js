/* DayTrader Pro (mobil) · şimşek (sinyal) geçmişi ve kâğıt üstü sonuç takibi (pro/pro_ledger.py karşılığı). Kayıt: localStorage. Emir yok. */
import { COST_BPS } from "./agents.js";
export const TIMEOUT_BARS = 48, COST_V = 2;        // pro_ledger.py ile aynı: 1 = Binance komisyonu her sembole, 2 = XM spreadi
const KEY = "dt_pro_simsek";
export const costR = (s) => ((COST_BPS[s.sym] ?? 5.0) * 1e-4 * s.entry) / s.risk;

export class Ledger {
  constructor(storage = globalThis.localStorage) {
    this.st = storage; this.sigs = []; this.nextId = 1;
    try { this.sigs = JSON.parse(this.st.getItem(KEY) || "[]"); this.nextId = Math.max(0, ...this.sigs.map((s) => s.id)) + 1; } catch (e) { this.sigs = []; }
    this.migrate();
  }
  /** Eski kayıtların net R'sini XM maliyetiyle yeniden hesaplar; önce bir kez yedek alır (yedek alınamazsa veriye dokunmaz). */
  migrate() {
    const old = this.sigs.filter((s) => s.cv !== COST_V); if (!old.length) return;
    try { if (!this.st.getItem(KEY + "_v1bak")) this.st.setItem(KEY + "_v1bak", this.st.getItem(KEY) || "[]"); } catch (e) { return; }
    for (const s of old) { if (s.net_r != null && s.exit != null && s.risk) s.net_r = (s.side * (s.exit - s.entry)) / s.risk - costR(s); s.cv = COST_V; }
    this.save();
  }
  save() { try { this.st.setItem(KEY, JSON.stringify(this.sigs.slice(-1500))); } catch (e) { /* depolama dolu */ } }
  add(ev) {
    const p = ev.plan, rk = ev.agents.find((a) => a.name === "Risk");
    const s = { id: this.nextId++, ts: ev.t, sym: ev.sym, tf: ev.tf, side: p.side, setup: ev.setup || "", entry: p.entry, stop: p.stop, tp1: p.tp1, tp2: p.tp2, risk: p.risk, r1: p.r1, r2: p.r2, score: ev.score, conf: ev.conf,
      risk_label: rk ? rk.label : "", agree: ev.agree, reasons: (ev.reasons || []).slice(0, 4).filter((r) => r.pts.length).map((r) => r.agent + ": " + r.pts[0]), status: "açık", exit: null, exit_ts: null, net_r: null, tp1_hit: false, tp2_hit: false, bars: 0, cv: COST_V};
    this.sigs.push(s); this.save(); return s;
  }
  openFor(sym, tf, side) { return this.sigs.filter((s) => s.status === "açık" && s.sym === sym && s.tf === tf && s.side === side); }
  /** Açık sinyalleri 1 dk mumlarla çöz: önce stop mu hedef mi (aynı mumda ikisi varsa temkinli: stop). get1m(sym) -> {ts,high,low,close} */
  resolve(get1m, tfSec) {
    let changed = false;
    for (const s of this.sigs) {
      if (s.status !== "açık") continue;
      const df = get1m(s.sym); if (!df || !df.ts.length) continue;
      let k0 = df.ts.findIndex((t) => t > s.ts); if (k0 < 0) continue;
      let res = null, side = s.side;
      for (let k = k0; k < df.ts.length; k++) {
        const hitSl = side === 1 ? df.low[k] <= s.stop : df.high[k] >= s.stop, hitT1 = side === 1 ? df.high[k] >= s.tp1 : df.low[k] <= s.tp1;
        if (hitSl) { res = ["SL", s.stop, k]; break; }
        if (hitT1) { res = ["TP1", s.tp1, k]; break; }
        if (df.ts[k] - s.ts > TIMEOUT_BARS * (tfSec[s.tf] || 900)) { res = ["süre", df.close[k], k]; break; }
      }
      if (res) {
        const [why, px, k] = res, gross = (side * (px - s.entry)) / s.risk, cost = costR(s);
        Object.assign(s, { status: why, exit: px, exit_ts: df.ts[k], net_r: gross - cost, bars: k - k0 });
        if (why === "TP1") { let t2 = false; for (let j = k + 1; j < df.ts.length; j++) if (side === 1 ? df.high[j] >= s.tp2 : df.low[j] <= s.tp2) { t2 = true; break; } s.tp2_hit = t2; }
        changed = true;
      }
    }
    if (changed) this.save();
  }
  stats() {
    const out = {}, groups = {};
    for (const s of this.sigs) if (["TP1", "SL", "süre"].includes(s.status)) { (groups[s.setup] = groups[s.setup] || []).push(s); (groups["*"] = groups["*"] || []).push(s); }
    for (const [k, v] of Object.entries(groups)) {
      const n = v.length, w = v.filter((s) => s.status === "TP1").length, z = 1.2816, p = w / n, den = 1 + (z * z) / n, ctr = (p + (z * z) / (2 * n)) / den, half = (z * Math.sqrt((p * (1 - p)) / n + (z * z) / (4 * n * n))) / den;
      out[k] = { n, win: p, lo: Math.max(0, ctr - half), hi: Math.min(1, ctr + half), avg_r: v.reduce((a, s) => a + s.net_r, 0) / n };
    }
    return out;
  }
  recent(n = 200) { return this.sigs.slice(-n).reverse(); }
}
