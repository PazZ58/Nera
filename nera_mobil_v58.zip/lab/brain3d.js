"use strict";
/* NERA 2 · 3B Beyin (Three.js, yalnız yeni tasarım + masaüstü). Kozmos'un VERİSİNİ aynen kullanır, yalnız çizimi yenisi alır:
   - gezegen listesi/renkleri: Cosmos.P (anahtar, ad, rol, col()), değerler: Lab.planetInfo(k, true).v, hız: Lab.stats.rate
   - seçim/gezinme: Cosmos.go(k), Cosmos.focus, ‹ › düğmeleri ve bilgi kartı (DOM) olduğu gibi çalışır
   - darbeler: Cosmos.hot(k, s) sarmalanır (laboratuvar/piyasa olayları ağda akan ışık olur); sinyal: DT "signal"
   Hiçbir veri/iş mantığı değişmez. WebGL yoksa ya da yükleme başarısızsa eski Kozmos çizimi aynen devam eder.
   Three.js r160 (MIT) vendor/three.module.min.js, ilk kez Beyin açılınca tembel yüklenir. */
(function () {
const BASE = document.currentScript && document.currentScript.src;
const MOB = /Android|iPhone|iPad/i.test(navigator.userAgent) || !!window.Capacitor;
const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches && localStorage.getItem("nera_fx") !== "1";
const S = { on: false, tried: false, T: null, r: null, scene: null, cam: null, el: null, cv: null, labs: {}, nodes: [], pulses: [], rings: [], yaw: 0.6, pitch: 0.28, D: 11, zoom: 1, tgt: null, enter: 1, enterT: 0, vals: {}, vt: 0, t: 0, last: 0, act: 0.3, drag: null, mx: -1, my: -1, hover: null, ready: false };
window.Brain3D = S;
const cssv = (v, d) => { try { return getComputedStyle(document.body).getPropertyValue(v).trim() || d; } catch (e) { return d; } };
const rnd = (a, b) => a + Math.random() * (b - a);

function glowTex(T) { const c = document.createElement("canvas"); c.width = c.height = 128; const x = c.getContext("2d"), g = x.createRadialGradient(64, 64, 0, 64, 64, 64); g.addColorStop(0, "rgba(255,255,255,1)"); g.addColorStop(0.25, "rgba(255,255,255,.55)"); g.addColorStop(0.6, "rgba(255,255,255,.12)"); g.addColorStop(1, "rgba(255,255,255,0)"); x.fillStyle = g; x.fillRect(0, 0, 128, 128); const t = new T.CanvasTexture(c); return t; }

function build(T) {
  const core = document.getElementById("bv-core"), orb = document.getElementById("orb-big"); if (!core || !orb) return false;
  const cv = document.createElement("canvas"); cv.id = "nb3d"; cv.style.cssText = "position:absolute;inset:0;width:100%;height:100%;opacity:0;transition:opacity 1.1s ease;touch-action:none;cursor:grab"; orb.after(cv); S.cv = cv; S.el = core;
  let r; try { r = new T.WebGLRenderer({ canvas: cv, antialias: true, alpha: true, powerPreference: "high-performance" }); } catch (e) { cv.remove(); return false; }
  r.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75)); r.setClearColor(0x000000, 0); S.r = r;
  const scene = S.scene = new T.Scene(), cam = S.cam = new T.PerspectiveCamera(42, 1, 0.1, 120); S.T = T; S.tex = glowTex(T);
  const add = T.AdditiveBlending, c1 = new T.Color(cssv("--nb", "#8b5cf6")), c2 = new T.Color(cssv("--na", "#22d3ee"));
  S.c1 = c1; S.c2 = c2;
  /* çekirdek: nefes alan noktalı küre (gölgelendirici), iç ışıma, ters dönen tel kafes */
  const N = MOB ? 1400 : 2800, pos = new Float32Array(N * 3), seed = new Float32Array(N), ga = Math.PI * (3 - Math.sqrt(5));
  for (let i = 0; i < N; i++) { const y = 1 - (i / (N - 1)) * 2, rr = Math.sqrt(1 - y * y), th = ga * i; pos[i * 3] = Math.cos(th) * rr; pos[i * 3 + 1] = y; pos[i * 3 + 2] = Math.sin(th) * rr; seed[i] = Math.random(); }
  const g = new T.BufferGeometry(); g.setAttribute("position", new T.BufferAttribute(pos, 3)); g.setAttribute("aSeed", new T.BufferAttribute(seed, 1));
  S.core = new T.Points(g, new T.ShaderMaterial({ transparent: true, depthWrite: false, blending: add, uniforms: { uT: { value: 0 }, uB: { value: 1 }, uS: { value: 5.4 * (window.devicePixelRatio || 1) }, uC1: { value: c1 }, uC2: { value: c2 } },
    vertexShader: "uniform float uT,uB,uS;attribute float aSeed;varying float vA;varying vec3 vC;uniform vec3 uC1,uC2;void main(){vec3 p=position;float n=sin(p.x*3.1+uT*.7+aSeed*6.)+sin(p.y*2.7-uT*.5+aSeed*3.)+sin(p.z*3.7+uT*.6);p*=1.+.05*n*(uB-.9)+.06*(uB-1.);vec4 mv=modelViewMatrix*vec4(p,1.);gl_Position=projectionMatrix*mv;float d=clamp(1.-(-mv.z-7.)/9.,.15,1.);gl_PointSize=uS*(.6+aSeed*1.1)*(9./-mv.z);float lat=p.y*.5+.5;vC=mix(uC1,uC2,clamp(lat+.18*sin(uT*.3+aSeed*6.),0.,1.));vA=.3+.7*d;}",
    fragmentShader: "varying float vA;varying vec3 vC;void main(){float r=length(gl_PointCoord-.5);if(r>.5)discard;float a=smoothstep(.5,0.,r);gl_FragColor=vec4(vC,a*a*vA);}" }));
  S.core.scale.setScalar(1.35); scene.add(S.core);
  const sp = (col, sc, op) => { const m = new T.Sprite(new T.SpriteMaterial({ map: S.tex, color: col, transparent: true, opacity: op, blending: add, depthWrite: false })); m.scale.set(sc, sc, 1); return m; };
  S.glowA = sp(c1, 7, 0.5); S.glowB = sp(c2, 3.4, 0.45); scene.add(S.glowA, S.glowB);
  S.wire = new T.LineSegments(new T.EdgesGeometry(new T.IcosahedronGeometry(1.62, 2)), new T.LineBasicMaterial({ color: c2, transparent: true, opacity: 0.1, blending: add, depthWrite: false })); scene.add(S.wire);
  /* süzülen veri düğümleri + yakın olanlar arasında ince bağlar */
  const NN = MOB ? 160 : 300, np = [], nA = new Float32Array(NN * 3);
  for (let i = 0; i < NN; i++) { const u = rnd(-1, 1), th = rnd(0, 6.283), q = Math.sqrt(1 - u * u), rd = rnd(1.7, 5.4); np.push([q * Math.cos(th) * rd, u * rd * 0.8, q * Math.sin(th) * rd]); nA.set(np[i], i * 3); }
  const lp = []; for (let i = 0; i < NN; i++) for (let j = i + 1; j < NN; j++) { const d = Math.hypot(np[i][0] - np[j][0], np[i][1] - np[j][1], np[i][2] - np[j][2]); if (d < 0.95) lp.push(...np[i], ...np[j]); }
  const lg = new T.BufferGeometry(); lg.setAttribute("position", new T.Float32BufferAttribute(lp, 3));
  S.mesh = new T.Group(); S.mesh.add(new T.LineSegments(lg, new T.LineBasicMaterial({ color: c1, transparent: true, opacity: 0.1, blending: add, depthWrite: false })));
  const ng = new T.BufferGeometry(); ng.setAttribute("position", new T.BufferAttribute(nA, 3)); S.mesh.add(new T.Points(ng, new T.PointsMaterial({ size: 0.11, map: S.tex, color: c2, transparent: true, opacity: 0.8, blending: add, depthWrite: false })));
  scene.add(S.mesh);
  /* toz */
  const DN = MOB ? 500 : 1200, da = new Float32Array(DN * 3); for (let i = 0; i < DN; i++) { const u = rnd(-1, 1), th = rnd(0, 6.283), q = Math.sqrt(1 - u * u), rd = rnd(6, 16); da[i * 3] = q * Math.cos(th) * rd; da[i * 3 + 1] = u * rd * 0.7; da[i * 3 + 2] = q * Math.sin(th) * rd; }
  const dg = new T.BufferGeometry(); dg.setAttribute("position", new T.BufferAttribute(da, 3)); S.dust = new T.Points(dg, new T.PointsMaterial({ size: 0.06, color: 0x9fb0ff, transparent: true, opacity: 0.35, blending: add, depthWrite: false })); scene.add(S.dust);
  /* gezegen düğümleri + çekirdeğe bağlar (Kozmos verisinden) */
  const P = (window.Cosmos && Cosmos.P) || []; S.nodes = [];
  P.forEach((p, i) => {
    const col = new T.Color(p.col()), grp = new T.Group(), body = new T.Mesh(new T.SphereGeometry(0.07 + p.pr * 0.42, 24, 18), new T.MeshBasicMaterial({ color: col })), halo = sp(col, 0.9 + p.pr * 4.4, 0.8);
    grp.add(body, halo);
    if (p.ring) { const ring = new T.Mesh(new T.RingGeometry(0.24 + p.pr * 1.3, 0.262 + p.pr * 1.3, 64), new T.MeshBasicMaterial({ color: col, side: T.DoubleSide, transparent: true, opacity: 0.55, blending: add, depthWrite: false })); ring.rotation.x = 1.15; grp.add(ring); }
    scene.add(grp);
    const pts = new Float32Array(49 * 3), geo = new T.BufferGeometry(); geo.setAttribute("position", new T.BufferAttribute(pts, 3));
    const line = new T.Line(geo, new T.LineBasicMaterial({ color: col, transparent: true, opacity: 0.38, blending: add, depthWrite: false })); scene.add(line);
    S.nodes.push({ p, grp, body, halo, line, pts, geo, col, a: p.a, e: 0, w: new T.Vector3(), curve: [] });
    const el = document.createElement("div"); el.className = "nb-lab"; el.style.setProperty("--pc", p.col()); el.innerHTML = `<i></i><b>${p.n}</b><span>—</span>`; core.appendChild(el); S.labs[p.k] = el;
  });
  /* ağda akan ışık darbeleri */
  S.pulseGeo = new T.BufferGeometry(); S.pulseMax = 64; S.pulseGeo.setAttribute("position", new T.BufferAttribute(new Float32Array(S.pulseMax * 3), 3)); S.pulseGeo.setAttribute("color", new T.BufferAttribute(new Float32Array(S.pulseMax * 3), 3));
  S.pulsePts = new T.Points(S.pulseGeo, new T.PointsMaterial({ size: 0.34, map: S.tex, vertexColors: true, transparent: true, blending: add, depthWrite: false })); scene.add(S.pulsePts);
  /* olay halkaları */
  S.ringTpl = new T.RingGeometry(1.05, 1.08, 96);
  /* etkileşim */
  cv.addEventListener("pointerdown", (e) => { S.drag = { x: e.clientX, y: e.clientY, lx: e.clientX, ly: e.clientY, m: 0 }; try { cv.setPointerCapture(e.pointerId); } catch (x) { /* */ } });
  cv.addEventListener("pointermove", (e) => { const rc = cv.getBoundingClientRect(); S.mx = e.clientX - rc.left; S.my = e.clientY - rc.top; if (!S.drag) return; const dx = e.clientX - S.drag.lx, dy = e.clientY - S.drag.ly; S.drag.m += Math.abs(dx) + Math.abs(dy); S.drag.lx = e.clientX; S.drag.ly = e.clientY; if (S.drag.m > 6) { S.yaw -= dx * 0.006; S.pitch = Math.max(-1.1, Math.min(1.1, S.pitch + dy * 0.005)); cv.style.cursor = "grabbing"; } });
  const up = (e) => { if (!S.drag) return; const moved = S.drag.m > 6; S.drag = null; cv.style.cursor = "grab"; if (moved) return; const rc = cv.getBoundingClientRect(), h = pick(e.clientX - rc.left, e.clientY - rc.top); if (window.Cosmos) Cosmos.go(h ? h.p.k : null); };
  cv.addEventListener("pointerup", up); cv.addEventListener("pointercancel", () => { S.drag = null; });
  cv.addEventListener("pointerleave", () => { S.mx = S.my = -1; });
  cv.addEventListener("wheel", (e) => { if (window.Cosmos && Cosmos.focus) return; e.preventDefault(); S.zoom = Math.max(0.65, Math.min(1.6, S.zoom * (e.deltaY > 0 ? 0.93 : 1.07))); }, { passive: false });
  /* Kozmos darbelerini ve sinyalleri 3B ağa da ilet (Kozmos işlevi aynen çalışır) */
  if (window.Cosmos && !Cosmos._h3) { Cosmos._h3 = Cosmos.hot; Cosmos.hot = function (k, s) { Cosmos._h3.call(this, k, s); S.pulse(k, s); }; }
  if (window.DT) { DT.on("signal", (e) => S.ring(e && e.side < 0 ? "#f4577a" : "#34d3a0")); DT.on("view", (v) => { if (v === "brain") { S.enter = 0; S.enterT = performance.now(); } }); DT.on("palette", recolor); DT.on("theme", () => setTimeout(recolor, 80)); }
  new ResizeObserver(resize).observe(core); resize(); return true;
}
function recolor() {
  if (!S.ready) return; S.c1.set(cssv("--nb", "#8b5cf6")); S.c2.set(cssv("--na", "#22d3ee")); S.glowA.material.color.copy(S.c1); S.glowB.material.color.copy(S.c2); S.wire.material.color.copy(S.c2);
  S.nodes.forEach((n) => { n.col.set(n.p.col()); n.body.material.color.copy(n.col); n.halo.material.color.copy(n.col); n.line.material.color.copy(n.col); if (S.labs[n.p.k]) S.labs[n.p.k].style.setProperty("--pc", n.p.col()); });
}
function resize() { if (!S.r || !S.el) return; const w = S.el.clientWidth, h = S.el.clientHeight; if (w < 10 || h < 10) return; S.r.setSize(w, h, false); S.cam.aspect = w / h; S.cam.updateProjectionMatrix(); S.w = w; S.h = h; }
S.pulse = (k, s) => { const n = S.nodes.find((x) => x.p.k === k); if (!n) return; n.e = Math.min(1, n.e + 0.3 * (s || 1)); if (S.pulses.length < 40) S.pulses.push({ n, t: 0, dir: n.p.role < 0 ? 1 : -1, v: rnd(0.45, 0.8) }); };
S.ring = (hex) => { if (!S.ready || S.rings.length > 5) return; const T = S.T, m = new T.Mesh(S.ringTpl, new T.MeshBasicMaterial({ color: new T.Color(hex), side: T.DoubleSide, transparent: true, opacity: 0.85, blending: T.AdditiveBlending, depthWrite: false })); m.rotation.x = Math.PI / 2 + rnd(-0.3, 0.3); m.rotation.y = rnd(-0.3, 0.3); S.scene.add(m); S.rings.push({ m, t: 0 }); };
function pick(mx, my) {
  let best = null, bd = 1e9; const w = S.w, h = S.h;
  S.nodes.forEach((n) => { const v = n.w.clone().project(S.cam); if (v.z > 1) return; const sx = (v.x * 0.5 + 0.5) * w, sy = (-v.y * 0.5 + 0.5) * h, d = Math.hypot(sx - mx, sy - my); if (d < Math.max(30, 90 / (S.D / 11)) && d < bd) { bd = d; best = n; } });
  return best;
}
function frame(now) {
  requestAnimationFrame(frame);
  if (!S.ready) return;
  const vis = document.body.dataset.view === "brain" && !document.hidden && !(window.Splash && Splash.active);
  S.cv.style.pointerEvents = vis ? "auto" : "none";
  if (!vis) return;
  const raw = (now - (S.last || now)) / 1000, dt = Math.min(0.05, raw); S.last = now; S.t += dt;
  /* performans koruması: 2,5 sn'lik pencerede ortalama kare hızı düşükse kaliteyi kademeli indir (çözünürlük, çekirdek noktası, toz, ağ); gerçek zamanlı veri akışı etkilenmesin */
  if (raw > 0 && raw < 1) { S.gA = (S.gA || 0) + raw; S.gN = (S.gN || 0) + 1; if (S.gA >= 2.5) { const fps = S.gN / S.gA; S.gA = S.gN = 0; S.fps = Math.round(fps); if (fps < 22 && (S.q || 0) < 2) { S.q = (S.q || 0) + 1; if (S.q === 1) { S.r.setPixelRatio(1); S.core.geometry.setDrawRange(0, Math.floor(S.core.geometry.attributes.position.count * 0.6)); S.dust.visible = false; } else { S.r.setPixelRatio(0.8); S.mesh.visible = false; S.core.geometry.setDrawRange(0, Math.floor(S.core.geometry.attributes.position.count * 0.35)); } resize(); } } } const T = S.T, t = S.t, C = window.Cosmos;
  if (!S.shown && C && C.introP() >= 1) { S.shown = true; S.cv.style.opacity = "1"; const o = document.getElementById("orb-big"); if (o) { o.style.transition = "opacity .9s"; o.style.opacity = "0"; o.style.pointerEvents = "none"; } window.NERA_3D = true; }
  if (!S.shown) return;
  if (S.el.clientWidth !== S.w || S.el.clientHeight !== S.h) resize();
  /* etkinlik: laboratuvar hızı (Lab.stats.rate) → nefes hızı ve parıltı */
  const rate = (window.Lab && Lab.stats && +Lab.stats.rate) || 0; S.act += (Math.min(1, rate / 12) - S.act) * 0.03;
  const f0 = 0.1 + S.act * 0.18, br = 1 + 0.06 * Math.sin(t * f0 * 6.283) + 0.015 * Math.sin(t * 1.7);
  S.core.material.uniforms.uT.value = t; S.core.material.uniforms.uB.value = br;
  S.glowA.scale.setScalar((6.4 + 1 * Math.sin(t * f0 * 6.283)) * (1 + S.act * 0.25)); S.glowA.material.opacity = 0.42 + S.act * 0.25; S.glowB.scale.setScalar(3.2 + 0.6 * Math.sin(t * f0 * 6.283 + 1));
  S.core.rotation.y += dt * 0.06; S.wire.rotation.y -= dt * 0.04; S.wire.rotation.x += dt * 0.02; S.mesh.rotation.y += dt * 0.012; S.dust.rotation.y -= dt * 0.006;
  /* giriş: düğümler çekirdekten süzülerek yörüngeye açılır */
  if (S.enter < 1) S.enter = Math.min(1, (performance.now() - S.enterT) / 1500); const ee = 1 - Math.pow(1 - S.enter, 3);
  const P = S.nodes; const foc = C && C.focus ? P.find((n) => n.p === C.focus) : null;
  P.forEach((n, i) => {
    const p = n.p, R = p.orbit * 1.12 * ee; n.a += dt * p.sp * (reduce ? 0.3 : 0.6); const inc = p.inc;
    const ic = inc * 2.8; n.grp.position.set(Math.cos(n.a) * R, Math.sin(n.a) * R * Math.sin(ic), Math.sin(n.a) * R * Math.cos(ic)); n.w.copy(n.grp.position);
    n.e *= 0.965; const k = 1 + n.e * 0.5 + (foc === n ? 0.35 : 0) + (S.hover === n ? 0.18 : 0); n.grp.scale.setScalar(k); n.halo.material.opacity = 0.55 + n.e * 0.45 + (foc === n ? 0.2 : 0);
    /* bağ: çekirdek yüzeyinden düğüme kavisli eğri */
    const a = n.grp.position, dir = a.clone().normalize(), s0 = dir.clone().multiplyScalar(1.42), ctrl = a.clone().multiplyScalar(0.5).add(new T.Vector3(-dir.z, 0.55 + 0.25 * Math.sin(i), dir.x).multiplyScalar(0.8)), pts = n.pts;
    n.curve.length = 0; for (let q = 0; q <= 48; q++) { const u = q / 48, w1 = (1 - u) * (1 - u), w2 = 2 * u * (1 - u), w3 = u * u, x = w1 * s0.x + w2 * ctrl.x + w3 * a.x, y = w1 * s0.y + w2 * ctrl.y + w3 * a.y, z = w1 * s0.z + w2 * ctrl.z + w3 * a.z; pts[q * 3] = x; pts[q * 3 + 1] = y; pts[q * 3 + 2] = z; if (q % 8 === 0) n.curve.push(x, y, z); }
    n.geo.attributes.position.needsUpdate = true; n.line.material.opacity = (0.22 + 0.22 * n.e + (foc === n ? 0.3 : 0)) * ee; n.cs = [s0, ctrl, a];
  });
  /* darbeler: rastgele sık olmayan kendiliğinden darbeler + olay darbeleri; kaynak→çekirdek (rol<0) veya çekirdek→çıktı (rol>0) */
  if (!reduce && P.length && Math.random() < dt * (0.6 + S.act * 2)) S.pulse(P[Math.floor(Math.random() * P.length)].p.k, 0.3);
  const pp = S.pulseGeo.attributes.position.array, pc = S.pulseGeo.attributes.color.array; let m = 0;
  for (let i = S.pulses.length - 1; i >= 0; i--) {
    const u = S.pulses[i]; u.t += dt * u.v; if (u.t >= 1) { S.pulses.splice(i, 1); continue; }
    const tt = u.dir > 0 ? 1 - u.t : u.t, [s0, ctrl, a] = u.n.cs || [], q = 1 - tt; if (!a || m >= S.pulseMax) continue;
    pp[m * 3] = q * q * s0.x + 2 * q * tt * ctrl.x + tt * tt * a.x; pp[m * 3 + 1] = q * q * s0.y + 2 * q * tt * ctrl.y + tt * tt * a.y; pp[m * 3 + 2] = q * q * s0.z + 2 * q * tt * ctrl.z + tt * tt * a.z;
    const fade = Math.sin(Math.PI * u.t); pc[m * 3] = u.n.col.r * fade + fade * 0.25; pc[m * 3 + 1] = u.n.col.g * fade + fade * 0.25; pc[m * 3 + 2] = u.n.col.b * fade + fade * 0.25; m++;
  }
  S.pulseGeo.setDrawRange(0, m); S.pulseGeo.attributes.position.needsUpdate = true; S.pulseGeo.attributes.color.needsUpdate = true;
  for (let i = S.rings.length - 1; i >= 0; i--) { const r = S.rings[i]; r.t += dt / 2.2; if (r.t >= 1) { S.scene.remove(r.m); r.m.material.dispose(); S.rings.splice(i, 1); continue; } r.m.scale.setScalar(1 + r.t * 5.5); r.m.material.opacity = (1 - r.t) * 0.8; }
  /* kamera: yavaş otomatik dönüş; seçili gezegen varsa ona uçar */
  if (!S.drag && !(C && C.focus) && !reduce) S.yaw += dt * 0.045;
  const tgt = foc ? foc.w : new T.Vector3(0, 0, 0), D = foc ? 4.6 : 10.6 * S.zoom; S.D += (D - S.D) * Math.min(1, dt * 2.6);
  if (!S.tgt) S.tgt = new T.Vector3(); S.tgt.lerp(tgt, Math.min(1, dt * 3));
  const cy = Math.cos(S.pitch), ex = Math.sin(S.yaw) * cy * S.D, ey = Math.sin(S.pitch) * S.D, ez = Math.cos(S.yaw) * cy * S.D;
  S.cam.position.set(S.tgt.x + ex, S.tgt.y + ey, S.tgt.z + ez); S.cam.lookAt(S.tgt);
  S.r.render(S.scene, S.cam);
  /* etiketler: düğümün ekran konumu; değerler ~0,6 sn'de bir Lab.planetInfo'dan */
  S.hover = S.mx >= 0 && !S.drag ? pick(S.mx, S.my) : null; S.cv.style.cursor = S.drag && S.drag.m > 6 ? "grabbing" : S.hover ? "pointer" : "grab";
  if (now - S.vt > 600) { S.vt = now; if (window.Lab && Lab.planetInfo) P.forEach((n) => { try { const v = Lab.planetInfo(n.p.k, true); S.vals[n.p.k] = v && v.v != null ? v.v : "—"; } catch (e) { /* */ } }); if (C && C.card) C.card(); }
  P.forEach((n) => { const el = S.labs[n.p.k]; if (!el) return; const v = n.w.clone().project(S.cam); const on = v.z < 1 && ee > 0.4; el.style.opacity = on ? (foc && foc !== n ? 0.35 : 1) : 0; if (!on) return; el.style.transform = `translate(${((v.x * 0.5 + 0.5) * S.w).toFixed(1)}px, ${((-v.y * 0.5 + 0.5) * S.h).toFixed(1)}px) translate(-50%, 14px)`; const sp = el.lastChild, nv = String(S.vals[n.p.k] == null ? "—" : S.vals[n.p.k]); if (sp._v !== nv) { sp._v = nv; sp.textContent = nv; } el.classList.toggle("hov", S.hover === n); });
}
async function boot() {
  if (S.tried || MOB || !document.body.classList.contains("n2")) return; S.tried = true;
  try { const T = await import(new URL("../vendor/three.module.min.js", BASE).href); if (!build(T)) return; S.ready = true; requestAnimationFrame(frame); }
  catch (e) { S.err = String(e && e.message || e); }
}
/* Beyin ilk görünür olduğunda (açılış perdesi bittikten sonra) yükle */
const iv = setInterval(() => { if (S.tried) return clearInterval(iv); if (document.body.dataset.view === "brain" && !(window.Splash && Splash.active) && window.Cosmos && Cosmos.P && Cosmos.P.length) { clearInterval(iv); boot(); } }, 700);
document.addEventListener("visibilitychange", () => { S.last = 0; });
})();
