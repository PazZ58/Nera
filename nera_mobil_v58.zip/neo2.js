"use strict";
/* NERA 2 · yeni görünüm katmanı (sunum): atmosfer, menü sabitleme, imleç ışığı, sayfa geçişleri (GSAP), yumuşak kaydırma (Lenis), Ayarlar › Tasarım.
   Veri, API, WebSocket, durum ve yönlendirmeye dokunmaz. body.n2 yoksa hiçbir şey yapmaz (klasik görünüm). */
(function () {
const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
const get = (k, d) => { try { return localStorage.getItem(k) || d; } catch (e) { return d; } };
const set = (k, v) => { try { localStorage.setItem(k, v); } catch (e) { /* */ } };
const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches && get("nera_fx", "") !== "1";
const mobile = () => innerWidth <= 900;
window.NeraUI = { on: () => document.body.classList.contains("n2"), reduce };
if (!document.body.classList.contains("n2")) return;

/* atmosfer katmanı */
const bg = document.createElement("div"); bg.id = "n2-bg"; bg.innerHTML = "<i></i><i></i><i></i>"; document.body.prepend(bg);
if (get("nera_rail", "") === "pin") document.body.classList.add("rail-pin");

/* imleç ışığı: kartların üstünde --mx/--my */
const CARD = ".panel, .kp, .tcard, .ncard, .wn-card, .xp-card, .cos-card, .big-card";
let raf = 0, last = null;
document.addEventListener("pointermove", (e) => {
  last = e; if (raf) return;
  raf = requestAnimationFrame(() => { raf = 0; const t = last.target.closest && last.target.closest(CARD); if (!t) return; const r = t.getBoundingClientRect(); t.style.setProperty("--mx", last.clientX - r.left + "px"); t.style.setProperty("--my", last.clientY - r.top + "px"); });
}, { passive: true });

/* sayfa geçişi: GSAP; görünüme girince bölümler sırayla süzülür. Grafik ve tuvaller kaydırılmaz/titretilmez: yalnız .pg çocukları ve .kp */
const gs = window.gsap; let lenis = null, tick = null;
function enter(v) {
  const view = $("#v-" + v); if (!view) return;
  if (gs && !reduce && !mobile()) {
    const kids = $$(".pg > *", view).filter((e) => !e.matches("canvas, #nf-cloud") && e.offsetParent !== null).slice(0, 14);
    if (kids.length) gs.fromTo(kids, { autoAlpha: 0, y: 18, filter: "blur(6px)" }, { autoAlpha: 1, y: 0, filter: "blur(0px)", duration: 0.7, stagger: 0.06, ease: "power3.out", clearProps: "transform,opacity,visibility,filter" });
    const kp = $$(".kp", view); if (kp.length) gs.fromTo(kp, { autoAlpha: 0, y: 14 }, { autoAlpha: 1, y: 0, duration: 0.6, stagger: 0.04, delay: 0.1, ease: "power2.out", clearProps: "transform,opacity,visibility" });
  }
  /* yumuşak kaydırma yalnız uzun metin/panel sayfalarında; grafik ve tuval ekranlarında kapalı (gerçek zamanlı etkileşimi bozmasın) */
  if (lenis) { try { lenis.destroy(); } catch (e) { /* */ } if (tick && gs) gs.ticker.remove(tick); lenis = null; tick = null; }
  if (window.Lenis && !reduce && !mobile() && ["set", "kb", "book", "news", "lab", "labsig", "team", "friends"].includes(v)) {
    try {
      lenis = new window.Lenis({ wrapper: view, content: view.firstElementChild, lerp: 0.1, smoothWheel: true });
      if (gs) { tick = (t) => lenis && lenis.raf(t * 1000); gs.ticker.add(tick); gs.ticker.lagSmoothing(0); }
    } catch (e) { lenis = null; }
  }
}
if (window.DT) DT.on("view", (v) => setTimeout(() => enter(v), 40));
setTimeout(() => enter(document.body.dataset.view || "brain"), 900);

/* Ayarlar › Tasarım */
function panel() {
  const pg = $("#pg-set"); if (!pg || $("#n2-panel")) return;
  const p = document.createElement("div"); p.className = "panel"; p.id = "n2-panel";
  p.innerHTML = `<div class="ph">Tasarım <small>yeni görünüm · istediğin an klasiğe dönebilirsin</small></div><div class="pb">
    <div class="setrow" style="display:flex;align-items:center;gap:14px;flex-wrap:wrap"><div style="flex:1;min-width:220px"><b>Görünüm</b><div class="muted" style="font-size:11px">Yalnız görünümü değiştirir; veri, sinyal ve ayarlar aynıdır.</div></div><div class="seg" id="n2-ui"><button data-u="2" class="on">Yeni (NERA 2)</button><button data-u="classic">Klasik</button></div></div>
    <div class="setrow" style="display:flex;align-items:center;gap:14px;margin-top:14px"><div style="flex:1"><b>Menü sabit</b><div class="muted" style="font-size:11px">Kapalıysa simge çubuğu, üstüne gelince açılır.</div></div><label class="sw"><input type="checkbox" id="n2-pin" ${document.body.classList.contains("rail-pin") ? "checked" : ""}><i></i></label></div></div>`;
  const lead = pg.querySelector(".lead"); if (lead) lead.after(p); else pg.prepend(p);
  $("#n2-ui", p).onclick = (e) => { const b = e.target.closest("button"); if (!b) return; set("nera_ui", b.dataset.u === "classic" ? "classic" : "2"); location.reload(); };
  $("#n2-pin", p).onchange = (e) => { document.body.classList.toggle("rail-pin", e.target.checked); set("nera_rail", e.target.checked ? "pin" : ""); };
}
if (window.DT) DT.on("view", (v) => { if (v === "set") setTimeout(panel, 300); });
setInterval(() => { if (document.body.dataset.view === "set") panel(); }, 3000);
})();
