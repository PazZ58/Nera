"use strict";
/* NERA 3 · 3. tur: Ajan Ofisi + Laboratuvar ortak bileşenleri (düz JS, esinlenme: Aceternity "Card Spotlight" / Magic UI "Magic Card" imleç ışığı, Magic UI "Border Beam", Gather HUD).
   1) Spotlight: imleç kartın üstündeyken yumuşak ışık kartı izler. 2) Beam: çalışan panelin kenarında dönen ışık. 3) Canvas HUD: Sinyal Beyni ve Laboratuvar beyni tuvallerine
   Gather'daki gibi köşe artıları, cetvel, tarama çizgisi ve imleç koordinatı ("TRACK x y"). 4) KPI değişince değer kısa süre parlar ve yukarı kayar. Kod kopyalanmadı. */
(function () {
const U = window.NeraUI; if (!U || !document.body.classList.contains("u3")) return;
if (U.mobile()) return;
const SEL = ".panel, .kp, .ag, .scard, .sg, .symcards > *";
/* 1) spotlight */
let raf = 0, last = null;
addEventListener("pointermove", (e) => {
  if (U.reduced()) return; const t = e.target && e.target.closest && e.target.closest(SEL); if (last && last !== t) { last.style.removeProperty("--sx"); last.style.removeProperty("--sy"); last.classList.remove("spot"); }
  last = t; if (!t) return; if (raf) return; raf = requestAnimationFrame(() => { raf = 0; const r = t.getBoundingClientRect(); t.style.setProperty("--sx", e.clientX - r.left + "px"); t.style.setProperty("--sy", e.clientY - r.top + "px"); t.classList.add("spot"); });
}, { passive: true });
/* 3) canvas HUD */
function hud(host) {
  if (!host || host._hud) return; host._hud = 1; if (getComputedStyle(host).position === "static") host.style.position = "relative";
  const d = document.createElement("div"); d.className = "gvx"; d.innerHTML = '<i class="a"></i><i class="b"></i><i class="c"></i><i class="d"></i><u class="rl"></u><s class="sc"></s><span class="tr">TRACK 0.00 0.00</span>'; host.appendChild(d);
  const tr = d.querySelector(".tr"); let tk = 0;
  host.addEventListener("pointermove", (e) => { const n = performance.now(); if (n - tk < 60) return; tk = n; const r = host.getBoundingClientRect(); tr.textContent = "TRACK " + (((e.clientX - r.left) / r.width - 0.5) * 2).toFixed(2) + " " + ((0.5 - (e.clientY - r.top) / r.height) * 2).toFixed(2); }, { passive: true });
}
function scan() { document.querySelectorAll("#council, #lb-brain-w").forEach(hud); }
scan(); [800, 2500, 6000].forEach((ms) => setTimeout(scan, ms)); /* gövde gözlemcisi her karede DOM değişen ekranlarda fps düşürdü: ekran girişinde ve açılışta tara */
/* 4) KPI sayaçları: sayı değişince eski değerden yenisine akar (Magic UI "Number Ticker" örüntüsü, düz JS). Değerler "71.222" gibi tr-TR binlik noktalı tam sayılardır. */
const num = (t) => (/^[\d.]+$/.test(t.trim()) ? +t.trim().replace(/\./g, "") : null), fmt = (n) => Math.round(n).toLocaleString("tr-TR");
const kv = new Map();
function kpi(box) {
  if (!box || box._kp) return; box._kp = 1; let busy = false;
  new MutationObserver(() => {
    if (busy) return; busy = true;
    box.querySelectorAll(".kp").forEach((k, i) => {
      const v = k.querySelector(".v"); if (!v) return; const key = box.id + i, to = num(v.textContent), st = kv.get(key) || (kv.set(key, { cur: to, tw: null }), kv.get(key));
      if (to === null || U.reduced()) { st.cur = to; return; }
      if (st.cur === null || st.cur === to) { st.cur = to; return; }
      v.classList.remove("kp-chg"); void v.offsetWidth; v.classList.add("kp-chg");
      const from = st.cur; st.cur = to; v.textContent = fmt(from);
      if (st.tw) st.tw.kill(); const o = { n: from }; st.tw = window.gsap ? gsap.to(o, { n: to, duration: Math.min(1.6, 0.5 + Math.abs(to - from) / Math.max(1, to) * 6), ease: "power3.out", onUpdate: () => { busy = true; v.textContent = fmt(o.n); setTimeout(() => (busy = false), 0); }, onComplete: () => { v.textContent = fmt(to); } }) : null; if (!st.tw) v.textContent = fmt(to);
    });
    setTimeout(() => (busy = false), 0);
  }).observe(box, { childList: true, subtree: true, characterData: true });
}
function kscan() { ["#lb-kpis", "#bv-kpis"].forEach((s) => kpi(document.querySelector(s))); }
kscan(); [800, 2500, 6000].forEach((ms) => setTimeout(kscan, ms)); if (window.DT) DT.on("view", () => { setTimeout(scan, 300); setTimeout(kscan, 300); });

/* 5) kaydırınca giriş: Laboratuvar, Ajan Ofisi, Defter, Backtest, Bilgi Bankası, Haber panelleri aşağı inerken sırayla süzülerek gelir (bir kez) */
const RV = ".panel, .kpis, .two > *, .symcards, .lbrain";
const io = "IntersectionObserver" in window && !U.reduced() ? new IntersectionObserver((es) => { es.forEach((e) => { if (e.isIntersecting) { const t = e.target; setTimeout(() => t.classList.add("rv-in"), (t._rvd || 0)); io.unobserve(t); } }); }, { threshold: 0.08, rootMargin: "0px 0px -6% 0px" }) : null;
function rvScan() { if (!io) return; ["lab", "office", "book", "bt", "kb", "news", "labsig", "set"].forEach((v) => { const root = document.getElementById("v-" + v); if (!root) return; root.querySelectorAll(RV).forEach((el) => { if (el._rv) return; el._rv = 1; const r = el.getBoundingClientRect(); if (r.top < innerHeight * 0.9 && r.bottom > 0) return; el.classList.add("rv"); io.observe(el); }); }); }
setTimeout(rvScan, 400); if (window.DT) DT.on("view", () => setTimeout(rvScan, 150));
/* 6) 3B eğim: istasyon, ofis kartı, KPI ve piyasa ajanı kartları imleçle hafifçe döner */
const TILT = ".stn, .ag, .kp, .mk, .scard";
addEventListener("pointermove", (e) => { if (U.reduced()) return; const t = e.target && e.target.closest && e.target.closest(TILT); if (!t) { if (window._tl && window._tl !== t) { window._tl.style.setProperty("--rx", "0deg"); window._tl.style.setProperty("--ry", "0deg"); window._tl = null; } return; } const r = t.getBoundingClientRect(), px = (e.clientX - r.left) / r.width - 0.5, py = (e.clientY - r.top) / r.height - 0.5; if (window._tl && window._tl !== t) { window._tl.style.setProperty("--rx", "0deg"); window._tl.style.setProperty("--ry", "0deg"); } window._tl = t; t.style.setProperty("--rx", (-py * 7).toFixed(2) + "deg"); t.style.setProperty("--ry", (px * 9).toFixed(2) + "deg"); }, { passive: true });
})();
