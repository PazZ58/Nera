"use strict";
/* localStorage doluysa ya da kapalıysa (gizli mod, kota) setItem hata fırlatır; sym/tf seçimi gibi basit yazılar bile arayüzü yarıda kesiyordu.
   Bu dosya HER ŞEYDEN ÖNCE yüklenir: önce önbellek anahtarı silip bir kez yeniden dener, olmazsa bellekte tutar (oturum boyunca çalışır). */
(function () {
  const P = Storage.prototype, set = P.setItem, get = P.getItem, rem = P.removeItem, mem = new Map(), EVICT = ["nf_ticks", "nera_flow_obs"];
  P.setItem = function (k, v) {
    try { set.call(this, k, v); mem.delete(k); return; } catch (e) { /* kota ya da kapalı depo */ }
    for (const x of EVICT) { if (x === k) continue; try { rem.call(this, x); set.call(this, k, v); mem.delete(k); return; } catch (e) { /* sonraki */ } }
    mem.set(k, String(v)); window.__storeFull = (window.__storeFull || 0) + 1;
  };
  P.getItem = function (k) { return mem.has(k) ? mem.get(k) : get.call(this, k); };
  P.removeItem = function (k) { mem.delete(k); try { rem.call(this, k); } catch (e) { /* */ } };
})();
