"use strict";
/* Nera · Arkadaşlar: kim çevrimiçi, hangi cihazdan (PC / mobil), son görülme, grup sohbeti + özel mesaj, arkadaş istatistikleri.
   Kurulum gerekmez: ücretsiz ve hesapsız ntfy.sh yayın/abone servisi. Herkes aynı "grup kodu"nda buluşur (varsayılan: genel).
   - Varlık: her cihaz 40 sn'de bir gruba "buradayım" (takma ad + küçük foto + birkaç istatistik) yollar.
   - Grup sohbeti: nera7_<grup>_g konusu. Özel mesaj: alıcının ve kendi gelen kutusu konusu. Tek canlı bağlantı (SSE).
   - ntfy mesajları 12 saat saklar; sohbetler, kişi listesi ve profil bu cihazda kalıcıdır (PC: uygulama klasörüne yedek; telefon: uygulama dosyası).
   Gizlilik: grup kodunu bilen herkes o gruptaki mesajları okuyabilir. */
(function () {
const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const NT = "https://ntfy.sh/", PLAT = matchMedia("(max-width:900px)").matches ? "mobil" : "pc", START = Date.now();
const LSg = (k, d) => { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } }, LSs = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* dolu */ } };
const FS = () => window.Capacitor && Capacitor.Plugins && Capacitor.Plugins.Filesystem;

/* ---- profil: üç kopya (nera_prof, nera_prof_bak, telefonda dosya; PC'de ayrıca uygulama klasörü). Boş değer dolu değerin üstüne yazılmaz. */
const P0 = { nick: "", photo: "", room: "genel" };
let P = Object.assign({}, P0, LSg("nera_prof_bak", {}), LSg("nera_prof", {}));
["nick", "photo"].forEach((k) => { if (!P[k]) P[k] = (LSg("nera_prof_bak", {}) || {})[k] || ""; }); if (!P.room) P.room = "genel";
const save = () => { LSs("nera_prof", P); if (P.nick) LSs("nera_prof_bak", P); if (window.NERA_SAVE) setTimeout(window.NERA_SAVE, 50); const F = FS(); if (F && P.nick) F.writeFile({ path: "nera_prof.json", data: JSON.stringify(P), directory: "DATA", encoding: "utf8" }).catch(() => {}); };
async function restoreFile() { const F = FS(); if (!F || P.nick) return; try { const r = await F.readFile({ path: "nera_prof.json", directory: "DATA", encoding: "utf8" }); const o = JSON.parse(r.data); if (o && o.nick) { P = Object.assign({}, P0, o); save(); build(); upd(); connect(); } } catch (e) { /* dosya yok */ } }

const id = (n) => String(n || "").toLowerCase().replace(/ç/g, "c").replace(/ğ/g, "g").replace(/ı/g, "i").replace(/ö/g, "o").replace(/ş/g, "s").replace(/ü/g, "u").replace(/[^a-z0-9_]/g, "").slice(0, 24);
const me = () => id(P.nick), room = () => id(P.room) || "genel", pre = () => `nera7_${room()}`, tPres = () => pre() + "_p", tGrp = () => pre() + "_g", tBox = (u) => `${pre()}_u_${u}`;
const U = { users: LSg("nera_fr_users", {}), chats: LSg("nera_fr_chat", {}), g: LSg("nera_fr_gchat", []), first: LSg("nera_fr_first", {}), chat: null, tab: localStorage.getItem("nera_fr_tab") || "grp", lastRead: LSg("nera_lastread", {}), lastG: +localStorage.getItem("nera_lastread_g") || 0, err: "", ok: false, es: null, seen: new Set() };
const ICON = { pc: '<svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/></svg>', mobil: '<svg viewBox="0 0 24 24"><rect x="7" y="2.5" width="10" height="19" rx="2.5"/><path d="M11 18.5h2"/></svg>' };
const ago = (ms) => { const s = Math.max(0, Math.floor(ms / 1000)); return s < 60 ? "az önce" : s < 3600 ? Math.floor(s / 60) + " dk" : s < 86400 ? Math.floor(s / 3600) + " sa " + (Math.floor(s / 60) % 60) + " dk" : Math.floor(s / 86400) + " gün"; };
const ini = (n) => (n || "?").slice(0, 2).toUpperCase(), col = (n) => `hsl(${[...String(n)].reduce((a, c) => a + c.charCodeAt(0), 0) * 37 % 360},60%,45%)`;
const av = (u, size = 38) => `<span class="avt" style="width:${size}px;height:${size}px;background:${u.photo ? `url(${u.photo}) center/cover` : col(u.nick)};font-size:${size * 0.4}px">${u.photo ? "" : ini(u.nick)}</span>`;
const keep = () => { LSs("nera_fr_users", U.users); LSs("nera_fr_chat", U.chats); LSs("nera_fr_gchat", U.g); LSs("nera_fr_first", U.first); LSs("nera_lastread", U.lastRead); localStorage.setItem("nera_lastread_g", String(U.lastG)); };
const pub = async (topic, obj) => { const r = await fetch(NT + topic, { method: "POST", body: JSON.stringify(obj) }); if (!r.ok) throw new Error("HTTP " + r.status); };
const notify = (o) => { if (window.NeraNotify) NeraNotify.push(o); };
const tm = (t) => new Date(t).toLocaleString("tr-TR", { hour: "2-digit", minute: "2-digit", day: "2-digit", month: "2-digit" });
const ready = () => Date.now() - START > 20000;                         // ilk eşitlemede (geçmiş mesajlar) bildirim yağmuru olmasın

/* kendi istatistiklerim (varlık mesajıyla gruba gider) */
function myStats() {
  const o = { v: "Beta" }; try { const L = window.Lab; if (L && L.cnt) { o.ts = L.cnt.test || 0; o.kp = L.cnt.kept || 0; } if (L && L.book) o.bk = L.book.length; if (window.LabSig) { const s = LabSig.summary(); o.lv = s.live; o.sn = s.t.supernova; o.ps = s.t.pulsar; } o.th = document.body.className.match(/theme-(\w+)/) ? RegExp.$1 : "dark"; } catch (e) { /* */ } return o;
}

/* gelen her ntfy mesajı */
function onMsg(m) {
  if (!m || m.event !== "message" || U.seen.has(m.id)) return; U.seen.add(m.id); if (U.seen.size > 3000) U.seen.clear(); let o; try { o = JSON.parse(m.message); } catch (e) { return; } if (!o || !o.id) return;
  if (o.k === "hb") {
    const u = U.users[o.id] = U.users[o.id] || {}, prev = u[o.plat] || {}; if ((prev.seen || 0) > o.t) return; const wasOn = Object.values(u).some((d) => d && d.seen && Date.now() - d.seen < 95000);
    u[o.plat] = { nick: String(o.nick || o.id).slice(0, 20), photo: typeof o.photo === "string" && o.photo.startsWith("data:image/") ? o.photo : prev.photo || "", seen: o.t, since: o.since || o.t, st: o.st && typeof o.st === "object" ? o.st : prev.st };
    if (!U.first[o.id]) U.first[o.id] = o.t;
    if (!wasOn && o.id !== me() && ready() && Date.now() - o.t < 60000) notify({ kind: "online", title: `${u[o.plat].nick} çevrimiçi`, body: o.plat === "pc" ? "bilgisayardan bağlandı" : "telefondan bağlandı", photo: u[o.plat].photo, nick: u[o.plat].nick, onClick: () => showStats(o.id) });
    return;
  }
  if (o.k === "gmsg") {
    if (U.g.some((x) => x.mid === o.mid)) return; U.g.push({ mid: o.mid, id: o.id, nick: String(o.nick || o.id).slice(0, 20), m: String(o.m || "").slice(0, 400), t: o.t }); U.g.sort((x, y) => x.t - y.t); if (U.g.length > 300) U.g.splice(0, U.g.length - 300);
    const viewing = document.body.dataset.view === "friends" && U.tab === "grp" && !document.hidden;
    if (o.id !== me() && !viewing && o.t > U.lastG && ready() && Date.now() - o.t < 120000) { notify({ kind: "grp", title: `#${room()} · ${o.nick || o.id}`, body: String(o.m).slice(0, 90), photo: photoOf(o.id), nick: o.nick || o.id, onClick: () => openTab("grp") }); glow(); }
    if (viewing) { U.lastG = Math.max(U.lastG, o.t); renderChat(); } else updTabs();
    return;
  }
  if (o.k === "msg") {
    const other = o.id === me() ? o.to : o.id; if (!other) return; const a = U.chats[other] = U.chats[other] || []; if (a.some((x) => x.mid === o.mid)) return; a.push({ mid: o.mid, id: o.id, m: String(o.m || "").slice(0, 400), t: o.t }); a.sort((x, y) => x.t - y.t); if (a.length > 200) a.splice(0, a.length - 200);
    const viewing = document.body.dataset.view === "friends" && U.tab === "dm" && U.chat === other && !document.hidden;
    if (o.id !== me() && !viewing && o.t > (U.lastRead[other] || 0) && ready() && Date.now() - o.t < 120000) { notify({ kind: "msg", title: o.nick || o.id, body: String(o.m).slice(0, 90), photo: photoOf(o.id), nick: o.nick || o.id, onClick: () => openChat(other) }); glow(); }
    if (viewing) { U.lastRead[other] = Math.max(U.lastRead[other] || 0, o.t); renderChat(); } else updTabs();
  }
}
const photoOf = (uid) => { const d = U.users[uid] || {}; return (Object.values(d).find((x) => x && x.photo) || {}).photo || ""; };
const glow = () => { $$('[data-v="friends"]').forEach((b) => b.classList.add("glow")); try { if (window.LM) LM.event("friends", { color: "#8a7bff", msg: "Yeni mesaj" }); } catch (x) { /* */ } };
async function poll(topic, since) { const r = await fetch(`${NT}${topic}/json?poll=1&since=${since}`); if (!r.ok) throw new Error("HTTP " + r.status); const txt = await r.text(); txt.split("\n").forEach((ln) => { if (!ln.trim()) return; try { onMsg(JSON.parse(ln)); } catch (e) { /* */ } }); }
async function connect() {
  if (U.es) { try { U.es.close(); } catch (e) { /* */ } U.es = null; } if (!me()) { upd(); return; }
  try { await poll(tPres(), "15m"); await poll(tGrp(), "12h"); await poll(tBox(me()), "12h"); U.ok = true; U.err = ""; keep(); } catch (e) { U.ok = false; U.err = String(e.message || e); }
  try { const es = new EventSource(`${NT}${tPres()},${tGrp()},${tBox(me())}/sse`); es.onmessage = (e) => { try { onMsg(JSON.parse(e.data)); U.ok = true; } catch (x) { /* */ } }; es.onerror = () => { U.ok = false; }; es.onopen = () => { U.ok = true; U.err = ""; }; U.es = es; } catch (e) { U.err = "canlı bağlantı açılamadı"; }
  beat(); upd(); renderChat();
}
async function beat() { if (!me()) return; try { await pub(tPres(), { k: "hb", id: me(), nick: P.nick, photo: P.photo || "", plat: PLAT, since: START, t: Date.now(), st: myStats() }); U.ok = true; U.err = ""; } catch (e) { U.ok = false; U.err = String(e.message || e); } upd(); }
function roster() {
  return Object.entries(U.users).map(([uid, d]) => { const devs = Object.entries(d || {}).filter(([, v]) => v && v.seen).map(([plat, v]) => ({ plat, ...v, on: Date.now() - v.seen < 95000 })), last = Math.max(0, ...devs.map((x) => x.seen)), top = devs.slice().sort((a, b) => b.seen - a.seen)[0] || {}, nick = top.nick || uid, photo = (devs.find((x) => x.photo) || {}).photo || "";
    return { uid, nick, photo, devs, st: top.st || null, on: devs.some((x) => x.on), last, since: Math.min(...devs.filter((x) => x.on).map((x) => x.since), Infinity) }; }).filter((u) => u.last > 0).sort((a, b) => b.on - a.on || b.last - a.last);
}
const unread = (uid) => (U.chats[uid] || []).filter((m) => m.id !== me() && m.t > (U.lastRead[uid] || 0)).length, unreadG = () => U.g.filter((m) => m.id !== me() && m.t > U.lastG).length;

function build() {
  const el = $("#pg-friends"); if (!el) return;
  el.innerHTML = `<div class="eyebrow">Sistem · çevrimiçi kişiler</div><h1>Arkadaşlar</h1><p class="lead">Takma adını yaz, kaydet. Aynı grup kodundakiler birbirini görür.</p>
  <div class="panel"><div class="ph">Profilim <small id="fr-st"></small></div><div class="pb"><div class="frme"><div id="fr-av" class="fr-avw" title="Fotoğraf seç"></div><div class="frfld"><label class="fld">Takma ad<input id="fr-nick" maxlength="20" placeholder="örn. adile" value="${esc(P.nick)}"></label><label class="fld">Profil fotoğrafı<input id="fr-photo" type="file" accept="image/*"></label><label class="fld">Grup kodu<input id="fr-room" maxlength="24" placeholder="genel" value="${esc(P.room)}"></label></div></div>
    <div class="ctl" style="margin-top:10px"><button class="btn pri" id="fr-save">Kaydet ve bağlan</button><span class="muted" style="font-size:11.5px">Profilin bu cihazda kalıcıdır. Grup kodunu bilen herkes grup mesajlarını okuyabilir; kişisel bilgi yazma.</span></div></div></div>
  <div class="two frgrid"><div class="panel"><div class="ph"><div class="seg frtabs" id="fr-tabs"><button data-t="grp">Grup sohbeti<em class="unr" id="fr-ug"></em></button><button data-t="dm">Özel mesajlar<em class="unr" id="fr-ud"></em></button></div><small id="fr-n"></small></div><div id="fr-list"></div></div><div class="panel" id="fr-chat"></div></div>`;
  $("#fr-photo").onchange = (e) => { const f = e.target.files[0]; if (!f) return; const im = new Image(); im.onload = () => { const c = document.createElement("canvas"), s = Math.min(im.width, im.height); c.width = c.height = 64; c.getContext("2d").drawImage(im, (im.width - s) / 2, (im.height - s) / 2, s, s, 0, 0, 64, 64); let q = 0.7, d = c.toDataURL("image/jpeg", q); while (d.length > 2600 && q > 0.3) { q -= 0.1; d = c.toDataURL("image/jpeg", q); } P.photo = d; save(); upd(); beat(); URL.revokeObjectURL(im.src); }; im.src = URL.createObjectURL(f); };
  $("#fr-av").onclick = () => $("#fr-photo").click();
  $("#fr-save").onclick = () => { const was = room(), nn = $("#fr-nick").value.trim(); if (nn) P.nick = nn; else $("#fr-nick").value = P.nick; P.room = $("#fr-room").value.trim() || "genel"; save(); if (was !== room()) { U.users = {}; U.g = []; U.lastG = 0; keep(); } connect(); };
  $$("#fr-tabs button").forEach((b) => (b.onclick = () => openTab(b.dataset.t)));
}
function updTabs() {
  $$("#fr-tabs button").forEach((b) => b.classList.toggle("on", b.dataset.t === U.tab)); const L = roster(), ug = $("#fr-ug"), ud = $("#fr-ud"); if (!ug) return;
  const g = U.tab === "grp" && document.body.dataset.view === "friends" ? 0 : unreadG(), d = L.reduce((s, u) => s + (U.tab === "dm" && u.uid === U.chat ? 0 : unread(u.uid)), 0);
  ug.textContent = g || ""; ug.style.display = g ? "" : "none"; ud.textContent = d || ""; ud.style.display = d ? "" : "none";
  $$('[data-v="friends"]').forEach((b) => b.classList.toggle("glow", g + d > 0 && document.body.dataset.view !== "friends"));
}
function upd() {
  if (!$("#fr-list")) return; const st = $("#fr-st"), a = $("#fr-av"); if (a) { const h = av({ nick: P.nick || "?", photo: P.photo }, 64); if (a._h !== h) { a._h = h; a.innerHTML = h; } }
  if (st) st.textContent = !me() ? "takma ad gir ve kaydet" : U.ok ? `bağlı · grup "${room()}" · ${PLAT === "pc" ? "PC" : "mobil"}` : U.err ? "bağlanamadı: " + U.err : "bağlanıyor…";
  const L = roster(), dm = U.tab === "dm";
  const h = L.map((u) => { const n = dm ? unread(u.uid) : 0; return `<div class="fru ${dm && U.chat === u.uid ? "sel" : ""}" data-u="${u.uid}"><span class="fr-ava" data-s="${u.uid}" title="istatistikler">${av(u)}</span><div class="frm"><b>${esc(u.nick)}${u.uid === me() ? ' <span class="muted">(sen)</span>' : ""}</b><span class="muted">${u.on ? `çevrimiçi · ${ago(Date.now() - u.since)}dır aktif` : `son görülme ${ago(Date.now() - u.last)} önce`}</span></div><div class="frp">${u.devs.map((d) => `<i class="${d.on ? "on" : ""}" title="${d.plat}">${ICON[d.plat] || ""}</i>`).join("")}</div><i class="dotp ${u.on ? "on" : ""}"></i>${n ? `<em class="unr">${n}</em>` : ""}</div>`; }).join("") || '<div class="pb muted">Henüz kimse görünmüyor. Aynı grup kodunu kullanan arkadaşların açınca burada belirir.</div>';
  const le = $("#fr-list"); if (le._h !== h) { le._h = h; le.innerHTML = h; $$(".fru", le).forEach((e) => (e.onclick = (ev) => { if (ev.target.closest(".fr-ava") || !dm) showStats(e.dataset.u); else openChat(e.dataset.u); })); }
  $("#fr-n").textContent = `${L.filter((x) => x.on).length} çevrimiçi`; updTabs();
}
function openTab(t) { U.tab = t; localStorage.setItem("nera_fr_tab", t); if (document.body.dataset.view !== "friends" && window.Lab && Lab.go) Lab.go("friends"); if (t === "grp") { U.lastG = U.g.length ? U.g[U.g.length - 1].t : U.lastG; keep(); document.body.classList.add("chat-open"); } else if (!U.chat) document.body.classList.remove("chat-open"); else document.body.classList.add("chat-open"); renderChat(true); upd(); }
function openChat(uid) { U.tab = "dm"; localStorage.setItem("nera_fr_tab", "dm"); U.chat = uid; if (document.body.dataset.view !== "friends" && window.Lab && Lab.go) Lab.go("friends"); const a = U.chats[uid] || []; U.lastRead[uid] = a.length ? a[a.length - 1].t : Date.now(); keep(); closeStats(); renderChat(true); upd(); document.body.classList.add("chat-open"); }

/* sohbet: yalnız YENİ mesajlar eklenir (eski balonlar yeniden çizilip "gidip gelmez") */
function bubble(m, grp) { const d = document.createElement("div"); d.className = "msg" + (m.id === me() ? " me" : ""); d.dataset.mid = m.mid; d.innerHTML = `${grp && m.id !== me() ? `<b class="mn" style="color:${col(m.nick || m.id)}">${esc(m.nick || m.id)}</b>` : ""}<span>${esc(m.m)}</span><i>${tm(m.t)}</i>`; return d; }
function renderChat(force) {
  const box = $("#fr-chat"); if (!box) return; const grp = U.tab === "grp", key = grp ? "#g" : U.chat;
  if (!grp && !U.chat) { if (box._k !== "") { box._k = ""; box.innerHTML = '<div class="ph">Özel mesajlar</div><div class="pb muted" style="padding:30px;text-align:center">Mesajlaşmak için soldan bir kişiye dokun.</div>'; } return; }
  const u = grp ? null : roster().find((x) => x.uid === U.chat) || { nick: U.chat, devs: [], on: false, last: 0 };
  if (box._k !== key || force && !box.querySelector("#fr-msgs")) {
    box._k = key; box.innerHTML = `<div class="ph"><button class="btn bk2" id="fr-back">‹</button>${grp ? '<span class="grpic">#</span>' : av(u, 26)} <span>${grp ? esc(room()) : esc(u.nick)}</span><small id="fr-s2"></small>${grp ? "" : `<button class="btn" id="fr-ist" style="margin-left:auto;padding:3px 10px">İstatistik</button>`}</div><div id="fr-msgs"></div><form id="fr-form" class="frform"><input id="fr-in" placeholder="${grp ? "gruba yaz…" : "mesaj yaz…"}" autocomplete="off" maxlength="400"><button class="btn pri">Gönder</button></form>`;
    const ms = $("#fr-msgs"); ms._mids = new Set(); ms.classList.add("still");
    $("#fr-form").onsubmit = async (e) => { e.preventDefault(); const inp = $("#fr-in"), v = inp.value.trim(); if (!v || !me()) return; inp.value = ""; inp.focus(); const o = { k: grp ? "gmsg" : "msg", id: me(), nick: P.nick, t: Date.now(), m: v, mid: Math.random().toString(36).slice(2, 12) }; if (!grp) o.to = U.chat;
      onMsg({ event: "message", id: "loc" + o.mid, message: JSON.stringify(o) }); keep(); try { if (grp) await pub(tGrp(), o); else { await pub(tBox(U.chat), o); if (U.chat !== me()) await pub(tBox(me()), o); } } catch (er) { U.err = String(er.message); upd(); } };
    $("#fr-back").onclick = () => document.body.classList.remove("chat-open"); const ist = $("#fr-ist"); if (ist) ist.onclick = () => showStats(U.chat);
  }
  const s2 = $("#fr-s2"), t2 = grp ? ` ${roster().filter((x) => x.on).length} çevrimiçi` : u.on ? " çevrimiçi" : u.last ? " son görülme " + ago(Date.now() - u.last) + " önce" : ""; if (s2 && s2.textContent !== t2) s2.textContent = t2;
  const ms = $("#fr-msgs"), list = grp ? U.g : U.chats[U.chat] || [], near = ms.scrollHeight - ms.scrollTop - ms.clientHeight < 80; let added = 0, mine = false;
  const emp = ms.querySelector(".fr-empty"); if (!list.length) { if (!emp) ms.innerHTML = `<div class="muted fr-empty" style="padding:20px;text-align:center">${grp ? "Grupta henüz mesaj yok. İlk mesajı sen yaz." : "Henüz mesaj yok."}</div>`; return; } if (emp) emp.remove();
  for (const m of list) { if (ms._mids.has(m.mid)) continue; ms._mids.add(m.mid); const b = bubble(m, grp), nx = [...ms.children].find((c) => +c.dataset.t > m.t); b.dataset.t = m.t; if (nx) ms.insertBefore(b, nx); else ms.appendChild(b); added++; if (m.id === me()) mine = true; }
  if (added && (near || mine || ms.classList.contains("still"))) ms.scrollTop = ms.scrollHeight; if (added) requestAnimationFrame(() => ms.classList.remove("still"));
  if (document.body.dataset.view === "friends") { if (grp) U.lastG = Math.max(U.lastG, list[list.length - 1].t); else U.lastRead[U.chat] = Math.max(U.lastRead[U.chat] || 0, list[list.length - 1].t); if (added) { keep(); updTabs(); } }
}

/* arkadaş istatistik kartı */
function closeStats() { const m = $("#fr-stats"); if (m) { m.classList.remove("on"); setTimeout(() => m.remove(), 260); } }
function showStats(uid) {
  closeStats(); const u = roster().find((x) => x.uid === uid); if (!u) return; const st = u.st || {}, dm = (U.chats[uid] || []).length, gm = U.g.filter((m) => m.id === uid).length, nf = (x) => (x == null ? "—" : Number(x).toLocaleString("tr-TR"));
  const tiles = [["Test edilen tarif", nf(st.ts)], ["Kalıcı strateji", nf(st.kp)], ["Defterde", nf(st.bk)], ["Sinyal veren (★/✦)", st.lv == null ? "—" : `${st.lv} <small>${st.sn || 0}★ ${st.ps || 0}✦</small>`], ["Özel mesaj", nf(dm)], ["Grup mesajı", nf(gm)]];
  const m = document.createElement("div"); m.id = "fr-stats"; m.innerHTML = `<div class="frs-card"><button class="frs-x">✕</button><div class="frs-hd">${av(u, 68)}<div><b>${esc(u.nick)}${uid === me() ? " (sen)" : ""}</b><span class="${u.on ? "na" : "muted"}">${u.on ? `çevrimiçi · ${ago(Date.now() - u.since)}dır aktif` : `son görülme ${ago(Date.now() - u.last)} önce`}</span><span class="muted">${u.devs.map((d) => `${d.plat === "pc" ? "PC" : "Telefon"}${d.on ? " ●" : ""}`).join(" · ")} · Nera ${esc(st.v || "Beta")}${st.th ? " · tema " + esc(st.th) : ""}</span></div></div>
    <div class="frs-grid">${tiles.map(([k, v], i) => `<div class="frs-t" style="animation-delay:${0.05 + i * 0.05}s"><span>${k}</span><b>${v}</b></div>`).join("")}</div>
    <div class="frs-ft muted">İlk görülme ${U.first[uid] ? new Date(U.first[uid]).toLocaleDateString("tr-TR") : "—"} · istatistikler onun uygulamasından gelir</div>${uid !== me() ? '<div class="ctl" style="justify-content:center;margin-top:12px"><button class="btn pri" id="frs-dm">Özel mesaj</button></div>' : ""}</div>`;
  document.body.appendChild(m); requestAnimationFrame(() => m.classList.add("on"));
  m.onclick = (e) => { if (e.target === m || e.target.closest(".frs-x")) closeStats(); }; const b = $("#frs-dm", m); if (b) b.onclick = () => openChat(uid);
}

window.NeraFriends = { openChat, openTab, showStats };
window.addEventListener("DOMContentLoaded", () => {
  build(); upd(); renderChat(true); restoreFile(); setTimeout(connect, 2500); setInterval(beat, 40000);
  setInterval(() => { if (document.body.dataset.view === "friends") { upd(); renderChat(); } keep(); }, 5000);
  document.addEventListener("visibilitychange", () => { if (!document.hidden) { beat(); if (!U.es || U.es.readyState === 2) connect(); } });
  DT.on("view", (v) => { if (v === "friends") { if (U.tab === "grp") U.lastG = U.g.length ? U.g[U.g.length - 1].t : U.lastG; upd(); renderChat(); } });
});
})();
