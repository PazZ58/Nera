"use strict";
/* Nera · XM botu paneli (Ayarlar). PC: yerel sunucu /api/bot (tam kontrol). Telefon: eşleştirme koduyla uzaktan izleme + duraklat/devam/kapat
   (ntfy.sh gizli konusu; komutlar HMAC-SHA256 ile imzalanır, PC doğrular). İşlemi PC'deki bot açar; MT5 telefonda çalışmaz. */
(function () {
const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s == null ? "" : s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const NT = "https://ntfy.sh/", isPhone = () => !!(window.LOCAL_API || window.Capacitor), NM = { XAUUSDT: "Altın", XAGUSDT: "Gümüş", EURUSD: "EUR/USD" };
const money = (x, c = "$") => (x == null ? "—" : `${x >= 0 ? "+" : "−"}${Math.abs(x).toFixed(2)} ${c === "USD" ? "$" : c}`);
const ago = (t) => { const s = Math.max(0, Date.now() / 1000 - t); return s < 60 ? Math.floor(s) + " sn" : s < 3600 ? Math.floor(s / 60) + " dk" : Math.floor(s / 3600) + " sa"; };
let S = null, built = false;

/* merdiven görseli: basamaklar, şu anki basamak parlar */
const ladder = (p) => { const n = p.steps || 5; let h = ""; for (let i = n; i >= 1; i--) h += `<i class="${i <= p.n ? "on" : ""} ${i === p.n + 1 ? "nx" : ""}" style="--d:${(n - i) * 0.06}s"></i>`; return `<div class="bt-lad" title="${p.n}/${n} basamak">${h}</div>`; };
const posRow = (p, cur) => `<div class="bt-pos ${p.side > 0 ? "L" : "S"}">${ladder(p)}<div class="bt-pi"><b>${esc(p.sym)} ${p.side > 0 ? "LONG" : "SHORT"} · ${p.vol} lot</b><span class="muted">giriş ${p.open} · stop ${p.sl || "—"} · şimdi ${p.now}</span><span class="muted">basamak ${p.n}/${p.steps}${p.step ? " · adım " + p.step : ""}</span></div><b class="bt-pl ${p.pnl >= 0 ? "na" : "down"}">${money(p.pnl, cur)}</b></div>`;
const logRow = (l) => `<div class="bt-lg k-${l.k}"><i>${ago(l.t)}</i><span>${esc(l.m)}</span></div>`;

function head(s) {
  const on = s.on != null ? s.on : s.cfg && s.cfg.on, paused = s.paused != null ? s.paused : s.cfg && s.cfg.paused, a = s.acct || {};
  const state = !s.xm ? ["XM BAĞLI DEĞİL", "off"] : !on ? ["KAPALI", "off"] : paused ? ["DURAKLADI", "pause"] : s.cool > 0 ? [`MOLA ${Math.ceil(s.cool / 60)} dk`, "pause"] : ["ÇALIŞIYOR", "run"];
  return `<div class="up-row bt-head"><div class="bt-orb ${state[1]}"><i></i><i></i><i></i></div><div class="up-v"><span>Durum</span><b class="bt-st ${state[1]}">${state[0]}</b></div><div class="up-v"><span>Hesap</span><b style="font-size:16px" class="${a.real ? "down" : ""}">${a.mode || "—"}${a.eq != null ? ` · ${Number(a.eq).toFixed(2)} ${a.cur === "USD" ? "$" : a.cur || ""}` : ""}</b></div><div class="up-v"><span>Bugün</span><b class="${(s.day || 0) >= 0 ? "na" : "down"}">${s.day == null ? "—" : money(s.day, a.cur)}</b></div><div class="up-v"><span>İşlem</span><b>${s.trades || 0}</b></div></div>`;
}

/* ---------------- PC: tam panel */
async function api(body) { try { const r = await fetch("/api/bot", body ? { method: "POST", body: JSON.stringify(body) } : { cache: "no-store" }); return await r.json(); } catch (e) { return null; } }
function buildPC(p) {
  const c = S.cfg, num = (k, lab, st = 1, sub = "") => `<label class="fld">${lab}<input type="number" step="${st}" data-c="${k}" value="${c[k]}">${sub ? `<small class="muted">${sub}</small>` : ""}</label>`;
  p.innerHTML = `<div class="ph">XM botu · merdiven <small>sinyale göre işlem açar, kâr basamak basamak kilitlenir</small></div><div class="pb">
    <div id="bt-head"></div>
    <div class="ctl" style="margin:12px 0"><button class="btn pri" id="bt-on"></button><button class="btn" id="bt-pause"></button><button class="btn warn" id="bt-close">Tümünü kapat</button><span class="muted" style="font-size:11.5px">Önce DEMO hesapta dene. Sinyaller kanıtlanmış kârlı değildir; zarar edebilirsin.</span></div>
    <div id="bt-pos"></div>
    <details class="bt-adv"><summary>Bot ayarları</summary>
      <div class="bt-grid">${num("risk_usd", "İşlem başı risk ($)", 1, "stopa değerse kaybedilecek tutar")}${num("max_lot", "En büyük lot", 0.01)}${num("max_loss_day", "Günlük zarar sınırı ($)", 1)}${num("max_trades_day", "Günlük işlem sınırı", 1)}${num("steps", "Basamak sayısı", 1, "son basamakta tamamı kapanır")}${num("partial", "Basamakta kâr al (oran)", 0.05, "0 = kısmi kapatma yok")}${num("be_buf", "Başa baş tamponu (adımın oranı)", 0.05)}${num("max_spread", "En çok spread (adımın oranı)", 0.05)}${num("cool_losses", "Ardışık kayıpta mola", 1)}${num("cool_min", "Mola (dk)", 5)}</div>
      <div class="setrow"><div><b>Semboller</b></div><div class="seg" id="bt-syms">${Object.keys(NM).map((s) => `<button data-s="${s}" class="${c.syms[s] ? "on" : ""}">${NM[s]}</button>`).join("")}</div><span></span></div>
      <div class="setrow"><div><b>Nera sinyal zaman dilimleri</b></div><div class="seg" id="bt-tfs">${["5m", "15m", "1h", "4h"].map((t) => `<button data-t="${t}" class="${c.tfs.includes(t) ? "on" : ""}">${t}</button>`).join("")}</div><span></span></div>
      <div class="setrow"><div><b>Merdiven adımı</b><div class="muted" style="font-size:11px">sabit: aşağıdaki fiyat farkı · otomatik: sinyalin stop mesafesinin yarısı</div></div><div class="seg" id="bt-sm">${[["fixed", "Sabit"], ["auto", "Otomatik"]].map(([k, n]) => `<button data-m="${k}" class="${c.step_mode === k ? "on" : ""}">${n}</button>`).join("")}</div><span></span></div>
      <div class="bt-grid">${Object.keys(NM).map((s) => `<label class="fld">${NM[s]} adımı<input type="number" step="${s === "EURUSD" ? 0.0001 : 0.01}" data-st="${s}" value="${c.step[s]}"></label>`).join("")}</div>
      <div class="setrow"><div><b>Lab sinyalleriyle de işlem aç</b><div class="muted" style="font-size:11px">yalnız ★ Süpernova ve ✦ Pulsar</div></div><label class="sw"><input type="checkbox" id="bt-lab" ${c.use_lab ? "checked" : ""}><i></i></label><span></span></div>
      <div class="setrow"><div><b>Ters sinyalde pozisyonu çevir</b></div><label class="sw"><input type="checkbox" id="bt-rev" ${c.reverse ? "checked" : ""}><i></i></label><span></span></div>
      <div class="setrow"><div><b>Gerçek hesapta işlem izni</b><div class="muted" style="font-size:11px">kapalıyken bot yalnız DEMO hesapta işlem açar</div></div><label class="sw"><input type="checkbox" id="bt-real" ${c.allow_real ? "checked" : ""}><i></i></label><span></span></div>
      <div class="ctl" style="margin-top:8px"><button class="btn pri" id="bt-save">Ayarları kaydet</button><span class="muted" id="bt-msg" style="font-size:12px"></span></div>
    </details>
    <details class="bt-adv"><summary>Telefondan kumanda</summary><div class="pb" style="padding:10px 0"><div class="muted" style="font-size:12px">Telefonda Ayarlar › XM botu bölümüne bu kodu yaz. Telefon durumu görür; duraklat, devam, tümünü kapat ve durdur komutlarını gönderebilir. Kodu kimseyle paylaşma.</div><div class="bt-code" id="bt-code"></div><button class="btn" id="bt-np">Yeni kod üret</button></div></details>
    <div class="ph" style="margin-top:6px">Bot günlüğü</div><div id="bt-log" class="bt-logs"></div></div>`;
  $("#bt-on", p).onclick = async () => { S = await api({ cfg: { on: !S.cfg.on } }); draw(); };
  $("#bt-pause", p).onclick = async () => { S = await api({ cfg: { paused: !S.cfg.paused } }); draw(); };
  $("#bt-close", p).onclick = async () => { if (confirm("Botun açtığı tüm pozisyonlar şimdi kapatılsın mı?")) { S = await api({ act: "close_all" }); draw(); } };
  $("#bt-np", p).onclick = async () => { if (confirm("Yeni kod üretilince eski kodlu telefon bağlantısı kopar. Devam?")) { S = await api({ act: "new_pair" }); draw(); } };
  $$("#bt-syms button, #bt-tfs button, #bt-sm button", p).forEach((b) => (b.onclick = () => { if (b.dataset.m) $$("#bt-sm button", p).forEach((x) => x.classList.toggle("on", x === b)); else b.classList.toggle("on"); }));
  $("#bt-real", p).onchange = async (e) => { if (e.target.checked) { const w = prompt("Bot GERÇEK paranla işlem açabilecek. Zarar riski tamamen sana ait. Onaylamak için ONAYLIYORUM yaz:"); if (w !== "ONAYLIYORUM") { e.target.checked = false; return; } } S = await api({ act: e.target.checked ? "real_on" : "real_off" }); draw(); };
  $("#bt-save", p).onclick = async () => {
    const cfg = { syms: {}, step: {}, tfs: $$("#bt-tfs button.on", p).map((b) => b.dataset.t), step_mode: ($("#bt-sm button.on", p) || {}).dataset.m || "fixed", use_lab: $("#bt-lab", p).checked, reverse: $("#bt-rev", p).checked };
    $$("#bt-syms button", p).forEach((b) => (cfg.syms[b.dataset.s] = b.classList.contains("on"))); $$("[data-st]", p).forEach((i) => (cfg.step[i.dataset.st] = +i.value)); $$("[data-c]", p).forEach((i) => (cfg[i.dataset.c] = +i.value));
    S = await api({ cfg }); $("#bt-msg", p).textContent = "kaydedildi ✓"; setTimeout(() => { const m = $("#bt-msg", p); if (m) m.textContent = ""; }, 2500); draw(); };
}
function draw() {
  const p = $("#bot-panel"); if (!p || !S) return; if (!isPhone() && !built) { buildPC(p); built = true; }
  const cur = (S.acct || {}).cur; const hh = head(S); const he = $("#bt-head", p); if (he && he._h !== hh) { he._h = hh; he.innerHTML = hh; }
  const on = $("#bt-on", p); if (on) { on.textContent = S.cfg.on ? "Botu durdur" : "Botu başlat"; on.className = "btn " + (S.cfg.on ? "warn" : "pri"); }
  const pa = $("#bt-pause", p); if (pa) pa.textContent = S.cfg.paused ? "Devam et" : "Duraklat";
  const ph = (S.pos || []).map((x) => posRow(x, cur)).join("") || '<div class="muted bt-empty">Açık bot pozisyonu yok.</div>'; const pe = $("#bt-pos", p); if (pe && pe._h !== ph) { pe._h = ph; pe.innerHTML = ph; }
  const lh = (S.log || []).map(logRow).join("") || '<div class="muted">Henüz kayıt yok.</div>'; const le = $("#bt-log", p); if (le && le._h !== lh) { le._h = lh; le.innerHTML = lh; }
  const cd = $("#bt-code", p); if (cd && S.pair && cd.textContent !== S.pair) cd.textContent = S.pair;
}

/* ---------------- telefon: uzaktan kumanda */
const PK = () => { const v = (localStorage.getItem("nera_bot_pair") || "").trim(); const i = v.lastIndexOf("-"); return i > 0 ? { topic: "nera_bot_" + v.slice(0, i), key: v.slice(i + 1) } : null; };
let es = null;
async function sign(cmd, t, key) { const k = await crypto.subtle.importKey("raw", new TextEncoder().encode(key), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]); const b = await crypto.subtle.sign("HMAC", k, new TextEncoder().encode(`${cmd}|${t}`)); return [...new Uint8Array(b)].map((x) => x.toString(16).padStart(2, "0")).join(""); }
async function send(cmd) { const pk = PK(); if (!pk) return; const t = Date.now(), sig = await sign(cmd, t, pk.key); try { await fetch(NT + pk.topic + "_c", { method: "POST", body: JSON.stringify({ cmd, t, sig }) }); flash(cmd); } catch (e) { flash("hata"); } }
const flash = (c) => { const m = $("#bt-msg"); if (m) { m.textContent = { pause: "duraklat gönderildi", resume: "devam gönderildi", close_all: "kapat gönderildi", stop: "durdur gönderildi" }[c] || "gönderilemedi"; setTimeout(() => (m.textContent = ""), 3000); } };
function onSt(o) { if (!o || o.k !== "st") return; const was = S; S = Object.assign({ cfg: { on: o.on, paused: o.paused } }, o, { at: Date.now() }); draw(); if (was && was.pos && o.pos && o.pos.length > was.pos.length && window.NeraNotify) NeraNotify.push({ kind: "app", title: "XM botu işlem açtı", body: o.log && o.log[0] ? o.log[0].m : "" }); }
async function phoneConnect() {
  if (es) { es.close(); es = null; } const pk = PK(); if (!pk) return draw();
  try { const r = await fetch(`${NT}${pk.topic}_s/json?poll=1&since=30m`); (await r.text()).split("\n").filter(Boolean).forEach((ln) => { try { const m = JSON.parse(ln); if (m.event === "message") onSt(JSON.parse(m.message)); } catch (e) { /* */ } }); } catch (e) { /* */ }
  es = new EventSource(`${NT}${pk.topic}_s/sse`); es.onmessage = (e) => { try { onSt(JSON.parse(JSON.parse(e.data).message)); } catch (x) { /* */ } };
}
function buildPhone(p) {
  p.innerHTML = `<div class="ph">XM botu · uzaktan <small id="bt-age"></small></div><div class="pb"><div class="muted" style="font-size:12px">İşlemleri PC'deki Nera açar (MT5 telefonda çalışmaz). PC'de Ayarlar › XM botu › Telefondan kumanda'daki kodu buraya yaz.</div>
    <label class="fld" style="margin-top:8px">Eşleştirme kodu<input id="bt-pair" autocomplete="off" placeholder="ör. 3f9a…-b21c…" value="${esc(localStorage.getItem("nera_bot_pair") || "")}"></label><div class="ctl" style="margin-top:8px"><button class="btn pri" id="bt-pc">Bağlan</button><span class="muted" id="bt-msg" style="font-size:12px"></span></div>
    <div id="bt-head" style="margin-top:12px"></div><div class="ctl bt-rc" style="margin:12px 0"><button class="btn" data-c="pause">Duraklat</button><button class="btn" data-c="resume">Devam</button><button class="btn warn" data-c="close_all">Tümünü kapat</button><button class="btn warn" data-c="stop">Durdur</button></div><div id="bt-pos"></div><div id="bt-log" class="bt-logs"></div></div>`;
  $("#bt-pc", p).onclick = () => { localStorage.setItem("nera_bot_pair", $("#bt-pair", p).value.trim()); if (window.NERA_SAVE) NERA_SAVE(); S = null; phoneConnect(); flash("ok"); $("#bt-msg", p).textContent = "bağlanıyor…"; };
  $$(".bt-rc button", p).forEach((b) => (b.onclick = () => { if (["close_all", "stop"].includes(b.dataset.c) && !confirm(b.dataset.c === "stop" ? "Bot durdurulsun mu?" : "Tüm bot pozisyonları kapatılsın mı?")) return; send(b.dataset.c); }));
}

async function panel() {
  const pg = $("#pg-set"); if (!pg) return; let p = $("#bot-panel");
  if (!p) { p = document.createElement("div"); p.className = "panel bot-panel"; p.id = "bot-panel"; const xm = $("#xm-panel"), lead = pg.querySelector(".lead"); if (xm) xm.after(p); else if (lead) lead.after(p); else pg.prepend(p); built = false; if (isPhone()) { buildPhone(p); phoneConnect(); } }
  if (!isPhone()) { const s = await api(); if (s) { S = s; draw(); } } else { const a = $("#bt-age", p); if (a) a.textContent = S && S.at ? `son durum ${ago(S.t || S.at / 1000)} önce` : PK() ? "bekleniyor…" : "eşleşmedi"; draw(); }
}
DT.on("view", (v) => { if (v === "set") setTimeout(panel, 300); });
setInterval(() => { if (document.body.dataset.view === "set" && !document.hidden) panel(); }, 2000);
setTimeout(() => { if (isPhone() && PK()) phoneConnect(); }, 6000);
})();
