"use strict";
/* Nera · bildirim merkezi: köşede küçük, temaya göre animasyonlu canlı kartlar + telefonda bildirim paneli (Capacitor LocalNotifications)
   ve PC'de pencere arka plandayken Windows bildirimi. Türler: msg (özel mesaj), grp (grup), online (arkadaş geldi), upd (güncelleme), app (uygulama).
   Ayarlar › Bildirimler (nera_ntf). */
(function () {
const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const DEF = { on: true, pos: "br", dur: 6, sound: true, sys: true, msg: true, grp: true, online: true, upd: true, app: true };
const S = Object.assign({}, DEF, (() => { try { return JSON.parse(localStorage.getItem("nera_ntf") || "{}"); } catch (e) { return {}; } })());
const store = () => { try { localStorage.setItem("nera_ntf", JSON.stringify(S)); } catch (e) { /* */ } if (window.NERA_SAVE) setTimeout(window.NERA_SAVE, 50); };
const KIND = { msg: ["Özel mesaj", "#8a7bff"], grp: ["Grup sohbeti", "#35e0c4"], online: ["Arkadaş çevrimiçi", "#26c6a0"], upd: ["Güncelleme", "#ffb04a"], app: ["Nera", "#35e0c4"] };
const ICO = {
  msg: '<svg viewBox="0 0 24 24"><path d="M4 5h16v10H9l-5 4z"/></svg>', grp: '<svg viewBox="0 0 24 24"><path d="M5 5h14v9H10l-5 4z"/><path d="M9 9h6M9 11.5h4"/></svg>',
  online: '<svg viewBox="0 0 24 24"><circle cx="12" cy="9" r="4"/><path d="M4.5 20c1.4-3.6 4.2-5 7.5-5s6.1 1.4 7.5 5"/></svg>', upd: '<svg viewBox="0 0 24 24"><path d="M12 19V6M6.5 11.5 12 6l5.5 5.5"/><path d="M5 21h14"/></svg>',
  app: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="5"/><ellipse cx="12" cy="12" rx="10" ry="3.6" transform="rotate(-22 12 12)"/></svg>',
};
const LN = () => window.Capacitor && Capacitor.Plugins && Capacitor.Plugins.LocalNotifications;
let chan = false, nid = 1;
async function sys(o) {
  if (!S.sys) return; const text = String(o.body || "").replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
  try {
    const L = LN(); if (L) { if (!chan) { chan = true; try { await L.createChannel({ id: "nera_genel", name: "Nera bildirimleri", description: "Arkadaşlar, mesajlar ve güncellemeler", importance: 4, visibility: 1, vibration: true }); } catch (e) { /* */ } }
      await L.schedule({ notifications: [{ id: 1500000000 + (Date.now() % 400000000) + nid++, title: o.title, body: text.slice(0, 200), channelId: "nera_genel", schedule: { at: new Date(Date.now() + 250) } }] }); return; }
    if ("Notification" in window && Notification.permission === "granted" && document.hidden) { const n = new Notification(o.title, { body: text.slice(0, 200), icon: "logo.png", tag: o.kind + (o.nick || "") }); n.onclick = () => { window.focus(); if (o.onClick) o.onClick(); n.close(); }; }
  } catch (e) { /* bildirim izni yok */ }
}
function host() { let h = $("#nn-host"); if (!h) { h = document.createElement("div"); h.id = "nn-host"; document.body.appendChild(h); } h.className = "p-" + S.pos; return h; }
function chime(kind) {
  if (!S.sound) return; try { const A = window.Sound && Sound.ctx ? Sound.ctx : (window.__nnac = window.__nnac || new (window.AudioContext || window.webkitAudioContext)()), t = A.currentTime, notes = kind === "upd" ? [523, 659, 784, 1047] : kind === "online" ? [587, 880] : [740, 988];
    notes.forEach((f, i) => { const o = A.createOscillator(), g = A.createGain(); o.type = "sine"; o.frequency.value = f; g.gain.setValueAtTime(0, t + i * 0.09); g.gain.linearRampToValueAtTime(0.07, t + i * 0.09 + 0.02); g.gain.exponentialRampToValueAtTime(0.0008, t + i * 0.09 + 0.5); o.connect(g); g.connect(A.destination); o.start(t + i * 0.09); o.stop(t + i * 0.09 + 0.55); }); } catch (e) { /* ses yok */ }
}
/* o: {kind, title, body | html, photo, nick, color, onClick, action:[etiket, fn], sticky, force} */
function push(o) {
  o = Object.assign({ kind: "app" }, o); if (!o.force && (!S.on || S[o.kind] === false)) return; const [lab, c0] = KIND[o.kind] || KIND.app, h = host(), col = o.color || c0;
  if (o.kind === "upd" || o.kind !== "app" && document.hidden) sys(o);           // güncelleme her zaman panele; diğerleri uygulama arka plandayken
  const ic = o.photo ? `<span class="nn-ph" style="background:url(${o.photo}) center/cover"></span>` : o.nick ? `<span class="nn-ph" style="background:hsl(${[...String(o.nick)].reduce((a, ch) => a + ch.charCodeAt(0), 0) * 37 % 360},60%,45%)">${esc(o.nick.slice(0, 2).toUpperCase())}</span>` : ICO[o.kind] || ICO.app;
  const el = document.createElement("div"); el.className = "nn-card k-" + o.kind; if (o.color || !/theme-(halloween|neon|matrix|ocean|forest|sunset)/.test(document.body.className)) el.style.setProperty("--nk", col); const dur = o.sticky ? 0 : Math.max(2, S.dur) * 1000;
  el.innerHTML = `<span class="nn-fx"><i></i><i></i><i></i><i></i><i></i></span><div class="nn-ic"><span class="nn-orb"></span>${ic}</div><div class="nn-tx"><em>${lab}</em><b>${esc(o.title || lab)}</b>${o.html ? `<span>${o.html}</span>` : o.body ? `<span>${esc(o.body)}</span>` : ""}${o.action ? `<button class="nn-act">${esc(o.action[0])}</button>` : ""}</div><button class="nn-x" aria-label="kapat">✕</button>${dur ? `<i class="nn-bar" style="animation-duration:${dur}ms"></i>` : ""}`;
  h.prepend(el); while (h.children.length > 4) h.lastChild.remove(); requestAnimationFrame(() => el.classList.add("in")); chime(o.kind);
  let tmr = 0, left = dur, t0 = Date.now(); const out = () => { clearTimeout(tmr); el.classList.add("out"); setTimeout(() => el.remove(), 420); };
  if (dur) { tmr = setTimeout(out, dur); el.onmouseenter = () => { clearTimeout(tmr); left -= Date.now() - t0; el.classList.add("hold"); }; el.onmouseleave = () => { t0 = Date.now(); el.classList.remove("hold"); tmr = setTimeout(out, Math.max(800, left)); }; }
  el.onclick = (e) => { if (e.target.closest(".nn-x")) return out(); if (e.target.closest(".nn-act")) { o.action[1](); return out(); } if (o.onClick) { o.onClick(); out(); } };
  try { if (window.LM && o.kind !== "app") LM.event(o.kind === "upd" ? "set" : "friends", { color: col, msg: o.title }); } catch (e) { /* */ }
  return el;
}

/* Ayarlar › Bildirimler */
const sw = (k) => `<label class="sw"><input type="checkbox" data-nk="${k}" ${S[k] ? "checked" : ""}><i></i></label>`;
function panel() {
  const pg = $("#pg-set"); if (!pg || $("#nn-panel")) return; const p = document.createElement("div"); p.className = "panel"; p.id = "nn-panel";
  const row = (k, t, d) => `<div class="setrow"><div><b>${t}</b>${d ? `<div class="muted" style="font-size:11px">${d}</div>` : ""}</div>${sw(k)}<span></span></div>`;
  p.innerHTML = `<div class="ph">Bildirim paneli <small>köşedeki canlı kartlar · temaya göre</small><div class="sp"><button class="btn" id="nn-test">Dene</button></div></div>
    ${row("on", "Bildirimler açık")}${row("msg", "Özel mesaj")}${row("grp", "Grup sohbeti")}${row("online", "Arkadaş çevrimiçi oldu")}${row("upd", "Güncelleme hazır")}${row("app", "Uygulama bildirimleri", "strateji, sinyal beyni ve diğer kısa bilgiler")}${row("sound", "Bildirim sesi")}${row("sys", "Telefon / Windows bildirim paneli", "uygulama arka plandayken sistem bildirimi; güncelleme her zaman")}
    <div class="setrow"><div><b>Konum</b></div><div class="seg" id="nn-pos">${[["br", "Sağ alt"], ["tr", "Sağ üst"], ["bl", "Sol alt"]].map(([k, n]) => `<button data-p="${k}" class="${S.pos === k ? "on" : ""}">${n}</button>`).join("")}</div><span></span></div>
    <div class="setrow"><div><b>Ekranda kalma süresi</b></div><select id="nn-dur" class="sel">${[4, 6, 10, 15].map((d) => `<option value="${d}" ${S.dur === d ? "selected" : ""}>${d} saniye</option>`).join("")}</select><span></span></div>`;
  const up = $("#upd-panel"), lead = pg.querySelector(".lead"); if (up) up.before(p); else if (lead) lead.after(p); else pg.prepend(p);
  $$("input[data-nk]", p).forEach((i) => (i.onchange = () => { S[i.dataset.nk] = i.checked; store(); if (i.dataset.nk === "sys" && i.checked) perm(); }));
  $$("#nn-pos button", p).forEach((b) => (b.onclick = () => { S.pos = b.dataset.p; store(); $$("#nn-pos button", p).forEach((x) => x.classList.toggle("on", x === b)); host(); }));
  $("#nn-dur", p).onchange = (e) => { S.dur = +e.target.value; store(); };
  $("#nn-test", p).onclick = () => { perm(); const k = ["msg", "online", "grp", "upd"][(panel.n = ((panel.n || 0) + 1) % 4)]; push({ kind: k, force: true, title: k === "upd" ? "Yeni Beta güncellemesi hazır" : k === "online" ? "Deneme çevrimiçi" : k === "grp" ? "#genel · Deneme" : "Deneme", body: k === "upd" ? "İndirildi ve doğrulandı." : "Bildirim paneli böyle görünür.", nick: k === "upd" ? "" : "Deneme" }); };
}
function perm() { try { const L = LN(); if (L) L.requestPermissions(); else if ("Notification" in window && Notification.permission === "default") Notification.requestPermission(); } catch (e) { /* */ } }

window.NeraNotify = { push, settings: S, perm };
window.addEventListener("DOMContentLoaded", () => { host(); if (window.DT) DT.on("view", (v) => { if (v === "set") setTimeout(panel, 250); }); setInterval(() => { if (document.body.dataset.view === "set") panel(); }, 3000); });
})();
