"use strict";
/* Nera · XM Botu ekranı (yalnız PC). Beyin: dönen çift sarmal "merdiven" + çevresinde nöron bulutu. Her açık işlem sarmalda bulunduğu
   basamakta parlayan bir küre olarak tırmanır; yeni işlem patlama, stop yukarı çekilince basamak parlaması, kapanışta kıvılcım.
   Veri: /api/bot (pro_bot.Bot.status) görünürken 1 sn, değilse 6 sn'de bir. */
(function () {
if (window.LOCAL_API || window.Capacitor) return;
const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s == null ? "" : s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const SYMI = { GOLD: "Au", XAUUSD: "Au", SILVER: "Ag", XAGUSD: "Ag", EURUSD: "€", BTCUSD: "₿", ETHUSD: "Ξ" };
const ico = (n) => SYMI[n] || SYMI[String(n).replace(/[^A-Z]/g, "").slice(0, 6)] || String(n).slice(0, 2);
const money = (x, c) => (x == null || !isFinite(x) ? "—" : `${x >= 0 ? "+" : "−"}${Math.abs(x).toFixed(2)} ${!c || c === "USD" ? "$" : c}`);
const ago = (t) => { const s = Math.max(0, Date.now() / 1000 - t); return s < 60 ? Math.floor(s) + " sn" : s < 3600 ? Math.floor(s / 60) + " dk" : s < 86400 ? Math.floor(s / 3600) + " sa" : Math.floor(s / 86400) + " g"; };
const X = { s: null, prev: null, fx: [], sparks: [], flashR: {}, t: 0, col: null, pk: {}, eq: [] };

/* ---------- görünüm */
function build() {
  const pg = $("#pg-xbot"); if (!pg || pg._b) return; pg._b = 1;
  pg.innerHTML = `<div class="eyebrow">XM · canlı işlem</div><h1>XM Botu</h1><p class="lead">Sinyale göre işlem açar, kârı merdiven gibi basamak basamak kilitler. Önce demo hesapta dene; kâr garantisi yoktur.</p>
  <div class="xb-top"><div class="panel xb-brain"><canvas id="xb-cv"></canvas><div class="xb-hud"><div class="xb-st" id="xb-st"></div><div class="xb-eq"><span>Varlık</span><b id="xb-eq">—</b><em id="xb-acct"></em></div></div><div class="xb-hint" id="xb-hint"></div></div>
    <div class="xb-side"><div class="panel xb-ctl"><div class="xb-btns"><button class="btn pri" id="xb-on"></button><button class="btn" id="xb-pause"></button><button class="btn warn" id="xb-close">Tümünü kapat</button></div><button class="btn xb-set" id="xb-set">Bot ayarları ›</button></div>
      <div class="panel xb-man"><div class="ph">Elle işlem <small id="xb-tg"></small></div><div class="xb-mb"><div class="seg xb-syms" id="xb-syms">${[["XAUUSDT", "Altın"], ["XAGUSDT", "Gümüş"], ["EURUSD", "EUR"], ["BTCUSDT", "BTC"], ["ETHUSDT", "ETH"]].map(([k, n], i) => `<button data-s="${k}" class="${i ? "" : "on"}">${n}</button>`).join("")}</div>
        <div class="xb-mf"><label class="fld">Risk ($)<input type="number" id="xb-risk" min="1" step="1" placeholder="ayar"></label><label class="fld">Stop mesafesi<input type="number" id="xb-dist" step="any" placeholder="otomatik"></label></div>
        <div class="xb-ls"><button class="xb-go L" id="xb-long"><span class="xb-gfx"></span><b>LONG</b><em>al</em></button><button class="xb-go S" id="xb-short"><span class="xb-gfx"></span><b>SHORT</b><em>sat</em></button></div><div class="muted xb-mn">Merdiven ve hedef bu işleme de uygulanır. Bot kapalıyken de çalışır.</div></div></div>
      <div class="xb-kpis"><div class="xb-k" id="k-day"><span>Bugün</span><b>—</b><i></i></div><div class="xb-k" id="k-open"><span>Açık K/Z</span><b>—</b><i></i></div><div class="xb-k" id="k-win"><span>Kazanma</span><b>—</b><i></i></div><div class="xb-k" id="k-n"><span>İşlem (bugün)</span><b>—</b><i></i></div></div>
      <div class="panel xb-spark"><div class="ph">Kapanan işlemler eğrisi <small id="xb-sp-t"></small></div><canvas id="xb-sp"></canvas></div></div></div>
  <div class="panel"><div class="ph">Canlı işlemler <small id="xb-pn">—</small></div><div id="xb-pos" class="xb-pos"></div></div>
  <div class="two"><div class="panel"><div class="ph">Kapanan işlemler</div><div id="xb-closed" class="xb-list"></div></div><div class="panel"><div class="ph">Bot akışı <small>canlı</small></div><div id="xb-log" class="xb-list xb-log"></div></div></div>`;
  $("#xb-on").onclick = async () => { if (!X.s) return; if (!X.s.cfg.on && X.s.acct && X.s.acct.real && !confirm("GERÇEK hesapta işlem açılacak. Devam?")) return; await post({ cfg: { on: !X.s.cfg.on } }); };
  $("#xb-pause").onclick = () => X.s && post({ cfg: { paused: !X.s.cfg.paused } });
  $("#xb-close").onclick = () => { if (confirm("Botun açtığı tüm pozisyonlar şimdi kapatılsın mı?")) post({ act: "close_all" }); };
  $$("#xb-syms button").forEach((b) => (b.onclick = () => $$("#xb-syms button").forEach((x) => x.classList.toggle("on", x === b))));
  const man = async (side, btn) => { if (!X.s || !X.s.xm) return alert("Önce Ayarlar › XM bağlantısı › Bağlan."); const sym = ($("#xb-syms button.on") || {}).dataset.s, nm = $("#xb-syms button.on").textContent, a = X.s.acct || {};
    if (!confirm(`${nm} ${side > 0 ? "LONG (al)" : "SHORT (sat)"} işlemi ${a.mode || ""} hesapta şimdi açılsın mı?`)) return; btn.classList.remove("fire"); void btn.offsetWidth; btn.classList.add("fire"); X.fx.push({ k: "open", side, t: 0 });
    await post({ act: "manual", sym, side, risk: +$("#xb-risk").value || null, dist: +$("#xb-dist").value || null }); setTimeout(poll, 900); };
  $("#xb-long").onclick = (e) => man(1, e.currentTarget); $("#xb-short").onclick = (e) => man(-1, e.currentTarget);
  $("#xb-set").onclick = () => { Lab.go("set"); setTimeout(() => { const b = $("#bot-panel"); if (b) { b.scrollIntoView({ behavior: "smooth" }); const d = b.querySelector(".bt-adv"); if (d) d.open = true; } }, 600); };
  const cv = $("#xb-cv"); cv.addEventListener("pointermove", (e) => { const r = cv.getBoundingClientRect(); X.mx = (e.clientX - r.left) / r.width - 0.5; X.my = (e.clientY - r.top) / r.height - 0.5; }); cv.addEventListener("pointerleave", () => { X.mx = X.my = 0; });
}
async function post(b) { try { X.s = await (await fetch("/api/bot", { method: "POST", body: JSON.stringify(b) })).json(); render(); } catch (e) { /* */ } }
async function poll() { try { const s = await (await fetch("/api/bot", { cache: "no-store" })).json(); X.prev = X.s; X.s = s; events(); render(); } catch (e) { /* sunucu yok */ } }

/* ---------- olaylar → animasyon */
function events() {
  const a = X.prev, b = X.s; if (!a || !b) return; const key = (p) => p.sym + p.side + p.open, A = new Map((a.pos || []).map((p) => [key(p), p])), B = new Map((b.pos || []).map((p) => [key(p), p]));
  for (const [k, p] of B) { const o = A.get(k); if (!o) { X.fx.push({ k: "open", side: p.side, t: 0 }); try { Sound && Sound.tone && Sound.tone(p.side > 0 ? 660 : 520, 0.14, 0.45); } catch (e) { /* */ } } else if (p.n > o.n) { X.flashR[k] = { n: p.n, t: 0 }; X.fx.push({ k: "step", side: p.side, t: 0, lvl: p.n / (p.steps || 5) }); try { Sound && Sound.tone && Sound.tone(880 + p.n * 60, 0.1, 0.35); } catch (e) { /* */ } } }
  for (const [k, p] of A) if (!B.has(k)) X.fx.push({ k: "close", side: p.side, t: 0, win: (p.pnl || 0) >= 0, lvl: (p.n || 0) / (p.steps || 5) });
  try { if (B.size !== A.size && window.LM) LM.event("xbot", { color: B.size > A.size ? "#3ddc84" : "#ffb04a", msg: B.size > A.size ? "Bot işlem açtı" : "Bot işlem kapattı" }); } catch (e) { /* */ }
}

/* ---------- listeler */
function lad(p) { const n = p.steps || 5; let h = ""; for (let i = 1; i <= n; i++) h += `<i class="${i <= p.n ? "on" : ""}${i === p.n + 1 ? " nx" : ""}"></i>`; return `<div class="xb-lad">${h}</div>`; }
function posHTML(p, cur) {
  const prog = Math.max(0, Math.min(1, p.step ? ((p.now - p.open) * p.side) / (p.step * (p.steps || 5)) : 0)), risk = p.sl ? ((p.sl - p.open) * p.side >= 0 ? "kâr kilitli" : "risk açık") : "stop yok";
  return `<div class="xb-p ${p.side > 0 ? "L" : "S"}" data-k="${esc(p.sym + p.side + p.open)}"><div class="xb-ic">${esc(ico(p.sym))}</div><div class="xb-pm"><b>${esc(p.sym)} <em class="xb-sd">${p.side > 0 ? "LONG" : "SHORT"}</em> <span class="muted">${p.vol} lot</span></b><span class="muted">giriş ${p.open} → şimdi <span class="xb-now">${p.now}</span> · stop ${p.sl || "—"} <em class="xb-lock ${risk === "kâr kilitli" ? "ok" : ""}">${risk}</em></span>
    <div class="xb-bar"><i style="width:${(prog * 100).toFixed(1)}%"></i></div></div>${lad(p)}<div class="xb-pl ${p.pnl >= 0 ? "up" : "dn"}"><b>${money(p.pnl, cur)}</b><span class="muted">basamak ${p.n}/${p.steps}${p.tgt ? ` · hedef ${p.tgt}$` : ""}${p.chain ? ` · ${p.chain + 1}. tur` : ""}</span></div></div>`;
}
function render() {
  const s = X.s; if (!s || !$("#pg-xbot")) return; const a = s.acct || {}, cur = a.cur, on = s.cfg.on, pa = s.cfg.paused;
  const st = !s.xm ? ["XM BAĞLI DEĞİL", "off"] : !on ? ["KAPALI", "off"] : pa ? ["DURAKLADI", "pause"] : s.cool > 0 ? [`MOLA · ${Math.ceil(s.cool / 60)} dk`, "pause"] : ["ÇALIŞIYOR", "run"]; X.state = st[1];
  const sh = `<i class="xb-dot ${st[1]}"></i>${st[0]}`; const se = $("#xb-st"); if (se._h !== sh) { se._h = sh; se.innerHTML = sh; se.className = "xb-st " + st[1]; }
  $("#xb-eq").textContent = a.eq != null ? `${Number(a.eq).toFixed(2)} ${cur === "USD" ? "$" : cur || ""}` : "—"; $("#xb-acct").textContent = a.mode ? `${a.mode} hesap · kaldıraç 1:${a.lev || "?"}` : s.xm ? "" : "Ayarlar › XM bağlantısı";
  $("#xb-acct").className = a.real ? "real" : "";
  const hint = !s.xm ? "MT5 açık olmalı · Ayarlar › XM bağlantısı › Bağlan" : !on ? "Bot kapalı · başlatınca sinyal beklenir" : (s.pos || []).length ? "" : pa ? "Duraklatıldı: yeni işlem açılmaz, açık işlemler yönetilir" : "Sinyal bekleniyor…"; $("#xb-hint").textContent = hint;
  const ob = $("#xb-on"); ob.textContent = on ? "Botu durdur" : "Botu başlat"; ob.className = "btn " + (on ? "warn" : "pri"); $("#xb-pause").textContent = pa ? "Devam et" : "Duraklat"; $("#xb-pause").disabled = !on;
  const openPl = (s.pos || []).reduce((t, p) => t + (p.pnl || 0), 0), cl = s.closed || [], wins = cl.filter((c) => c.pnl > 0).length;
  kpi("k-day", s.day == null ? "—" : money(s.day, cur), s.day || 0); kpi("k-open", (s.pos || []).length ? money(openPl, cur) : "—", openPl); kpi("k-win", cl.length ? `%${Math.round((wins / cl.length) * 100)} <small>${wins}/${cl.length}</small>` : "—", cl.length ? wins / cl.length - 0.5 : 0); kpi("k-n", String(s.trades || 0), 0);
  const tg = s.cfg.target_usd > 0 ? `hedef ${s.cfg.target_usd}$${s.cfg.reenter ? ` · ${s.cfg.max_chain} tura kadar` : ""}` : `${s.cfg.steps} basamak`; if ($("#xb-tg").textContent !== tg) $("#xb-tg").textContent = tg; const ri = $("#xb-risk"); if (ri && !ri.value && document.activeElement !== ri) ri.placeholder = `${s.cfg.risk_usd} (ayar)`;
  $("#xb-pn").textContent = (s.pos || []).length ? `${s.pos.length} açık` : "yok";
  const pe = $("#xb-pos"), have = new Set(); (s.pos || []).forEach((p) => { const k = p.sym + p.side + p.open; have.add(k); let el = pe.querySelector(`[data-k="${CSS.escape(k)}"]`); const h = posHTML(p, cur);
    if (!el) { const d = document.createElement("div"); d.innerHTML = h; el = d.firstChild; el.classList.add("in"); pe.prepend(el); el._h = h; } else if (el._h !== h) { const old = el.querySelector(".xb-pl b").textContent; el.innerHTML = new DOMParser().parseFromString(h, "text/html").body.firstChild.innerHTML; el.className = el.className.replace(/\b(L|S)\b/, p.side > 0 ? "L" : "S"); el._h = h; if (old !== el.querySelector(".xb-pl b").textContent) { const b = el.querySelector(".xb-pl"); b.classList.remove("tick"); void b.offsetWidth; b.classList.add("tick"); } const f = X.flashR[k]; if (f && f.t < 0.1) { el.classList.remove("stepped"); void el.offsetWidth; el.classList.add("stepped"); } } });
  pe.querySelectorAll(".xb-p").forEach((el) => { if (!have.has(el.dataset.k) && !el.classList.contains("out")) { el.classList.add("out"); setTimeout(() => el.remove(), 600); } });
  let emp = pe.querySelector(".xb-empty"); if (!(s.pos || []).length) { if (!emp) { emp = document.createElement("div"); emp.className = "xb-empty"; emp.innerHTML = `<div class="xb-radar"><i></i><i></i><i></i></div><span>${s.xm && on ? "Açık işlem yok · bot sinyal bekliyor" : "Açık işlem yok"}</span>`; pe.appendChild(emp); } } else if (emp) emp.remove();
  sync($("#xb-closed"), cl, (c) => c.t + c.tag, (c) => `<div class="xb-c ${c.pnl >= 0 ? "up" : "dn"}"><i class="xb-cd"></i><div><b>${esc(c.tag)}</b><span class="muted"><em class="ag">${ago(c.t)}</em> önce · ${c.n} basamak</span></div><b class="xb-cp">${money(c.pnl, cur)}</b></div>`, "Henüz kapanan işlem yok.");
  const LI = { open: "▲", close: "■", stop: "‖", err: "!", info: "·" }; sync($("#xb-log"), (s.log || []).slice(0, 30), (l) => l.t + l.m, (l) => `<div class="xb-l k-${l.k}"><i>${LI[l.k] || "·"}</i><span>${esc(l.m)}</span><em class="ag">${ago(l.t)}</em></div>`, "Kayıt yok.");
  let c = 0; X.eq = cl.slice().reverse().map((x) => (c += x.pnl || 0)); $("#xb-sp-t").textContent = cl.length ? money(c, cur) : "";
}
/* anahtarlı liste: yalnız yeni satır eklenir (animasyonlu), eskilerin sadece "önce" yazısı güncellenir; liste her saniye baştan çizilmez */
function sync(box, items, key, html, empty) {
  if (!box) return; const want = items.map(key), have = new Map([...box.children].filter((e) => e.dataset.key).map((e) => [e.dataset.key, e]));
  [...box.children].forEach((e) => { if (!e.dataset.key || !want.includes(e.dataset.key)) e.remove(); });
  let prev = null; items.forEach((it, i) => { const k = want[i]; let el = have.get(k); if (!el) { const d = document.createElement("div"); d.innerHTML = html(it); el = d.firstElementChild; el.dataset.key = k; if (box._init) el.classList.add("new"); }
    else { const ag = el.querySelector(".ag"), nh = (html(it).match(/class="ag">([^<]*)</) || [])[1]; if (ag && nh != null && ag.textContent !== nh) ag.textContent = nh; }
    const at = prev ? prev.nextSibling : box.firstChild; if (at !== el) box.insertBefore(el, at); prev = el; });
  if (!items.length && !box.querySelector(".xb-none")) box.innerHTML = `<div class="muted xb-none">${empty}</div>`; box._init = true;
}
function kpi(id, html, v) { const e = $("#" + id); if (!e) return; const b = e.querySelector("b"); if (b._h !== html) { b._h = html; b.innerHTML = html; e.classList.remove("bump"); void e.offsetWidth; e.classList.add("bump"); } e.classList.toggle("up", v > 0); e.classList.toggle("dn", v < 0); }

/* ---------- beyin: merdiven sarmalı + nöron bulutu */
const N = 150, CL = [], PAIRS = [];
for (let i = 0; i < N; i++) { const lobe = i % 2 ? 1 : -1, a = Math.random() * 6.283, r = Math.pow(Math.random(), 0.6); CL.push({ x: lobe * 0.42 + Math.cos(a) * r * 0.55, y: Math.sin(a) * r * 0.62 - 0.05, z: (Math.random() - 0.5) * 0.8, ph: Math.random() * 6.3, e: 0 }); }
for (let i = 0; i < N; i++) for (let j = i + 1; j < N; j++) { const d = Math.hypot(CL[i].x - CL[j].x, CL[i].y - CL[j].y, CL[i].z - CL[j].z); if (d < 0.17 && PAIRS.length < 420) PAIRS.push([i, j]); }
function colors() { const cs = getComputedStyle(document.body), g = (v, d) => (cs.getPropertyValue(v).trim() || d); X.col = { a: g("--na", "#35e0c4"), b: g("--nb", "#8a7bff"), c: g("--nc", "#ffb04a"), up: g("--up", "#3ddc84"), dn: g("--dn", "#f2566a") }; }
const rgb = (hex, al) => { const h = hex.replace("#", ""), n = parseInt(h.length === 3 ? h.split("").map((x) => x + x).join("") : h.slice(0, 6), 16); return `rgba(${n >> 16},${(n >> 8) & 255},${n & 255},${al})`; };
function frame(dt) {
  const cv = $("#xb-cv"); if (!cv || !vis(cv)) return; const w = cv.parentElement.clientWidth, h = cv.parentElement.clientHeight; if (w < 60) return; const c = fitCanvas(cv, w, h); if (!X.col) colors(); const C = X.col, st = X.state || "off";
  X.t += dt * (st === "run" ? 1 : st === "pause" ? 0.35 : 0.5); const t = X.t; c.clearRect(0, 0, w, h);
  const cx = w * 0.5 + (X.mx || 0) * 18, cy = h * 0.52 + (X.my || 0) * 12, S = Math.min(w, h * 1.25) * 0.5, base = st === "run" ? C.a : st === "pause" ? C.c : "#5a6278";
  const g0 = c.createRadialGradient(cx, cy, 10, cx, cy, S * 1.2); g0.addColorStop(0, rgb(base, 0.13)); g0.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = g0; c.fillRect(0, 0, w, h);
  // nöron bulutu (iki lob, nefes alır, yavaş döner)
  const yaw = t * 0.12, cyw = Math.cos(yaw), syw = Math.sin(yaw), br = 1 + Math.sin(t * 0.8) * 0.025, P = CL.map((n) => { const x = n.x * cyw - n.z * syw, z = n.x * syw + n.z * cyw, k = 1 / (1.6 - z * 0.5); return [cx + (x + Math.sin(t * 0.5 + n.ph) * 0.012) * S * br * k * 1.15, cy + (n.y + Math.cos(t * 0.45 + n.ph) * 0.012) * S * br * k * 1.15, z]; });
  if (Math.random() < dt * (st === "run" ? 4 : 1.2)) { const i = (Math.random() * N) | 0; CL[i].e = 1; }
  c.lineWidth = 0.7; for (const [i, j] of PAIRS) { const e = Math.max(CL[i].e, CL[j].e); c.strokeStyle = rgb(e > 0.15 ? C.c : C.b, 0.1 + e * 0.5); c.beginPath(); c.moveTo(P[i][0], P[i][1]); c.lineTo(P[j][0], P[j][1]); c.stroke(); if (CL[i].e > 0.5) CL[j].e = Math.max(CL[j].e, CL[i].e * 0.6); }
  CL.forEach((n, i) => { n.e *= Math.pow(0.12, dt); const r = 1.1 + n.e * 2.4 + (P[i][2] + 0.4); c.fillStyle = n.e > 0.3 ? "#fff" : rgb(i % 3 ? C.b : C.a, 0.5 + (P[i][2] + 0.4) * 0.45); c.beginPath(); c.arc(P[i][0], P[i][1], Math.max(0.6, r), 0, 6.283); c.fill(); });
  // çift sarmal merdiven: tabanda giriş, tepede son hedef
  const H = h * 0.74, top = cy - H / 2, R = S * 0.22, RUN = 16, rot = t * 0.9, pts = (k, off) => { const y = k / RUN, a = rot + y * 7.2 + off, z = Math.sin(a); return [cx + Math.cos(a) * R, top + (1 - y) * H, z]; };
  for (let k = 0; k <= RUN; k++) { const A = pts(k, 0), B = pts(k, Math.PI), back = (A[2] + B[2]) / 2 < 0, lit = X.litTop != null && k / RUN <= X.litTop + 0.001; c.strokeStyle = rgb(lit ? C.up : C.a, (back ? 0.12 : 0.32) + (lit ? 0.35 : 0)); c.lineWidth = back ? 1 : 1.8; c.beginPath(); c.moveTo(A[0], A[1]); c.lineTo(B[0], B[1]); c.stroke(); }
  for (const off of [0, Math.PI]) { for (let k = 0; k < RUN * 4; k++) { const A = pts(k / 4, off), B = pts((k + 1) / 4, off); c.strokeStyle = rgb(off ? C.b : C.a, A[2] < 0 ? 0.25 : 0.85); c.lineWidth = A[2] < 0 ? 1.4 : 2.6; c.beginPath(); c.moveTo(A[0], A[1]); c.lineTo(B[0], B[1]); c.stroke(); } }
  // sarmal üzerinde yükselen sinyal kıvılcımları
  if (Math.random() < dt * (st === "run" ? 3 : 0.8)) X.sparks.push({ y: 0, off: Math.random() < 0.5 ? 0 : Math.PI, v: 0.25 + Math.random() * 0.3 }); for (let i = X.sparks.length - 1; i >= 0; i--) { const sp = X.sparks[i]; sp.y += dt * sp.v; if (sp.y > 1) { X.sparks.splice(i, 1); continue; } const q = pts(sp.y * RUN, sp.off), g = c.createRadialGradient(q[0], q[1], 0, q[0], q[1], 8); g.addColorStop(0, "rgba(255,255,255,.9)"); g.addColorStop(0.4, rgb(sp.off ? C.b : C.a, 0.6)); g.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = g; c.fillRect(q[0] - 8, q[1] - 8, 16, 16); }
  // açık işlemler: basamaktaki ışık küresi
  const pos = (X.s && X.s.pos) || []; X.litTop = null; c.font = '600 11px "Segoe UI",sans-serif'; c.textAlign = "left";
  pos.forEach((p, i) => { const steps = p.steps || 5, prog = p.step ? Math.max(-0.08, Math.min(1, ((p.now - p.open) * p.side) / (p.step * steps))) : 0, lvl = Math.max(0, prog), k = lvl * RUN, q = pts(k, i * 2.1 + 0.6), col = p.side > 0 ? C.up : C.dn, pul = 1 + Math.sin(t * 4 + i) * 0.15;
    X.litTop = Math.max(X.litTop || 0, (p.n || 0) / steps);
    const sl = p.step && p.sl ? Math.max(0, Math.min(1, ((p.sl - p.open) * p.side) / (p.step * steps))) : null; if (sl != null && sl > 0) { const s2 = pts(sl * RUN, i * 2.1 + 0.6); c.strokeStyle = rgb(C.c, 0.8); c.setLineDash([4, 4]); c.beginPath(); c.moveTo(s2[0] - 20, s2[1]); c.lineTo(s2[0] + 20, s2[1]); c.stroke(); c.setLineDash([]); }
    const g = c.createRadialGradient(q[0], q[1], 0, q[0], q[1], 26 * pul); g.addColorStop(0, "rgba(255,255,255,.95)"); g.addColorStop(0.25, rgb(col, 0.9)); g.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = g; c.beginPath(); c.arc(q[0], q[1], 26 * pul, 0, 6.283); c.fill();
    c.strokeStyle = rgb(col, 0.6); c.lineWidth = 1.2; c.beginPath(); c.arc(q[0], q[1], 13 + Math.sin(t * 3) * 2, 0, 6.283); c.stroke();
    const lx = q[0] + (q[0] > cx ? 22 : -22), lt = `${p.sym} ${p.side > 0 ? "▲" : "▼"} ${money(p.pnl, (X.s.acct || {}).cur)}`; c.textAlign = q[0] > cx ? "left" : "right"; c.fillStyle = "rgba(4,7,14,.72)"; const tw = c.measureText(lt).width; c.fillRect(q[0] > cx ? lx - 5 : lx - tw - 5, q[1] - 11, tw + 10, 18); c.fillStyle = rgb(col, 1); c.fillText(lt, lx, q[1] + 2); });
  // basamak etiketleri
  c.textAlign = "center"; c.font = '9px "Cascadia Mono",Consolas,monospace'; c.fillStyle = rgb(C.a, 0.55); c.fillText("HEDEF", cx, top - 10); c.fillText("GİRİŞ", cx, top + H + 16);
  // olay efektleri
  for (let i = X.fx.length - 1; i >= 0; i--) { const f = X.fx[i]; f.t += dt / (f.k === "open" ? 1.1 : 0.9); if (f.t >= 1) { X.fx.splice(i, 1); continue; } const col = f.k === "close" ? (f.win ? C.up : C.dn) : f.side > 0 ? C.up : C.dn, y = f.k === "open" ? top + H : top + (1 - (f.lvl || 0)) * H;
    if (f.k === "open") { for (let r = 0; r < 3; r++) { c.strokeStyle = rgb(col, (1 - f.t) * (0.8 - r * 0.2)); c.lineWidth = 2; c.beginPath(); c.arc(cx, y, (f.t + r * 0.12) * S * 0.9, 0, 6.283); c.stroke(); } }
    else if (f.k === "step") { c.strokeStyle = rgb(C.c, 1 - f.t); c.lineWidth = 3; c.beginPath(); c.moveTo(cx - R * 1.6 - f.t * 40, y); c.lineTo(cx + R * 1.6 + f.t * 40, y); c.stroke(); }
    else { for (let k = 0; k < 14; k++) { const a = (k / 14) * 6.283, d = f.t * S * 0.5; c.fillStyle = rgb(col, 1 - f.t); c.fillRect(cx + Math.cos(a) * d - 2, y + Math.sin(a) * d - 2, 4, 4); } } }
  // kapanan işlem eğrisi
  spark();
}
function spark() {
  const cv = $("#xb-sp"); if (!cv || !vis(cv)) return; const w = cv.parentElement.clientWidth - 28, h = 70; if (w < 40) return; const c = fitCanvas(cv, w, h), C = X.col, e = [0, ...X.eq]; c.clearRect(0, 0, w, h);
  if (e.length < 2) { c.fillStyle = rgb(C.a, 0.4); c.font = '11px "Segoe UI",sans-serif'; c.textAlign = "center"; c.fillText("kapanan işlem olunca eğri burada çizilir", w / 2, h / 2 + 4); return; }
  const mn = Math.min(...e), mx = Math.max(...e), sx = (i) => (i / (e.length - 1)) * (w - 4) + 2, sy = (v) => h - 6 - ((v - mn) / (mx - mn || 1)) * (h - 12), col = e[e.length - 1] >= 0 ? C.up : C.dn;
  const g = c.createLinearGradient(0, 0, 0, h); g.addColorStop(0, rgb(col, 0.35)); g.addColorStop(1, rgb(col, 0)); c.beginPath(); e.forEach((v, i) => (i ? c.lineTo(sx(i), sy(v)) : c.moveTo(sx(i), sy(v)))); c.lineTo(sx(e.length - 1), h); c.lineTo(sx(0), h); c.fillStyle = g; c.fill();
  c.beginPath(); e.forEach((v, i) => (i ? c.lineTo(sx(i), sy(v)) : c.moveTo(sx(i), sy(v)))); c.strokeStyle = col; c.lineWidth = 2; c.stroke(); const lx = sx(e.length - 1), ly = sy(e[e.length - 1]), pu = 3 + Math.sin(X.t * 4) * 1.5; c.fillStyle = col; c.beginPath(); c.arc(lx, ly, pu, 0, 6.283); c.fill();
  c.strokeStyle = rgb(C.a, 0.25); c.setLineDash([3, 4]); c.beginPath(); c.moveTo(0, sy(0)); c.lineTo(w, sy(0)); c.stroke(); c.setLineDash([]);
}

window.addEventListener("DOMContentLoaded", () => {
  build(); TICKS.push(frame); DT.on("palette", () => (X.col = null)); DT.on("theme", () => setTimeout(() => (X.col = null), 50));
  DT.on("view", (v) => { if (v === "xbot") { build(); poll(); } });
  let k = 0; setInterval(() => { k++; if (document.body.dataset.view === "xbot" && !document.hidden) poll(); else if (k % 6 === 0) poll(); }, 1000);
});
})();
