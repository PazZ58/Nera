"use strict";
/* Nera · Sinyal Beyni: kural ajanları + (anahtarı girilen) yapay zekâlar piyasa, haber, gösterge ve strateji defteri verisini birlikte tartışır; karar 3B nebula beyne iletilir.
   LONG / SHORT / BEKLE rengi beyne yansır. Kâr garantisi değildir; yalnızca analiz. */
(function () {
const $ = (s, r = document) => r.querySelector(s), esc = (s) => String(s).replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c]));
const NAME = { BTCUSDT: "BTC", ETHUSDT: "ETH", XAUUSDT: "Altın", XAGUSDT: "Gümüş", EURUSD: "EUR/USD" }, SYMS = Object.keys(NAME);
const COL = { LONG: [38, 198, 160], SHORT: [242, 86, 106], BEKLE: [255, 176, 74] }, CL = { LONG: "L", SHORT: "S", BEKLE: "W" };
const palCol = () => { COL.LONG = hex2(CUP); COL.SHORT = hex2(CDN); COL.BEKLE = hex2(CC); };
const clamp = (x, a = -1, b = 1) => Math.max(a, Math.min(b, x)), sg = (v) => (v > 0.12 ? 1 : v < -0.12 ? -1 : 0);
const LLMS = [["gemini", "Gemini", "teknik analist"], ["groq", "Groq", "şüpheci risk yöneticisi"], ["openrouter", "OpenRouter", "makro ve haber analisti"], ["mistral", "Mistral", "momentum / order flow trader"]];
const MEM = [["tek", "Teknik ajanlar", "r"], ["flow", "Order flow", "r"], ["ict", "ICT / likidite", "r"], ["ind", "Göstergeler", "r"], ["haber", "Haber", "r"], ["defter", "Strateji defteri", "r"], ...LLMS.map(([k, n]) => [k, n, "l"])];
const C = { sym: localStorage.getItem("nera_cn_sym") || "XAUUSDT", st: {}, running: false, pulses: [], chords: [], tick: 0, col: [255, 176, 74], t: 0, init: false };
const stOf = (s) => (C.st[s] = C.st[s] || { dec: "BEKLE", conf: 0, score: 0, at: 0, llmAt: 0, mem: {}, talk: [], dossier: null });
const keysOn = () => (window.Lab && Lab.keys) || {};

/* ---- bulut: 3B parçacıklar + nöron düğümleri */
const P = [], NEU = []; let seed = 11; const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647), gauss = () => (rnd() + rnd() + rnd() + rnd() - 2) * 0.9;
function build() {
  const lobes = [[0, 0, 0, 0.55], [0.55, 0.15, -0.2, 0.34], [-0.5, -0.2, 0.3, 0.36], [0.1, 0.5, 0.25, 0.3], [-0.15, -0.55, -0.3, 0.3]];
  for (let i = 0; i < (MOB ? 400 : 760); i++) { const l = lobes[i % lobes.length]; P.push({ x: l[0] + gauss() * l[3], y: l[1] + gauss() * l[3] * 0.9, z: l[2] + gauss() * l[3], ph: rnd() * 6.28, sz: 0.9 + rnd() * 1.5 }); }
  const pick = []; for (let k = 0; k < 40; k++) pick.push(Math.floor(rnd() * P.length)); pick.forEach((pi) => NEU.push({ pi, e: 0, nb: [] }));
  NEU.forEach((n, i) => { const d = NEU.map((m, j) => [j === i ? 9 : (P[n.pi].x - P[m.pi].x) ** 2 + (P[n.pi].y - P[m.pi].y) ** 2 + (P[n.pi].z - P[m.pi].z) ** 2, j]).sort((a, b) => a[0] - b[0]); n.nb = d.slice(0, 3).map((x) => x[1]); });
}

/* ---- veri paketi ---- */
async function dossier(sym) {
  const j = await NAPI(`/api/analysis?sym=${sym}&tf=15m`); if (!j || !j.ready || !j.eval) return null;
  const ev = j.eval, ind = j.ind && j.ind.sum ? j.ind.sum : null, nw = (Lab.newsSum || {})[sym] || { n: 0, score: 0, conf: 0, top: [], shock: false };
  const book = (Lab.book || []).filter((r) => r.sym === sym), liv = Lab.data && Lab.data.sym === sym ? book.map((r) => Lab.live[r.sym + r.tf + JSON.stringify(r.g)]).filter((x) => x && x.side) : [], lg = liv.filter((x) => x.side > 0).length, sh = liv.filter((x) => x.side < 0).length;
  const risk = ev.agents.find((a) => a.name === "Risk");
  return { sym, name: NAME[sym], price: ev.price, ev, ind, nw, lg, sh, nbook: book.length, risk, adx: ev.adx };
}
const compact = (d) => JSON.stringify({ varlik: d.name, fiyat: +d.price.toFixed(2), ajan_skoru: +d.ev.score.toFixed(2), durum: d.ev.state, adx: Math.round(d.adx || 0), ajanlar: d.ev.agents.filter((a) => a.name !== "Risk").map((a) => ({ ad: a.name, oy: +a.vote.toFixed(2), guven: +a.conf.toFixed(2) })), gosterge_ozeti: d.ind ? { al: d.ind.all.buy, sat: d.ind.all.sell, notr: d.ind.all.neutral } : null, haber_skoru: +d.nw.score.toFixed(2), haber_olay_riski: !!d.nw.shock, haberler: (d.nw.top || []).slice(0, 3).map((t) => t.title.slice(0, 90)), defter_long: d.lg, defter_short: d.sh, risk_etiketi: d.risk ? d.risk.label : "?", risk_notlari: d.risk ? d.risk.why.slice(0, 2) : [] });

/* ---- üyelerin oyları ---- */
function ruleVotes(d) {
  const ev = d.ev, ag = (re) => ev.agents.filter((a) => re.test(a.name.toLowerCase()) && a.name !== "Risk"), avg = (L) => (L.length ? [L.reduce((s, a) => s + a.vote, 0) / L.length, L.reduce((s, a) => s + a.conf, 0) / L.length] : [0, 0]);
  const fl = avg(ag(/flow/)), ic = avg(ag(/ict|likidite|liquidity/)), v = {};
  v.tek = [clamp(ev.score * 2.2), clamp(ev.conf || Math.abs(ev.score) * 1.8, 0, 1), `Ajan skoru ${ev.score >= 0 ? "+" : ""}${ev.score.toFixed(2)} · ${ev.agree} ajan aynı yönde`];
  v.flow = [fl[0], fl[1], `Order flow oyu ${fl[0] >= 0 ? "+" : ""}${fl[0].toFixed(2)}`];
  v.ict = [ic[0], ic[1], `ICT / likidite ${ic[0] >= 0 ? "+" : ""}${ic[0].toFixed(2)}`];
  v.ind = d.ind ? [d.ind.all.score, 0.7, `${d.ind.all.buy} al · ${d.ind.all.sell} sat · ${d.ind.all.neutral} nötr gösterge`] : [0, 0, "gösterge verisi yok"];
  v.haber = d.nw.n ? [clamp(d.nw.score * 1.4), d.nw.conf, `${d.nw.n} haber, duygu ${d.nw.score >= 0 ? "+" : ""}${d.nw.score.toFixed(2)}${d.nw.shock ? " · büyük olay" : ""}`] : [0, 0, "haber yok"];
  const tot = d.lg + d.sh; v.defter = tot ? [(d.lg - d.sh) / tot, Math.min(1, tot / 3), `${d.lg} long · ${d.sh} short stratejisi şu an sinyalde`] : [0, 0, d.nbook ? "şu an sinyalde olan strateji yok" : "bu varlıkta kayıtlı strateji yok"];
  return v;
}
function parseDec(txt) { try { const m = txt.match(/\{[\s\S]*\}/); const o = JSON.parse(m[0]), k = String(o.karar || "").toUpperCase(); const dec = k.startsWith("LONG") ? 1 : k.startsWith("SHORT") ? -1 : 0; return [dec, clamp(+o.guven || 0.5, 0, 1), String(o.gerekce || "").slice(0, 160)]; } catch (e) { return null; } }
async function llmAsk(prov, persona, d, others) {
  const q = `Sen "${persona}" rolündesin. Kısa vadeli (15 dakikalık grafik, birkaç saat) yön önerisi ver. Yalnızca şu JSON'u döndür: {"karar":"LONG" veya "SHORT" veya "BEKLE","guven":0 ile 1 arası sayı,"gerekce":"en çok 25 kelime, Türkçe"}. Veri uydurma, yalnızca verilenleri kullan. Bu analiz yatırım tavsiyesi değildir.\nVERİ: ${compact(d)}${others ? `\nDİĞER ÜYELERİN GÖRÜŞLERİ (gerekirse fikrini güncelle): ${others}` : ""}`;
  const j = await NAPI("/api/llm", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ prompt: q, only: prov }) });
  if (!j || !j.text) return { err: (j && j.err) || "yanıt yok" }; const p = parseDec(j.text); return p ? { v: p[0], c: p[1], t: p[2] } : { err: "anlaşılamayan yanıt" };
}

/* ---- tartışma oturumu ---- */
const W = { tek: 0.3, flow: 0.14, ict: 0.12, ind: 0.1, haber: 0.1, defter: 0.08 };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function say(S, who, txt, cls) { S.talk.unshift({ who, txt, cls: cls || "", t: Date.now() }); if (S.talk.length > 40) S.talk.length = 40; }
function vote(S, id, v, c, txt) { S.mem[id] = { v, c, txt }; if (C.sym === S.sym) { C.pulses.push({ id, t: 0, col: v > 0.12 ? [38, 198, 160] : v < -0.12 ? [242, 86, 106] : [150, 160, 190] }); } }
function decide(S, d) {
  const m = S.mem; let num = 0, den = 0, agree = 0, pos = 0, neg = 0;
  for (const k in W) { const x = m[k]; if (!x) continue; const w = W[k] * (x.c > 0 ? 1 : 0.35); num += w * x.v * (0.5 + 0.5 * x.c); den += w; if (x.v > 0.15) pos++; if (x.v < -0.15) neg++; }
  const ls = LLMS.map(([k]) => m[k]).filter((x) => x && !x.err); if (ls.length) { const lv = ls.reduce((s, x) => s + x.v * (0.4 + 0.6 * x.c), 0) / ls.length; num += 0.16 * lv * 1.2; den += 0.16; ls.forEach((x) => { if (x.v > 0.15) pos++; if (x.v < -0.15) neg++; }); }
  let score = den ? num / den : 0; const rl = d.risk ? d.risk.label : "", veto = rl === "ÇOK YÜKSEK" || (d.ev.why_wait && d.ev.why_wait.some((w) => /haber çok yakın|Makro/i.test(w)));
  let dec = score >= 0.2 && pos >= 3 ? "LONG" : score <= -0.2 && neg >= 3 ? "SHORT" : "BEKLE"; let conf = clamp(Math.abs(score) * 2.2, 0, 1) * (rl === "YÜKSEK" ? 0.7 : 1);
  if (veto && dec !== "BEKLE") { dec = "BEKLE"; say(S, "Risk", `Karar BEKLE'ye çevrildi: ${rl} risk${veto && rl !== "ÇOK YÜKSEK" ? " (makro olay yakın)" : ""}.`, "W"); }
  if (dec === "BEKLE") conf = clamp(1 - Math.abs(score) * 2.5, 0.2, 0.9) * 0.6;
  return { dec, conf, score, pos, neg };
}
async function session(sym, withLLM) {
  if (C.running) return; C.running = true; const S = stOf(sym); S.sym = sym; S.at = Date.now();
  try {
    const d = await dossier(sym); if (!d) { C.running = false; return; } S.dossier = d; const rv = ruleVotes(d), vis = window.Lab && Lab.view() === "office";
    for (const [id] of MEM.filter((x) => x[2] === "r")) { const [v, c, t] = rv[id]; vote(S, id, v, c, t); say(S, MEM.find((x) => x[0] === id)[1], t, v > 0.12 ? "L" : v < -0.12 ? "S" : "W"); if (vis) await sleep(260); }
    const keys = keysOn(); const lm = withLLM ? LLMS.filter(([k]) => keys[k]) : [];
    if (lm.length) {
      S.llmAt = Date.now(); say(S, "Konsey", `${lm.length} yapay zekâ görüş bildiriyor…`); C.chords.push(...lm.map(([k]) => ({ a: k, b: "tek", t: 0 })));
      const r1 = await Promise.all(lm.map(([k, n, per]) => llmAsk(k, per, d).then((r) => ({ k, n, r }))));
      for (const { k, n, r } of r1) { if (r.err) { const e = /429/.test(r.err) ? "ücretsiz kota / hız sınırı doldu, sonra denenecek" : /401|403|nvalid|not valid/i.test(r.err) ? "anahtar geçersiz görünüyor (Ayarlar'dan kontrol et)" : /404/.test(r.err) ? "model bulunamadı" : r.err.slice(0, 90); S.mem[k] = { v: 0, c: 0, err: 1, txt: e }; say(S, n, e, "W"); } else { vote(S, k, r.v, r.c, r.t); say(S, n, `${r.v > 0 ? "LONG" : r.v < 0 ? "SHORT" : "BEKLE"} %${Math.round(r.c * 100)} · ${r.t}`, r.v > 0 ? "L" : r.v < 0 ? "S" : "W"); } if (vis) await sleep(300); }
      const ok = r1.filter((x) => !x.r.err), signs = new Set(ok.map((x) => x.r.v)); const pre = decide(S, d);
      if (ok.length >= 2 && (signs.size > 1 || (pre.dec !== "BEKLE" && signs.has(0) === false && false))) {                 // görüş ayrılığı varsa ikinci tur: istişare
        say(S, "Konsey", "Görüşler ayrışıyor: istişare turu başlıyor…"); ok.forEach((x, i) => ok.forEach((y, j) => { if (i !== j) C.chords.push({ a: x.k, b: y.k, t: -(i * 0.15 + j * 0.05) }); }));
        const sum = ok.map((x) => `${x.n}: ${x.r.v > 0 ? "LONG" : x.r.v < 0 ? "SHORT" : "BEKLE"} (%${Math.round(x.r.c * 100)}) ${x.r.t}`).join(" | ");
        const r2 = await Promise.all(ok.map((x) => llmAsk(x.k, LLMS.find((l) => l[0] === x.k)[2], d, sum).then((r) => ({ k: x.k, n: x.n, r }))));
        for (const { k, n, r } of r2) if (!r.err) { vote(S, k, r.v, r.c, r.t); say(S, n, `(2. tur) ${r.v > 0 ? "LONG" : r.v < 0 ? "SHORT" : "BEKLE"} %${Math.round(r.c * 100)} · ${r.t}`, r.v > 0 ? "L" : r.v < 0 ? "S" : "W"); if (vis) await sleep(300); }
      }
    }
    const f = decide(S, d), was = S.dec; S.dec = f.dec; S.conf = f.conf; S.score = f.score; say(S, "KARAR", `${f.dec} · güven %${Math.round(f.conf * 100)} · skor ${f.score >= 0 ? "+" : ""}${f.score.toFixed(2)} (${f.pos} yukarı / ${f.neg} aşağı üye)`, CL[f.dec]);
    if (sym === C.sym) C.flash = 1;
    if (was !== f.dec && S.noted && f.dec !== "BEKLE" && f.conf >= 0.45 && localStorage.getItem("nera_cn_notify") !== "0") { Lab.toast(`<b>Sinyal beyni: ${NAME[sym]} ${f.dec}</b><br><span style="color:#8b92a8">güven %${Math.round(f.conf * 100)} · ${f.pos} üye yukarı / ${f.neg} aşağı. Yatırım tavsiyesi değildir.</span>`, f.dec === "LONG" ? "#26c6a0" : "#f2566a"); DT.emit("council", { sym, dec: f.dec }); if (window.Sound && window.__S && __S().sound) Sound.signal(f.dec === "LONG" ? 1 : -1); LM.event("office", { color: f.dec === "LONG" ? "#26c6a0" : "#f2566a", msg: "Sinyal beyni kararı" }); }
    if (was !== f.dec && S.noted && f.dec !== "BEKLE" && f.conf >= 0.45 && !window.LOCAL_API) { const pl = d.ev.plan; fetch("/api/bot/sig", { method: "POST", body: JSON.stringify({ src: "council", sym, tf: "15m", side: f.dec === "LONG" ? 1 : -1, entry: d.price, stop: pl && pl.side === (f.dec === "LONG" ? 1 : -1) ? pl.stop : null, conf: f.conf, ts: Date.now() / 1000 }) }).catch(() => {}); }      // XM botu (kapalıysa bir şey yapmaz)
    S.noted = true;
  } catch (e) { console.error(e); }
  C.running = false;
}
window.Council = { run: (llm = true) => session(C.sym, llm), state: C.st };

/* ---- çizim ---- */
function frame(dt, t) {
  const cv = $("#council canvas"); if (!cv || !vis(cv)) return; const wrap = cv.parentElement, w = wrap.clientWidth, h = wrap.clientHeight; if (w < 100) return; const c = Lab.fitCanvas(cv, w, h); C.t += dt; c.clearRect(0, 0, w, h);
  const S = stOf(C.sym), tgt = COL[S.dec], k = Math.min(1, dt * 2.2); for (let i = 0; i < 3; i++) C.col[i] += (tgt[i] - C.col[i]) * k; const rgb = (a) => `rgba(${C.col[0] | 0},${C.col[1] | 0},${C.col[2] | 0},${a})`;
  const cx = w / 2, cy = h * 0.5, Rc = Math.min(h * 0.27, cx * 0.5), br = 1 + 0.035 * Math.sin(C.t * 0.9); C.flash = Math.max(0, (C.flash || 0) - dt * 0.9);
  const yaw = C.t * 0.14, ca = Math.cos(yaw), sa = Math.sin(yaw), tilt = 0.35 + 0.1 * Math.sin(C.t * 0.2), ct = Math.cos(tilt), st = Math.sin(tilt), proj = (x, y, z) => { const x1 = x * ca + z * sa, z1 = -x * sa + z * ca, y1 = y * ct - z1 * st, z2 = y * st + z1 * ct, s = 1 / (1 - z2 * 0.42); return [cx + x1 * Rc * 1.7 * s * br, cy + y1 * Rc * 1.7 * s * br, z2, s]; };
  const g = c.createRadialGradient(cx, cy, 4, cx, cy, Rc * 2.6); g.addColorStop(0, rgb(0.16 + C.flash * 0.25)); g.addColorStop(0.5, rgb(0.05)); g.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = g; c.fillRect(0, 0, w, h);
  const bins = [new Path2D(), new Path2D(), new Path2D()]; for (const p of P) { const dx = Math.sin(C.t * 0.5 + p.ph) * 0.02, dy = Math.cos(C.t * 0.45 + p.ph) * 0.02, q = proj(p.x + dx, p.y + dy, p.z), b = q[2] < -0.3 ? 0 : q[2] < 0.3 ? 1 : 2, r = p.sz * q[3]; bins[b].rect(q[0] - r / 2, q[1] - r / 2, r, r); p._q = q; }
  [0.24, 0.5, 0.85].forEach((a, i) => { c.fillStyle = rgb(a); c.fill(bins[i]); });
  const np = NEU.map((n) => P[n.pi]._q); c.lineWidth = 0.8; NEU.forEach((n, i) => { n.e *= Math.pow(0.1, dt); n.nb.forEach((j) => { const e = Math.max(n.e, NEU[j].e); c.strokeStyle = rgb(0.14 + e * 0.7); c.beginPath(); c.moveTo(np[i][0], np[i][1]); c.lineTo(np[j][0], np[j][1]); c.stroke(); }); });
  NEU.forEach((n, i) => { const q = np[i], r = (1.8 + n.e * 3.5) * q[3]; c.fillStyle = n.e > 0.25 ? "#fff" : rgb(0.9); c.beginPath(); c.arc(q[0], q[1], r, 0, 6.3); c.fill(); if (n.e > 0.25) { const gg = c.createRadialGradient(q[0], q[1], 0, q[0], q[1], r * 5); gg.addColorStop(0, rgb(0.5 * n.e)); gg.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = gg; c.fillRect(q[0] - r * 5, q[1] - r * 5, r * 10, r * 10); } });
  if (Math.random() < dt * 2.2) { const i = Math.floor(Math.random() * NEU.length); NEU[i].e = 0.8; NEU[i].nb.forEach((j) => (NEU[j].e = Math.max(NEU[j].e, 0.5))); }          // bulut kendi kendine "düşünür"
  // üyeler
  const rx = Math.min(cx * 0.92, 340), ry = h * 0.4, pos = {}; const L = MEM.filter((x) => x[2] === "r"), R = MEM.filter((x) => x[2] === "l");
  L.forEach((m, i) => { const a = Math.PI * (0.62 + 0.76 * (i / (L.length - 1))); pos[m[0]] = [cx + Math.cos(a) * rx, cy + Math.sin(a) * ry]; }); R.forEach((m, i) => { const a = Math.PI * (-0.34 + 0.68 * (i / (R.length - 1))); pos[m[0]] = [cx + Math.cos(a) * rx, cy + Math.sin(a) * ry]; });
  const anchor = {}; MEM.forEach(([id]) => { let best = 0, bd = 1e9; np.forEach((q, i) => { const d = (q[0] - pos[id][0]) ** 2 + (q[1] - pos[id][1]) ** 2 + (q[2] > 0.1 ? 0 : 4000); if (d < bd) { bd = d; best = i; } }); anchor[id] = best; });
  const kc = keysOn();
  MEM.forEach(([id, name, ty]) => { const m = S.mem[id], on = ty === "r" || kc[id], v = m && !m.err ? m.v : 0, mc = v > 0.12 ? "38,198,160" : v < -0.12 ? "242,86,106" : "150,160,190", p = pos[id], q = np[anchor[id]], al = on ? 1 : 0.25;
    const mx = (p[0] + q[0]) / 2, my = (p[1] + q[1]) / 2 + (p[1] < cy ? -18 : 18); c.strokeStyle = `rgba(${mc},${(0.18 + (m ? Math.abs(v) * 0.4 : 0)) * al})`; c.lineWidth = 1.2; c.beginPath(); c.moveTo(p[0], p[1]); c.quadraticCurveTo(mx, my, q[0], q[1]); c.stroke();
    const rr = 7 + (m && !m.err ? Math.abs(v) * 4 : 0) + (m && m.pulse > 0 ? m.pulse * 3 : 0); if (m && m.pulse) m.pulse = Math.max(0, m.pulse - dt * 2); const gg = c.createRadialGradient(p[0], p[1], 0, p[0], p[1], rr * 3); gg.addColorStop(0, `rgba(${mc},${0.45 * al})`); gg.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = gg; c.fillRect(p[0] - rr * 3, p[1] - rr * 3, rr * 6, rr * 6);
    c.fillStyle = `rgba(${mc},${al})`; c.beginPath(); c.arc(p[0], p[1], rr * 0.62, 0, 6.3); c.fill(); c.strokeStyle = `rgba(${mc},${0.7 * al})`; c.lineWidth = 1.4; c.beginPath(); c.arc(p[0], p[1], rr, 0, 6.3); c.stroke();
    c.textAlign = "center"; c.fillStyle = `rgba(200,208,228,${0.85 * al})`; c.font = '600 11px "Segoe UI",sans-serif'; c.fillText(name, p[0], p[1] + rr + 14); c.fillStyle = `rgba(${mc},${al})`; c.font = '10px "Cascadia Mono",Consolas,monospace'; c.fillText(!on ? "anahtar yok" : m && !m.err ? `${v >= 0 ? "+" : ""}${v.toFixed(2)}` : m && m.err ? "hata" : "…", p[0], p[1] + rr + 26); });
  // oy atımları + istişare okları
  for (let i = C.pulses.length - 1; i >= 0; i--) { const q = C.pulses[i]; q.t += dt / 0.8; if (q.t >= 1) { C.pulses.splice(i, 1); const n = NEU[anchor[q.id]]; if (n) { n.e = 1; n.nb.forEach((j) => { NEU[j].e = Math.max(NEU[j].e, 0.8); NEU[j].nb.forEach((k2) => (NEU[k2].e = Math.max(NEU[k2].e, 0.5))); }); } const m = S.mem[q.id]; if (m) m.pulse = 1; continue; } const p = pos[q.id], a = np[anchor[q.id]], u = q.t, mx = (p[0] + a[0]) / 2, my = (p[1] + a[1]) / 2 + (p[1] < cy ? -18 : 18), m1 = 1 - u, x = m1 * m1 * p[0] + 2 * m1 * u * mx + u * u * a[0], y = m1 * m1 * p[1] + 2 * m1 * u * my + u * u * a[1], gg = c.createRadialGradient(x, y, 0, x, y, 12); gg.addColorStop(0, "rgba(255,255,255,.95)"); gg.addColorStop(0.4, `rgba(${q.col},.6)`); gg.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = gg; c.fillRect(x - 12, y - 12, 24, 24); }
  for (let i = C.chords.length - 1; i >= 0; i--) { const q = C.chords[i]; q.t += dt / 1.1; if (q.t >= 1) { C.chords.splice(i, 1); continue; } if (q.t < 0) continue; const a = pos[q.a], b = pos[q.b]; if (!a || !b) { C.chords.splice(i, 1); continue; } const u = q.t, mx = (a[0] + b[0]) / 2 + (cx - (a[0] + b[0]) / 2) * 0.5, my = (a[1] + b[1]) / 2 + (cy - (a[1] + b[1]) / 2) * 0.5, m1 = 1 - u, x = m1 * m1 * a[0] + 2 * m1 * u * mx + u * u * b[0], y = m1 * m1 * a[1] + 2 * m1 * u * my + u * u * b[1]; c.strokeStyle = "rgba(160,170,220,.18)"; c.lineWidth = 1; c.beginPath(); c.moveTo(a[0], a[1]); c.quadraticCurveTo(mx, my, b[0], b[1]); c.stroke(); const gg = c.createRadialGradient(x, y, 0, x, y, 9); gg.addColorStop(0, "rgba(255,255,255,.9)"); gg.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = gg; c.fillRect(x - 9, y - 9, 18, 18); }
  if (C.flash > 0) { c.strokeStyle = rgb(C.flash * 0.7); c.lineWidth = 2; c.beginPath(); c.arc(cx, cy, Rc * (1.2 + (1 - C.flash) * 1.4), 0, 6.3); c.stroke(); }
}
function ui() {
  const el = $("#council"); if (!el) return; const S = stOf(C.sym), big = $(".cdec .big", el), sub = $(".cdec .sub", el); const col = `rgb(${COL[S.dec].join(",")})`;
  if (big.textContent !== S.dec) { big.textContent = S.dec; } big.style.color = col; const s2 = `${NAME[C.sym]} · 15m · güven %${Math.round(S.conf * 100)} · skor ${S.score >= 0 ? "+" : ""}${S.score.toFixed(2)}${C.running ? " · tartışılıyor…" : ""}`; if (sub.textContent !== s2) sub.textContent = s2;
  const th = S.talk.slice(0, 14).map((l) => `<div class="ln"><b>${esc(l.who)}</b> <span class="${l.cls}">${esc(l.txt)}</span></div>`).join("") || '<div class="ln" style="color:#6f768c">Sinyal beyni ilk toplantısını yapıyor…</div>'; const tk = $("#cn-talk"); if (tk && tk._h !== th) { tk._h = th; tk.innerHTML = th; }
  $("#cn-sym").querySelectorAll("button").forEach((b) => b.classList.toggle("on", b.dataset.s === C.sym));
}
function boot() {
  const el = $("#council"); if (!el) return; build(); $("#cn-sym").innerHTML = SYMS.map((s) => `<button data-s="${s}">${NAME[s]}</button>`).join(""); $("#cn-sym").querySelectorAll("button").forEach((b) => (b.onclick = () => { C.sym = b.dataset.s; localStorage.setItem("nera_cn_sym", C.sym); C.pulses.length = 0; C.chords.length = 0; const S = stOf(C.sym); if (Date.now() - S.at > 30000) session(C.sym, false); ui(); }));
  const run = $("#cn-run"); if (run) run.onclick = () => session(C.sym, true);
  palCol(); DT.on("palette", palCol); TICKS.push(frame); setInterval(ui, 400);
  setTimeout(() => { if (!MOB || Lab.view() === "office") session(C.sym, false); }, 9000);                                                    // kural oturumu: ucuz, 1 dk'da bir
  setInterval(() => { if (!C.running && (!MOB || Lab.view() === "office")) session(C.sym, false); }, 60000);
  setInterval(() => { const S = stOf(C.sym), every = (+localStorage.getItem("nera_cn_llm") || 10) * 60000, k = keysOn(); if (!C.running && LLMS.some(([x]) => k[x]) && Date.now() - S.llmAt > every && (!MOB || Lab.view() === "office")) session(C.sym, true); }, 30000);
  DT.on("view", (v) => { if (v === "office") { const S = stOf(C.sym), k = keysOn(); if (!C.running && Date.now() - S.at > 20000) session(C.sym, LLMS.some(([x]) => k[x]) && Date.now() - S.llmAt > 6 * 60000); } });
  DT.on("wake", () => { C.pulses.length = 0; C.chords.length = 0; });
}
window.addEventListener("DOMContentLoaded", boot);
})();


