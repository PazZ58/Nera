"use strict";
/* Nera · laboratuvar içindeki sinir ağı (otonom), haber, ayarlar/API anahtarları, Piyasa sinyal paneli eki. lab2.js'den sonra yüklenir. */
(function () {
const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
const f1 = (x, d = 2) => (x == null || !isFinite(x) ? "—" : Number(x).toFixed(d)), pc = (x, d = 0) => (x == null || !isFinite(x) ? "—" : (x * 100).toFixed(d) + "%"), nf = (x) => Number(x || 0).toLocaleString("tr-TR");
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const fit = (cv, w, h) => Lab.fitCanvas(cv, w, h);
const visible = (id) => Lab.view() === id;
const NAMES = { BTCUSDT: "BTC", ETHUSDT: "ETH", XAUUSDT: "Altın", XAGUSDT: "Gümüş", EURUSD: "EUR/USD" };
const jget = (u) => NAPI(u);
const jpost = (u, b) => NAPI(u, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(b) });

/* ================================================================ SİNİR AĞI (laboratuvar içinde, kendi kendine eğitilir) */
const NN = { s: [32, 32, 16, 3], W: null, b: null, X: null, P: null, T: null, key: 0, drawn: -1, play: null, pk: [], run: false, ep: 0, E: 0, hist: [], ev: null, strong: [], k: 0, nextT: 0, lastTrain: 0, off: null };
const FEAT = ["Getiri/ATR", "EMA mesafe", "RSI", "ADX", "Delta oranı", "Mum aralığı", "Kapanış konumu", "Hacim z"], OUTN = ["YOK", "AL", "SAT"], ORD = [1, 0, 2];            // ekran sırası: AL, YOK, SAT
function buildNN() {
  const h = $("#lb-nn"); if (!h) return; h.innerHTML = `<div class="ph">Sinir ağı <small id="nn-sub">piyasa durumunu öğrenir</small><div class="sp"><span class="chip vio" id="nn-state">hazır</span><button class="btn" id="nn-go">Şimdi yeniden eğit</button></div></div>
    <div id="nn-wrap"><canvas id="nn-cv"></canvas></div><div class="nnbars" id="nn-bars">—</div>
    <div class="two" style="padding:0 12px 12px"><div><div class="eyebrow" style="margin:6px 0">Eğitim eğrisi</div><canvas id="nn-loss" style="width:100%;height:130px"></canvas></div><div id="nn-res" style="font-size:12.5px;line-height:1.6;color:#aab1c4;padding-top:6px">Veri yüklenince ağ kendi kendine eğitilmeye başlar.</div></div>`;
  $("#nn-go").onclick = () => train(true);
}
function train(manual) {
  if (!Lab.data || NN.run) { if (manual && !Lab.data) Lab.toast("Önce laboratuvar verisi yüklenmeli.", "#ffb04a"); return; }
  NN.hist = []; NN.run = true; NN.ev = null; NN.lastTrain = Date.now(); Lab.post({ cmd: "nn", cfg: Object.assign({}, Lab.cfg, { epochs: 20, thr: 0.5 }) }); Lab.logAdd("MODEL", "vio", "Sinir ağı eğitimi başladı (otomatik).");
}
const lay = (w, h) => { const xs = [0.1, 0.37, 0.64, 0.9].map((v) => w * v), out = []; NN.s.forEach((n, l) => { const a = [], t = 44, b = h - 26; for (let i = 0; i < n; i++) a.push({ x: xs[l], y: l === 3 ? t + (b - t) * (ORD.indexOf(i) + 0.5) / 3 : t + (b - t) * (i + 0.5) / n }); out.push(a); }); return out; };
function renderEdges(w, h, P) {
  const oc = NN.off || (NN.off = document.createElement("canvas")); oc.width = w; oc.height = h; const o = oc.getContext("2d"); o.clearRect(0, 0, w, h); NN.strong = [];
  for (let l = 0; l < NN.s.length - 1; l++) { const a = NN.s[l], b = NN.s[l + 1], W = NN.W[l]; let mx = 1e-6; for (const v of W) mx = Math.max(mx, Math.abs(v));
    for (let j = 0; j < b; j++) { const inc = []; for (let k = 0; k < a; k++) inc.push([Math.abs(W[k * b + j]), k]); inc.sort((p, q) => q[0] - p[0]); const keep = l === 2 ? 16 : 5;
      for (const [aw, k] of inc.slice(0, keep)) { const v = W[k * b + j], q = aw / mx, A = P[l][k], B = P[l + 1][j], dx = (B.x - A.x) * 0.5; const g = o.createLinearGradient(A.x, A.y, B.x, B.y), col = v > 0 ? "255,176,74" : "138,123,255"; g.addColorStop(0, `rgba(${col},${0.08 + q * 0.4})`); g.addColorStop(1, `rgba(${col},${0.18 + q * 0.5})`);
        o.strokeStyle = g; o.lineWidth = 0.5 + q * 1.5; o.beginPath(); o.moveTo(A.x, A.y); o.bezierCurveTo(A.x + dx, A.y, B.x - dx, B.y, B.x, B.y); o.stroke(); if (q > 0.3) NN.strong.push([l, k, j, v > 0 ? 1 : -1, q]); } } }
  NN.drawn = NN.key;
}
function fwd(x) {
  const A = [x.slice()]; const L = NN.s.length - 1;
  for (let l = 0; l < L; l++) { const a = NN.s[l], b = NN.s[l + 1], W = NN.W[l], bb = NN.b[l], inp = A[l], out = new Array(b); for (let j = 0; j < b; j++) { let s = bb[j]; for (let k = 0; k < a; k++) s += inp[k] * W[k * b + j]; out[j] = l < L - 1 ? Math.max(0, s) : s; }
    if (l === L - 1) { const m = Math.max(...out); let z = 0; for (let j = 0; j < b; j++) { out[j] = Math.exp(out[j] - m); z += out[j]; } for (let j = 0; j < b; j++) out[j] /= z; } A.push(out); }
  return A;
}
function playAct(act, tag) { NN.play = { t: 0, act, tag, spawned: [0, 0, 0] }; }
function drawNN(dt, t) {
  const cv = $("#nn-cv"); if (!cv || !vis(cv)) return; const wrap = cv.parentElement, w = wrap.clientWidth, h = wrap.clientHeight; if (w < 50) return; const c = fit(cv, w, h), P = lay(w, h); c.clearRect(0, 0, w, h);
  c.font = '700 9px "Cascadia Mono",Consolas,monospace'; c.fillStyle = "#6a7188"; c.textAlign = "center"; ["GİRDİ ÖZELLİKLERİ", "DERİN ÖZELLİKLER", "KARAR ÖZELLİKLERİ", "PİYASA DURUMU"].forEach((s, l) => c.fillText(s, P[l][0].x, 22)); c.textAlign = "left";
  if (NN.W && NN.key !== NN.drawn) renderEdges(w, h, P); if (NN.off && NN.W) c.drawImage(NN.off, 0, 0, w, h);
  if (!NN.W) { c.fillStyle = "#6f768c"; c.font = "13px sans-serif"; c.textAlign = "center"; c.fillText("Ağ henüz eğitilmedi: veri yüklenince kendiliğinden başlar", w / 2, h / 2); c.textAlign = "left"; }
  if (NN.W && !NN.run) { NN.nextT -= dt; if (NN.nextT <= 0 && NN.X && NN.X.length) { NN.nextT = 1.9; NN.k = (NN.k + 1 + Math.floor(Math.random() * 4)) % NN.X.length; const A = fwd(NN.X[NN.k]); playAct(A, { t: NN.T && NN.T[NN.k], p: A[3] }); } }
  const pl = NN.play; let lv = [0, 0, 0, 0]; if (pl) { pl.t += dt; for (let l = 0; l < 4; l++) { const x = (pl.t - l * 0.28) / 0.35; lv[l] = x < 0 ? 0 : x < 1 ? x : Math.max(0, 1 - (x - 1) / 4); if (pl.t > l * 0.28 && !pl.spawned[l] && l < 3) { pl.spawned[l] = 1; const ed = NN.strong.filter((e) => e[0] === l); for (let q = 0; q < 26 && ed.length; q++) { const e = ed[Math.floor(Math.random() * ed.length)], a = pl.act[l][e[1]]; const mxv = Math.max(1e-6, ...pl.act[l].map(Math.abs)); if (Math.abs(a) / mxv > 0.25 || Math.random() < 0.15) NN.pk.push({ e, u: 0, v: 1.6 + Math.random() * 0.8, a: Math.abs(a) / mxv }); } } } if (pl.t > 4.5) NN.play = null; }
  for (let i = NN.pk.length - 1; i >= 0; i--) { const p = NN.pk[i]; p.u += dt * p.v; if (p.u >= 1) { NN.pk.splice(i, 1); continue; } const [l, k, j, sg] = p.e, A = P[l][k], B = P[l + 1][j], dx = (B.x - A.x) * 0.5, u = p.u, m = 1 - u; const x = m * m * m * A.x + 3 * m * m * u * (A.x + dx) + 3 * m * u * u * (B.x - dx) + u * u * u * B.x, y = m * m * m * A.y + 3 * m * m * u * A.y + 3 * m * u * u * B.y + u * u * u * B.y;
    const g = c.createRadialGradient(x, y, 0, x, y, 7); g.addColorStop(0, "rgba(255,255,255,.9)"); g.addColorStop(0.4, sg > 0 ? "rgba(255,190,100,.6)" : "rgba(170,150,255,.6)"); g.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = g; c.fillRect(x - 7, y - 7, 14, 14); }
  P.forEach((layer, l) => { const act = pl ? pl.act[l] : null, mxv = act ? Math.max(1e-6, ...act.map(Math.abs)) : 1; layer.forEach((n, i) => { let a = 0.12 + 0.08 * Math.sin(t * 1.3 + i * 0.7 + l); if (act) { const v = l === 3 ? act[i] : Math.abs(act[i]) / mxv; a = Math.max(a, v * lv[l]); } const r = 3.2 + a * 4.2 + (l === 3 ? 3 : 0);
      const g = c.createRadialGradient(n.x, n.y, 0, n.x, n.y, r * 3.4); g.addColorStop(0, l === 3 ? (i === 1 ? `rgba(38,198,160,${0.2 + a * 0.6})` : i === 2 ? `rgba(242,86,106,${0.2 + a * 0.6})` : `rgba(160,170,200,${0.2 + a * 0.5})`) : `rgba(255,220,160,${0.1 + a * 0.55})`); g.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = g; c.fillRect(n.x - r * 3.4, n.y - r * 3.4, r * 6.8, r * 6.8);
      c.fillStyle = l === 3 ? ["#9aa3bd", "#26c6a0", "#f2566a"][i] : `rgba(245,240,255,${0.45 + a * 0.55})`; c.beginPath(); c.arc(n.x, n.y, r, 0, 6.3); c.fill();
      if (l === 0 && i < 8) { c.fillStyle = "rgba(150,170,210,.75)"; c.font = "9px Consolas,monospace"; c.textAlign = "right"; c.fillText(FEAT[i], n.x - 12, n.y + 3); c.textAlign = "left"; }
      if (l === 3) { c.fillStyle = "#d6dbea"; c.font = "bold 11px Consolas,monospace"; c.fillText(OUTN[i] === "YOK" ? "YOK" : OUTN[i] === "AL" ? "AL" : "SAT", n.x + 14, n.y + 4); if (act) { c.fillStyle = "#8b92a8"; c.fillText(" " + Math.round(act[i] * 100 * lv[3]) + "%", n.x + 14 + (OUTN[i] === "YOK" ? 24 : 18), n.y + 4); } } }); });
}
function drawLoss() {
  const cv = $("#nn-loss"); if (!cv || !vis(cv)) return; const w = cv.parentElement.clientWidth, h = 130, c = fit(cv, w, h); c.clearRect(0, 0, w, h); const H = NN.hist; if (H.length < 2) { c.fillStyle = "#6f768c"; c.font = "12px sans-serif"; c.fillText("eğitim sürerken çizilir", 8, 22); return; }
  const all = H.flatMap((x) => [x.loss, x.vloss]), lo = Math.min(...all) - 0.02, hi = Math.max(...all) + 0.02, X = (i) => 6 + i / Math.max(1, NN.E - 1) * (w - 12), Y = (v) => h - 10 - (v - lo) / (hi - lo) * (h - 20);
  c.strokeStyle = "rgba(120,140,200,.15)"; for (let i = 0; i < 3; i++) { c.beginPath(); c.moveTo(0, 10 + i * (h - 20) / 2); c.lineTo(w, 10 + i * (h - 20) / 2); c.stroke(); }
  [["loss", "#ffb04a"], ["vloss", "#8a7bff"]].forEach(([k, col]) => { c.strokeStyle = col; c.lineWidth = 2; c.beginPath(); H.forEach((x, i) => (i ? c.lineTo(X(i), Y(x[k])) : c.moveTo(X(i), Y(x[k])))); c.stroke(); });
}
function updNN() {
  if (!$("#nn-state")) return; const st = NN.run ? `eğitiliyor ${NN.ep}/${NN.E || 20}` : NN.ev ? "canlı akış" : Lab.data ? "başlıyor…" : "veri bekliyor"; const s = $("#nn-state"); if (s.textContent !== st) s.textContent = st;
  const b = $("#nn-bars"), pl = NN.play && NN.play.tag, e = NN.ev;
  const bh = NN.W ? `<span>${NN.run ? "Eğitim sürüyor: ağırlıklar canlı değişiyor." : pl && pl.t ? `Gerçek geçmiş mum: <b>${new Date(pl.t).toLocaleString("tr-TR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" })}</b> ağdan geçiyor` : "Son 120 mum sırayla ağdan geçiyor"}</span>${pl && pl.p ? `<span class="na">AL ${pc(pl.p[1])}</span><span class="muted">YOK ${pc(pl.p[0])}</span><span class="down">SAT ${pc(pl.p[2])}</span>` : ""}${NN.live ? `<span class="mono muted">son mum: AL ${pc(NN.live[1])} · SAT ${pc(NN.live[2])}</span>` : ""}` : "—"; if (b._h !== bh) { b._h = bh; b.innerHTML = bh; }
  const r = $("#nn-res"); if (r && e) { const maj = Math.max(...e.base), good = e.oos.avgR > 0.03 && e.oos.pf > 1.1 && e.oos.n >= 20;
    const h = `<b class="${good ? "na" : "nc"}">${good ? "OOS pozitif görünüyor" : "OOS'ta kârlı değil"}</b> · doğruluk ${pc(e.acc, 1)} (çoğunluk sınıfı ${pc(maj, 1)}, rastgele 33%)<br>IS: ${e.is.n} işlem · ort ${f1(e.is.avgR)}R · PF ${f1(e.is.pf)}<br>OOS: ${e.oos.n} işlem · ort ${f1(e.oos.avgR)}R · PF ${f1(e.oos.pf)}<br><span class="muted">${good ? "Yine de tek deneme; her yeniden eğitim yeni bir şans denemesidir." : "Model eğitim verisine uydu: finansal verilerde beklenen sonuç. Sinyallere bağlı değil."}${e.mc ? ` Monte Carlo: %${(e.mc.pDD25 * 100).toFixed(0)} ihtimalle >%25 düşüş.` : ""}</span>`; if (r._h !== h) { r._h = h; r.innerHTML = h; } }
  drawLoss();
}
DT.on("lab:msg", (m) => {
  if (m.ev === "nnstep") { NN.s = m.s; NN.W = m.W; NN.b = m.b; NN.ep = m.ep + 1; NN.key++; if (m.act && (!NN.play || NN.play.t > 0.7)) playAct(m.act, { t: 0, p: m.act[3] }); }
  else if (m.ev === "nnep") { NN.hist.push({ loss: m.loss, vloss: m.vloss }); NN.ep = m.ep; NN.E = m.E; Office.act("nn", `Epoch ${m.ep}/${m.E}: kayıp ${f1(m.loss, 3)} · doğrulama ${f1(m.vloss, 3)} · doğ. ${pc(m.vacc)}`); }
  else if (m.ev === "nnmodel") { NN.s = m.s; NN.W = m.W; NN.b = m.b; NN.X = m.X; NN.P = m.P; NN.T = m.T; NN.key++; NN.k = 0; NN.nextT = 0.5; }
  else if (m.ev === "nnlog") Lab.logAdd("MODEL", "vio", m.txt);
  else if (m.ev === "nneval") { NN.ev = m; NN.live = m.last; Office.act("nn", `OOS doğruluk ${pc(m.acc, 1)} · OOS ${m.oos.n} işlem · ort ${f1(m.oos.avgR)}R`, 3000); Lab.logAdd("MODEL", m.oos.avgR > 0.03 ? "ok" : "bad", `NN OOS: doğruluk ${pc(m.acc, 1)}, ${m.oos.n} işlem, ort ${f1(m.oos.avgR)}R (IS ${f1(m.is.avgR)}R)`); }
  else if (m.ev === "nndone") { NN.run = false; LM.event("lab", { color: "#8a7bff", msg: "Sinir ağı eğitimi bitti" }); }
});
DT.on("lab:data", () => { NN.W = null; NN.X = null; NN.ev = null; setTimeout(() => train(false), 12000); });
setInterval(() => { if (Lab.data && !NN.run && NN.ev && Date.now() - NN.lastTrain > 30 * 60 * 1000) train(false); }, 60000);          // 30 dakikada bir kendini yeniden eğitir

/* ================================================================ HABER */
const NP = {};
function nDec(m) { if (!m || !m.n) return { d: "BEKLE", c: 0, why: "haber yok" }; const s = m.score, c = m.conf; let d = "BEKLE"; if (c >= 0.25 && s >= 0.16) d = "LONG"; else if (c >= 0.25 && s <= -0.16) d = "SHORT"; if (m.shock && Math.abs(s) < 0.4) d = "BEKLE"; return { d, c: Math.min(1, Math.abs(s) * 2.2 * (0.5 + c)), why: m.top && m.top[0] ? m.top[0].title : "" }; }
TICKS.push((dt, t) => {                                        // haber görüşü: LONG yukarı, SHORT aşağı akan parçacık rüzgârı; BEKLE'de yanal salınım
  const cvs = document.querySelectorAll("canvas.nbc"); if (!cvs.length || !vis(cvs[0])) return;
  cvs.forEach((cv) => { const w = cv.parentElement.clientWidth, h = cv.parentElement.clientHeight; if (w < 20) return; const c = fit(cv, w, h), s = cv.dataset.s, m = News.sum[s] || { n: 0, score: 0 }, d = nDec(m), st = NP[s] || (NP[s] = { ps: Array.from({ length: 46 }, () => ({ x: Math.random(), y: Math.random(), v: 0.4 + Math.random(), z: Math.random() })), col: [255, 176, 74] }), tg = d.d === "LONG" ? hex2(CUP) : d.d === "SHORT" ? hex2(CDN) : hex2(CC);
    for (let i = 0; i < 3; i++) st.col[i] += (tg[i] - st.col[i]) * Math.min(1, dt * 2); const rgb = (a) => `rgba(${st.col[0] | 0},${st.col[1] | 0},${st.col[2] | 0},${a})`; c.clearRect(0, 0, w, h);
    const g = c.createLinearGradient(0, d.d === "SHORT" ? 0 : h, 0, d.d === "SHORT" ? h : 0); g.addColorStop(0, rgb(0.0)); g.addColorStop(1, rgb(d.d === "BEKLE" ? 0.05 : 0.16)); c.fillStyle = g; c.fillRect(0, 0, w, h);
    const sp = (d.d === "BEKLE" ? 0.05 : 0.18 + Math.abs(m.score) * 0.5) * (d.d === "SHORT" ? 1 : -1);
    for (const p of st.ps) { if (d.d === "BEKLE") { p.x += Math.sin(t * 0.8 + p.z * 9) * 0.0016 * p.v; p.y += Math.cos(t * 0.6 + p.z * 7) * 0.0012; } else p.y += sp * p.v * dt; if (p.y < -0.05) p.y = 1.05; if (p.y > 1.05) p.y = -0.05; p.x = (p.x + 1) % 1; const x = p.x * w, y = p.y * h, tail = d.d === "BEKLE" ? 3 : 10 + Math.abs(sp) * 40 * p.v;
      c.strokeStyle = rgb(0.18 + p.z * 0.5); c.lineWidth = 1 + p.z * 1.2; c.beginPath(); c.moveTo(x, y); c.lineTo(x, y + (d.d === "SHORT" ? -tail : tail)); c.stroke(); c.fillStyle = rgb(0.5 + p.z * 0.5); c.beginPath(); c.arc(x, y, 1 + p.z * 1.4, 0, 6.3); c.fill(); }
    const bar = (0.5 + m.score * 0.5) * w; c.fillStyle = "rgba(255,255,255,.07)"; c.fillRect(0, h - 4, w, 4); c.fillStyle = rgb(0.9); c.fillRect(Math.min(bar, w / 2), h - 4, Math.abs(bar - w / 2), 4); });
});
const News = { items: [], sum: {}, status: {}, keys: {}, sel: "ALL", seen: new Set(), first: true };
Lab.newsSum = News.sum;
async function pollNews() {
  const j = await jget("/api/news"); if (!j) return; News.items = j.items; News.sum = j.sum; News.status = j.status; j.keys.llm = ["gemini", "groq", "openrouter", "mistral"].some((k) => j.keys[k]); News.keys = j.keys; Lab.keys = j.keys; if (window.Office) Office.act("haber", `${j.items.length} haber tarandı · ${Object.values(j.sum).filter((x) => x.shock).length} büyük olay işareti`, 2500); Lab.newsSum = j.sum;
  let fresh = 0; for (const it of j.items) { if (!News.seen.has(it.title)) { News.seen.add(it.title); if (!News.first && it.shock && it.age_min < 120) fresh++; } } if (fresh) { LM.event("news", { color: "#ffb04a", msg: "Büyük haber" }); Lab.logAdd("HABER", "warn", "Yeni önemli haber akışta."); } News.first = false;
  updNews();
}
function buildNews() {
  $("#pg-news").innerHTML = `<div class="eyebrow">Sistem · haber akışı</div><h1>Haber</h1><p class="lead">Varlık başına son haberler ve duygu puanı. Büyük olaylar riski artırır.</p>
  <div class="ncards" id="nw-cards"></div><div class="panel"><div class="ph">Haberler <small id="nw-st"></small></div><div id="nw-list"></div></div>`;
}
function updNews() {
  if (!$("#nw-cards")) return; const cards = ["XAUUSDT", "XAGUSDT", "BTCUSDT", "ETHUSDT", "EURUSD"].map((s) => { const m = News.sum[s] || { n: 0, score: 0, shock: false, top: [] }, d = nDec(m), cl = d.d === "LONG" ? "L" : d.d === "SHORT" ? "S" : "W"; return `<div class="ncard ${cl} ${News.sel === s ? "on" : ""}" data-s="${s}"><canvas class="nbc" data-s="${s}"></canvas><div class="in"><div class="nm"><span>${NAMES[s].toUpperCase()}</span><span>${m.n} haber${m.shock ? " · olay" : ""}</span></div><div><div class="dec">${d.d}</div><div class="why">haber görüşü · güven %${Math.round(d.c * 100)} · puan ${m.score >= 0 ? "+" : ""}${m.score.toFixed(2)}${d.why ? "<br>" + esc(d.why.slice(0, 70)) : ""}</div></div></div></div>`; }).join("") + `<div class="ncard ${News.sel === "ALL" ? "on" : ""}" data-s="ALL" style="--dc:#8a7bff;display:flex;align-items:center;justify-content:center;color:#d6dbea"><div style="text-align:center"><b style="font-size:16px">Tümü</b><div style="font-size:11px;color:#8b93ab;margin-top:4px">${News.items.length} haber</div></div></div>`;
  const ce = $("#nw-cards"); if (ce._h !== cards) { ce._h = cards; ce.innerHTML = cards; $$(".ncard", ce).forEach((e) => (e.onclick = () => { News.sel = e.dataset.s; ce._h = ""; updNews(); })); }
  const its = News.items.filter((x) => News.sel === "ALL" || x.syms.includes(News.sel)); const l = its.map((x) => `<div class="newsitem"><span class="sc ${x.score > 0.15 ? "p" : x.score < -0.15 ? "n" : "z"}">${x.score >= 0 ? "+" : ""}${x.score.toFixed(1)}</span><div><a href="${esc(x.link)}" target="_blank" rel="noopener">${esc(x.title)}</a><div class="muted" style="font-size:11px">${esc(x.src)} · ${x.age_min < 60 ? x.age_min + " dk" : Math.round(x.age_min / 60) + " sa"} önce · ${x.syms.map((s) => NAMES[s]).join(", ")}${x.llm ? " · Gemini" : ""}</div></div>${x.shock ? '<span class="chip warn">büyük olay</span>' : ""}</div>`).join("") || '<div class="empty2">Henüz haber yüklenmedi (ilk yükleme birkaç saniye sürer).</div>';
  const le = $("#nw-list"); if (le._h !== l) { le._h = l; le.innerHTML = l; }
  const er = Object.entries(News.status.err || {}).map(([k, v]) => `${k}: ${v}`).join(" · "); const st = `kaynak: Google News + CoinDesk${News.keys.finnhub ? " + Finnhub" : ""} · puanlama: ${News.keys.llm ? "yapay zekâ" : "sözlük"}${News.status.llm && News.status.llm !== "ok" ? " (" + News.status.llm + ")" : ""}${er ? " · uyarı: " + er : ""}`; $("#nw-st").textContent = st;
}
Lab.newsAdj = (sym, side) => { const m = News.sum[sym]; if (!m || !side || m.n < 2) return ""; const o = m.score * side; return o < -0.3 ? ' <span class="chip bad">haber ters</span>' : o > 0.3 ? ' <span class="chip ok">haber destekliyor</span>' : ""; };

/* ================================================================ AYARLAR */
const PROVS = [["gemini", "Gemini (Google)", "haber puanlama + ajan tartışması", "https://aistudio.google.com/apikey", "aistudio.google.com/apikey"], ["groq", "Groq", "hızlı açık modeller (Llama)", "https://console.groq.com/keys", "console.groq.com/keys"], ["openrouter", "OpenRouter", "ücretsiz modeller, tek anahtar", "https://openrouter.ai/keys", "openrouter.ai/keys"], ["mistral", "Mistral", "Mistral modelleri", "https://console.mistral.ai/api-keys", "console.mistral.ai/api-keys"], ["finnhub", "Finnhub", "ek haber kaynağı", "https://finnhub.io/register", "finnhub.io/register"]];
const PRESETS = [["Nera", { a: "#35e0c4", b: "#8a7bff", c: "#ffb04a", up: "#26c6a0", dn: "#f2566a" }], ["Okyanus", { a: "#4cc9f0", b: "#4361ee", c: "#f9c74f", up: "#2ec4b6", dn: "#ef476f" }], ["Gün batımı", { a: "#ff9e7a", b: "#e56bff", c: "#ffd166", up: "#7bd88f", dn: "#ff5d73" }], ["Orman", { a: "#7bdc8c", b: "#3aa6a0", c: "#e9c46a", up: "#8ac926", dn: "#e5634d" }], ["Cadılar Bayramı", { a: "#ff8a1f", b: "#a35cff", c: "#7bff6a", up: "#9bdc5b", dn: "#ff4d4d" }], ["Mono", { a: "#e6e9f2", b: "#8d96ad", c: "#c9ccd6", up: "#d6dbea", dn: "#7a8199" }]];
const sw = (id, on) => `<label class="sw"><input type="checkbox" id="${id}" ${on ? "checked" : ""}><i></i></label>`;
function buildSet() {
  const S = window.__S ? __S() : { theme: "dark", sound: false };
  $("#pg-set").innerHTML = `<div class="eyebrow">Sistem</div><h1>Ayarlar</h1><p class="lead">Anahtarlar yalnız bu bilgisayarda saklanır (<span class="mono">nera_anahtar.json</span>).</p>
  <div class="two"><div class="panel"><div class="ph">Görünüm</div><div class="setrow"><div><b>Tema</b><div class="muted" style="font-size:11px">grafik ve küre alanları her temada koyu kalır</div></div><div class="seg" id="st-theme">${[["dark", "Koyu"], ["black", "Siyah"], ["light", "Açık"], ["halloween", "Cadılar Bayramı"], ["neon", "Neon Siber"], ["ocean", "Okyanus"], ["forest", "Orman"], ["sunset", "Gün Batımı"], ["matrix", "Matrix"]].map(([k, n]) => `<button data-t="${k}" class="${S.theme === k ? "on" : ""}">${n}</button>`).join("")}</div><span></span></div></div>
  <div class="panel"><div class="ph">Ses</div><div class="setrow"><div><b>Ortam sesi</b><div class="muted" style="font-size:11px">Beyin ekranında sürekli, diğerlerinde kısık</div></div>${sw("st-amb", window.Sound && Sound.on)}<span></span></div><div class="setrow"><div><b>Sinyal sesi</b><div class="muted" style="font-size:11px">yeni sinyalde nöron akoru</div></div>${sw("st-sig", S.sound)}<span></span></div></div></div>
  <div class="panel"><div class="ph">Renk paleti <small>küre, bağlar, grafikler, LONG / SHORT renkleri</small></div><div class="pb"><div class="pals" id="pal-pre">${PRESETS.map((p, i) => `<button class="pal" data-i="${i}"><span>${[p[1].a, p[1].b, p[1].c, p[1].up, p[1].dn].map((c) => `<i style="background:${c}"></i>`).join("")}</span><b>${p[0]}</b></button>`).join("")}</div>
    <div class="palrow">${[["a", "Ana renk"], ["b", "İkincil"], ["c", "Vurgu"], ["up", "LONG"], ["dn", "SHORT"]].map(([k, n]) => `<label class="fld">${n}<input type="color" data-k="${k}" value="${(window.getPalette ? getPalette() : PALDEF)[k]}"></label>`).join("")}<button class="btn" id="pal-reset">Varsayılana dön</button></div></div></div>
  <div class="panel"><div class="ph">Bildirimler ve ekran</div>
    <div class="setrow"><div><b>Yeni strateji bildirimi (sağ alt)</b><div class="muted" style="font-size:11px">laboratuvar aday/kalıcı strateji bulunca kutu açar</div></div>${sw("st-stn", localStorage.getItem("nera_strat_notify") !== "0")}<span></span></div>
    <div class="setrow"><div><b>Sinyalde küre rengi (15 sn)</b><div class="muted" style="font-size:11px">LONG yeşil, SHORT kırmızı: kürelerin hepsi o renge bürünür</div></div>${sw("st-tint", localStorage.getItem("nera_tint") !== "0")}<span></span></div>
    <div class="setrow"><div><b>Strateji bağ sesi</b><div class="muted" style="font-size:11px">menüden küreye bağ kurulurken çalan nota</div></div>${sw("st-lnk", window.Sound ? Sound.linkOn : true)}<span></span></div>
    <div class="setrow"><div><b>Sinyal beyni bildirimi</b><div class="muted" style="font-size:11px">konsey LONG/SHORT kararı verince bildirim</div></div>${sw("st-cn", localStorage.getItem("nera_cn_notify") !== "0")}<span></span></div>
    <div class="setrow"><div><b>Yapay zekâ toplantı aralığı</b><div class="muted" style="font-size:11px">anahtar girilen yapay zekâlar bu sıklıkta toplanır (ücretsiz kota için seyrek tut)</div></div><select id="st-cnl" class="sel">${[5, 10, 20, 30].map((m) => `<option value="${m}" ${(+localStorage.getItem("nera_cn_llm") || 10) === m ? "selected" : ""}>${m} dakika</option>`).join("")}</select><span></span></div>
    <div class="setrow"><div><b>Tam ekran</b><div class="muted" style="font-size:11px">başlık çubuğunu gizler (F11 de çalışır)</div></div><button class="btn" id="st-fs">Tam ekrana geç / çık</button><span></span></div></div>
  <div class="panel"><div class="ph">Sinyaller ve laboratuvar</div>
    <div class="setrow"><div><b>5 dakikalık sinyali kapat</b><div class="muted" style="font-size:11px">5m grafikte komisyon ATR'yi yer; bu zamanda yeni sinyal üretilmez</div></div>${sw("st-no5", false)}<span></span></div>
    <div class="setrow"><div><b>Laboratuvar sembolü</b><div class="muted" style="font-size:11px">Otomatik: piyasası açık olanı seçer, altın öncelikli, 25 dk'da bir döner</div></div><select id="st-sym" class="sel">${[["auto", "Otomatik (altın öncelikli)"], ["XAUUSDT", "Altın XAU"], ["XAGUSDT", "Gümüş XAG"], ["BTCUSDT", "BTC"], ["ETHUSDT", "ETH"]].map(([v, n]) => `<option value="${v}" ${(Lab.symMode === "auto" ? "auto" : Lab.sym) === v ? "selected" : ""}>${n}</option>`).join("")}</select><span></span></div>
    <div class="setrow"><div><b>Risk tutarı ($)</b><div class="muted" style="font-size:11px">sinyal planında stop/hedef boyutu</div></div><input id="s-risk" type="number" min="1" step="5"><button class="btn" id="s-risksave">Kaydet</button></div></div>
  <div class="panel"><div class="ph">Yapay zekâ ve haber anahtarları <small>hepsi isteğe bağlı · ücretsiz katmanları var</small></div>
    ${PROVS.map(([k, n, d, u, ut]) => `<div class="setrow"><div><b>${n}</b><div class="muted" style="font-size:11px">${d}</div><a class="plink" href="${u}" target="_blank" rel="noopener">${ut} ↗</a></div><input id="k-${k}" type="password" placeholder="anahtarı yapıştır" autocomplete="off"><span id="ks-${k}" class="chip">—</span></div>`).join("")}
    <div class="setrow"><div><b>Kullanılacak yapay zekâ</b><div class="muted" style="font-size:11px">Otomatik: anahtarı olan ilk sağlayıcı; hata verirse sıradakine geçer</div></div><select id="k-prov" class="sel">${[["auto", "Otomatik"], ["gemini", "Gemini"], ["groq", "Groq"], ["openrouter", "OpenRouter"], ["mistral", "Mistral"]].map(([v, n]) => `<option value="${v}">${n}</option>`).join("")}</select><span></span></div>
    <div class="pb ctl"><button class="btn pri" id="k-save">Kaydet</button><button class="btn" id="k-test">Yapay zekâyı dene</button><button class="btn warn" id="k-clear">Anahtarları sil</button><span class="muted" id="k-msg" style="font-size:12px"></span></div></div>
  <div class="panel"><div class="ph">Notlar</div><div class="pb" style="font-size:12.5px;line-height:1.7;color:var(--text2)">Kotalar ve kurallar sağlayıcıya göre değişir ve zamanla değişebilir; kayıt sayfasında kontrol et. Ücretsiz katmanlarda istekler model eğitimi için kullanılabilir; kişisel bilgi girme. Finnhub haber toplar, diğerleri metin yorumlar ve haberleri puanlar.</div></div>`;
  const load = async () => { const j = await jget("/api/news"); if (!j) return; for (const p of PROVS) { const e = $("#ks-" + p[0]); e.textContent = j.keys[p[0]] ? "kayıtlı" : "yok"; e.className = "chip " + (j.keys[p[0]] ? "ok" : ""); } if ($("#k-prov")) $("#k-prov").value = j.prov || "auto"; const s = await jget("/api/settings"); if (s) { if ($("#s-risk")) $("#s-risk").value = s.risk_usd; if ($("#st-no5")) $("#st-no5").checked = !!s.no5m; } };
  DT.on("theme", (th) => $$("#st-theme button").forEach((x) => x.classList.toggle("on", x.dataset.t === th)));
  $$("#st-theme button").forEach((b) => (b.onclick = () => { window.setNeraTheme && setNeraTheme(b.dataset.t); $$("#st-theme button").forEach((x) => x.classList.toggle("on", x === b)); }));
  $("#st-amb").onchange = () => { if (Sound.on !== $("#st-amb").checked) Sound.toggle(); }; DT.on("sound", () => { const e = $("#st-amb"); if (e) e.checked = Sound.on; });
  $("#st-sig").onchange = () => window.setSignalSound && setSignalSound($("#st-sig").checked);
  $$("#pal-pre .pal").forEach((b) => (b.onclick = () => { const p = PRESETS[+b.dataset.i][1]; applyPalette(p); $$("#pg-set input[type=color]").forEach((i) => (i.value = p[i.dataset.k])); }));
  $$("#pg-set input[type=color]").forEach((i) => (i.oninput = () => { const p = Object.assign({}, getPalette()); p[i.dataset.k] = i.value; applyPalette(p); }));
  $("#pal-reset").onclick = () => { applyPalette(PALDEF); $$("#pg-set input[type=color]").forEach((i) => (i.value = PALDEF[i.dataset.k])); };
  $("#st-tint").onchange = () => localStorage.setItem("nera_tint", $("#st-tint").checked ? "1" : "0");
  $("#st-stn").onchange = () => localStorage.setItem("nera_strat_notify", $("#st-stn").checked ? "1" : "0");
  $("#st-lnk").onchange = () => { Sound.linkOn = $("#st-lnk").checked; localStorage.setItem("nera_lnk", Sound.linkOn ? "1" : "0"); };
  $("#st-cn").onchange = () => localStorage.setItem("nera_cn_notify", $("#st-cn").checked ? "1" : "0");
  $("#st-cnl").onchange = () => localStorage.setItem("nera_cn_llm", $("#st-cnl").value);
  $("#st-fs").onclick = () => window.toggleFS && toggleFS();
  $("#st-no5").onchange = () => jpost("/api/settings", { no5m: $("#st-no5").checked });
  $("#st-sym").onchange = () => { const v = $("#st-sym").value; Lab.symMode = v === "auto" ? "auto" : "fixed"; try { localStorage.setItem("nera_lab_symmode", JSON.stringify(Lab.symMode)); if (v !== "auto") { Lab.sym = v; localStorage.setItem("nera_lab_sym", JSON.stringify(v)); } } catch (e) { /* */ } Lab.want = true; Lab.applyCfg(); };
  $("#k-save").onclick = async () => { const b = { _prov: $("#k-prov").value }; for (const p of PROVS) { const v = $("#k-" + p[0]).value.trim(); if (v) b[p[0]] = v; } await jpost("/api/keys", b); PROVS.forEach((p) => ($("#k-" + p[0]).value = "")); $("#k-msg").textContent = "Kaydedildi."; load(); setTimeout(pollNews, 6000); };
  $("#k-clear").onclick = async () => { const b = {}; PROVS.forEach((p) => (b[p[0]] = "")); await jpost("/api/keys", b); $("#k-msg").textContent = "Silindi."; load(); };
  $("#k-test").onclick = async () => { $("#k-msg").textContent = "Deneniyor…"; const j = await jpost("/api/llm", { prompt: "Sadece 'tamam' yaz." }); $("#k-msg").textContent = j && j.text ? `Yanıt verdi (${j.prov}): ${j.text.slice(0, 40)}` : "Hata: " + ((j && j.err) || "yanıt yok"); };
  $("#s-risksave").onclick = async () => { await jpost("/api/settings", { risk_usd: +$("#s-risk").value }); $("#k-msg").textContent = "Risk tutarı kaydedildi."; };
  DT.on("view", (v) => { if (v === "set") load(); }); load();
}

/* ================================================================ Piyasa > Sinyal paneli eki: beyin görüşü, haber, strateji defteri */
function updExtra() {
  const el = $("#sig-extra"); if (!el || document.body.dataset.view !== "market" || !window.__S) return; const S = __S(), ev = S.ana && S.ana.eval; if (!ev) return;
  const m = News.sum[S.sym], nw = m && m.n ? `<div class="r"><span class="t">Haber duygusu ${m.score >= 0 ? "+" : ""}${m.score.toFixed(2)} · ${m.n} haber${m.shock ? " · <b class=nc>büyük olay</b>" : ""}</span></div>${(m.top || []).slice(0, 2).map((t) => `<div class="r"><span class="t muted">${esc(t.title)}</span><span class="${t.score > 0.15 ? "na" : t.score < -0.15 ? "down" : "muted"}">${t.score >= 0 ? "+" : ""}${t.score.toFixed(1)}</span></div>`).join("")}` : '<div class="r muted">Bu varlık için haber yok.</div>';
  const here = Lab.data && Lab.data.sym === S.sym ? Lab.book.filter((r) => r.sym === S.sym && r.tf === Lab.data.tf) : [], others = Lab.book.filter((r) => r.sym === S.sym).length;
  const bk = here.length ? here.slice(0, 5).map((r) => { const lv = Lab.live[r.sym + r.tf + JSON.stringify(r.g)]; const sd = lv ? lv.side : 0; return `<div class="r"><span class="t">${esc(r.name).slice(0, 52)}</span>${sd ? `<span class="chip ${sd > 0 ? "ok" : "bad"}">${sd > 0 ? "AL" : "SAT"}</span>${Lab.newsAdj(r.sym, sd)}` : '<span class="muted">—</span>'}</div>`; }).join("") : `<div class="r muted">${others ? others + " kayıtlı strateji var; laboratuvar bu varlıkta çalışınca burada canlı görünür." : "Bu varlık için henüz kayıtlı strateji yok."}</div>`;
  const agree = ev.agents.filter((a) => a.name !== "Risk" && a.vote * (ev.score >= 0 ? 1 : -1) > 0.15).length;
  const ls = window.LabSig ? LabSig.forSym(S.sym) : bk;
  const h = `<h5>Lab stratejileri · ${S.sym.replace("USDT", "")}</h5>${ls}<h5>Beyin görüşü</h5><div class="r"><span class="t">Ajan skoru ${ev.score >= 0 ? "+" : ""}${ev.score.toFixed(2)} · ${agree}/${ev.agents.length - 1} ajan aynı yönde · durum <b>${ev.state}</b></span></div><h5>Haber</h5>${nw}`;
  if (el._h !== h) { el._h = h; el.innerHTML = h; }
}
function boot() { buildNN(); buildNews(); buildSet(); setInterval(() => updNN(), 300); TICKS.push((dt, t) => drawNN(dt, t)); setTimeout(pollNews, 3500); setInterval(pollNews, MOB ? 240000 : 60000); setInterval(() => { updExtra(); if (visible("news")) updNews(); }, 2500); DT.on("view", (v) => { if (v === "news") pollNews(); }); }
window.addEventListener("DOMContentLoaded", boot);
})();
