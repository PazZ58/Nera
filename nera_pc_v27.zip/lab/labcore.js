"use strict";
/* DayTrader Lab çekirdeği · Web Worker (DOM yok). Veri: Binance Futures klines (taker alış hacmi = gerçek delta).
   Parçalar: veri yükleme · göstergeler · strateji kitaplığı (bouwstenen) · olay tabanlı backtest (maliyetli, bir sonraki mum açılışında dolum,
   stop-önce kuralı) · metrikler (Sharpe, deflated Sharpe eşiği, Monte Carlo) · genetik arama (IS'te evrim, OOS'ta eleme) · MLP sinir ağı eğitimi.
   Hiçbir şey kârlılık kanıtı değildir: OOS'tan geçen strateji bile geleceği garanti etmez. */
const IN_WORKER = typeof importScripts === "function";
const TFMS = { "1m": 60000, "5m": 300000, "15m": 900000, "1h": 3600000 };
const FAPI = "https://fapi.binance.com/fapi/v1/klines";
const DAY = 86400000;
const LAB = { onmsg: null };
const post = (m) => { if (IN_WORKER) self.postMessage(m); else if (LAB.onmsg) LAB.onmsg(m); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function rng32(a) { return () => { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
let R = rng32(Date.now() & 0xffffff);
const pick = (a) => a[Math.floor(R() * a.length)];

/* ---------------------------------------------------------------- veri */
let D = null, MEMO = new Map(), WARM = 250;
const nthSun = (y, m, n) => { const f = new Date(Date.UTC(y, m - 1, 1)).getUTCDay(); return Date.UTC(y, m - 1, 1 + (7 - f) % 7 + 7 * (n - 1)); };
const nyOff = (ms) => { const y = new Date(ms).getUTCFullYear(); return ms >= nthSun(y, 3, 2) + 7 * 3600e3 && ms < nthSun(y, 11, 1) + 6 * 3600e3 ? -4 : -5; };
async function loadData(sym, tf, days, prog) {
  const ms = TFMS[tf], need = Math.min(Math.round(days * DAY / ms), 60000);
  let end = Date.now(), rows = [];
  while (rows.length < need) {
    const lim = Math.min(1500, need - rows.length);
    const r = await fetch(`${FAPI}?symbol=${sym}&interval=${tf}&limit=${lim}&endTime=${end}`);
    if (!r.ok) throw new Error("Binance HTTP " + r.status);
    const j = await r.json(); if (!Array.isArray(j) || !j.length) break;
    rows = j.concat(rows); end = j[0][0] - 1; prog(rows.length, need);
    if (j.length < lim) break;
  }
  if (rows.length && rows[rows.length - 1][6] > Date.now()) rows.pop();          // oluşan mumu at
  if (/^XA[UG]/.test(sym)) rows = rows.filter((x) => { const g = new Date(x[0] + nyOff(x[0]) * 3600e3), wd = g.getUTCDay(), h = g.getUTCHours(); return !(wd === 6 || (wd === 5 && h >= 17) || (wd === 0 && h < 18) || (wd >= 1 && wd <= 4 && h === 17)); });      // altın/gümüş: hafta sonu ve günlük ara (NY 17-18) perpetual mumları gerçek piyasa değil
  if (rows.length < 800) throw new Error("Yetersiz geçmiş veri: " + rows.length + " mum");
  const n = rows.length, d = { sym, tf, ms, n, t: new Float64Array(n), o: new Float64Array(n), h: new Float64Array(n), l: new Float64Array(n), c: new Float64Array(n), v: new Float64Array(n), tb: new Float64Array(n) };
  rows.forEach((x, i) => { d.t[i] = x[0]; d.o[i] = +x[1]; d.h[i] = +x[2]; d.l[i] = +x[3]; d.c[i] = +x[4]; d.v[i] = +x[5]; d.tb[i] = +x[9]; });
  MEMO = new Map(); D = d; return d;
}
const memo = (k, f) => { const key = D.sym + D.tf + D.n + k; let v = MEMO.get(key); if (!v) { v = f(); MEMO.set(key, v); } return v; };

/* ---------------------------------------------------------------- göstergeler */
function emaA(a, n) { const k = 2 / (n + 1), o = new Float64Array(a.length); o[0] = a[0]; for (let i = 1; i < a.length; i++) o[i] = a[i] * k + o[i - 1] * (1 - k); return o; }
function atrA(n) {
  return memo("atr" + n, () => { const { h, l, c } = D, o = new Float64Array(D.n); o[0] = h[0] - l[0]; for (let i = 1; i < D.n; i++) { const tr = Math.max(h[i] - l[i], Math.abs(h[i] - c[i - 1]), Math.abs(l[i] - c[i - 1])); o[i] = (o[i - 1] * (n - 1) + tr) / n; } return o; });
}
function rsiA(n) {
  return memo("rsi" + n, () => { const c = D.c, o = new Float64Array(D.n); let g = 0, w = 0; o[0] = 50;
    for (let i = 1; i < D.n; i++) { const d = c[i] - c[i - 1], u = Math.max(d, 0), dn = Math.max(-d, 0); if (i <= n) { g += u / n; w += dn / n; } else { g = (g * (n - 1) + u) / n; w = (w * (n - 1) + dn) / n; } o[i] = i < n ? 50 : (w === 0 ? 100 : 100 - 100 / (1 + g / w)); } return o; });
}
function adxA() {
  return memo("adx", () => { const { h, l, c } = D, n = 14, N = D.n, adx = new Float64Array(N); let tr = 0, pd = 0, md = 0, dx = 0, a = 0;
    for (let i = 1; i < N; i++) { const up = h[i] - h[i - 1], dn = l[i - 1] - l[i], p = up > dn && up > 0 ? up : 0, m = dn > up && dn > 0 ? dn : 0, t = Math.max(h[i] - l[i], Math.abs(h[i] - c[i - 1]), Math.abs(l[i] - c[i - 1]));
      if (i <= n) { tr += t; pd += p; md += m; } else { tr = tr - tr / n + t; pd = pd - pd / n + p; md = md - md / n + m; }
      const pi = tr ? 100 * pd / tr : 0, mi = tr ? 100 * md / tr : 0, d = pi + mi ? 100 * Math.abs(pi - mi) / (pi + mi) : 0;
      if (i < n * 2) { dx += d; adx[i] = 0; if (i === n * 2 - 1) a = dx / n; } else { a = (a * (n - 1) + d) / n; adx[i] = a; } }
    return adx; });
}
const emaC = (n) => memo("ema" + n, () => emaA(D.c, n));
const dRatio = () => memo("dr", () => { const o = new Float64Array(D.n); for (let i = 0; i < D.n; i++) o[i] = D.v[i] > 0 ? 2 * D.tb[i] / D.v[i] - 1 : 0; return o; });
const volZ = () => memo("vz", () => { const v = D.v, o = new Float64Array(D.n); for (let i = 50; i < D.n; i++) { let s = 0, q = 0; for (let k = i - 50; k < i; k++) { s += v[k]; q += v[k] * v[k]; } const m = s / 50, sd = Math.sqrt(Math.max(q / 50 - m * m, 1e-9)); o[i] = (v[i] - m) / sd; } return o; });
function rollMax(a, n) { return memo("rmx" + n + a.length + a[5], () => { const o = new Float64Array(D.n); for (let i = n; i < D.n; i++) { let m = -Infinity; for (let k = i - n; k < i; k++) if (a[k] > m) m = a[k]; o[i] = m; } return o; }); }
function rollMin(a, n) { return memo("rmn" + n + a.length + a[5], () => { const o = new Float64Array(D.n); for (let i = n; i < D.n; i++) { let m = Infinity; for (let k = i - n; k < i; k++) if (a[k] < m) m = a[k]; o[i] = m; } return o; }); }
const hourUTC = (t) => ((t % DAY) / 3600000);

/* ---------------------------------------------------------------- strateji kitaplığı (bouwstenen) */
const SP = {
  orb: { om: [15, 30, 60], so: [0, 8, 13.5] }, ema_pb: { f: [13, 21, 34], s: [55, 100, 200] }, rsi_mr: { n: [7, 14], lo: [20, 25, 30] },
  bb_sq: { n: [20, 30], k: [2, 2.5], pc: [0.2, 0.3] }, donch: { n: [20, 40, 55] }, supert: { n: [10, 14], m: [2, 3] }, vwap_rc: { k: [3, 6, 10] },
  sweep: { n: [20, 40, 60] }, delta: { thr: [0.15, 0.25, 0.35], inv: [0, 1] }, fvg: { disp: [0.8, 1.2, 1.6], exp: [12, 24] }, macd: { set: [0, 1] },
  tod: { h: [7, 8, 13, 14], n: [2, 4, 8] }, volx: { r: [0.6, 0.75], b: [1.3, 1.6] },
};
const REC = {
  orb: { tr: "Açılış aralığı kırılımı (ORB)", src: "day-trader-skill", mr: false, fn(p) {
    const { t, h, l, c } = D, N = D.n, sig = new Int8Array(N), sl = new Float64Array(N), off = p.so * 3600000, om = p.om * 60000; let cur = -1, hi = 0, lo = 0, mid = 0, done = false;
    for (let i = 0; i < N; i++) { const sd = Math.floor((t[i] - off) / DAY), st = sd * DAY + off, el = t[i] - st;
      if (sd !== cur) { cur = sd; hi = -Infinity; lo = Infinity; done = false; }
      if (el < om) { if (h[i] > hi) hi = h[i]; if (l[i] < lo) lo = l[i]; continue; }
      if (done || el > 8 * 3600000 || !isFinite(hi)) continue; mid = (hi + lo) / 2;
      if (c[i] > hi) { sig[i] = 1; sl[i] = mid; done = true; } else if (c[i] < lo) { sig[i] = -1; sl[i] = mid; done = true; } }
    return { sig, sl, flat: true }; } },
  ema_pb: { tr: "EMA trend geri çekilmesi", src: "pro/klasik", mr: false, fn(p) {
    const { o, h, l, c } = D, f = emaC(p.f), s = emaC(p.s), sig = new Int8Array(D.n);
    for (let i = p.s; i < D.n; i++) { const up = f[i] > s[i], dn = f[i] < s[i];
      if (up && l[i] <= f[i] && c[i] > f[i] && c[i] > o[i]) sig[i] = 1; else if (dn && h[i] >= f[i] && c[i] < f[i] && c[i] < o[i]) sig[i] = -1; }
    return { sig }; } },
  rsi_mr: { tr: "RSI aşırılık dönüşü", src: "TradeBot/klasik", mr: true, fn(p) {
    const r = rsiA(p.n), sig = new Int8Array(D.n);
    for (let i = 30; i < D.n; i++) { if (r[i - 1] < p.lo && r[i] >= p.lo) sig[i] = 1; else if (r[i - 1] > 100 - p.lo && r[i] <= 100 - p.lo) sig[i] = -1; }
    return { sig }; } },
  bb_sq: { tr: "Bollinger sıkışma kırılımı", src: "squeeze/klasik", mr: false, fn(p) {
    const c = D.c, N = D.n, n = p.n, sig = new Int8Array(N), bw = new Float64Array(N), up = new Float64Array(N), dn = new Float64Array(N);
    for (let i = n; i < N; i++) { let s = 0, q = 0; for (let k = i - n + 1; k <= i; k++) { s += c[k]; q += c[k] * c[k]; } const m = s / n, sd = Math.sqrt(Math.max(q / n - m * m, 0)); bw[i] = 2 * p.k * sd / m; up[i] = m + p.k * sd; dn[i] = m - p.k * sd; }
    const sq = new Uint8Array(N);
    for (let i = n + 100; i < N; i++) { let cnt = 0; for (let k = i - 100; k < i; k++) if (bw[k] < bw[i]) cnt++; sq[i] = cnt / 100 <= p.pc ? 1 : 0; }
    for (let i = n + 105; i < N; i++) { let was = 0; for (let k = i - 5; k < i; k++) was |= sq[k]; if (!was) continue; if (c[i] > up[i]) sig[i] = 1; else if (c[i] < dn[i]) sig[i] = -1; }
    return { sig }; } },
  donch: { tr: "Donchian kırılımı", src: "klasik/turtle", mr: false, fn(p) {
    const hi = rollMax(D.h, p.n), lo = rollMin(D.l, p.n), c = D.c, sig = new Int8Array(D.n);
    for (let i = p.n + 1; i < D.n; i++) { if (c[i] > hi[i]) sig[i] = 1; else if (c[i] < lo[i]) sig[i] = -1; }
    return { sig }; } },
  supert: { tr: "Supertrend dönüşü", src: "pro/klasik", mr: false, fn(p) {
    const { h, l, c } = D, N = D.n, a = atrA(p.n), sig = new Int8Array(N); let ub = 0, lb = 0, dir = 1;
    for (let i = 1; i < N; i++) { const hl = (h[i] + l[i]) / 2, u = hl + p.m * a[i], d = hl - p.m * a[i];
      ub = (u < ub || c[i - 1] > ub) ? u : ub; lb = (d > lb || c[i - 1] < lb) ? d : lb; const pd = dir;
      if (pd === 1 && c[i] < lb) dir = -1; else if (pd === -1 && c[i] > ub) dir = 1; if (i > p.n * 2 && dir !== pd) sig[i] = dir; }
    return { sig }; } },
  vwap_rc: { tr: "VWAP geri kazanımı", src: "lab/futures", mr: false, fn(p) {
    const { t, h, l, c, v } = D, N = D.n, sig = new Int8Array(N); let day = -1, pv = 0, vv = 0, below = 0, above = 0;
    for (let i = 0; i < N; i++) { const d = Math.floor(t[i] / DAY); if (d !== day) { day = d; pv = 0; vv = 0; below = 0; above = 0; } const tp = (h[i] + l[i] + c[i]) / 3; pv += tp * v[i]; vv += v[i]; const w = vv ? pv / vv : c[i];
      if (c[i] > w) { if (below >= p.k) sig[i] = 1; above++; below = 0; } else { if (above >= p.k) sig[i] = -1; below++; above = 0; } }
    return { sig }; } },
  sweep: { tr: "Likidite süpürme (ICT)", src: "pro/ICT", mr: true, fn(p) {
    const { o, h, l, c } = D, hi = rollMax(h, p.n), lo = rollMin(l, p.n), a = atrA(14), sig = new Int8Array(D.n), sl = new Float64Array(D.n);
    for (let i = p.n + 1; i < D.n; i++) {
      if (h[i] > hi[i] && c[i] < hi[i] && c[i] < o[i]) { sig[i] = -1; sl[i] = h[i] + 0.1 * a[i]; }
      else if (l[i] < lo[i] && c[i] > lo[i] && c[i] > o[i]) { sig[i] = 1; sl[i] = l[i] - 0.1 * a[i]; } }
    return { sig, sl }; } },
  delta: { tr: "Order flow delta dengesizliği", src: "pro/order flow", mr: false, fn(p) {
    const { o, c } = D, s = emaA(dRatio(), 3), z = volZ(), sig = new Int8Array(D.n);
    for (let i = 60; i < D.n; i++) { if (z[i] < 0.5) continue; let x = 0; if (s[i] > p.thr && c[i] > o[i]) x = 1; else if (s[i] < -p.thr && c[i] < o[i]) x = -1; sig[i] = p.inv ? -x : x; }
    return { sig }; } },
  fvg: { tr: "FVG geri dönüşü (ICT)", src: "pro/ICT", mr: false, fn(p) {
    const { o, h, l, c } = D, a = atrA(14), N = D.n, sig = new Int8Array(N), sl = new Float64Array(N); let gaps = [];
    for (let i = 3; i < N; i++) {
      gaps = gaps.filter((g) => i - g.b <= p.exp && !(g.d > 0 ? c[i] < g.lo : c[i] > g.hi));
      for (const g of gaps) { if (g.used) continue; const mid = (g.lo + g.hi) / 2;
        if (g.d > 0 && l[i] <= g.hi && c[i] > mid && c[i] > o[i]) { sig[i] = 1; sl[i] = g.lo - 0.2 * a[i]; g.used = true; break; }
        if (g.d < 0 && h[i] >= g.lo && c[i] < mid && c[i] < o[i]) { sig[i] = -1; sl[i] = g.hi + 0.2 * a[i]; g.used = true; break; } }
      if (l[i] > h[i - 2] && c[i - 1] - o[i - 1] > p.disp * a[i - 1]) gaps.push({ d: 1, lo: h[i - 2], hi: l[i], b: i });
      else if (h[i] < l[i - 2] && o[i - 1] - c[i - 1] > p.disp * a[i - 1]) gaps.push({ d: -1, lo: h[i], hi: l[i - 2], b: i });
      if (gaps.length > 6) gaps.shift(); }
    return { sig, sl }; } },
  macd: { tr: "MACD histogram kesişimi", src: "klasik", mr: false, fn(p) {
    const [f, s, g] = p.set ? [8, 21, 5] : [12, 26, 9], m = new Float64Array(D.n), e1 = emaC(f), e2 = emaC(s); for (let i = 0; i < D.n; i++) m[i] = e1[i] - e2[i];
    const sg = emaA(m, g), sig = new Int8Array(D.n);
    for (let i = 60; i < D.n; i++) { const a = m[i - 1] - sg[i - 1], b = m[i] - sg[i]; if (a <= 0 && b > 0) sig[i] = 1; else if (a >= 0 && b < 0) sig[i] = -1; }
    return { sig }; } },
  tod: { tr: "Seans saati momentumu", src: "lab/seans", mr: false, fn(p) {
    const { t, c } = D, sig = new Int8Array(D.n), nb = Math.max(1, Math.round(p.n * 3600000 / D.ms)); let lastDay = -1;
    for (let i = nb; i < D.n; i++) { const hr = hourUTC(t[i]), d = Math.floor(t[i] / DAY); if (Math.abs(hr - p.h) < D.ms / 7200000 && d !== lastDay) { const r = c[i] / c[i - nb] - 1; if (Math.abs(r) > 0) { sig[i] = r > 0 ? 1 : -1; lastDay = d; } } }
    return { sig }; } },
  volx: { tr: "Oynaklık genişlemesi", src: "lab/rejim", mr: false, fn(p) {
    const { o, h, l, c } = D, a5 = atrA(5), a50 = atrA(50), a = atrA(14), sig = new Int8Array(D.n);
    for (let i = 60; i < D.n; i++) { if (a5[i - 1] / a50[i - 1] < p.r && (h[i] - l[i]) > p.b * a[i - 1]) sig[i] = c[i] > o[i] ? 1 : c[i] < o[i] ? -1 : 0; }
    return { sig }; } },
};
/* ---- eski sürümlerden (xau_motor / daytrader) taşınan tarifler: order flow, hacim profili, print, X-Ray rejimi, klasikler, meta oylama */
const clvA = () => memo("clv", () => { const { h, l, c } = D, o = new Float64Array(D.n); for (let i = 0; i < D.n; i++) { const r = h[i] - l[i]; o[i] = r > 0 ? (2 * c[i] - h[i] - l[i]) / r : 0; } return o; });
const erA = (n) => memo("er" + n, () => { const c = D.c, o = new Float64Array(D.n); for (let i = n; i < D.n; i++) { let s = 0; for (let k = i - n + 1; k <= i; k++) s += Math.abs(c[k] - c[k - 1]); o[i] = s > 0 ? Math.abs(c[i] - c[i - n]) / s : 0; } return o; });
const bbA = (k) => memo("bb" + k, () => { const c = D.c, N = D.n, u = new Float64Array(N), l = new Float64Array(N); for (let i = 20; i < N; i++) { let s = 0, q = 0; for (let j = i - 19; j <= i; j++) { s += c[j]; q += c[j] * c[j]; } const m = s / 20, sd = Math.sqrt(Math.max(q / 20 - m * m, 0)); u[i] = m + k * sd; l[i] = m - k * sd; } return { u, l }; });
const cdA = () => memo("cd", () => { const N = D.n, dl = new Float64Array(N), cd = new Float64Array(N), z = new Float64Array(N); for (let i = 0; i < N; i++) dl[i] = 2 * D.tb[i] - D.v[i]; let s = 0; for (let i = 0; i < N; i++) { s += dl[i]; if (i >= 20) s -= dl[i - 20]; cd[i] = s; }
  for (let i = 120; i < N; i++) { let m = 0, q = 0; for (let k = i - 100; k < i; k++) { m += cd[k]; q += cd[k] * cd[k]; } m /= 100; const sd = Math.sqrt(Math.max(q / 100 - m * m, 1e-9)); z[i] = (cd[i] - m) / sd; } return { cd, z }; });
const vpA = () => memo("vp", () => { const { h, l, c, v } = D, N = D.n, W = 100, B = 24, poc = new Float64Array(N), vah = new Float64Array(N), val = new Float64Array(N);
  for (let i = W; i < N; i++) { let lo = Infinity, hi = -Infinity; for (let k = i - W; k < i; k++) { if (l[k] < lo) lo = l[k]; if (h[k] > hi) hi = h[k]; } const st = (hi - lo) / B || 1, bins = new Float64Array(B);
    for (let k = i - W; k < i; k++) bins[Math.min(B - 1, Math.floor(((h[k] + l[k] + c[k]) / 3 - lo) / st))] += v[k];
    let pi = 0; for (let b = 1; b < B; b++) if (bins[b] > bins[pi]) pi = b; let tot = 0; for (const x of bins) tot += x; let a = bins[pi], lo2 = pi, hi2 = pi;
    while (a < tot * 0.7 && (lo2 > 0 || hi2 < B - 1)) { const dn = lo2 > 0 ? bins[lo2 - 1] : -1, up = hi2 < B - 1 ? bins[hi2 + 1] : -1; if (up >= dn) a += bins[++hi2]; else a += bins[--lo2]; }
    poc[i] = lo + (pi + 0.5) * st; val[i] = lo + lo2 * st; vah[i] = lo + (hi2 + 1) * st; }
  return { poc, vah, val }; });
const sub = (rec, p) => memo("S" + rec + JSON.stringify(p), () => REC[rec].fn(p)).sig;
Object.assign(SP, { of_flow: { k: [1, 1.5, 2], m: [0, 1] }, of_div: { W: [20, 40] }, of_abs: { thr: [1.5, 2], W: [20, 50] }, of_stk: { n: [2, 3, 4], m: [0, 1] }, vp: { m: [0, 1, 2] }, prt: { thr: [2, 3], m: [0, 1] }, xr: { er: [0.3, 0.4], m: [0, 1] }, ema_x: { set: [0, 1, 2] }, rsi2: { lo: [5, 8, 10] }, bb_rev: { k: [2, 2.5] }, meta: { N: [3, 4, 6] } });
const META_SET = [["of_flow", { k: 1.5, m: 0 }], ["of_flow", { k: 1.5, m: 1 }], ["of_div", { W: 20 }], ["of_abs", { thr: 1.5, W: 20 }], ["of_stk", { n: 3, m: 0 }], ["vp", { m: 0 }], ["vp", { m: 1 }], ["prt", { thr: 2, m: 0 }], ["xr", { er: 0.3, m: 0 }], ["xr", { er: 0.3, m: 1 }], ["donch", { n: 20 }], ["donch", { n: 55 }], ["ema_x", { set: 1 }], ["rsi2", { lo: 8 }], ["bb_rev", { k: 2 }], ["macd", { set: 0 }]];
Object.assign(REC, {
  of_flow: { tr: "Kümülatif delta (devam / dönüş)", src: "eski sürüm · order flow", mr: false, fn(p) { const { o, c } = D, z = cdA().z, e50 = emaC(50), hh = rollMax(D.h, 20), ll = rollMin(D.l, 20), sig = new Int8Array(D.n);
    for (let i = 120; i < D.n; i++) { const bu = c[i] > o[i], be = c[i] < o[i]; if (!p.m) { if (z[i] > p.k && c[i] > e50[i] && bu) sig[i] = 1; else if (z[i] < -p.k && c[i] < e50[i] && be) sig[i] = -1; } else { if (z[i] < -p.k && c[i] <= ll[i] * 1.002 && bu) sig[i] = 1; else if (z[i] > p.k && c[i] >= hh[i] * 0.998 && be) sig[i] = -1; } } return { sig }; } },
  of_div: { tr: "CVD uyumsuzluğu", src: "eski sürüm · order flow", mr: true, fn(p) { const { o, h, l, c } = D, cd = cdA().cd, pl = rollMin(l, p.W), ph = rollMax(h, p.W), sig = new Int8Array(D.n); let cl = NaN, ch = NaN;
    for (let i = p.W + 1; i < D.n; i++) { if (l[i] < pl[i] && cd[i] > cl && c[i] > o[i]) sig[i] = 1; else if (h[i] > ph[i] && cd[i] < ch && c[i] < o[i]) sig[i] = -1; if (l[i] <= pl[i]) cl = cd[i]; if (h[i] >= ph[i]) ch = cd[i]; } return { sig }; } },
  of_abs: { tr: "Emilim (absorption) dönüşü", src: "eski sürüm · order flow", mr: true, fn(p) { const { h, l } = D, vz = volZ(), clv = clvA(), a = atrA(14), nl = rollMin(l, p.W), nh = rollMax(h, p.W), sig = new Int8Array(D.n);
    for (let i = p.W + 1; i < D.n; i++) { if (!(vz[i] > p.thr && (h[i] - l[i]) < 0.9 * a[i])) continue; if (l[i] <= nl[i] * 1.001 && clv[i] > -0.2) sig[i] = 1; else if (h[i] >= nh[i] * 0.999 && clv[i] < 0.2) sig[i] = -1; } return { sig }; } },
  of_stk: { tr: "Ardışık baskı mumları (devam / fade)", src: "eski sürüm · order flow", mr: false, fn(p) { const c = D.c, clv = clvA(), vz = volZ(), e21 = emaC(21), r = rsiA(14), sig = new Int8Array(D.n);
    for (let i = 60; i < D.n; i++) { let up = true, dn = true; for (let k = 0; k < p.n; k++) { if (!(clv[i - k] > 0.4)) up = false; if (!(clv[i - k] < -0.4)) dn = false; }
      if (!p.m) { if (up && vz[i] > 0 && c[i] > e21[i]) sig[i] = 1; else if (dn && vz[i] > 0 && c[i] < e21[i]) sig[i] = -1; } else { if (dn && r[i] < 35) sig[i] = 1; else if (up && r[i] > 65) sig[i] = -1; } } return { sig }; } },
  vp: { tr: "Hacim profili (VAL/VAH/POC)", src: "eski sürüm · hacim profili", mr: false, fn(p) { const { o, h, l, c } = D, { poc, vah, val } = vpA(), vz = volZ(), e50 = emaC(50), sig = new Int8Array(D.n);
    for (let i = 101; i < D.n; i++) { const bu = c[i] > o[i], be = c[i] < o[i];
      if (p.m === 0) { if (l[i] <= val[i] && c[i] > val[i] && bu) sig[i] = 1; else if (h[i] >= vah[i] && c[i] < vah[i] && be) sig[i] = -1; }
      else if (p.m === 1) { if (c[i] > vah[i] && c[i - 1] <= vah[i] && bu && vz[i] > 0.5) sig[i] = 1; else if (c[i] < val[i] && c[i - 1] >= val[i] && be && vz[i] > 0.5) sig[i] = -1; }
      else { if (c[i] > poc[i] && c[i - 1] <= poc[i] && c[i] > e50[i]) sig[i] = 1; else if (c[i] < poc[i] && c[i - 1] >= poc[i] && c[i] < e50[i]) sig[i] = -1; } } return { sig }; } },
  prt: { tr: "Büyük hacimli mum (Print)", src: "eski sürüm · Print", mr: false, fn(p) { const c = D.c, vz = volZ(), clv = clvA(), e50 = emaC(50), r = rsiA(14), sig = new Int8Array(D.n);
    for (let i = 60; i < D.n; i++) { const bb = vz[i] > p.thr && clv[i] > 0.6, bs = vz[i] > p.thr && clv[i] < -0.6; if (!p.m) { if (bb && c[i] > e50[i]) sig[i] = 1; else if (bs && c[i] < e50[i]) sig[i] = -1; } else { if (bs && r[i] < 30) sig[i] = 1; else if (bb && r[i] > 70) sig[i] = -1; } } return { sig }; } },
  xr: { tr: "Rejim: trend geri çekilmesi / yatay dönüş", src: "eski sürüm · X-Ray", mr: false, fn(p) { const { o, h, l, c } = D, er = erA(20), e21 = emaC(21), e50 = emaC(50), bb = bbA(2), sig = new Int8Array(D.n);
    for (let i = 60; i < D.n; i++) { const bu = c[i] > o[i], be = c[i] < o[i]; if (!p.m) { if (e21[i] > e50[i] && er[i] > p.er && l[i] <= e21[i] && c[i] > e21[i] && bu) sig[i] = 1; else if (e21[i] < e50[i] && er[i] > p.er && h[i] >= e21[i] && c[i] < e21[i] && be) sig[i] = -1; } else { const t = p.er - 0.15; if (er[i] < t && c[i] < bb.l[i] && bu) sig[i] = 1; else if (er[i] < t && c[i] > bb.u[i] && be) sig[i] = -1; } } return { sig }; } },
  ema_x: { tr: "EMA kesişimi (9/21 · 21/50 · 50/200)", src: "eski sürüm · klasik", mr: false, fn(p) { const [a, b] = [[9, 21], [21, 50], [50, 200]][p.set], ea = emaC(a), eb = emaC(b), sig = new Int8Array(D.n);
    for (let i = b + 1; i < D.n; i++) { if (ea[i] > eb[i] && ea[i - 1] <= eb[i - 1]) sig[i] = 1; else if (ea[i] < eb[i] && ea[i - 1] >= eb[i - 1]) sig[i] = -1; } return { sig }; } },
  rsi2: { tr: "RSI(2) aşırılık + EMA200", src: "eski sürüm · klasik", mr: true, fn(p) { const r = rsiA(2), c = D.c, e = emaC(200), sig = new Int8Array(D.n); for (let i = 210; i < D.n; i++) { if (r[i] < p.lo && c[i] > e[i]) sig[i] = 1; else if (r[i] > 100 - p.lo && c[i] < e[i]) sig[i] = -1; } return { sig }; } },
  bb_rev: { tr: "Bollinger bandına dönüş", src: "eski sürüm · klasik", mr: true, fn(p) { const { o, c } = D, b = bbA(p.k), sig = new Int8Array(D.n); for (let i = 22; i < D.n; i++) { if (c[i - 1] < b.l[i - 1] && c[i] > b.l[i] && c[i] > o[i]) sig[i] = 1; else if (c[i - 1] > b.u[i - 1] && c[i] < b.u[i] && c[i] < o[i]) sig[i] = -1; } return { sig }; } },
  meta: { tr: "Meta: çok stratejili oylama", src: "eski sürüm · META", mr: false, fn(p) { const N = D.n, vl = new Float64Array(N), vs = new Float64Array(N), sig = new Int8Array(N);
    for (const [r, q] of META_SET) { const s = sub(r, q); for (let i = 2; i < N; i++) { let a = 0, b = 0; for (let k = 0; k < 3; k++) { if (s[i - k] > 0) a = 1; else if (s[i - k] < 0) b = 1; } vl[i] += a; vs[i] += b; } }
    for (let i = 120; i < N; i++) { if (vl[i] >= p.N && vs[i] < 2) sig[i] = 1; else if (vs[i] >= p.N && vl[i] < 2) sig[i] = -1; } return { sig }; } },
});
/* ---- yeni nesil üretici ajanların tarifleri: rejim uyarlamalı ve topluluk (ensemble) stratejileri */
const DEFP = (rec) => { const p = {}; for (const k in SP[rec]) p[k] = SP[rec][k][Math.floor(SP[rec][k].length / 2)]; return p; };
const ENS = [["ema_pb", "supert", "macd", "donch", "ema_x", "xr"], ["of_flow", "delta", "prt", "of_stk", "vp", "of_abs"], ["sweep", "fvg", "vwap_rc", "of_div", "bb_rev", "rsi_mr"]];
Object.assign(SP, { regime: { a: [18, 22, 25], t: ["ema_pb", "donch", "supert", "macd", "ema_x"], m: ["rsi_mr", "bb_rev", "rsi2", "sweep", "of_div"] }, ens: { k: [2, 3], set: [0, 1, 2] } });
Object.assign(REC, {
  regime: { tr: "Rejim uyarlamalı (trend ↔ yatay)", src: "lab/meta ajanı", mr: false, fn(p) { const a = adxA(), st = sub(p.t, DEFP(p.t)), sm = sub(p.m, DEFP(p.m)), sig = new Int8Array(D.n); for (let i = 60; i < D.n; i++) sig[i] = a[i] >= p.a ? st[i] : sm[i]; return { sig }; } },
  ens: { tr: "Topluluk oylaması (aileden k strateji)", src: "lab/meta ajanı", mr: false, fn(p) { const N = D.n, arr = ENS[p.set].map((r) => sub(r, DEFP(r))), sig = new Int8Array(N); for (let i = 120; i < N; i++) { let vl = 0, vs = 0; for (const s of arr) { let a = 0, b = 0; for (let k = 0; k < 3; k++) { if (s[i - k] > 0) a = 1; else if (s[i - k] < 0) b = 1; } vl += a; vs += b; } if (vl >= p.k && vs === 0) sig[i] = 1; else if (vs >= p.k && vl === 0) sig[i] = -1; } return { sig }; } },
});
/* ---- altın (XAU/XAG) seans tarifleri: Asya aralığı, Londra/New York açılışı, önceki gün seviyeleri, yuvarlak seviyeler, kurumsal VWAP bandı.
   Altın gün içinde seanslarla hareket eder: Asya dar aralık kurar, Londra çoğu zaman o aralığın bir ucunu süpürüp kırar, NY Londra trendini sürdürür ya da tersine çevirir. */
const dayRng = (h0, h1) => memo("dyr" + h0 + "_" + h1, () => { const { t, h, l } = D, N = D.n, hi = new Float64Array(N).fill(NaN), lo = new Float64Array(N).fill(NaN); let day = -1, ch = -Infinity, cl = Infinity;
  for (let i = 0; i < N; i++) { const d = Math.floor(t[i] / DAY), hr = hourUTC(t[i]); if (d !== day) { day = d; ch = -Infinity; cl = Infinity; } if (hr >= h0 && hr < h1) { if (h[i] > ch) ch = h[i]; if (l[i] < cl) cl = l[i]; } else if (hr >= h1 && isFinite(ch)) { hi[i] = ch; lo[i] = cl; } } return { hi, lo }; });
const prevDay = () => memo("pdy", () => { const { t, h, l } = D, N = D.n, ph = new Float64Array(N).fill(NaN), pl = new Float64Array(N).fill(NaN); let day = -1, ch = -Infinity, cl = Infinity, lh = NaN, ll = NaN;
  for (let i = 0; i < N; i++) { const d = Math.floor(t[i] / DAY); if (d !== day) { if (day >= 0 && isFinite(ch)) { lh = ch; ll = cl; } day = d; ch = -Infinity; cl = Infinity; } ph[i] = lh; pl[i] = ll; if (h[i] > ch) ch = h[i]; if (l[i] < cl) cl = l[i]; } return { ph, pl }; });
Object.assign(SP, { asia_bo: { buf: [0, 0.1, 0.25], end: [10, 12] }, judas: { w: [0, 1], buf: [0.05, 0.15] }, pdhl: { rej: [0.55, 0.7] }, ny_cont: { k: [1.5, 2.5, 4], e: [20, 34] }, rn_rej: { m: [1, 2.5, 5], rej: [0.6, 0.75] }, vwap_band: { k: [1.5, 2, 2.5] }, mom_brk: { rng: [1.3, 1.7], vz: [1, 1.5] } });
Object.assign(REC, {
  asia_bo: { tr: "Asya aralığı Londra kırılımı", src: "altın seans", mr: false, fn(p) { const { t, c } = D, N = D.n, { hi, lo } = dayRng(0, 7), a = atrA(14), sig = new Int8Array(N), sl = new Float64Array(N); let day = -1, done = false;
    for (let i = 1; i < N; i++) { const d = Math.floor(t[i] / DAY), hr = hourUTC(t[i]); if (d !== day) { day = d; done = false; } if (done || hr < 7 || hr >= p.end || !isFinite(hi[i])) continue; const b = p.buf * a[i], mid = (hi[i] + lo[i]) / 2;
      if (c[i] > hi[i] + b) { sig[i] = 1; sl[i] = mid; done = true; } else if (c[i] < lo[i] - b) { sig[i] = -1; sl[i] = mid; done = true; } }
    return { sig, sl, flat: true }; } },
  judas: { tr: "Judas swing: Asya ucunda sahte kırılım dönüşü", src: "altın seans · ICT", mr: true, fn(p) { const { t, o, h, l, c } = D, N = D.n, { hi, lo } = dayRng(0, 7), a = atrA(14), sig = new Int8Array(N), sl = new Float64Array(N), [w0, w1] = p.w ? [13, 16] : [7, 10]; let day = -1, done = false;
    for (let i = 1; i < N; i++) { const d = Math.floor(t[i] / DAY), hr = hourUTC(t[i]); if (d !== day) { day = d; done = false; } if (done || hr < w0 || hr >= w1 || !isFinite(hi[i])) continue; const b = p.buf * a[i];
      if (h[i] > hi[i] + b && c[i] < hi[i] && c[i] < o[i]) { sig[i] = -1; sl[i] = h[i] + 0.1 * a[i]; done = true; } else if (l[i] < lo[i] - b && c[i] > lo[i] && c[i] > o[i]) { sig[i] = 1; sl[i] = l[i] - 0.1 * a[i]; done = true; } }
    return { sig, sl, flat: true }; } },
  pdhl: { tr: "Önceki gün yüksek/düşük süpürme dönüşü", src: "altın · likidite", mr: true, fn(p) { const { h, l, c } = D, N = D.n, { ph, pl } = prevDay(), a = atrA(14), sig = new Int8Array(N), sl = new Float64Array(N);
    for (let i = 1; i < N; i++) { if (!isFinite(ph[i])) continue; const r = h[i] - l[i]; if (!(r > 0)) continue; const pos = (c[i] - l[i]) / r;
      if (h[i] > ph[i] && c[i] < ph[i] && pos <= 1 - p.rej) { sig[i] = -1; sl[i] = h[i] + 0.1 * a[i]; } else if (l[i] < pl[i] && c[i] > pl[i] && pos >= p.rej) { sig[i] = 1; sl[i] = l[i] - 0.1 * a[i]; } }
    return { sig, sl }; } },
  ny_cont: { tr: "Londra trendinin New York devamı (EMA geri çekilmesi)", src: "altın seans", mr: false, fn(p) { const { t, o, h, l, c } = D, N = D.n, e = emaC(p.e), a = atrA(14), sig = new Int8Array(N); let day = -1, lo7 = NaN, dir = 0, done = false;
    for (let i = 1; i < N; i++) { const d = Math.floor(t[i] / DAY), hr = hourUTC(t[i]); if (d !== day) { day = d; lo7 = NaN; dir = 0; done = false; } if (isNaN(lo7) && hr >= 7 && hr < 8) lo7 = o[i];
      if (hr >= 12.75 && hr < 13.5 && !dir && isFinite(lo7)) { const mv = c[i] - lo7; dir = Math.abs(mv) > p.k * a[i] ? Math.sign(mv) : 0; }
      if (done || !dir || hr < 13.5 || hr >= 16.5) continue;
      if (dir > 0 && l[i] <= e[i] && c[i] > e[i] && c[i] > o[i]) { sig[i] = 1; done = true; } else if (dir < 0 && h[i] >= e[i] && c[i] < e[i] && c[i] < o[i]) { sig[i] = -1; done = true; } }
    return { sig, flat: true }; } },
  rn_rej: { tr: "Yuvarlak seviye reddi ($10 / $25 / $50)", src: "altın · psikolojik seviye", mr: true, fn(p) { const { h, l, c } = D, N = D.n, a = atrA(14), r = rsiA(14), sig = new Int8Array(N), sl = new Float64Array(N);
    for (let i = 20; i < N; i++) { const st = Math.pow(10, Math.floor(Math.log10(c[i]))) * p.m / 100, rg = h[i] - l[i]; if (!(rg > 0) || !(st > 0)) continue; const pos = (c[i] - l[i]) / rg, Ll = Math.round(l[i] / st) * st, Lh = Math.round(h[i] / st) * st;
      if (l[i] <= Ll + 0.12 * a[i] && l[i] >= Ll - 0.6 * a[i] && c[i] > Ll + 0.2 * a[i] && pos >= p.rej && r[i] < 58) { sig[i] = 1; sl[i] = l[i] - 0.1 * a[i]; }
      else if (h[i] >= Lh - 0.12 * a[i] && h[i] <= Lh + 0.6 * a[i] && c[i] < Lh - 0.2 * a[i] && pos <= 1 - p.rej && r[i] > 42) { sig[i] = -1; sl[i] = h[i] + 0.1 * a[i]; } }
    return { sig, sl }; } },
  vwap_band: { tr: "VWAP sapma bandı dönüşü (Londra–NY)", src: "altın · kurumsal", mr: true, fn(p) { const { t, o, h, l, c, v } = D, N = D.n, a = atrA(14), sig = new Int8Array(N), sl = new Float64Array(N); let day = -1, pv = 0, vv = 0, p2 = 0, lbP = NaN, ubP = NaN;
    for (let i = 0; i < N; i++) { const d = Math.floor(t[i] / DAY), hr = hourUTC(t[i]); if (d !== day) { day = d; pv = 0; vv = 0; p2 = 0; lbP = NaN; ubP = NaN; } const tp = (h[i] + l[i] + c[i]) / 3, vol = v[i] || 1; pv += tp * vol; vv += vol; p2 += tp * tp * vol;
      const w = pv / vv, sd = Math.sqrt(Math.max(p2 / vv - w * w, 0)), lb = w - p.k * sd, ub = w + p.k * sd;
      if (i > 0 && hr >= 7 && hr < 20 && sd > 0) { if (c[i - 1] < lbP && c[i] > lb && c[i] > o[i]) { sig[i] = 1; sl[i] = Math.min(l[i], l[i - 1]) - 0.1 * a[i]; } else if (c[i - 1] > ubP && c[i] < ub && c[i] < o[i]) { sig[i] = -1; sl[i] = Math.max(h[i], h[i - 1]) + 0.1 * a[i]; } }
      lbP = lb; ubP = ub; }
    return { sig, sl }; } },
  mom_brk: { tr: "Seans açılışı momentum mumu + hacim", src: "altın seans", mr: false, fn(p) { const { t, o, h, l, c } = D, N = D.n, a = atrA(14), vz = volZ(), sig = new Int8Array(N), sl = new Float64Array(N);
    for (let i = 60; i < N; i++) { const hr = hourUTC(t[i]); if (!((hr >= 7 && hr < 9) || (hr >= 13 && hr < 15.5))) continue; const rg = h[i] - l[i]; if (!(rg > p.rng * a[i - 1]) || vz[i] < p.vz) continue; const pos = (c[i] - l[i]) / rg;
      if (pos >= 0.75 && c[i] > o[i]) { sig[i] = 1; sl[i] = l[i] - 0.05 * a[i]; } else if (pos <= 0.25 && c[i] < o[i]) { sig[i] = -1; sl[i] = h[i] + 0.05 * a[i]; } }
    return { sig, sl }; } },
});
const GOLD_REC = ["asia_bo", "judas", "pdhl", "ny_cont", "rn_rej", "vwap_band", "mom_brk"];
const atrPctA = () => memo("atrpct", () => { const a = atrA(14), o = new Float64Array(D.n); for (let i = 200; i < D.n; i++) { let c = 0; for (let k = i - 200; k < i; k++) if (a[k] < a[i]) c++; o[i] = c / 200; } return o; });
const SESS = { all: [0, 24], ldn: [7, 16], ny: [13, 21], ldnny: [7, 21], asia: [0, 7] };
const gkey = (g) => JSON.stringify([g.rec, g.p, g.f, g.side, g.x]);
function buildSig(g) {
  const raw = memo("S" + g.rec + JSON.stringify(g.p), () => REC[g.rec].fn(g.p)), N = D.n, sig = new Int8Array(N), f = g.f || {};
  const adx = adxA(), e200 = emaC(200), dr = emaA(dRatio(), 3), [h0, h1] = SESS[f.sess || "all"];
  for (let i = 0; i < N; i++) { let s = raw.sig[i]; if (!s) continue;
    if (g.side === "long" && s < 0) continue; if (g.side === "short" && s > 0) continue;
    if (f.adx && adx[i] < f.adx) continue; if (f.adxMax && adx[i] > f.adxMax) continue;
    if (f.trend && ((s > 0 && D.c[i] < e200[i]) || (s < 0 && D.c[i] > e200[i]))) continue;
    if (f.htf) { const q1 = emaC(100)[i], q2 = emaC(400)[i]; if ((s > 0 && !(q1 > q2)) || (s < 0 && !(q1 < q2))) continue; }
    if (f.vol) { const q = atrPctA()[i]; if ((f.vol === "mid" && !(q > 0.3 && q < 0.85)) || (f.vol === "hi" && q < 0.6) || (f.vol === "lo" && q > 0.4)) continue; }
    if (f.delta && ((s > 0 && dr[i] <= 0) || (s < 0 && dr[i] >= 0))) continue;
    const hr = hourUTC(D.t[i]); if (f.sess && f.sess !== "all" && !(hr >= h0 && hr < h1)) continue;
    sig[i] = s; }
  return { sig, sl: raw.sl, flat: !!raw.flat };
}

/* ---------------------------------------------------------------- backtest (maliyetli, bir sonraki mum açılışında dolum) */
function sim(g, S, lo, hi, cfg) {
  const { t, o, h, l, c } = D, A = atrA(14), sig = S.sig, trs = [], fee = cfg.fee / 1e4, slip = cfg.slip / 1e4, x = g.x;
  for (let i = lo; i < hi - 2; i++) {
    const s = sig[i]; if (!s) continue;
    const e = o[i + 1] * (1 + s * slip); let sd = S.sl && S.sl[i] > 0 ? (e - S.sl[i]) * s : x.stop * A[i];
    if (!(sd > 0)) continue; if (sd < 0.3 * A[i]) sd = 0.3 * A[i]; if (sd > 4 * A[i]) continue;
    let sl = e - s * sd; const tp = e + s * sd * x.rr, last = Math.min(hi - 1, i + 1 + x.maxb); let best = e; let ex = c[last], j = i + 1, why = "zaman";
    for (; j <= last; j++) {
      const hitSL = s > 0 ? l[j] <= sl : h[j] >= sl, hitTP = s > 0 ? h[j] >= tp : l[j] <= tp;
      if (hitSL) { ex = s > 0 ? Math.min(sl, o[j]) : Math.max(sl, o[j]); ex *= 1 - s * slip; why = "stop"; break; }
      if (hitTP) { ex = tp; why = "hedef"; break; }
      if (S.flat && j + 1 < N_() && Math.floor(t[j + 1] / DAY) !== Math.floor(t[j] / DAY)) { ex = c[j]; why = "gün sonu"; break; }
      if (j === last) { ex = c[j]; break; }
      if (x.trail) { if (s > 0) { if (h[j] > best) best = h[j]; if (best - e >= sd) sl = Math.max(sl, best - x.trail * A[j]); } else { if (l[j] < best) best = l[j]; if (e - best >= sd) sl = Math.min(sl, best + x.trail * A[j]); } }
    }
    if (j > last) j = last;
    const r = ((ex - e) * s - (e + ex) * fee) / sd;
    trs.push({ i0: i + 1, i1: j, t0: t[i + 1], t1: t[j], s, e, x: ex, r, sd, why }); i = j;
  }
  return trs;
}
const N_ = () => D.n;

/* ---------------------------------------------------------------- metrikler */
function ninv(p) {
  const a = [-39.69683028665376, 220.9460984245205, -275.9285104469687, 138.357751867269, -30.66479806614716, 2.506628277459239], b = [-54.47609879822406, 161.5858368580409, -155.6989798598866, 66.80131188771972, -13.28068155288572],
    c = [-0.007784894002430293, -0.3223964580411365, -2.400758277161838, -2.549732539343734, 4.374664141464968, 2.938163982698783], d = [0.007784695709041462, 0.3224671290700398, 2.445134137142996, 3.754408661907416];
  if (p < 0.02425) { const q = Math.sqrt(-2 * Math.log(p)); return (((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1); }
  if (p > 1 - 0.02425) return -ninv(1 - p);
  const q = p - 0.5, r = q * q; return (((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * q / (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1);
}
const sr0 = (N, days) => { const g = 0.5772156649, z = (1 - g) * ninv(1 - 1 / Math.max(N, 2)) + g * ninv(1 - 1 / (Math.max(N, 2) * Math.E)); return Math.sqrt(365 / Math.max(days, 5)) * z; };
function metr(trs, t0, t1, risk) {
  const n = trs.length, days = Math.max(1, Math.round((t1 - t0) / DAY)); let sw = 0, sl = 0, w = 0, sum = 0, eq = 1, pk = 1, dd = 0; const dr = new Float64Array(days);
  for (const x of trs) { sum += x.r; if (x.r > 0) { sw += x.r; w++; } else sl -= x.r; eq *= 1 + risk * x.r; if (eq > pk) pk = eq; dd = Math.max(dd, 1 - eq / pk); const di = Math.min(days - 1, Math.max(0, Math.floor((x.t1 - t0) / DAY))); dr[di] += risk * x.r; }
  let m = 0; for (const v of dr) m += v; m /= days; let q = 0; for (const v of dr) q += (v - m) * (v - m); const sd = Math.sqrt(q / days);
  const mR = n ? sum / n : 0; let vR = 0; for (const x of trs) vR += (x.r - mR) * (x.r - mR);
  return { n, days, win: n ? w / n : 0, avgR: mR, sumR: sum, pf: sl > 0 ? sw / sl : (sw > 0 ? 9.99 : 0), sh: sd > 0 ? m / sd * Math.sqrt(365) : 0, ret: eq - 1, dd, stdR: n > 1 ? Math.sqrt(vR / (n - 1)) : 1,
    sqn: n > 1 && vR > 0 ? mR / Math.sqrt(vR / (n - 1)) * Math.sqrt(n) : 0, avgW: w ? sw / w : 0, avgL: n - w ? sl / (n - w) : 0 };
}
function monteCarlo(trs, risk, sims) {
  if (trs.length < 8) return null; const fin = [], dds = []; let ruin = 0, bad = 0;
  for (let k = 0; k < sims; k++) { let eq = 1, pk = 1, dd = 0; for (let i = 0; i < trs.length; i++) { eq *= 1 + risk * trs[Math.floor(R() * trs.length)].r; if (eq > pk) pk = eq; dd = Math.max(dd, 1 - eq / pk); } fin.push(eq); dds.push(dd); if (dd > 0.25) ruin++; if (eq < 1) bad++; }
  fin.sort((a, b) => a - b); dds.sort((a, b) => a - b); const q = (a, p) => a[Math.min(a.length - 1, Math.floor(p * a.length))];
  return { p5: q(fin, 0.05) - 1, p50: q(fin, 0.5) - 1, p95: q(fin, 0.95) - 1, ddMed: q(dds, 0.5), dd95: q(dds, 0.95), pDD25: ruin / sims, pLoss: bad / sims };
}
function curve(trsA, trsB, st, split, end, k) {
  const sd = st.stdR > 0 ? st.stdR : 1, all = trsA.concat(trsB), out = new Float32Array(k); let j = 0, cum = 0, mark = 0;
  for (let q = 0; q < k; q++) { const tt = st.t0 + (end - st.t0) * (q + 1) / k; while (j < all.length && all[j].t1 <= tt) cum += all[j++].r; out[q] = cum / sd; if (mark === 0 && tt >= split) mark = q; }
  return { y: out, mark: mark / k };
}

/* ---------------------------------------------------------------- genom */
const NAMES_TF = (g) => `${D.sym.replace("USDT", "")} ${D.tf}`;
function rndG() {
  const rec = D && /^XA[UG]/.test(D.sym || "") && R() < 0.45 ? pick(GOLD_REC) : pick(Object.keys(REC)), p = {}; for (const k in SP[rec]) p[k] = pick(SP[rec][k]);      // altın/gümüşte seans tarifleri daha sık denenir
  const f = { adx: pick([0, 0, 18, 25]), adxMax: 0, trend: pick([0, 1]), sess: pick(["all", "all", "ldn", "ny", "ldnny"]), delta: pick([0, 0, 1]), htf: pick([0, 0, 1]), vol: pick([0, 0, 0, "mid", "hi"]) };
  if (REC[rec].mr) { f.adxMax = pick([0, 0, 22, 28]); f.adx = 0; }
  return { rec, p, f, side: pick(["both", "both", "both", "long", "short"]), x: { stop: pick([1, 1.5, 2, 3]), rr: pick([1, 1.5, 2, 3]), maxb: pick([12, 24, 48, 96]), trail: pick([0, 0, 0, 1.5, 2.5]) } };
}
function mutate(g0) {
  const g = JSON.parse(JSON.stringify(g0)), r = R(); g.f = g.f || {}; g.x = g.x || {};
  if (r < 0.28) { const ks = Object.keys(SP[g.rec]); const k = pick(ks); g.p[k] = pick(SP[g.rec][k]); }
  else if (r < 0.48) { const k = pick(["stop", "rr", "maxb", "trail"]); g.x[k] = k === "stop" || k === "rr" ? pick([1, 1.5, 2, 3]) : k === "maxb" ? pick([12, 24, 48, 96]) : pick([0, 1.5, 2.5]); }
  else if (r < 0.60) g.f.adx = pick([0, 15, 18, 22, 25]);
  else if (r < 0.68) g.f.trend = 1 - (g.f.trend || 0);
  else if (r < 0.76) g.f.sess = pick(Object.keys(SESS));
  else if (r < 0.82) g.f.delta = 1 - (g.f.delta || 0);
  else if (r < 0.88) g.f.htf = 1 - (g.f.htf || 0);
  else if (r < 0.94) g.f.vol = pick([0, "mid", "hi"]);
  else g.side = pick(["both", "long", "short"]);
  return g;
}
function gdesc(g) {
  const f = g.f || {}, parts = []; if (f.trend) parts.push("trend"); if (f.htf) parts.push("HTF"); if (f.vol) parts.push("vol:" + f.vol); if (g.x && g.x.trail) parts.push("iz-süren stop"); if (f.adx) parts.push("ADX≥" + f.adx); if (f.adxMax) parts.push("yatay"); if (f.delta) parts.push("delta"); if (f.sess && f.sess !== "all") parts.push(f.sess.toUpperCase());
  return REC[g.rec].tr + (parts.length ? " + " + parts.join("·") : "") + (g.side !== "both" ? " · " + (g.side === "long" ? "yalnız AL" : "yalnız SAT") : "");
}

/* ---------------------------------------------------------------- aday değerlendirme hattı */
const ST = { running: false, stop: false, id: 1200, gen: 0, cnt: { idea: 0, test: 0, passIS: 0, passOOS: 0, rob: 0, cand: 0, kept: 0, rej: 0 }, arch: new Map(), recs: [], pbo: [], trials: 0 };
function split(cfg) { const N = D.n, sp = WARM + Math.floor((N - WARM) * cfg.split); return { lo: WARM, sp, oosLo: sp + 48, hi: N }; }
function evalCand(g, cfg) {
  const risk = cfg.risk, sp = split(cfg), S = buildSig(g), t0 = D.t[sp.lo], tS = D.t[sp.sp], tE = D.t[D.n - 1];
  const isT = sim(g, S, sp.lo, sp.sp, cfg), mi = metr(isT, t0, tS, risk); mi.t0 = t0;
  const rec = { id: ++ST.id, g, name: "#" + ST.id + " " + gdesc(g) + " · " + NAMES_TF(g), is: pub(mi), fit: mi.n >= 25 ? mi.sqn : -9 };
  ST.cnt.test++; ST.trials++;
  const fin = (status, reason) => { rec.status = status; rec.reason = reason; if (status.startsWith("rej")) ST.cnt.rej++; return rec; };
  if (mi.n < 25 || mi.pf < 1.1 || mi.avgR < 0.03) { rec.curve = curve(isT, [], mi, tS, tE, 48); return fin("rej-is", mi.n < 25 ? `yalnız ${mi.n} işlem (min 25)` : `IS zayıf: PF ${mi.pf.toFixed(2)} · ort ${mi.avgR.toFixed(2)}R`); }
  ST.cnt.passIS++;
  const oT = sim(g, S, sp.oosLo, sp.hi, cfg), mo = metr(oT, D.t[sp.oosLo], tE, risk); rec.oos = pub(mo); rec.curve = curve(isT, oT, mi, tS, tE, 48);
  ST.pbo.push([mi.sh, mo.sh]);
  if (mo.n < 12 || mo.pf < 1.1 || mo.avgR < 0.03) return fin("rej-oos", mo.n < 12 ? `OOS'ta yalnız ${mo.n} işlem` : `OOS'ta çöktü: PF ${mo.pf.toFixed(2)} · ort ${mo.avgR.toFixed(2)}R · Sharpe ${mi.sh.toFixed(1)}→${mo.sh.toFixed(1)}`);
  ST.cnt.passOOS++;
  const full = []; let ok = 0; const vars = [{ stop: 0.8 }, { stop: 1.25 }, { rr: 0.8 }, { rr: 1.25 }, { maxb: 0.5 }];
  for (const v of vars) { const g2 = JSON.parse(JSON.stringify(g)); for (const k in v) g2.x[k] = k === "maxb" ? Math.max(6, Math.round(g.x[k] * v[k])) : g.x[k] * v[k]; const tt = sim(g2, S, sp.lo, sp.hi, cfg), m2 = metr(tt, t0, tE, risk); full.push(m2.avgR); if (m2.avgR > 0 && m2.n >= 20) ok++; }
  rec.rob = ok / vars.length;
  if (ok < 3) return fin("rej-rob", `parametre kırılgan: ${ok}/5 komşu kârlı`);
  ST.cnt.rob++;
  const thr = sr0(ST.cnt.passIS, mo.days); rec.dsr = { thr, sr: mo.sh, pass: mo.sh >= thr }; rec.mc = monteCarlo(oT, risk, 250);
  rec.risk = riskGate(mo, rec.mc, cfg);
  if (rec.dsr.pass && rec.risk.pass && mo.n >= 20) { ST.cnt.kept++; return fin("kept", `OOS Sharpe ${mo.sh.toFixed(2)} ≥ şans sınırı ${thr.toFixed(2)} (${ST.cnt.passIS} OOS denemesi)`); }
  ST.cnt.cand++; return fin("cand", rec.dsr.pass ? `risk kapısı: ${rec.risk.why}` : `Sharpe ${mo.sh.toFixed(2)} < şans sınırı ${thr.toFixed(2)}: ${ST.cnt.passIS} OOS denemesinden biri şans olabilir`);
}
function riskGate(m, mc, cfg) {   // day-trader-skill risk kapısı mantığı: işlem başı zarar, ödül/risk, düşüş, işlem sayısı
  const rr = m.avgL > 0 ? m.avgW / m.avgL : 9, why = [];
  if (rr < 0.8 && m.win < 0.55) why.push(`ödül/risk ${rr.toFixed(2)} düşük`); if (m.dd > 0.25) why.push(`maks düşüş %${(m.dd * 100).toFixed(0)}`); if (mc && mc.pDD25 > 0.25) why.push(`Monte Carlo: %${(mc.pDD25 * 100).toFixed(0)} ihtimalle >%25 düşüş`); if (m.n < 20) why.push("işlem az");
  return { pass: !why.length, why: why.join("; ") || "PASS", rr };
}
const pub = (m) => ({ n: m.n, win: m.win, avgR: m.avgR, pf: m.pf, sh: m.sh, ret: m.ret, dd: m.dd, sqn: m.sqn, sumR: m.sumR, days: m.days });
function pboNow() {
  if (ST.pbo.length < 20) return null; const s = ST.pbo.slice().sort((a, b) => b[0] - a[0]), top = s.slice(0, Math.max(5, Math.floor(s.length * 0.2))), oo = ST.pbo.map((x) => x[1]).sort((a, b) => a - b), med = oo[Math.floor(oo.length / 2)];
  return top.filter((x) => x[1] < med).length / top.length;
}
function cross(a, b) { const g = JSON.parse(JSON.stringify(a)); g.f = JSON.parse(JSON.stringify(b.f || {})); g.x = JSON.parse(JSON.stringify(b.x || {})); if (R() < 0.5) g.side = b.side; return g; }
function nextG() {
  const top = ST.recs.filter((r) => r.fit > 0).sort((a, b) => b.fit - a.fit).slice(0, 12), seeds = ST.seeds || [];
  for (let k = 0; k < 30; k++) { const q = R(), g = seeds.length && q < 0.14 ? mutate(pick(seeds)) : top.length >= 6 && q < 0.32 ? cross(pick(top).g, pick(top).g) : top.length >= 6 && q < 0.65 ? mutate(pick(top).g) : rndG(), key = gkey(g); if (!ST.arch.has(key)) { ST.arch.set(key, 1); return g; } }
  return rndG();
}
async function runSearch(cfg) {
  if (!D || ST.running) return; ST.running = true; ST.stop = false; const sp = split(cfg);
  post({ ev: "log", ag: "kasif", txt: `Bilgi bankasından ${Object.keys(REC).length} yapı taşı + ${Object.keys(SESS).length} seans filtresi yüklendi.` });
  post({ ev: "log", ag: "veri", txt: `${D.sym} ${D.tf}: ${D.n} mum · IS ${sp.sp - sp.lo} / OOS ${D.n - sp.oosLo} (OOS kapalı kutuda).` });
  let n = 0;
  while (!ST.stop) {
    const g = nextG(); ST.cnt.idea++; const t0 = Date.now();
    post({ ev: "work", ag: "fikir", txt: `Yeni tarif: ${gdesc(g)}` });
    let r; try { r = evalCand(g, cfg); } catch (e) { post({ ev: "log", ag: "test", txt: "Hata: " + e.message }); await sleep(500); continue; }
    ST.recs.push(r); if (ST.recs.length > 600) ST.recs.splice(0, 200); n++;
    post({ ev: "cand", r: { id: r.id, name: r.name, status: r.status, reason: r.reason, is: r.is, oos: r.oos, rob: r.rob, dsr: r.dsr, mc: r.mc, risk: r.risk, curve: r.curve ? Array.from(r.curve.y) : null, mark: r.curve ? r.curve.mark : 0, g: r.g } });
    if (r.status === "kept" || r.status === "cand") post({ ev: "keep", r: { id: r.id, name: r.name, status: r.status, reason: r.reason, g: r.g, is: r.is, oos: r.oos, rob: r.rob, dsr: r.dsr, mc: r.mc, risk: r.risk, sym: D.sym, tf: D.tf, at: Date.now() } });
    if (n % 5 === 0) post({ ev: "stats", cnt: ST.cnt, pbo: pboNow(), trials: ST.trials, thr: sr0(ST.cnt.passIS, Math.round((D.t[D.n - 1] - D.t[sp.oosLo]) / DAY)), rate: Math.round(1000 / Math.max(1, Date.now() - t0 + cfg.delay)) });
    await sleep(cfg.delay);
  }
  ST.running = false; post({ ev: "stopped" });
}

/* ---------------------------------------------------------------- rapor (Portfolio Visualizer tarzı) */
function report(g, cfg) {
  const S = buildSig(g), sp = split(cfg), tE = D.t[D.n - 1], t0 = D.t[sp.lo], trs = sim(g, S, sp.lo, D.n, cfg), m = metr(trs, t0, tE, cfg.risk);
  const pts = [], dd = [], mon = {}, monN = {}; let eq = 1, pk = 1; pts.push([t0, 1]); dd.push([t0, 0]);
  for (const x of trs) { eq *= 1 + cfg.risk * x.r; if (eq > pk) pk = eq; pts.push([x.t1, eq]); dd.push([x.t1, eq / pk - 1]); const d = new Date(x.t1), k = d.getUTCFullYear() + "-" + String(d.getUTCMonth() + 1).padStart(2, "0"); mon[k] = (mon[k] || 0) + cfg.risk * x.r; monN[k] = (monN[k] || 0) + 1; }
  const bh = [], step = Math.max(1, Math.floor((D.n - sp.lo) / 200)); for (let i = sp.lo; i < D.n; i += step) bh.push([D.t[i], D.c[i] / D.c[sp.lo]]);
  const roll = [], W = 30 * DAY; let a = 0; for (let b = 0; b < trs.length; b++) { while (trs[b].t1 - trs[a].t1 > W) a++; if (b - a >= 5) { const sl = trs.slice(a, b + 1), mm = metr(sl, trs[b].t1 - W, trs[b].t1, cfg.risk); roll.push([trs[b].t1, mm.sh]); } }
  const hist = {}; for (const x of trs) { const k = Math.max(-3, Math.min(5, Math.round(x.r * 2) / 2)); hist[k] = (hist[k] || 0) + 1; }
  const why = {}; for (const x of trs) why[x.why] = (why[x.why] || 0) + 1;
  return { name: gdesc(g), m, split: D.t[sp.sp], t0, t1: tE, eq: pts, dd, bh, mon, roll, hist, why, monN, mc: monteCarlo(trs, cfg.risk, 300), is: pub(metr(trs.filter((x) => x.i0 < sp.sp), t0, D.t[sp.sp], cfg.risk)), oos: pub(metr(trs.filter((x) => x.i0 >= sp.oosLo), D.t[sp.oosLo], tE, cfg.risk)), last: trs.slice(-40).reverse().map((x) => ({ t0: x.t0, s: x.s, e: x.e, x: x.x, r: x.r, why: x.why })), bars: D.n };
}
function live(g) {
  const S = buildSig(g), i = D.n - 1, A = atrA(14)[i], s = S.sig[i], e = D.c[i]; let sd = S.sl && S.sl[i] > 0 ? (e - S.sl[i]) * s : g.x.stop * A; if (s && sd < 0.3 * A) sd = 0.3 * A;
  let since = 0; for (let k = i; k > i - 400 && k >= 0; k--) { if (S.sig[k]) { since = i - k; break; } }
  return { side: s, price: e, stop: s ? e - s * sd : null, tp: s ? e + s * sd * g.x.rr : null, t: D.t[i], lastSigAgo: since };
}

/* ---------------------------------------------------------------- sinir ağı (MLP) */
const NN = { stop: false, net: null, norm: null, running: false };
const LAGS = [0, 1, 2, 4], NF = 8;
function featRow(i) {
  const { o, h, l, c } = D, a = atrA(14)[i], e = emaC(21)[i], r = rsiA(14)[i], x = adxA()[i], dr = dRatio()[i], z = volZ()[i], rg = h[i] - l[i], at = a || 1;
  return [(c[i] - c[i - 1]) / at, (c[i] - e) / at, r / 100 - 0.5, x / 100, dr, rg / at - 1, rg > 0 ? (c[i] - l[i]) / rg - 0.5 : 0, Math.max(-3, Math.min(3, z))];
}
function nnInput(i) { const x = []; for (const lg of LAGS) x.push(...featRow(i - lg)); return x; }
function labels() {
  return memo("lab", () => { const { o, h, l } = D, A = atrA(14), N = D.n, y = new Int8Array(N).fill(-1);
    for (let i = 60; i < N - 26; i++) { const e = o[i + 1], a = A[i], su = e - a, tu = e + 1.5 * a, sd = e + a, td = e - 1.5 * a; let lw = 0, sw = 0, ld = 0, sdn = 0;      // AL: hedef +1.5 ATR / stop −1 ATR; SAT tersi
      for (let j = i + 1; j <= i + 24; j++) {
        if (!ld) { if (l[j] <= su) ld = j; else if (h[j] >= tu) { lw = j; ld = j; } }
        if (!sdn) { if (h[j] >= sd) sdn = j; else if (l[j] <= td) { sw = j; sdn = j; } }
        if (ld && sdn) break; }
      y[i] = lw && !sw ? 1 : sw && !lw ? 2 : lw && sw ? (lw < sw ? 1 : 2) : 0; }
    return y; });
}
function mkNet(sizes, seed) {
  const rr = rng32(seed), net = { s: sizes, W: [], b: [], mW: [], vW: [], mb: [], vb: [], t: 0 };
  for (let l = 0; l < sizes.length - 1; l++) { const a = sizes[l], b = sizes[l + 1], w = new Float64Array(a * b), sc = Math.sqrt(2 / a); for (let k = 0; k < w.length; k++) w[k] = (rr() + rr() + rr() - 1.5) * 2 * sc; net.W.push(w); net.b.push(new Float64Array(b)); net.mW.push(new Float64Array(a * b)); net.vW.push(new Float64Array(a * b)); net.mb.push(new Float64Array(b)); net.vb.push(new Float64Array(b)); }
  return net;
}
function fwd(net, x) {
  const A = [Float64Array.from(x)]; const L = net.s.length - 1;
  for (let l = 0; l < L; l++) { const a = net.s[l], b = net.s[l + 1], W = net.W[l], bb = net.b[l], inp = A[l], out = new Float64Array(b);
    for (let j = 0; j < b; j++) { let s = bb[j]; for (let k = 0; k < a; k++) s += inp[k] * W[k * b + j]; out[j] = l < L - 1 ? (s > 0 ? s : 0) : s; }
    if (l === L - 1) { let m = -Infinity; for (const v of out) if (v > m) m = v; let z = 0; for (let j = 0; j < b; j++) { out[j] = Math.exp(out[j] - m); z += out[j]; } for (let j = 0; j < b; j++) out[j] /= z; }
    A.push(out); }
  return A;
}
function trainBatch(net, X, Y, cw, lr) {
  const L = net.s.length - 1, gW = net.W.map((w) => new Float64Array(w.length)), gb = net.b.map((w) => new Float64Array(w.length)); let loss = 0, hit = 0;
  for (let n = 0; n < X.length; n++) { const A = fwd(net, X[n]), y = Y[n], p = A[L]; loss -= cw[y] * Math.log(Math.max(p[y], 1e-9)); let am = 0; for (let j = 1; j < 3; j++) if (p[j] > p[am]) am = j; if (am === y) hit++;
    let d = Float64Array.from(p); d[y] -= 1; for (let j = 0; j < d.length; j++) d[j] *= cw[y];
    for (let l = L - 1; l >= 0; l--) { const a = net.s[l], b = net.s[l + 1], inp = A[l], W = net.W[l]; const nd = new Float64Array(a);
      for (let k = 0; k < a; k++) { const ik = inp[k]; let s = 0; for (let j = 0; j < b; j++) { gW[l][k * b + j] += ik * d[j]; s += W[k * b + j] * d[j]; } nd[k] = l > 0 && inp[k] <= 0 ? 0 : s; }
      for (let j = 0; j < b; j++) gb[l][j] += d[j]; d = nd; } }
  net.t++; const b1 = 0.9, b2 = 0.999, c1 = 1 - Math.pow(b1, net.t), c2 = 1 - Math.pow(b2, net.t), nb = X.length;
  for (let l = 0; l < L; l++) { const W = net.W[l], g = gW[l], m = net.mW[l], v = net.vW[l]; for (let k = 0; k < W.length; k++) { const gg = g[k] / nb + 1e-4 * W[k]; m[k] = b1 * m[k] + (1 - b1) * gg; v[k] = b2 * v[k] + (1 - b2) * gg * gg; W[k] -= lr * (m[k] / c1) / (Math.sqrt(v[k] / c2) + 1e-8); }
    const bb = net.b[l], g2 = gb[l], m2 = net.mb[l], v2 = net.vb[l]; for (let k = 0; k < bb.length; k++) { const gg = g2[k] / nb; m2[k] = b1 * m2[k] + (1 - b1) * gg; v2[k] = b2 * v2[k] + (1 - b2) * gg * gg; bb[k] -= lr * (m2[k] / c1) / (Math.sqrt(v2[k] / c2) + 1e-8); } }
  return { loss: loss / X.length, acc: hit / X.length };
}
const snap = (net, extra) => Object.assign({ ev: "nnstep", s: net.s, W: net.W.map((w) => Array.from(w, (x) => +x.toFixed(3))), b: net.b.map((w) => Array.from(w, (x) => +x.toFixed(3))), act: null }, extra);
async function nnTrain(cfg) {
  if (!D || NN.running) return; NN.running = true; NN.stop = false; const y = labels(), sp = split(cfg), nin = LAGS.length * NF, sizes = [nin, 32, 16, 3];
  const idx = []; for (let i = sp.lo + 10; i < sp.sp - 30; i++) if (y[i] >= 0) idx.push(i);
  const mu = new Float64Array(nin), sg = new Float64Array(nin).fill(1), rows = idx.map((i) => nnInput(i));
  for (const r of rows) for (let k = 0; k < nin; k++) mu[k] += r[k] / rows.length; for (const r of rows) for (let k = 0; k < nin; k++) sg[k] += (r[k] - mu[k]) ** 2; for (let k = 0; k < nin; k++) sg[k] = Math.sqrt(sg[k] / rows.length) || 1;
  const nz = (r) => r.map((v, k) => Math.max(-4, Math.min(4, (v - mu[k]) / sg[k]))), X = rows.map(nz), Y = idx.map((i) => y[i]);
  const nv = Math.floor(X.length * 0.15), nt = X.length - nv, cnt = [0, 0, 0]; for (let k = 0; k < nt; k++) cnt[Y[k]]++; const cw = cnt.map((c) => nt / (3 * Math.max(c, 1)));
  const net = mkNet(sizes, 7 + Math.floor(R() * 1000)); NN.net = net; NN.norm = { mu: Array.from(mu), sg: Array.from(sg) };
  post({ ev: "nnlog", txt: `Eğitim kümesi ${nt} örnek · doğrulama ${nv} · sınıf dağılımı yok/AL/SAT: ${cnt.join("/")} (OOS ${D.n - sp.oosLo} mum kapalı kutuda)` });
  let best = 9, bestW = null; const ord = Array.from({ length: nt }, (_, k) => k); const E = cfg.epochs || 24;
  for (let ep = 0; ep < E && !NN.stop; ep++) {
    for (let k = nt - 1; k > 0; k--) { const j = Math.floor(R() * (k + 1)); [ord[k], ord[j]] = [ord[j], ord[k]]; }
    let ls = 0, ac = 0, nb = 0;
    for (let b = 0; b + 96 <= nt; b += 96) { const bx = [], by = []; for (let k = b; k < b + 96; k++) { bx.push(X[ord[k]]); by.push(Y[ord[k]]); } const r = trainBatch(net, bx, by, cw, 0.003); ls += r.loss; ac += r.acc; nb++;
      if (nb % 6 === 0) { const act = fwd(net, X[nt + (nb % Math.max(1, nv))]).map((a) => Array.from(a, (v) => +v.toFixed(3))); post(snap(net, { ep, loss: ls / nb, acc: ac / nb, act })); await sleep(0); } }
    let vl = 0, va = 0; for (let k = nt; k < X.length; k++) { const p = fwd(net, X[k])[3]; vl -= Math.log(Math.max(p[Y[k]], 1e-9)); let am = 0; for (let j = 1; j < 3; j++) if (p[j] > p[am]) am = j; if (am === Y[k]) va++; } vl /= nv; va /= nv;
    if (vl < best) { best = vl; bestW = net.W.map((w) => Float64Array.from(w)); bestB = net.b.map((w) => Float64Array.from(w)); }
    post({ ev: "nnep", ep: ep + 1, E, loss: ls / nb, acc: ac / nb, vloss: vl, vacc: va });
    await sleep(10);
  }
  if (bestW) { net.W = bestW; net.b = bestB; }
  await nnEval(cfg); NN.running = false; post({ ev: "nndone" });
}
var bestB = null;
async function nnEval(cfg) {
  const net = NN.net, y = labels(), sp = split(cfg), { mu, sg } = NN.norm, N = D.n, P = new Float32Array(N * 3);
  for (let i = sp.lo + 10; i < N; i++) { const r = nnInput(i).map((v, k) => Math.max(-4, Math.min(4, (v - mu[k]) / sg[k]))), p = fwd(net, r)[3]; P[i * 3] = p[0]; P[i * 3 + 1] = p[1]; P[i * 3 + 2] = p[2]; }
  const thr = cfg.thr || 0.5, sig = new Int8Array(N); let hit = 0, tot = 0; const base = [0, 0, 0]; let cmat = [[0, 0, 0], [0, 0, 0], [0, 0, 0]];
  for (let i = sp.oosLo; i < N - 26; i++) { if (y[i] < 0) continue; let am = 0; for (let j = 1; j < 3; j++) if (P[i * 3 + j] > P[i * 3 + am]) am = j; cmat[y[i]][am]++; base[y[i]]++; tot++; if (am === y[i]) hit++; }
  for (let i = sp.lo + 10; i < N; i++) { if (P[i * 3 + 1] > thr && P[i * 3 + 1] > P[i * 3 + 2] + 0.1) sig[i] = 1; else if (P[i * 3 + 2] > thr && P[i * 3 + 2] > P[i * 3 + 1] + 0.1) sig[i] = -1; }
  const g = { rec: "nn", p: {}, f: {}, side: "both", x: { stop: 1, rr: 1.5, maxb: 24 } }, S = { sig, sl: null, flat: false }, tE = D.t[N - 1];
  const tI = sim(g, S, sp.lo + 10, sp.sp, cfg), tO = sim(g, S, sp.oosLo, N, cfg), mI = metr(tI, D.t[sp.lo], D.t[sp.sp], cfg.risk), mO = metr(tO, D.t[sp.oosLo], tE, cfg.risk);
  let lastP = null; { const i = N - 1, r = nnInput(i).map((v, k) => Math.max(-4, Math.min(4, (v - mu[k]) / sg[k]))); lastP = Array.from(fwd(net, r)[3], (v) => +v.toFixed(3)); }
  { const ix = []; for (let i = Math.max(sp.lo + 10, N - 120); i < N; i++) ix.push(i); const q = (a) => Array.from(a, (x) => +x.toFixed(3));
    post({ ev: "nnmodel", s: net.s, W: net.W.map(q), b: net.b.map(q), X: ix.map((i) => q(nnInput(i).map((v, k) => Math.max(-4, Math.min(4, (v - mu[k]) / sg[k]))))), P: ix.map((i) => [P[i * 3], P[i * 3 + 1], P[i * 3 + 2]].map((x) => +x.toFixed(3))), T: ix.map((i) => D.t[i]) }); }
  post({ ev: "nneval", acc: tot ? hit / tot : 0, base: base.map((b) => b / Math.max(tot, 1)), cm: cmat, is: pub(mI), oos: pub(mO), last: lastP, thr, mc: monteCarlo(tO, cfg.risk, 200) });
}
function nnLive() { if (!NN.net) return null; const { mu, sg } = NN.norm, i = D.n - 1; return Array.from(fwd(NN.net, nnInput(i).map((v, k) => Math.max(-4, Math.min(4, (v - mu[k]) / sg[k]))))[3], (v) => +v.toFixed(3)); }

/* ---------------------------------------------------------------- mesaj kapısı */
async function onMsg(m) {
  try {
    if (m.cmd === "load") { post({ ev: "load", n: 0, total: 1 }); const d = await loadData(m.sym, m.tf, m.days, (n, total) => post({ ev: "load", n, total })); ST.arch.clear(); ST.recs = []; ST.cnt = { idea: 0, test: 0, passIS: 0, passOOS: 0, rob: 0, cand: 0, kept: 0, rej: 0 }; ST.pbo = []; ST.trials = 0;
      post({ ev: "data", sym: d.sym, tf: d.tf, n: d.n, t0: d.t[0], t1: d.t[d.n - 1], last: d.c[d.n - 1] }); }
    else if (m.cmd === "search") runSearch(m.cfg);
    else if (m.cmd === "stop") { ST.stop = true; NN.stop = true; }
    else if (m.cmd === "report") post({ ev: "report", rid: m.rid, rep: report(m.g, m.cfg) });
    else if (m.cmd === "live") post({ ev: "live", rid: m.rid, res: (m.gs || []).map((g) => { try { return live(g); } catch (e) { return null; } }) });
    else if (m.cmd === "seeds") ST.seeds = (m.gs || []).slice(0, 30);
    else if (m.cmd === "nn") nnTrain(m.cfg);
    else if (m.cmd === "nnlive") post({ ev: "nnlive", p: nnLive() });
    else if (m.cmd === "meta") post({ ev: "meta", rec: Object.fromEntries(Object.entries(REC).map(([k, v]) => [k, { tr: v.tr, src: v.src, sp: SP[k], mr: v.mr }])), sess: Object.keys(SESS) });
  } catch (e) { post({ ev: "error", msg: String(e && e.message || e), cmd: m.cmd }); }
}
if (IN_WORKER) self.onmessage = (e) => onMsg(e.data); else LAB.send = onMsg;
if (typeof module !== "undefined") module.exports = { LAB, REC, SP, SESS, rndG, mutate, gdesc, evalCand, loadData: (...a) => loadData(...a), setData: (d) => { D = d; MEMO = new Map(); }, get D() { return D; }, ST, split, report, live, onMsg, sr0, buildSig, sim, metr, nnTrain };





