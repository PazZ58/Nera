"use strict";
/* Nera · yenilikler: yeni sürüm ilk açıldığında animasyonlu "neler değişti" listesi (temaya uygun) + Ayarlar › Güncelleme geçmişi. Kaynak: changelog.json */
(function () {
const $ = (s, r = document) => r.querySelector(s);
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const GR = [["add", "Eklendi", "+"], ["fix", "Düzeltildi / değişti", "↻"], ["del", "Kaldırıldı", "−"]];
let LOG = null, CUR = 0;
async function load() { try { const [a, b] = await Promise.all([fetch("changelog.json", { cache: "no-store" }), fetch("version.json", { cache: "no-store" })]); LOG = await a.json(); CUR = (await b.json()).v || 0; } catch (e) { LOG = LOG || []; } return LOG; }
const date = (d) => { try { return new Date(d + "T12:00:00").toLocaleDateString("tr-TR", { day: "numeric", month: "long" }); } catch (e) { return d; } };
const body = (e, base = 0) => { let i = base; return GR.filter(([k]) => (e[k] || []).length).map(([k, n, g]) => `<div class="wn-g k-${k}"><h5><span>${g}</span>${n}</h5><ul>${e[k].map((x) => `<li style="--d:${(i++ * 0.07).toFixed(2)}s">${esc(x)}</li>`).join("")}</ul></div>`).join(""); };

function show(list) {
  const m = document.createElement("div"); m.id = "wn-modal";
  m.innerHTML = `<div class="wn-card"><div class="wn-fx"><i></i><i></i><i></i><i></i><i></i><i></i></div><div class="wn-hd"><span class="wn-badge">Nera Beta</span><h3>Yenilikler</h3><small>${list.length > 1 ? `${list.length} güncelleme` : date(list[0].date)}</small></div>
    <div class="wn-body">${list.map((e, j) => `<div class="wn-e"><b class="wn-t">${esc(e.title || "Güncelleme")}${list.length > 1 ? ` <small>${date(e.date)}</small>` : ""}</b>${body(e, j * 6)}</div>`).join("")}</div><button class="btn pri wn-ok">Harika</button></div>`;
  document.body.appendChild(m); requestAnimationFrame(() => m.classList.add("on"));
  const close = () => { m.classList.remove("on"); m.classList.add("off"); setTimeout(() => m.remove(), 450); };
  m.onclick = (e) => { if (e.target === m || e.target.closest(".wn-ok")) close(); };
  try { if (window.Sound && Sound.tone) { Sound.tone(523, 0.12, 0.4); setTimeout(() => Sound.tone(784, 0.16, 0.4), 140); } } catch (e) { /* */ }
}
async function check() {
  await load(); if (!CUR) return; const seen = +localStorage.getItem("nera_seen_v") || CUR - 1; localStorage.setItem("nera_seen_v", String(CUR)); if (window.NERA_SAVE) setTimeout(window.NERA_SAVE, 100);
  if (seen >= CUR) return; const list = (LOG || []).filter((e) => e.v > seen && e.v <= CUR).sort((a, b) => b.v - a.v).slice(0, 4); if (list.length) show(list);
}
async function panel() {
  const pg = $("#pg-set"); if (!pg) return; let p = $("#wn-panel"); if (!LOG) await load();
  if (!p) { p = document.createElement("div"); p.className = "panel"; p.id = "wn-panel"; const up = $("#upd-panel"); if (up) up.after(p); else pg.appendChild(p); }
  const h = `<div class="ph">Güncelleme geçmişi <small>Nera Beta</small></div><div class="wn-hist">${(LOG || []).slice().sort((a, b) => b.v - a.v).map((e, i) => `<details class="wn-row" ${i === 0 ? "open" : ""}><summary><b>${esc(e.title || "Güncelleme")}</b><span class="muted">${date(e.date)}</span>${e.v === CUR ? '<em class="chip ok">kurulu</em>' : ""}</summary>${body(e)}</details>`).join("") || '<div class="pb muted">Kayıt yok.</div>'}</div>`;
  if (p._h !== h) { p._h = h; p.innerHTML = h; }
}
window.NeraWhatsNew = { show: async () => { await load(); show((LOG || []).slice(0, 1)); } };
DT.on("view", (v) => { if (v === "set") setTimeout(panel, 350); });
let done = false; const go = () => { if (done) return; if (window.Splash && Splash.active) return void setTimeout(go, 800); done = true; setTimeout(check, 1500); }; DT.on("splash-done", go); setTimeout(go, 9000);
})();
