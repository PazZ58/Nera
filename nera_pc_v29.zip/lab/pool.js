"use strict";
/* Nera · Bilardo (8 top). Arkadaşlar ekranında. 2–4 oyuncu, A/B takımı (sıra takımlar arasında döner), izleyiciler.
   Ağ: arkadaş grubunun ntfy konusu <grup>_pool. Atışı yapan cihaz fiziği hesaplar ve sonucu (topların son yeri + kural durumu) yayınlar;
   diğerleri aynı atışı canlandırıp sonuca oturur (yetkili atıcı). Lobi: masa kur → takım seç → Hazır; takımlardaki herkes hazırsa oyun başlar.
   Kurallar: standart 8 top (düz 1-7 / çizgili 9-15), faulde rakibe "top elde", 8'i erken ya da faulle sokan kaybeder. */
(function () {
const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s == null ? "" : s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const F = () => window.NeraFriends || {}, NT = "https://ntfy.sh/";
const W = 1000, H = 500, R = 11, RAIL = 44, MU = 230, VMAX = 1750, DT = 1 / 240;
const PK = [[-7, -7, 23], [W / 2, -11, 19], [W + 7, -7, 23], [-7, H + 7, 23], [W / 2, H + 11, 19], [W + 7, H + 7, 23]];
const COL = { 1: "#f5c518", 2: "#1f5fd6", 3: "#e0262b", 4: "#5b2a86", 5: "#f07d1a", 6: "#18864b", 7: "#7a1f1f", 8: "#111", 9: "#f5c518", 10: "#1f5fd6", 11: "#e0262b", 12: "#5b2a86", 13: "#f07d1a", 14: "#18864b", 15: "#7a1f1f" };
const grp = (n) => (n >= 1 && n <= 7 ? "solid" : n >= 9 ? "stripe" : n === 8 ? "eight" : "cue"), GRN = { solid: "Düzler (1-7)", stripe: "Çizgililer (9-15)" };
const CUES = [["classic", "Klasik"], ["neon", "Neon"], ["halloween", "Cadı"], ["matrix", "Matrix"], ["ocean", "Okyanus"], ["forest", "Orman"], ["sunset", "Gün batımı"], ["gold", "Altın"]];
const themeNow = () => (document.body.className.match(/theme-(\w+)/) || [])[1] || "dark";
const P = { tables: {}, cur: null, view: "lobby", G: null, anim: null, pend: null, aim: 0, pow: 0, press: null, placed: false, es: null, seen: new Set(), mine: null, cue: localStorage.getItem("nera_cue") || null, practice: false, fx: [], t: 0, mouse: null };
const myCue = () => P.cue || ({ neon: "neon", halloween: "halloween", matrix: "matrix", ocean: "ocean", forest: "forest", sunset: "sunset" }[themeNow()] || "classic");
const rng = (a) => () => { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };

/* ---------------- fizik ---------------- */
function rack(seed) {
  const r = rng(seed), rest = [1, 2, 3, 4, 5, 6, 7, 9, 10, 11, 12, 13, 14, 15]; for (let i = rest.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [rest[i], rest[j]] = [rest[j], rest[i]]; }
  const solids = rest.filter((n) => n < 8), stripes = rest.filter((n) => n > 8), order = []; const cornerA = solids.pop(), cornerB = stripes.pop(); const mid = rest.filter((n) => n !== cornerA && n !== cornerB);
  const B = [{ n: 0, x: W * 0.25, y: H / 2, vx: 0, vy: 0, in: false }], ax = W * 0.72, dx = R * 2 * 0.866 + 0.4; let k = 0;
  for (let row = 0; row < 5; row++) for (let i = 0; i <= row; i++) { let n; if (row === 2 && i === 1) n = 8; else if (row === 4 && i === 0) n = cornerA; else if (row === 4 && i === 4) n = cornerB; else n = mid[k++]; order.push(n); B.push({ n, x: ax + row * dx, y: H / 2 + (i - row / 2) * (R * 2 + 0.4), vx: 0, vy: 0, in: false }); }
  return B;
}
function step(B, ev) {
  for (const b of B) { if (b.in) continue; b.x += b.vx * DT; b.y += b.vy * DT; const sp = Math.hypot(b.vx, b.vy); if (sp > 0) { const ns = Math.max(0, sp - MU * DT); b.vx *= ns / sp; b.vy *= ns / sp; } }
  for (let i = 0; i < B.length; i++) { const a = B[i]; if (a.in) continue; for (let j = i + 1; j < B.length; j++) { const b = B[j]; if (b.in) continue; const dx = b.x - a.x, dy = b.y - a.y, d = Math.hypot(dx, dy); if (d >= 2 * R || d === 0) continue;
    const nx = dx / d, ny = dy / d, rv = (a.vx - b.vx) * nx + (a.vy - b.vy) * ny, ov = (2 * R - d) / 2; a.x -= nx * ov; a.y -= ny * ov; b.x += nx * ov; b.y += ny * ov; if (rv <= 0) continue; const jm = rv * (1 + 0.95) / 2;
    a.vx -= jm * nx; a.vy -= jm * ny; b.vx += jm * nx; b.vy += jm * ny; if (ev) { if (ev.first == null && (a.n === 0 || b.n === 0)) ev.first = a.n === 0 ? b.n : a.n; ev.hits.push(rv); } } }
  for (const b of B) { if (b.in) continue; for (const [px, py, pr] of PK) if (Math.hypot(b.x - px, b.y - py) < pr) { b.in = true; b.vx = b.vy = 0; if (ev) ev.pot.push(b.n); break; } if (b.in) continue;
    const mouthX = b.x < 34 || b.x > W - 34 || Math.abs(b.x - W / 2) < 24, mouthY = b.y < 34 || b.y > H - 34;
    if (b.x < R && !(mouthY && b.x < 34)) { b.x = R; b.vx = -b.vx * 0.78; if (ev) ev.rail = 1; } if (b.x > W - R && !(mouthY && b.x > W - 34)) { b.x = W - R; b.vx = -b.vx * 0.78; if (ev) ev.rail = 1; }
    if (b.y < R && !mouthX) { b.y = R; b.vy = -b.vy * 0.78; if (ev) ev.rail = 1; } if (b.y > H - R && !mouthX) { b.y = H - R; b.vy = -b.vy * 0.78; if (ev) ev.rail = 1; }
    if (b.x < -40 || b.x > W + 40 || b.y < -40 || b.y > H + 40) { b.in = true; b.vx = b.vy = 0; if (ev) ev.pot.push(b.n); } }
  return B.every((b) => b.in || Math.hypot(b.vx, b.vy) < 3);
}
const clone = (B) => B.map((b) => Object.assign({}, b)), cueB = (G) => G.balls.find((b) => b.n === 0);
function shoot(G, ang, pow, cx, cy) { const B = clone(G.balls), c = B.find((b) => b.n === 0); if (cx != null) { c.x = cx; c.y = cy; c.in = false; } const v = Math.max(0.03, Math.min(1, pow)) * VMAX; c.vx = Math.cos(ang) * v; c.vy = Math.sin(ang) * v; return { B, ev: { first: null, pot: [], hits: [], rail: 0 }, steps: 0 }; }
function runAll(S) { let k = 0; while (!step(S.B, S.ev) && k < 240 * 40) k++; S.B.forEach((b) => { b.vx = b.vy = 0; }); return S; }

/* ---------------- kurallar (atıcı uygular) ---------------- */
const teamOf = (G, id) => G.teams[id], curId = (G) => G.order[G.turn % G.order.length], other = (t) => (t === "A" ? "B" : "A");
const cleared = (G, team, B) => { const g = G.groups[team]; return !!g && B.filter((b) => grp(b.n) === g).every((b) => b.in); };
function rules(G, S) {
  const id = curId(G), T = teamOf(G, id), g = G.groups[T], pot = S.ev.pot, first = S.ev.first, before = cleared(G, T, G.balls), B = S.B;
  const N = Object.assign({}, G, { balls: B, n: G.n + 1, groups: Object.assign({}, G.groups), bih: false, brk: false, tt: Date.now() });
  const scratch = pot.includes(0); let foul = false, why = "";
  if (scratch) { foul = true; why = "beyaz top deliğe girdi"; }
  else if (first == null) { foul = true; why = "hiçbir topa değmedi"; }
  else if (g && before && first !== 8) { foul = true; why = "grubun bitti, önce 8'e değmeliydi"; }
  else if (g && !before && grp(first) !== g) { foul = true; why = `önce kendi grubuna (${GRN[g]}) değmeliydi`; }
  else if (!g && first === 8 && !G.brk) { foul = true; why = "grup belli değilken önce 8'e değdi"; }
  if (pot.includes(8)) {
    if (G.brk && !scratch) { const e = B.find((b) => b.n === 8); e.in = false; e.x = W * 0.72; e.y = H / 2; }
    else { const win = !foul && before; N.win = win ? T : other(T); N.msg = win ? `${T} takımı 8'i sokup kazandı!` : `${T} takımı 8'i ${foul ? "faulle" : "erken"} soktu · ${other(T)} kazandı`; return N; }
  }
  const objs = pot.filter((n) => n !== 0 && n !== 8);
  if (!foul && !g && !G.brk && objs.length) { const ng = grp(objs[0]); N.groups[T] = ng; N.groups[other(T)] = ng === "solid" ? "stripe" : "solid"; }
  const keep = !foul && (G.brk ? objs.length > 0 : objs.some((n) => grp(n) === N.groups[T]));
  if (scratch) { const c = B.find((b) => b.n === 0); c.in = false; c.x = W * 0.25; c.y = H / 2; }
  if (foul) { N.turn = G.turn + 1; N.bih = true; N.msg = `Faul: ${why} · ${other(T)} takımına top elde`; }
  else if (keep) N.msg = `${objs.length} top girdi · sıra devam`;
  else { N.turn = G.turn + 1; N.msg = objs.length ? "Rakibin topu girdi · sıra geçti" : "Top girmedi · sıra geçti"; }
  if (G.brk && !foul) N.msg = (keep ? "Açılışta top girdi · sıra devam" : "Açılış yapıldı · sıra geçti") + " · masa açık";
  if (!N.groups[T] && N.groups.A) N.msg += ` · ${T}: ${GRN[N.groups[T]] || ""}`;
  if (N.groups[T] && !G.groups[T]) N.msg += ` · ${T} takımı ${GRN[N.groups[T]]}`;
  return N;
}
function newGame(tid, order, teams, seed, cues) { return { tid, balls: rack(seed), order, teams, cues: cues || {}, turn: 0, groups: { A: null, B: null }, bih: true, brk: true, win: null, n: 0, msg: "Açılış: beyaz topu sol çeyreğe yerleştir ve vur", t0: Date.now() }; }

/* ---------------- ağ ---------------- */
const topic = () => (F().pre ? F().pre() + "_pool" : "nera7_genel_pool");
const pub = (o) => fetch(NT + topic(), { method: "POST", body: JSON.stringify(Object.assign({ t: Date.now() }, o)) }).then((r) => { P.quota = r.status === 429; }).catch(() => {});
function onMsg(m, replay) {
  if (!m || m.event !== "message" || P.seen.has(m.id)) return; P.seen.add(m.id); let o; try { o = JSON.parse(m.message); } catch (e) { return; } if (!o || !o.tid) return;
  const T = P.tables[o.tid] = P.tables[o.tid] || { tid: o.tid, players: {}, st: "lobby", t: o.t };
  if (o.k === "tbl") { Object.assign(T, { host: o.host, hostNick: o.hostNick, st: o.st || T.st, t: Math.max(T.t || 0, o.t) }); }
  else if (o.k === "pl") { T.players[o.id] = { nick: o.nick, team: o.team || null, ready: !!o.ready, cue: o.cue, t: o.t }; T.t = Math.max(T.t || 0, o.t); maybeStart(T); }
  else if (o.k === "lv") { delete T.players[o.id]; }
  else if (o.k === "go") { T.st = "game"; T.G = newGame(o.tid, o.order, o.teams, o.seed, o.cues); if (P.cur === o.tid) { P.G = T.G; P.view = "game"; if (!replay) { P.fx.push({ k: "break", t: 0 }); sfx(330, 0.2); } } }
  else if (o.k === "shot") { if (!replay && P.cur === o.tid && P.G && o.n === P.G.n + 1 && o.by !== F().me()) { P.anim = shoot(P.G, o.ang, o.pow, o.cx, o.cy); P.anim.by = o.by; P.anim.ang = o.ang; P.anim.cue = o.cue; P.anim.strike = 0; } }
  else if (o.k === "res") { const G = o.G; if (!T.G || G.n > T.G.n) { T.G = G; if (G.win) T.st = "over"; } if (P.cur === o.tid && P.G && G.n > P.G.n) { if (P.anim && !replay) P.pend = G; else { P.G = G; P.anim = null; } } }
  else if (o.k === "close") { T.st = "closed"; }
  if (!replay) render();
}
async function connect() {
  if (!F().me || !F().me()) return; if (P.es) { try { P.es.close(); } catch (e) { /* */ } }
  try { const r = await fetch(`${NT}${topic()}/json?poll=1&since=3h`); (await r.text()).split("\n").forEach((l) => { if (l.trim()) try { onMsg(JSON.parse(l), true); } catch (e) { /* */ } }); } catch (e) { /* */ }
  if (P.cur && P.tables[P.cur] && P.tables[P.cur].G) { P.G = P.tables[P.cur].G; P.view = P.tables[P.cur].st === "lobby" ? "lobby" : "game"; }
  P.es = new EventSource(`${NT}${topic()}/sse`); P.es.onmessage = (e) => { try { onMsg(JSON.parse(e.data)); } catch (x) { /* */ } }; render();
}
const live = (T) => Object.entries(T.players).filter(([, p]) => Date.now() - p.t < 200000);
function maybeStart(T) {
  if (!F().me || T.host !== F().me() || T.st !== "lobby") return; const L = live(T), A = L.filter(([, p]) => p.team === "A"), B = L.filter(([, p]) => p.team === "B");
  if (A.length && B.length && A.length + B.length <= 4 && [...A, ...B].every(([, p]) => p.ready)) { clearTimeout(T._go); T._go = setTimeout(() => { const L2 = live(T), a = L2.filter(([, p]) => p.team === "A").map(([i]) => i), b = L2.filter(([, p]) => p.team === "B").map(([i]) => i); if (!a.length || !b.length) return; const order = []; for (let i = 0; i < Math.max(a.length, b.length); i++) order.push(a[i % a.length], b[i % b.length]); const teams = {}, cues = {}; L2.forEach(([i, p]) => { if (p.team) teams[i] = p.team; cues[i] = p.cue; }); pub({ k: "tbl", tid: T.tid, host: T.host, hostNick: T.hostNick, st: "game" }); const go = { k: "go", tid: T.tid, order, teams, cues, seed: (Math.random() * 1e9) | 0, t: Date.now() }; pub(go); onMsg({ event: "message", id: "loc" + go.seed, message: JSON.stringify(go) }); }, 1800); }
}
function myPl(patch) { const T = P.tables[P.cur]; if (!T) return; const me = F().me(), cur = T.players[me] || { team: null, ready: false }; const o = Object.assign({ k: "pl", tid: P.cur, id: me, nick: F().nick(), team: cur.team, ready: cur.ready, cue: myCue() }, patch); T.players[me] = { nick: o.nick, team: o.team, ready: o.ready, cue: o.cue, t: Date.now() }; pub(o); maybeStart(T); render(); }
function createTable() { const me = F().me(); if (!me) return alert("Önce profilde takma adını kaydet."); const tid = "t" + Math.random().toString(36).slice(2, 8); P.tables[tid] = { tid, host: me, hostNick: F().nick(), players: {}, st: "lobby", t: Date.now() }; P.cur = tid; P.view = "lobby"; pub({ k: "tbl", tid, host: me, hostNick: F().nick(), st: "lobby" }); myPl({ team: "A", ready: false }); }
function leave() { if (P.cur && !P.practice) { pub({ k: "lv", tid: P.cur, id: F().me() }); const T = P.tables[P.cur]; if (T && T.host === F().me() && T.st === "lobby") pub({ k: "close", tid: P.cur }); } P.cur = null; P.G = null; P.anim = null; P.practice = false; P.view = "lobby"; render(); }
setInterval(() => { if (P.cur && !P.practice && F().me && F().me()) { const T = P.tables[P.cur]; if (T && T.players[F().me()]) myPl({}); if (T && T.host === F().me()) pub({ k: "tbl", tid: T.tid, host: T.host, hostNick: T.hostNick, st: T.st }); } }, 75000);

/* ---------------- atış (yerel) ---------------- */
const myTurn = () => P.G && !P.G.win && !P.anim && (P.practice || curId(P.G) === F().me());
function doShot() {
  const G = P.G, c = cueB(G), pow = P.pow; if (pow < 0.03) return; const placed = G.bih ? [c.x, c.y] : [null, null];
  P.anim = shoot(G, P.aim, pow, placed[0], placed[1]); P.anim.by = F().me ? F().me() : "ben"; P.anim.ang = P.aim; P.anim.cue = myCue(); P.anim.strike = 0; P.anim.mine = true; P.pow = 0; P.press = null; P.placed = false;
  if (!P.practice) pub({ k: "shot", tid: G.tid, n: G.n + 1, by: F().me(), ang: P.aim, pow, cx: placed[0], cy: placed[1], cue: myCue() });
}
function settle() {
  const A = P.anim; if (!A) return; if (A.mine) { let N; if (P.practice) { N = Object.assign({}, P.G, { balls: A.B, n: P.G.n + 1, bih: A.ev.pot.includes(0), brk: false, msg: A.ev.pot.filter((n) => n).length ? `${A.ev.pot.filter((n) => n).length} top girdi` : "Antrenman" }); if (A.ev.pot.includes(0)) { const c = A.B.find((b) => b.n === 0); c.in = false; c.x = W * 0.25; c.y = H / 2; } if (A.B.filter((b) => b.n).every((b) => b.in)) { N.balls = rack((Math.random() * 1e9) | 0); N.msg = "Masa temizlendi! Yeni dizilim"; } }
    else { N = rules(P.G, A); pub({ k: "res", tid: P.G.tid, n: N.n, by: F().me(), G: N }); } P.G = N; if (P.tables[N.tid]) P.tables[N.tid].G = N; }
  else if (P.pend) { P.G = P.pend; P.pend = null; } else { P.G = Object.assign({}, P.G, { balls: A.B }); }
  P.anim = null; if (P.G.win) { P.fx.push({ k: "win", t: 0 }); sfx(784, 0.3); setTimeout(() => sfx(988, 0.3), 160); } render();
}
function sfx(f, d, v) { try { if (window.Sound && Sound.tone) Sound.tone(f, d || 0.06, v || 0.25); } catch (e) { /* */ } }

/* ---------------- çizim ---------------- */
const FELT = { dark: ["#0f6b4c", "#0a4a35", "#5a3a22"], black: ["#1d2a24", "#111814", "#2a2a2a"], light: ["#1c8a62", "#126447", "#8a5a34"], halloween: ["#3b1a52", "#240f33", "#ff8a1f"], neon: ["#1b0f3a", "#0e0824", "#ff2bd6"], ocean: ["#0f5f8a", "#093f5d", "#d9c9a3"], forest: ["#2d5a1f", "#1d3d14", "#6b4a2a"], sunset: ["#7a2b46", "#4f1b2e", "#ffb070"], matrix: ["#031a0b", "#010d05", "#39ff7a"] };
function drawCue(c, x, y, ang, back, id, sc) {
  const L = 380 * sc, w0 = 3.2 * sc, w1 = 7 * sc, d0 = (R + 6 + back) * sc; c.save(); c.translate(x, y); c.rotate(ang + Math.PI); c.translate(d0, 0);
  const g = c.createLinearGradient(0, 0, L, 0), set = { classic: [["#f3e7c9", 0], ["#c9a46a", 0.08], ["#8a5a2b", 0.62], ["#1a1008", 0.66], ["#3b2210", 1]], neon: [["#fff", 0], ["#00f0ff", 0.1], ["#5b1bd6", 0.6], ["#ff2bd6", 0.66], ["#14001f", 1]], halloween: [["#fff", 0], ["#ff8a1f", 0.1], ["#111", 0.45], ["#ff8a1f", 0.6], ["#111", 1]], matrix: [["#d6ffe2", 0], ["#39ff7a", 0.1], ["#03200c", 0.6], ["#39ff7a", 0.64], ["#010d05", 1]], ocean: [["#fff", 0], ["#7fdcff", 0.1], ["#0f5f8a", 0.6], ["#d9c9a3", 0.64], ["#062c45", 1]], forest: [["#f0f5e0", 0], ["#b7d98a", 0.1], ["#3a5a1f", 0.62], ["#6b4a2a", 0.66], ["#24180c", 1]], sunset: [["#fff", 0], ["#ffcf6b", 0.1], ["#ff7a59", 0.5], ["#a62a5c", 0.66], ["#2a0a1c", 1]], gold: [["#fff", 0], ["#ffe08a", 0.1], ["#b8862b", 0.6], ["#2a1e08", 0.66], ["#ffd27a", 1]] }[id] || [];
  set.forEach(([col, o]) => g.addColorStop(o, col)); c.fillStyle = g; if (id === "neon" || id === "matrix") { c.shadowColor = id === "neon" ? "#ff2bd6" : "#39ff7a"; c.shadowBlur = 14 * sc; }
  c.beginPath(); c.moveTo(0, -w0 / 2); c.lineTo(L, -w1 / 2); c.lineTo(L, w1 / 2); c.lineTo(0, w0 / 2); c.closePath(); c.fill(); c.shadowBlur = 0; c.fillStyle = "#e9eef5"; c.fillRect(0, -w0 / 2, 6 * sc, w0); c.fillStyle = "#2b6cb0"; c.fillRect(-1.5 * sc, -w0 / 2, 2 * sc, w0);
  if (id === "halloween") { c.fillStyle = "#ff8a1f"; c.beginPath(); c.arc(L - 26 * sc, 0, 5 * sc, 0, 6.283); c.fill(); } if (id === "forest") { c.fillStyle = "#9be15d"; c.beginPath(); c.ellipse(L - 30 * sc, 0, 7 * sc, 3 * sc, 0.5, 0, 6.283); c.fill(); } c.restore();
}
function ball(c, b, X, Y, sc, roll) {
  const x = X(b.x), y = Y(b.y), r = R * sc; c.save(); c.beginPath(); c.arc(x, y, r, 0, 6.283); c.clip(); const base = b.n === 0 ? "#f7f4ea" : b.n > 8 ? "#f7f4ea" : COL[b.n]; c.fillStyle = base; c.fillRect(x - r, y - r, 2 * r, 2 * r);
  if (b.n > 8) { c.fillStyle = COL[b.n]; const o = Math.sin(roll || 0) * r * 0.3; c.fillRect(x - r, y - r * 0.55 + o, 2 * r, r * 1.1); } if (b.n) { c.fillStyle = "#fff"; c.beginPath(); c.arc(x, y, r * 0.45, 0, 6.283); c.fill(); c.fillStyle = "#111"; c.font = `700 ${Math.max(7, r * 0.6)}px Segoe UI,sans-serif`; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(b.n, x, y + 0.5); }
  const g = c.createRadialGradient(x - r * 0.35, y - r * 0.4, r * 0.1, x, y, r * 1.1); g.addColorStop(0, "rgba(255,255,255,.55)"); g.addColorStop(0.35, "rgba(255,255,255,0)"); g.addColorStop(1, "rgba(0,0,0,.45)"); c.fillStyle = g; c.fillRect(x - r, y - r, 2 * r, 2 * r); c.restore();
}
function frame(dt) {
  const cv = $("#pool-cv"); if (!cv || !vis(cv) || !P.G) return; P.t += dt; const wrap = cv.parentElement, cw = wrap.clientWidth, ch = cw * ((H + 2 * RAIL) / (W + 2 * RAIL)), c = fitCanvas(cv, cw, ch), sc = cw / (W + 2 * RAIL), X = (x) => (x + RAIL) * sc, Y = (y) => (y + RAIL) * sc;
  if (P.anim) { P.anim.strike = Math.min(1, P.anim.strike + dt * 6); if (P.anim.strike >= 1) { const nw = performance.now(), el = P.anim.lt ? (nw - P.anim.lt) / 1000 : dt; P.anim.lt = nw; const n = Math.min(720, Math.max(1, Math.round(el * 240))); let done = false; const h0 = P.anim.ev.hits.length, p0 = P.anim.ev.pot.length; for (let i = 0; i < n && !done; i++) done = step(P.anim.B, P.anim.ev); if (P.anim.ev.hits.length > h0) sfx(900 + Math.random() * 200, 0.03, Math.min(0.35, P.anim.ev.hits[P.anim.ev.hits.length - 1] / 2500)); if (P.anim.ev.pot.length > p0) { sfx(220, 0.12, 0.3); const b = P.anim.B.find((q) => q.n === P.anim.ev.pot[P.anim.ev.pot.length - 1]); P.fx.push({ k: "pot", t: 0, x: b.x, y: b.y }); } P.anim.steps += n; if (done || P.anim.steps > 240 * 40) settle(); } }
  const B = P.anim ? P.anim.B : P.G.balls, th = FELT[themeNow()] || FELT.dark;
  c.clearRect(0, 0, cw, ch); const rg = c.createLinearGradient(0, 0, 0, ch); rg.addColorStop(0, th[2]); rg.addColorStop(1, "#000"); c.fillStyle = rg; roundRect(c, 0, 0, cw, ch, 18 * sc); c.fill();
  const fg = c.createRadialGradient(cw / 2, ch / 2, 20, cw / 2, ch / 2, cw * 0.6); fg.addColorStop(0, th[0]); fg.addColorStop(1, th[1]); c.fillStyle = fg; c.fillRect(X(0) - 8 * sc, Y(0) - 8 * sc, (W + 16) * sc, (H + 16) * sc);
  c.fillStyle = "rgba(255,255,255,.55)"; for (let i = 1; i < 8; i++) { c.beginPath(); c.arc(X((W * i) / 8), Y(0) - 22 * sc, 2.4 * sc, 0, 6.283); c.fill(); c.beginPath(); c.arc(X((W * i) / 8), Y(H) + 22 * sc, 2.4 * sc, 0, 6.283); c.fill(); } for (let i = 1; i < 4; i++) { c.beginPath(); c.arc(X(0) - 22 * sc, Y((H * i) / 4), 2.4 * sc, 0, 6.283); c.fill(); c.beginPath(); c.arc(X(W) + 22 * sc, Y((H * i) / 4), 2.4 * sc, 0, 6.283); c.fill(); }
  c.strokeStyle = "rgba(255,255,255,.08)"; c.beginPath(); c.moveTo(X(W * 0.25), Y(0)); c.lineTo(X(W * 0.25), Y(H)); c.stroke();
  PK.forEach(([px, py, pr]) => { const g = c.createRadialGradient(X(px), Y(py), 0, X(px), Y(py), pr * 1.2 * sc); g.addColorStop(0, "#000"); g.addColorStop(0.75, "#050505"); g.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = g; c.beginPath(); c.arc(X(px), Y(py), pr * 1.25 * sc, 0, 6.283); c.fill(); });
  B.forEach((b) => { if (b.in) return; c.fillStyle = "rgba(0,0,0,.35)"; c.beginPath(); c.ellipse(X(b.x) + 2 * sc, Y(b.y) + 3 * sc, R * sc, R * sc * 0.8, 0, 0, 6.283); c.fill(); });
  B.forEach((b) => { if (!b.in) ball(c, b, X, Y, sc, (b.x + b.y) / 9); });
  // nişan + ıstaka
  const cb = B.find((b) => b.n === 0), mine = myTurn();
  if (mine && cb && !cb.in) { if (P.G.bih && !P.placed && P.mouse) { const m = P.mouse, ok = validPlace(m[0], m[1]); cb.x = m[0]; cb.y = m[1]; c.strokeStyle = ok ? "rgba(255,255,255,.7)" : "#f2566a"; c.setLineDash([4, 4]); c.beginPath(); c.arc(X(cb.x), Y(cb.y), (R + 5) * sc, 0, 6.283); c.stroke(); c.setLineDash([]); }
    else { if (P.mouse && !P.press) P.aim = Math.atan2(P.mouse[1] - cb.y, P.mouse[0] - cb.x); guide(c, B, cb, P.aim, X, Y, sc); drawCue(c, X(cb.x), Y(cb.y), P.aim, P.pow * 90, myCue(), sc); } }
  else if (P.anim && P.anim.strike < 1 && cb) drawCue(c, X(cb.x), Y(cb.y), P.anim.ang, (1 - P.anim.strike) * 60, P.anim.cue || "classic", sc);
  if (mine && P.press) { const bw = 10 * sc, bh = ch * 0.6, bx = cw - 24 * sc, by = (ch - bh) / 2; c.fillStyle = "rgba(0,0,0,.5)"; roundRect(c, bx, by, bw, bh, 5 * sc); c.fill(); const pg = c.createLinearGradient(0, by + bh, 0, by); pg.addColorStop(0, "#3ddc84"); pg.addColorStop(0.6, "#ffd27a"); pg.addColorStop(1, "#f2566a"); c.fillStyle = pg; roundRect(c, bx, by + bh * (1 - P.pow), bw, bh * P.pow, 5 * sc); c.fill(); }
  for (let i = P.fx.length - 1; i >= 0; i--) { const f = P.fx[i]; f.t += dt / (f.k === "win" ? 2.5 : 0.8); if (f.t >= 1) { P.fx.splice(i, 1); continue; }
    if (f.k === "pot") { c.strokeStyle = `rgba(255,210,122,${1 - f.t})`; c.lineWidth = 3; c.beginPath(); c.arc(X(f.x), Y(f.y), (10 + f.t * 40) * sc, 0, 6.283); c.stroke(); }
    else if (f.k === "win" || f.k === "break") for (let k = 0; k < 40; k++) { const a = k * 2.4, d = f.t * cw * 0.45; c.fillStyle = `hsla(${(k * 37) % 360},90%,60%,${1 - f.t})`; c.fillRect(cw / 2 + Math.cos(a) * d, ch / 2 + Math.sin(a) * d * 0.6 - f.t * 30, 5, 5); } }
}
function roundRect(c, x, y, w, h, r) { c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); }
function validPlace(x, y) { if (x < R || x > W - R || y < R || y > H - R) return false; if (P.G.brk && x > W * 0.25) return false; return P.G.balls.every((b) => b.n === 0 || b.in || Math.hypot(b.x - x, b.y - y) > 2 * R + 1); }
function guide(c, B, cb, ang, X, Y, sc) {
  const dx = Math.cos(ang), dy = Math.sin(ang); let best = 1e9, hit = null; B.forEach((b) => { if (b.in || b.n === 0) return; const fx = b.x - cb.x, fy = b.y - cb.y, t = fx * dx + fy * dy; if (t <= 0) return; const d2 = fx * fx + fy * fy - t * t; if (d2 > 4 * R * R) return; const tt = t - Math.sqrt(4 * R * R - d2); if (tt < best) { best = tt; hit = b; } });
  const wall = Math.min(dx > 0 ? (W - R - cb.x) / dx : dx < 0 ? (R - cb.x) / dx : 1e9, dy > 0 ? (H - R - cb.y) / dy : dy < 0 ? (R - cb.y) / dy : 1e9), L = Math.min(best, wall), gx = cb.x + dx * L, gy = cb.y + dy * L;
  c.strokeStyle = "rgba(255,255,255,.55)"; c.setLineDash([6, 6]); c.lineWidth = 1.4; c.beginPath(); c.moveTo(X(cb.x), Y(cb.y)); c.lineTo(X(gx), Y(gy)); c.stroke(); c.setLineDash([]); c.beginPath(); c.arc(X(gx), Y(gy), R * sc, 0, 6.283); c.stroke();
  if (hit && best <= wall) { const nx = (hit.x - gx) / (2 * R), ny = (hit.y - gy) / (2 * R); c.strokeStyle = "rgba(255,210,122,.8)"; c.beginPath(); c.moveTo(X(hit.x), Y(hit.y)); c.lineTo(X(hit.x + nx * 90), Y(hit.y + ny * 90)); c.stroke(); }
}

/* ---------------- arayüz ---------------- */
function toTable(e) { const cv = $("#pool-cv"), r = cv.getBoundingClientRect(), sc = r.width / (W + 2 * RAIL); return [(e.clientX - r.left) / sc - RAIL, (e.clientY - r.top) / sc - RAIL]; }
function bindCanvas() {
  const cv = $("#pool-cv"); if (!cv || cv._b) return; cv._b = 1;
  cv.addEventListener("pointermove", (e) => { P.mouse = toTable(e); if (P.press && myTurn()) { const d = Math.hypot(P.mouse[0] - P.press[0], P.mouse[1] - P.press[1]); P.pow = Math.min(1, d / 260); } });
  cv.addEventListener("pointerdown", (e) => { if (!myTurn()) return; try { cv.setPointerCapture(e.pointerId); } catch (x) { /* */ } P.mouse = toTable(e); const cb = cueB(P.G); if (P.G.bih && !P.placed) { if (validPlace(P.mouse[0], P.mouse[1])) { cb.x = P.mouse[0]; cb.y = P.mouse[1]; P.placed = true; sfx(600, 0.04); } return; } P.aim = Math.atan2(P.mouse[1] - cb.y, P.mouse[0] - cb.x); P.press = P.mouse.slice(); P.pow = 0; });
  const up = () => { if (P.press && myTurn()) doShot(); P.press = null; }; cv.addEventListener("pointerup", up); cv.addEventListener("pointercancel", () => { P.press = null; P.pow = 0; }); cv.addEventListener("pointerleave", () => { if (!P.press) P.mouse = null; });
}
function cuePicker() { return `<div class="pool-cues">${CUES.map(([k, n]) => `<button class="pool-cue ${myCue() === k ? "on" : ""}" data-c="${k}"><canvas width="160" height="26" data-cue="${k}"></canvas><span>${n}</span></button>`).join("")}</div>`; }
function paintCues() { $$("canvas[data-cue]").forEach((cv) => { const c = cv.getContext("2d"); c.clearRect(0, 0, 160, 26); drawCue(c, 168, 13, Math.PI, -150, cv.dataset.cue, 0.42); }); }
const rulesHTML = `<details class="pool-rules"><summary>8 top kuralları</summary><ul><li>Takımlar sırayla atar; aynı takımdaki oyuncular da kendi aralarında sırayla oynar.</li><li>Açılışta beyaz top sol çeyrekte istenen yere konur. Açılıştan sonra ilk sokulan top takımın grubunu belirler: düzler (1-7) ya da çizgililer (9-15).</li><li>Kendi grubundan top sokarsan sıra sende kalır; sokamazsan sıra geçer.</li><li>Faul: beyaz top deliğe girerse, hiçbir topa değmezsen ya da önce rakibin topuna (veya 8'e) değersen. Faulde rakip takım beyaz topu masada istediği yere koyar.</li><li>Grubunu bitiren takım 8'i sokarsa kazanır. 8'i erken ya da faulle sokan takım kaybeder. Açılışta 8 girerse yerine konur.</li><li>Nişan: fareyle/parmakla yönü seç, basılı tutup çek (güç), bırak = vur.</li></ul></details>`;
function render() {
  const root = $("#pool-root"); if (!root || !root.classList.contains("on")) return; const me = F().me ? F().me() : "";
  if (P.view === "game" && P.G) return renderGame(root);
  const T = P.cur && P.tables[P.cur];
  if (T) { const L = live(T), col = (team) => L.filter(([, p]) => p.team === team).map(([i, p]) => `<div class="pool-pl ${p.ready ? "rdy" : ""}"><span class="avt" style="width:30px;height:30px;font-size:12px;background:hsl(${[...String(p.nick)].reduce((a, ch) => a + ch.charCodeAt(0), 0) * 37 % 360},60%,45%)">${esc(String(p.nick).slice(0, 2).toUpperCase())}</span><b>${esc(p.nick)}${i === T.host ? " 👑" : ""}</b><em>${p.ready ? "HAZIR" : "bekliyor"}</em></div>`).join("") || '<div class="muted pool-empty">boş</div>';
    const mp = T.players[me] || {}, specs = L.filter(([, p]) => !p.team);
    const h = `<div class="pool-lobby"><div class="pool-head"><div><div class="eyebrow">Bilardo · 8 top</div><h3>${esc(T.hostNick || "Masa")} masası</h3></div><button class="btn" data-a="leave">Masadan ayrıl</button></div>
      <div class="pool-teams"><div class="pool-team A"><h4>A takımı</h4>${col("A")}<button class="btn" data-a="A" ${mp.team === "A" ? "disabled" : ""}>A'ya geç</button></div><div class="pool-vs">VS</div><div class="pool-team B"><h4>B takımı</h4>${col("B")}<button class="btn" data-a="B" ${mp.team === "B" ? "disabled" : ""}>B'ye geç</button></div></div>
      <div class="pool-specs">İzleyiciler: ${specs.map(([, p]) => esc(p.nick)).join(", ") || "yok"} <button class="btn" data-a="spec" ${!mp.team ? "disabled" : ""}>İzleyici ol</button></div>
      <div class="pool-go">${mp.team ? `<button class="btn ${mp.ready ? "warn" : "pri"} pool-ready" data-a="ready">${mp.ready ? "Hazır değilim" : "Hazırım"}</button>` : ""}<span class="muted">Takımlardaki herkes hazır olunca oyun başlar (en çok 4 oyuncu). ${T.host === me ? "Masayı sen kurdun." : ""}</span></div>
      <h5>Istakan</h5>${cuePicker()}${rulesHTML}</div>`;
    if (root._h !== h) { root._h = h; root.innerHTML = h; paintCues(); bindLobby(root); } return; }
  const list = Object.values(P.tables).filter((t) => t.st !== "closed" && Date.now() - (t.t || 0) < 3 * 3600e3 && live(t).length).sort((a, b) => b.t - a.t);
  const h = `<div class="pool-lobby">${P.quota ? '<div class="pool-quota">Ücretsiz mesaj sunucusunun (ntfy.sh) bu internet bağlantısı için günlük kotası doldu. Türkiye saatiyle 03:00&#39;te kendiliğinden açılır; o zamana kadar çok oyunculu masa ve sohbet çalışmaz. Antrenman çalışır.</div>' : ""}<div class="pool-head"><div><div class="eyebrow">Arkadaş grubu</div><h3>Bilardo masaları</h3></div><div class="ctl"><button class="btn pri" data-a="new">Masa kur</button><button class="btn" data-a="solo">Antrenman</button></div></div>
    <div class="pool-tables">${list.map((t) => { const L = live(t); return `<div class="pool-tc ${t.st}"><div><b>${esc(t.hostNick || "Masa")} masası</b><span class="muted">${t.st === "game" ? "oyunda" : t.st === "over" ? "bitti" : "lobide"} · ${L.filter(([, p]) => p.team === "A").length} vs ${L.filter(([, p]) => p.team === "B").length} · ${L.filter(([, p]) => !p.team).length} izleyici</span></div><button class="btn" data-t="${t.tid}">${t.st === "lobby" ? "Katıl" : "İzle"}</button></div>`; }).join("") || '<div class="muted pool-empty">Açık masa yok. "Masa kur" ile başlat; aynı grup kodundaki arkadaşların görür.</div>'}</div>
    <h5>Istakan</h5>${cuePicker()}${rulesHTML}</div>`;
  if (root._h !== h) { root._h = h; root.innerHTML = h; paintCues(); bindLobby(root); }
}
function bindLobby(root) {
  $$("[data-a]", root).forEach((b) => (b.onclick = () => { const a = b.dataset.a; if (a === "new") createTable(); else if (a === "solo") { P.practice = true; P.cur = "solo"; P.G = newGame("solo", [F().me() || "ben"], { [F().me() || "ben"]: "A" }, (Math.random() * 1e9) | 0); P.G.msg = "Antrenman: kurallar yok, istediğin gibi vur"; P.view = "game"; render(); }
    else if (a === "leave") leave(); else if (a === "A" || a === "B") myPl({ team: a, ready: false }); else if (a === "spec") myPl({ team: null, ready: false }); else if (a === "ready") myPl({ ready: !((P.tables[P.cur].players[F().me()] || {}).ready) }); }));
  $$("[data-t]", root).forEach((b) => (b.onclick = () => { const T = P.tables[b.dataset.t]; P.cur = b.dataset.t; if (T.st !== "lobby" && T.G) { P.G = T.G; P.view = "game"; myPl({ team: null, ready: false }); } else { P.view = "lobby"; myPl({ team: null, ready: false }); } render(); }));
  $$(".pool-cue", root).forEach((b) => (b.onclick = () => { P.cue = b.dataset.c; localStorage.setItem("nera_cue", P.cue); if (P.cur && !P.practice) myPl({}); root._h = ""; render(); }));
}
function renderGame(root) {
  const G = P.G, me = F().me ? F().me() : "", T = P.tables[G.tid] || { players: {} }, nick = (i) => (T.players[i] || {}).nick || (i === me ? F().nick() : i), cur = curId(G), team = (t) => G.order.filter((i, k) => G.order.indexOf(i) === k && G.teams[i] === t);
  if (!root.querySelector("#pool-cv")) { root._h = ""; root.innerHTML = `<div class="pool-game"><div class="pool-sb" id="pool-sb"></div><div class="pool-tw"><canvas id="pool-cv"></canvas></div><div class="pool-st" id="pool-st"></div><div class="ctl pool-gc"><button class="btn" data-g="leave">${P.practice ? "Antrenmandan çık" : "Masadan ayrıl"}</button><button class="btn" data-g="rack" style="${P.practice ? "" : "display:none"}">Yeniden diz</button><button class="btn" data-g="skip" style="display:none">Sırayı geç</button><span class="muted">Yön: fare/parmak · basılı tut ve çek: güç · bırak: vur</span></div></div>`;
    bindCanvas(); $$("[data-g]", root).forEach((b) => (b.onclick = () => { const a = b.dataset.g; if (a === "leave") leave(); else if (a === "rack") { P.G = Object.assign({}, P.G, { balls: rack((Math.random() * 1e9) | 0), bih: true, brk: true }); } else if (a === "skip" && P.tables[G.tid] && P.tables[G.tid].host === me) { const N = Object.assign({}, P.G, { n: P.G.n + 1, turn: P.G.turn + 1, bih: true, msg: "Sıra geçildi (oyuncu yanıt vermedi)" }); pub({ k: "res", tid: G.tid, n: N.n, by: me, G: N }); P.G = N; render(); } })); }
  const gi = (t) => (G.groups[t] ? `<span class="pool-gi ${G.groups[t]}">${G.groups[t] === "solid" ? "● düz" : "◐ çizgili"} · ${G.balls.filter((b) => grp(b.n) === G.groups[t] && b.in).length}/7</span>` : '<span class="pool-gi">grup açık</span>');
  const tb = (t) => `<div class="pool-sbt ${t} ${G.teams[cur] === t && !G.win ? "turn" : ""} ${G.win === t ? "won" : ""}"><b>${t} takımı</b>${gi(t)}<span>${team(t).map((i) => `<i class="${i === cur && !G.win ? "on" : ""}">${esc(nick(i))}</i>`).join("")}</span></div>`;
  const sb = P.practice ? `<div class="pool-sbt A turn"><b>Antrenman</b><span>${G.balls.filter((b) => b.n && b.in).length} top girdi</span></div>` : `${tb("A")}<div class="pool-turn">${G.win ? "🏆" : myTurn() ? "SIRA SENDE" : `sıra: ${esc(nick(cur))}`}${G.order.includes(me) || P.practice ? "" : '<em>izliyorsun</em>'}</div>${tb("B")}`;
  const se = $("#pool-sb"); if (se._h !== sb) { se._h = sb; se.innerHTML = sb; }
  const msg = (G.win ? `<b class="pool-win">${esc(G.msg)}</b>` : esc(G.msg || "")) + (myTurn() && G.bih && !P.placed ? " · <b>Beyaz topu yerleştir</b>" : ""); const st = $("#pool-st"); if (st._h !== msg) { st._h = msg; st.innerHTML = msg; st.classList.remove("pop"); void st.offsetWidth; st.classList.add("pop"); }
  const sk = root.querySelector('[data-g="skip"]'); if (sk) sk.style.display = !P.practice && T.host === me && !G.win && Date.now() - (G.tt || G.t0 || 0) > 90000 ? "" : "none";
}

/* Arkadaşlar ekranına "Sohbet | Bilardo" anahtarı */
function mount() {
  const pg = $("#pg-friends"); if (!pg || $("#pool-root")) return; const grid = pg.querySelector(".frgrid"); if (!grid) return;
  const sw = document.createElement("div"); sw.className = "seg pool-sw"; sw.innerHTML = '<button data-m="chat" class="on">💬 Sohbet</button><button data-m="pool">🎱 Bilardo</button>'; grid.before(sw);
  const root = document.createElement("div"); root.id = "pool-root"; root.className = "panel"; grid.after(root);
  $$("button", sw).forEach((b) => (b.onclick = () => { const on = b.dataset.m === "pool"; $$("button", sw).forEach((x) => x.classList.toggle("on", x === b)); grid.style.display = on ? "none" : ""; root.classList.toggle("on", on); if (on) { if (!P.es) connect(); root._h = ""; render(); } }));
}
window.addEventListener("DOMContentLoaded", () => { setTimeout(mount, 400); TICKS.push(frame); setInterval(() => { if ($("#pool-root.on")) render(); }, 1500); DT.on("theme", () => { const r = $("#pool-root"); if (r) { r._h = ""; render(); } }); });
window.NeraPool = { P, _t: { shoot, runAll, rules, newGame }, _msg: (o) => onMsg({ event: "message", id: "t" + Math.random(), message: JSON.stringify(o) }) };
})();
