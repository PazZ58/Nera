"use strict";
/* NeraFlow: gerçek order flow kaydı (Binance USDⓈ-M vadeli). Mumdan tahmin yok:
   - işlemler: aggTrade (her işlemin fiyatı, miktarı, agresör tarafı) → dakika × fiyat satırı alış/satış = ayak izi, gerçek CVD
   - balina: tek işlem notional'ı oturumun %99,7 diliminin (en az FLOOR $) üstünde
   - tasfiye: forceOrder (Binance her saniye sembol başına en büyük tasfiyeyi yayınlar; hepsi değil)
   - emir defteri: REST depth (güncel sembol 3 sn/1000 seviye, diğerleri 20 sn/500 seviye), 60 sn dilimde satır başına en büyük bekleyen tutar
   Uygulama açıkken kaydedilir, IndexedDB'de 3 gün saklanır. Kaydın olmadığı geçmiş için Binance 1 dk mumlarının gerçek taker alış/satış
   hacmi kullanılır (dakika toplamı gerçek; dakika içindeki fiyat satırlarına eşit yayılır, ekranda "≈" ile işaretli). */
(function () {
  const SY = ["BTCUSDT", "ETHUSDT", "XAUUSDT", "XAGUSDT"];
  const ROW = { BTCUSDT: 10, ETHUSDT: 0.5, XAUUSDT: 0.5, XAGUSDT: 0.01 };
  const FLOOR = { BTCUSDT: 150000, ETHUSDT: 60000, XAUUSDT: 25000, XAGUSDT: 10000 };
  const KEEP = 3 * 86400, BSLOT = 60, API = "https://fapi.binance.com/fapi/v1/";
  const MOB = /Android|iPhone|iPad/i.test(navigator.userAgent) || !!window.Capacitor;
  const D = {};
  SY.forEach((s) => (D[s] = { min: new Map(), big: [], liq: [], book: new Map(), bcur: null, snap: null, nt: [], thr: 0, n: 0, px: 0, dirty: new Set(), kl: {}, klAt: {}, cache: null }));
  const F = { ver: 0, kver: 0, ws: null, wsOk: 0, ui: 0, cur: "BTCUSDT", paused: false, lastD: {}, busy: false, since: 0 };
  const rk = (s, p) => Math.round(p / ROW[s]);
  const hr = (t) => t - (t % 3600);

  function onTrade(s, p, q, sell, T) {
    const d = D[s], t = Math.floor(T / 1000), m = t - (t % 60);
    let b = d.min.get(m); if (!b) { b = { r: new Map(), B: 0, S: 0, n: 0 }; d.min.set(m, b); }
    const k = rk(s, p); let c = b.r.get(k); if (!c) b.r.set(k, (c = [0, 0]));
    if (sell) { c[1] += q; b.S += q; } else { c[0] += q; b.B += q; }
    b.n++; d.px = p; d.dirty.add(hr(m));
    const usd = p * q; d.n++; d.nt.push(usd); if (d.nt.length > 5000) d.nt.splice(0, 1000);
    if (d.n % 400 === 0 && d.nt.length > 800) { const a = d.nt.slice().sort((x, y) => x - y); d.thr = Math.max(FLOOR[s], a[Math.floor(a.length * 0.997)]); }
    if (usd >= (d.thr || FLOOR[s] * 2)) { d.big.push({ t: T / 1000, p, q, usd, side: sell ? -1 : 1 }); F.ver++; }
  }
  function connect() {
    if (F.ws || F.paused) return;
    const st = SY.map((s) => s.toLowerCase() + "@aggTrade").concat(["!forceOrder@arr"]).join("/");
    const urls = ["wss://fstream.binance.com/market/stream?streams=" + st, "wss://fstream.binance.com/stream?streams=" + st];
    let ws, got = false;
    try { ws = new WebSocket(urls[F.ui++ % urls.length]); } catch (e) { setTimeout(connect, 5000); return; }
    F.ws = ws;
    ws.onmessage = (e) => {
      got = true; F.wsOk = Date.now();
      let m; try { m = JSON.parse(e.data); } catch (er) { return; }
      const d = m.data; if (!d) return;
      if (d.e === "aggTrade") { if (D[d.s]) onTrade(d.s, +d.p, +d.q, !!d.m, d.T); }
      else if (d.e === "forceOrder") { const o = d.o; if (o && D[o.s]) { const q = +(o.z || o.q), p = +(o.ap || o.p); D[o.s].liq.push({ t: d.E / 1000, p, q, usd: p * q, side: o.S === "SELL" ? -1 : 1 }); D[o.s].dirty.add(hr(Math.floor(d.E / 1000))); F.ver++; } }
    };
    ws.onclose = () => { if (F.ws === ws) F.ws = null; if (!F.paused) setTimeout(connect, 3000); };
    ws.onerror = () => { try { ws.close(); } catch (e) { /* */ } };
    setTimeout(() => { if (!got && F.ws === ws) ws.close(); }, 15000);
    if (!F.since) F.since = Date.now() / 1000;
  }
  function pack(m) {
    let lo = Infinity, hi = -Infinity; m.forEach((v, k) => { if (k < lo) lo = k; if (k > hi) hi = k; });
    if (lo > hi) return null; const v = new Float32Array(hi - lo + 1); m.forEach((x, k) => (v[k - lo] = x)); return { r0: lo, v };
  }
  async function depth(s, lim) {
    try {
      const j = await (await fetch(`${API}depth?symbol=${s}&limit=${lim}`)).json(); if (!j.bids) return;
      const d = D[s], t = Math.floor(Date.now() / 1000), sl = t - (t % BSLOT), m = new Map();
      j.bids.forEach(([p, q]) => { const k = rk(s, +p); m.set(k, (m.get(k) || 0) + p * q); });
      j.asks.forEach(([p, q]) => { const k = rk(s, +p); m.set(k, (m.get(k) || 0) - p * q); });
      if (d.bcur && d.bcur.sl !== sl) { const pk = pack(d.bcur.m); if (pk) { d.book.set(d.bcur.sl, pk); d.dirty.add(hr(d.bcur.sl)); } d.bcur = null; }
      if (!d.bcur) d.bcur = { sl, m };
      else m.forEach((v, k) => { const o = d.bcur.m.get(k); if (o === undefined || Math.abs(v) > Math.abs(o)) d.bcur.m.set(k, v); });
      d.snap = { t, bids: j.bids.map(([p, q]) => [+p, p * q]), asks: j.asks.map(([p, q]) => [+p, p * q]) };
      if (!d.px) d.px = (+j.bids[0][0] + +j.asks[0][0]) / 2;
      F.ver++;
    } catch (e) { /* ağ yok: sonraki turda */ }
  }
  setInterval(() => {
    if (F.paused || document.hidden && MOB) return; const now = Date.now();
    SY.forEach((s) => { const cur = s === F.cur, iv = cur ? 3000 : 20000; if (!cur && MOB) return; if (now - (F.lastD[s] || 0) < iv) return; F.lastD[s] = now; depth(s, cur ? 1000 : 500); });
  }, 1000);

  /* geçmiş: kaydın olmadığı dönemler için Binance mumlarının gerçek taker alış hacmi */
  async function hist(s, sub, t0) {
    const key = sub, now = Date.now(); if (now - (D[s].klAt[key] || 0) < 60000) return; D[s].klAt[key] = now;
    try {
      const j = await (await fetch(`${API}klines?symbol=${s}&interval=${sub}&startTime=${Math.floor(t0) * 1000}&limit=1500`)).json(); if (!Array.isArray(j)) return;
      const m = D[s].kl[key] = D[s].kl[key] || new Map();
      j.forEach((k) => { const v = +k[5], b = +k[9]; m.set(k[0] / 1000, { h: +k[2], l: +k[3], B: b, S: v - b }); });
      F.kver++; D[s].cache = null;
    } catch (e) { /* */ }
  }
  const SUB = (stp) => stp <= 3600 ? ["1m", 60] : stp <= 14400 ? ["15m", 900] : ["1h", 3600];

  /* mum dilimi (stp sn) başına satırlar: live = kendi kaydımız (tam dakika kapsamı ≥ %90), değilse mum geçmişi (≈) */
  function buckets(s, stp, t0) {
    const d = D[s]; if (!d) return null; const [sub, ss] = SUB(stp); hist(s, sub, Math.max(t0, Date.now() / 1000 - 1500 * ss));
    const nowT = Date.now() / 1000, key = s + stp + ":" + F.kver;
    if (!d.cache || d.cache.key !== key) d.cache = { key, done: new Map() };
    const out = new Map(), kl = d.kl[sub];
    const add = (bt) => {
      if (d.cache.done.has(bt)) return d.cache.done.get(bt);
      const r = new Map(); let B = 0, S = 0, lm = 0, n = 0;
      const end = Math.min(bt + stp, nowT), need = Math.max(1, Math.ceil((end - bt) / 60));
      for (let m = bt; m < bt + stp; m += 60) { const b = d.min.get(m); if (b) { lm++; n += b.n; } }
      const live = lm >= need * 0.9 && lm > 0;
      if (live) { for (let m = bt; m < bt + stp; m += 60) { const b = d.min.get(m); if (!b) continue; B += b.B; S += b.S; b.r.forEach((c, k) => { const o = r.get(k); if (o) { o[0] += c[0]; o[1] += c[1]; } else r.set(k, [c[0], c[1]]); }); } }
      else if (kl) {
        let any = false;
        for (let t = bt; t < bt + stp; t += ss) { const k = kl.get(t); if (!k) continue; any = true; B += k.B; S += k.S; const k0 = rk(s, k.l), k1 = rk(s, k.h), nk = k1 - k0 + 1; for (let q = k0; q <= k1; q++) { const o = r.get(q) || [0, 0]; o[0] += k.B / nk; o[1] += k.S / nk; r.set(q, o); } }
        if (!any) return null;
      } else return null;
      const res = { r, B, S, live, n };
      if (bt + stp < nowT - 90 && (live || !kl || kl.has(bt + stp - ss))) d.cache.done.set(bt, res);
      return res;
    };
    for (let bt = Math.floor(t0 / stp) * stp; bt <= nowT; bt += stp) { const x = add(bt); if (x) out.set(bt, x); }
    return out;
  }
  function book(s) { const d = D[s]; if (!d) return []; const a = []; d.book.forEach((v, t) => a.push({ t, r0: v.r0, v: v.v })); if (d.bcur) { const pk = pack(d.bcur.m); if (pk) a.push({ t: d.bcur.sl, r0: pk.r0, v: pk.v }); } return a; }
  function flowSum(s, secs) {
    const d = D[s]; if (!d) return null; const t1 = Date.now() / 1000, t0 = t1 - secs; let B = 0, S = 0, mins = 0, wb = 0, ws = 0, lb = 0, ls = 0;
    d.min.forEach((b, m) => { if (m >= t0) { B += b.B; S += b.S; mins++; } });
    d.big.forEach((e) => { if (e.t >= t0) { if (e.side > 0) wb += e.usd; else ws += e.usd; } });
    d.liq.forEach((e) => { if (e.t >= t0) { if (e.side < 0) lb += e.usd; else ls += e.usd; } });
    return { B, S, mins, cover: mins / (secs / 60), wb, ws, longLiq: lb, shortLiq: ls };
  }

  /* kalıcılık: IndexedDB, saat parçaları "SYM|saat" */
  let db = null;
  function idb() { return new Promise((res) => { try { const q = indexedDB.open("nera_flow", 1); q.onupgradeneeded = () => q.result.createObjectStore("c"); q.onsuccess = () => res(q.result); q.onerror = () => res(null); } catch (e) { res(null); } }); }
  function chunk(s, h) {
    const d = D[s], mins = [], bk = [];
    d.min.forEach((b, m) => { if (m >= h && m < h + 3600) { const a = []; b.r.forEach((c, k) => a.push(k, c[0], c[1])); mins.push([m, b.B, b.S, b.n, a]); } });
    d.book.forEach((v, t) => { if (t >= h && t < h + 3600) bk.push([t, v.r0, v.v]); });
    return { s, h, mins, bk, big: d.big.filter((e) => e.t >= h && e.t < h + 3600), liq: d.liq.filter((e) => e.t >= h && e.t < h + 3600) };
  }
  function prune() {
    const lim = Date.now() / 1000 - KEEP;
    SY.forEach((s) => { const d = D[s]; d.min.forEach((b, m) => { if (m < lim) d.min.delete(m); }); d.book.forEach((v, t) => { if (t < lim) d.book.delete(t); }); d.big = d.big.filter((e) => e.t >= lim); d.liq = d.liq.filter((e) => e.t >= lim); });
  }
  function save() {
    if (!db) return; prune();
    try {
      const tx = db.transaction("c", "readwrite"), st = tx.objectStore("c"), lim = hr(Math.floor(Date.now() / 1000 - KEEP));
      SY.forEach((s) => { D[s].dirty.forEach((h) => st.put(chunk(s, h), s + "|" + h)); D[s].dirty.clear(); });
      const cq = st.openCursor(); cq.onsuccess = () => { const c = cq.result; if (!c) return; const h = +String(c.key).split("|")[1]; if (h < lim) c.delete(); c.continue(); };
    } catch (e) { /* */ }
  }
  function load() {
    return new Promise((res) => {
      if (!db) return res();
      try {
        const lim = Date.now() / 1000 - KEEP, q = db.transaction("c").objectStore("c").openCursor();
        q.onsuccess = () => {
          const c = q.result; if (!c) { F.ver++; return res(); }
          const v = c.value, d = D[v.s];
          if (d && v.h >= lim - 3600) {
            v.mins.forEach(([m, B, S, n, a]) => { if (d.min.has(m)) return; const r = new Map(); for (let i = 0; i < a.length; i += 3) r.set(a[i], [a[i + 1], a[i + 2]]); d.min.set(m, { r, B, S, n }); });
            v.bk.forEach(([t, r0, vv]) => { if (!d.book.has(t)) d.book.set(t, { r0, v: vv instanceof Float32Array ? vv : Float32Array.from(vv) }); });
            const seen = new Set(d.big.map((e) => e.t + "|" + e.p)); v.big.forEach((e) => { if (!seen.has(e.t + "|" + e.p)) d.big.push(e); });
            const sl = new Set(d.liq.map((e) => e.t + "|" + e.p)); v.liq.forEach((e) => { if (!sl.has(e.t + "|" + e.p)) d.liq.push(e); });
          }
          c.continue();
        };
        q.onerror = () => res();
      } catch (e) { res(); }
    });
  }
  idb().then((x) => { db = x; return load(); }).then(() => { SY.forEach((s) => { D[s].big.sort((a, b) => a.t - b.t); D[s].liq.sort((a, b) => a.t - b.t); D[s].cache = null; }); });
  setInterval(save, 60000);
  window.addEventListener("pagehide", save);
  document.addEventListener("visibilitychange", () => {
    if (!MOB) return;
    if (document.hidden) { save(); F.paused = true; if (F.ws) { const w = F.ws; F.ws = null; try { w.close(); } catch (e) { /* */ } } }
    else { F.paused = false; connect(); }
  });
  connect();

  window.NeraFlow = {
    ROW, has: (s) => !!D[s], focus: (s) => { if (D[s]) F.cur = s; },
    ver: () => F.ver + ":" + F.kver, ok: () => Date.now() - F.wsOk < 15000,
    snap: (s) => (D[s] ? D[s].snap : null), last: (s) => (D[s] ? D[s].px : 0),
    big: (s) => (D[s] ? D[s].big : []), liq: (s) => (D[s] ? D[s].liq : []), thr: (s) => (D[s] ? D[s].thr || FLOOR[s] * 2 : 0),
    book, buckets, sum: flowSum, rowP: (s, k) => k * ROW[s], rowK: rk,
    since: (s) => { const d = D[s]; let m = Infinity; if (d) d.min.forEach((b, t) => { if (t < m) m = t; }); return m === Infinity ? null : m; },
  };
})();
