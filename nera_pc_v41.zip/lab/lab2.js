﻿"use strict";
/* Sinir Ağı · Ajan Ofisi · Backtest Stüdyosu · Bilgi Bankası. lab.js'den sonra yüklenir. */
(function () {
const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
const f1 = (x, d = 2) => (x == null || !isFinite(x) ? "—" : Number(x).toFixed(d)), pc = (x, d = 0) => (x == null || !isFinite(x) ? "—" : (x * 100).toFixed(d) + "%"), nf = (x) => Number(x || 0).toLocaleString("tr-TR");
const esc = (s) => String(s).replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c]));
const rgb = (hex, a) => { const n = parseInt(hex.slice(1), 16); return `rgba(${n >> 16},${(n >> 8) & 255},${n & 255},${a})`; };
const opt = (a, v) => a.map((x) => `<option value="${Array.isArray(x) ? x[0] : x}" ${String(Array.isArray(x) ? x[0] : x) === String(v) ? "selected" : ""}>${Array.isArray(x) ? x[1] : x}</option>`).join("");
const fit = (cv, w, h) => Lab.fitCanvas(cv, w, h);
const visible = (id) => Lab.view() === id;

/* ================================================================ AJAN OFİSİ */
const AGS = [
  ["veri", "Veri Mühendisi", "DESTEK", "#8a7bff", "book", 0], ["haber", "Haber Analisti", "DESTEK", "#4dd0e1", "scope", 0], ["kasif", "Kâşif", "ADIM 1 · ARAŞTIRMA", "#ffb04a", "scope", 1], ["fikir", "Fikir Üretici", "ADIM 2 · STRATEJİ", "#35e0c4", "bolt", 2], ["test", "Test Mühendisi", "ADIM 3 · BACKTEST", "#4dd0e1", "glasses", 3], ["supheci", "Şüpheci Denetçi", "ADIM 4 · DENETİM", "#f2566a", "scope", 4],
  ["risk", "Risk Müdürü", "ADIM 5 · RİSK KAPISI", "#ff9800", "visor", 5], ["boga", "Boğa Savunucusu", "ADIM 6 · TARTIŞMA", "#26c6a0", "tie", 6], ["ayi", "Ayı Savunucusu", "ADIM 7 · TARTIŞMA", "#ff7a59", "tie", 7], ["pm", "Portföy Müdürü", "ADIM 8 · KARAR", "#ffd54a", "tie", 8], ["nn", "Sinir Ağı Eğitmeni", "DESTEK", "#b085ff", "bolt", 0], ["bt", "Backtest Gözcüsü", "DESTEK", "#7dd3fc", "glasses", 0],
];
const EDGES = [["veri", "kasif"], ["kasif", "fikir"], ["fikir", "test"], ["test", "supheci"], ["supheci", "risk"], ["risk", "boga"], ["risk", "ayi"], ["boga", "pm"], ["ayi", "pm"], ["haber", "risk"], ["nn", "test"], ["bt", "pm"], ["veri", "nn"], ["haber", "kasif"]];
const STG = { kasif: "Kâşif", fikir: "Fikir", test: "Test", supheci: "Denetim", risk: "Risk", boga: "Boğa", ayi: "Ayı", pm: "Karar" };
const avatar = (col, acc) => `<svg class="avatar" viewBox="0 0 42 46"><circle cx="21" cy="5" r="2.4" fill="${col}"/><path d="M21 7.4v5" stroke="${col}" stroke-width="1.2"/><rect x="10" y="13" width="22" height="19" rx="9" fill="${col}" opacity=".22" stroke="${col}" stroke-width="1.3"/><circle cx="16.5" cy="22" r="2.1" fill="#fff"/><circle cx="25.5" cy="22" r="2.1" fill="#fff"/><path d="M17 27.5q4 3 8 0" stroke="#fff" stroke-width="1.2" fill="none" stroke-linecap="round"/>
  ${acc === "glasses" ? `<g stroke="#fff" stroke-width="1" fill="none"><circle cx="16.5" cy="22" r="4"/><circle cx="25.5" cy="22" r="4"/><path d="M20.5 22h1"/></g>` : acc === "visor" ? `<path d="M9 17h24" stroke="${col}" stroke-width="3" stroke-linecap="round"/>` : acc === "tie" ? `<path d="M21 33l-3 3 3 8 3-8z" fill="${col}"/>` : acc === "scope" ? `<g stroke="${col}" stroke-width="1.5" fill="none"><circle cx="34" cy="14" r="3.2"/><path d="M36.4 16.4l3 3"/></g>` : acc === "book" ? `<rect x="3" y="30" width="9" height="7" rx="1" fill="${col}" opacity=".6"/>` : `<path d="M31 9l-4 6h3l-2 5 5-7h-3z" fill="${col}"/>`}
  <rect class="arm a" x="6" y="34" width="9" height="4" rx="2" fill="${col}" opacity=".7"/><rect class="arm b" x="27" y="34" width="9" height="4" rx="2" fill="${col}" opacity=".7"/></svg>`;
const Office = window.Office = { ag: {}, ng: null, q: [], busy: false, lastCase: 0, cur: null, init() {
    AGS.forEach(([id, nm, rl, col, acc, step]) => (this.ag[id] = { id, nm, rl, col, acc, step, text: "Bekliyorum.", until: 0, cnt: 0, fin: 0 }));
    $("#pg-office").innerHTML = `<div class="eyebrow">Beyin · ajanlar çalışırken</div><h1>Ajan Ofisi</h1><p class="lead">Kâşif → Fikir → Test → Denetim → Risk → Boğa/Ayı → Karar.</p>
    <div class="panel"><div class="ph">Sinyal beyni <small>ajanlar + yapay zekâ</small><div class="sp"><button class="btn" id="cn-run">Şimdi toplan</button></div></div><div id="council"><canvas></canvas><div class="cdec"><div class="big">BEKLE</div><div class="sub">—</div></div><div class="csym" id="cn-sym"></div><div class="ctalk" id="cn-talk"></div></div></div>
    <div class="panel"><div class="ph">Ofis katı <small>çalışan ajanın çerçevesi parlar</small><div class="sp"><span class="chip vio" id="of-stat">bekliyor</span></div></div><div class="ofcase" id="of-case"><span class="muted">Yeni bir tarif gelince iş akışı burada izlenir.</span></div><div id="of-wrap"><canvas id="of-cv"></canvas><div class="floor">${AGS.map(([id]) => { const a = this.ag[id]; return `<div class="ag" id="ag-${id}" style="--ac:${a.col}">${a.step ? `<span class="step">${a.step}</span>` : ""}<span class="st" id="agst-${id}">BEKLİYOR</span><div class="hd">${avatar(a.col, a.acc)}<div><div class="nm">${a.nm}</div><div class="rl">${a.rl}</div></div></div><div class="bub" id="agb-${id}">${a.text}</div><div class="cnt"><span>görev</span><b id="agc-${id}">0</b></div></div>`; }).join("")}</div></div></div>
    <div class="panel"><div class="ph">Piyasa ajanları <small id="of-mkt-t">canlı oylar</small></div><div id="of-mg" style="position:relative;height:120px"><canvas id="of-mgc"></canvas></div><div class="mkt" id="of-mkt"></div></div>
    <div class="panel"><div class="ph">Toplantı odası <small>son aday için boğa / ayı tartışması</small></div><div class="pb" id="of-deb"><div class="muted">Laboratuvar bir aday bulunca ajanlar burada tartışır.</div></div></div>`;
    { const ids = ["m0", "m1", "m2", "m3", "m4", "m5", "m6", "m7"], nd = ids.map((id, i) => ({ id, x: (i + 0.5) / 8, y: 0.2, r: 4.5, col: "#8a7bff" })).concat([{ id: "hub", x: 0.5, y: 0.8, r: 8, col: "#ffb04a", label: "koordinatör" }]); this.mg = new NeuroGraph($("#of-mgc"), nd, ids.map((i) => [i, "hub"]), { idle: false, curve: 0, labels: true }); }
    const nodes = AGS.map(([id, , , col]) => ({ id, col, r: 5 })); this.ng = new NeuroGraph($("#of-cv"), nodes, EDGES, { idle: false, curve: 14, labels: false, dur: 0.95, pre: () => {
      const wrap = $("#of-wrap"), wr = wrap.getBoundingClientRect(); this.ng.N.forEach((n) => { const e = $("#ag-" + n.id); if (!e) return; const r = e.getBoundingClientRect(); n.px = r.left - wr.left + r.width / 2; n.py = r.top - wr.top + 2; }); } });
    setInterval(() => this.pump(), 500);
  },
  mkt(ev) {
    if (!ev || !ev.agents) return; const t = $("#of-mkt-t"); if (t) t.textContent = `${(window.__S ? __S().sym : "")} ${(window.__S ? __S().tf : "")} · skor ${ev.score >= 0 ? "+" : ""}${ev.score.toFixed(2)} · durum ${ev.state}`;
    const h = ev.agents.map((a) => { const v = a.name === "Risk" ? 0 : a.vote, w = Math.abs(v) * 50, col = v >= 0 ? "#26c6a0" : "#f2566a"; return `<div class="mk"><div class="h"><span>${a.icon} ${a.name === "Risk" ? "Risk müdürü" : a.name}</span><span class="${a.name === "Risk" ? "nc" : v >= 0 ? "na" : "down"}">${a.name === "Risk" ? a.label : (v >= 0 ? "+" : "") + v.toFixed(2)}</span></div><div class="vb"><i style="left:${v >= 0 ? 50 : 50 - w}%;width:${w}%;background:${col}"></i></div><div class="muted">${esc((a.why && a.why[0]) || "")}</div></div>`; }).join(""); const el = $("#of-mkt"); if (el && el._h !== h) { el._h = h; el.innerHTML = h; }
    if (this.mg && this._seen !== ev) { this._seen = ev; let k = 0; ev.agents.forEach((a, i) => { const col = a.name === "Risk" ? "#ff9800" : a.vote > 0.05 ? "#26c6a0" : a.vote < -0.05 ? "#f2566a" : "#8c96af", n = this.mg.byId["m" + i]; if (n) { n.label = a.name === "Risk" ? "Risk" : a.name.split(" ")[0].slice(0, 8); setTimeout(() => this.mg.fire("m" + i, col, 0.4 + Math.abs(a.vote), 0, "hub"), k * 110); k++; } }); setTimeout(() => this.mg.fire("hub", ev.score > 0.15 ? "#26c6a0" : ev.score < -0.15 ? "#f2566a" : "#ffb04a", 1, 0), k * 110 + 650); }
  },
  act(id, text, ms = 1500) { const a = this.ag[id]; if (!a) return; a.text = text; a.until = Date.now() + ms; a.fin = a.until; a.cnt++; a.flash = 1; if (this.ng && visible("office")) { const col = a.col; this.ng.fire(id, col, 0.9, 0); } },
  upd() { if (!visible("office")) return; const now = Date.now(); let n = 0; for (const id in this.ag) { const a = this.ag[id], w = a.until > now; if (w) n++; const el = $("#ag-" + id); if (!el) continue; el.classList.toggle("work", w); el.classList.toggle("done", !w && now - a.fin < 2200 && a.cnt > 0); const s = $("#agst-" + id), b = $("#agb-" + id), c = $("#agc-" + id); const st = w ? "ÇALIŞIYOR" : now - a.fin < 2200 && a.cnt > 0 ? "TAMAM ✓" : "BEKLİYOR"; if (s.textContent !== st) s.textContent = st; if (b.textContent !== a.text) { b.textContent = a.text; b.classList.remove("flash"); void b.offsetWidth; b.classList.add("flash"); } if (c.textContent !== String(a.cnt)) c.textContent = a.cnt; } const e = $("#of-stat"); if (e) e.textContent = this.busy ? "dosya inceleniyor" : n ? `${n} ajan çalışıyor` : "bekliyor"; },
  debate(r) {
    const o = r.oos, i = r.is, mc = r.mc, thr = r.dsr ? r.dsr.thr : null, days = o.days, kept = r.status === "kept";
    const bull = [`OOS'ta ${o.n} işlem: ort. ${f1(o.avgR)}R, PF ${f1(o.pf)}, kazanma %${(o.win * 100).toFixed(0)}`, `Sharpe IS ${f1(i.sh)} → OOS ${f1(o.sh)}: ${o.sh >= i.sh * 0.5 ? "büyük kısmı korundu" : "düştü ama pozitif"}`, `Dayanıklılık: ${Math.round((r.rob || 0) * 5)}/5 komşu parametre kârlı`, mc ? `Monte Carlo medyan getiri %${(mc.p50 * 100).toFixed(1)}` : "Monte Carlo için işlem az"];
    const bear = [thr != null ? `${Lab.cnt.passIS} OOS denemesinden seçildi: şans sınırı Sharpe ${f1(thr)}, bu strateji ${f1(o.sh)}${o.sh >= thr ? " (geçti)" : " (geçemedi)"}` : "", `OOS yalnızca ${days} gün ve ${o.n} işlem: güven aralığı geniş`, `OOS maks. düşüş %${(o.dd * 100).toFixed(0)}${mc ? ` · MC: %${(mc.pDD25 * 100).toFixed(0)} ihtimalle >%25 düşüş` : ""}`, `Komisyon+kayma ${Lab.cfg.fee + Lab.cfg.slip} bps/yön: rejim değişirse kenar kaybolur`].filter(Boolean);
    this.act("boga", bull[0], 2600); this.act("ayi", bear[0], 2600);
    $("#of-deb").innerHTML = `<div class="eyebrow" style="margin-bottom:8px">${esc(r.name)}</div><div class="debate"><div class="deb bull"><h5>BOĞA SAVUNUCUSU</h5><ul>${bull.map((x) => `<li>${esc(x)}</li>`).join("")}</ul></div><div class="deb bear"><h5>AYI SAVUNUCUSU</h5><ul>${bear.map((x) => `<li>${esc(x)}</li>`).join("")}</ul></div></div>
      <div class="verdict"><b class="${kept ? "na" : "nc"}">Portföy Müdürü kararı: ${kept ? "DEFTERE ALINDI (izleme)" : "ADAY olarak izlemede"}</b><br>${esc(r.reason)}. ${r.risk ? "Risk kapısı: " + esc(r.risk.why) + "." : ""} <span class="muted">Bu bir emir değildir; gerçek parayla kullanma kararı yalnız sana aittir.</span></div><div class="verdict" id="of-llm" style="display:none"></div>`;
    if (Lab.keys && Lab.keys.llm && Date.now() - (this._lt || 0) > 60000) { this._lt = Date.now(); const q = `Sen deneyimli bir piyasa analistisin. Aşağıdaki backtest sonucuna göre iki ayrı kısa paragraf yaz (Türkçe, toplam en çok 110 kelime): "BOĞA:" (stratejiyi savunan) ve "AYI:" (şüpheci, aşırı uyum ve şans riskini vurgulayan). Rakam uydurma, yalnız verilenleri kullan. Strateji: ${r.name}. OOS: ${o.n} işlem, ort ${f1(o.avgR)}R, PF ${f1(o.pf)}, Sharpe ${f1(o.sh)}, maks düşüş %${(o.dd * 100).toFixed(0)}. IS Sharpe ${f1(i.sh)}. Şans sınırı ${thr != null ? f1(thr) : "?"}. Dayanıklılık ${Math.round((r.rob || 0) * 5)}/5. Haber duygusu: ${Lab.newsSum && Lab.newsSum[r.sym] ? Lab.newsSum[r.sym].score.toFixed(2) : "bilinmiyor"}.`;
      NAPI("/api/llm", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ prompt: q }) }).then((j) => { if (!j) return; const e = $("#of-llm"); if (e && j.text) { e.style.display = ""; e.innerHTML = "<b class=nb>Yapay zekâ yorumu (" + (j.prov || "LLM") + ")</b><br>" + esc(j.text).replace(/\n/g, "<br>"); this.act("boga", "Gemini ile tartıştık.", 2500); } }).catch(() => {}); }
  },
  onCand(r) {
    const good = r.status === "cand" || r.status === "kept";
    if (!visible("office")) { if (good) this.debate(r); return; }                 // ofis görünmüyorsa iş birikmesin
    if (good || r.status !== "rej-is" || (!this.busy && !this.q.length && Date.now() - this.lastCase > 5000 && Math.random() < 0.2)) { this.q.push(r); if (this.q.length > 2) this.q.shift(); }
  },
  pump() { if (this.busy || !this.q.length || !visible("office")) return; this.run(this.q.shift()); },
  async run(r) {
    this.busy = true; const g = r.g, src = Lab.meta && Lab.meta.rec[g.rec] ? Lab.meta.rec[g.rec] : { src: "?", tr: g.rec }, st = [], o = r.oos, i = r.is, add = (id, t) => st.push([id, t]);
    add("kasif", `Kaynak: ${src.src} → ${src.tr}`); add("fikir", `Tarif: ${src.tr}${g.side !== "both" ? " · " + (g.side === "long" ? "yalnız AL" : "yalnız SAT") : ""}`); add("test", `IS: ${i.n} işlem · ort ${f1(i.avgR)}R · PF ${f1(i.pf)}`);
    if (o) { add("test", `OOS: ${o.n} işlem · ort ${f1(o.avgR)}R · PF ${f1(o.pf)}`); if (r.status === "rej-oos") add("supheci", `Reddettim: Sharpe ${f1(i.sh)} → ${f1(o.sh)}. İyi görünen IS, şans olabilir.`); else { add("supheci", `Komşu parametre testi: ${Math.round((r.rob || 0) * 5)}/5 kârlı`); if (r.status !== "rej-rob") { add("supheci", `Şans sınırı ${f1(r.dsr.thr)} · bu strateji ${f1(r.dsr.sr)}`); add("risk", `Risk kapısı: ${r.risk.pass ? "PASS" : "BLOCK"} · ${r.risk.why}`); if (r.status === "cand" || r.status === "kept") { add("boga", `Savunma: OOS ${o.n} işlem, ort ${f1(o.avgR)}R`); add("ayi", `İtiraz: ${Lab.cnt.passIS} denemeden seçildi, şans payı var`); add("pm", r.status === "kept" ? "Kalıcı: deftere aldım (izleme)." : "Aday: izlemeye aldım."); } } } }
    else add("supheci", "Yetersiz: IS aşamasında elendi, OOS'a gitmedi.");
    const ids = []; st.forEach(([id]) => { if (!ids.includes(id)) ids.push(id); }); this.cur = { name: r.name, ids, done: [], now: null, status: r.status }; this.trk();
    let prev = null;
    for (const [id, txt] of st) { if (!visible("office")) break; this.cur.now = id; this.trk(); if (prev && prev !== id && this.ng) this.ng.fire(prev, this.ag[prev].col, 0.9, 0, id); this.act(id, txt, 1450); await new Promise((res) => setTimeout(res, 1350)); if (!this.cur.done.includes(id)) this.cur.done.push(id); prev = id; }
    this.cur.now = null; this.trk(); if (r.status === "cand" || r.status === "kept") this.debate(r); this.lastCase = Date.now(); this.busy = false;
  },
  trk() { const c = this.cur, el = $("#of-case"); if (!c || !el) return; const h = `<b style="font-size:12px;margin-right:6px">${esc(c.name).slice(0, 90)}</b>` + c.ids.map((id, k) => `<span class="stg ${c.done.includes(id) && c.now !== id ? "ok" : c.now === id ? "on" : ""}">${c.done.includes(id) && c.now !== id ? "✓" : c.now === id ? "●" : "○"} ${STG[id] || id}</span>`).join('<span class="muted">→</span>'); if (el._h !== h) { el._h = h; el.innerHTML = h; } },
};
DT.on("lab:cand", (r) => Office.onCand(r)); DT.on("ana", (j) => { if (j && j.eval) { Office.last = j.eval; if (Lab.view() === "office") Office.mkt(j.eval); } }); DT.on("view", (v) => { if (v === "office" && Office.last) Office.mkt(Office.last); }); DT.on("lab:data", (m) => Office.act("veri", `${nf(m.n)} mum yüklendi: ${m.sym} ${m.tf}`, 2500));
DT.on("lab:meta", (m) => Office.act("kasif", `${Object.keys(m.rec).length} tarif + ${m.sess.length} seans filtresi yüklendi`, 2500));


/* ================================================================ BACKTEST STÜDYOSU (otonom) */
const LSb = { get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } }, set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* dolu */ } } };
const BT = { w: null, res: LSb.get("nera_bt", {}), q: [], busy: false, cur: null, loaded: "", pend: "", sel: null, ng: null, days: LSb.get("nera_bt_days", 180), cfg: Object.assign({ fee: 4, slip: 1, risk: 0.01, split: 0.65 }, LSb.get("nera_bt_cfg", {})), items: [], hash: "", err: "" };
const bkey = (r) => r.sym + "|" + r.tf + "|" + JSON.stringify(r.g);
const ds = (a, n) => { if (a.length <= n) return a; const o = []; for (let i = 0; i < n; i++) o.push(a[Math.floor(i * (a.length - 1) / (n - 1))]); return o; };
const cssv = (el, n) => getComputedStyle(el).getPropertyValue(n).trim() || "#7a8199";
function chart(cv, series, o) {
  const w = cv.parentElement.clientWidth, h = o.h || 200, c = fit(cv, w, h), all = series.flatMap((s) => s.pts); c.clearRect(0, 0, w, h); if (!all.length || w < 40) return;
  const t0 = Math.min(...all.map((p) => p[0])), t1 = Math.max(...all.map((p) => p[0])); let lo = Math.min(...all.map((p) => p[1])), hi = Math.max(...all.map((p) => p[1])); if (o.zero) { lo = Math.min(lo, 0); hi = Math.max(hi, 0); } const pad = (hi - lo) * 0.08 || 0.1; lo -= pad; hi += pad;
  const X = (t) => 44 + (t - t0) / (t1 - t0 || 1) * (w - 54), Y = (v) => h - 20 - (v - lo) / (hi - lo) * (h - 30), mu = cssv(cv, "--muted"), ln = cssv(cv, "--line");
  const draw = (p) => { c.clearRect(0, 0, w, h); c.font = "10px Consolas,monospace"; c.fillStyle = mu; c.strokeStyle = ln; c.lineWidth = 1; for (let i = 0; i <= 4; i++) { const v = lo + (hi - lo) * i / 4, y = Y(v); c.beginPath(); c.moveTo(44, y); c.lineTo(w - 6, y); c.stroke(); c.fillText(o.fmt ? o.fmt(v) : v.toFixed(2), 2, y + 3); }
    if (o.split && o.split > t0 && o.split < t1) { c.fillStyle = "rgba(138,123,255,.08)"; c.fillRect(X(o.split), 6, w - 6 - X(o.split), h - 26); c.strokeStyle = mu; c.setLineDash([4, 4]); c.beginPath(); c.moveTo(X(o.split), 6); c.lineTo(X(o.split), h - 20); c.stroke(); c.setLineDash([]); c.fillStyle = mu; c.fillText("OOS →", X(o.split) + 5, 18); }
    if (o.zero) { c.strokeStyle = mu; c.globalAlpha = 0.4; c.beginPath(); c.moveTo(44, Y(0)); c.lineTo(w - 6, Y(0)); c.stroke(); c.globalAlpha = 1; }
    c.save(); c.beginPath(); c.rect(0, 0, 44 + (w - 54) * p, h); c.clip();
    for (const s of series) { c.strokeStyle = s.col; c.lineWidth = s.lw || 1.6; c.beginPath(); s.pts.forEach((q, i) => { const x = X(q[0]); if (i) { if (s.step) c.lineTo(x, Y(s.pts[i - 1][1])); c.lineTo(x, Y(q[1])); } else c.moveTo(x, Y(q[1])); }); c.stroke(); if (s.fill) { c.lineTo(X(s.pts[s.pts.length - 1][0]), Y(0)); c.lineTo(X(s.pts[0][0]), Y(0)); c.fillStyle = s.fill; c.fill(); } }
    c.restore(); c.fillStyle = mu; for (let i = 0; i <= 4; i++) { const t = t0 + (t1 - t0) * i / 4; c.fillText(new Date(t).toLocaleDateString("tr-TR", { day: "2-digit", month: "2-digit" }), X(t) - 14, h - 5); } };
  const st = performance.now(); (function step() { const p = Math.min(1, (performance.now() - st) / 1000); draw(1 - Math.pow(1 - p, 3)); if (p < 1 && cv.isConnected) requestAnimationFrame(step); })();
}
function buildBT() {
  $("#pg-bt").innerHTML = `<div class="eyebrow">Laboratuvar · geçmişte sınama</div><h1>Backtest Stüdyosu</h1>
  <p class="lead">Defterdeki stratejiler ${BT.days} günde otomatik test edilir (komisyon+kayma dahil). Sonuç geleceği garanti etmez.</p>
  <div class="panel bt-engp"><div class="ph">Backtest motoru <small id="bt-now">bekliyor</small></div><div id="bt-net" class="bt-eng"><canvas></canvas><div class="bt-eng-l"><b>VERİ GİRİŞİ</b><span>Binance geçmiş mumları</span></div><div class="bt-eng-r"><b>SONUÇ</b><span>özkaynak eğrisi · tıkla: ayrıntı</span></div></div></div>
  <div class="kpis" id="bt-kpis"></div>
  <div class="panel"><div class="ph">Sıralama <small>OOS Sharpe'a göre · satıra tıkla</small></div><div style="overflow:auto"><table class="tbl" id="bt-tbl"><thead><tr><th>Strateji</th><th>Piyasa</th><th>Özkaynak</th><th>Getiri</th><th>Maks düşüş</th><th>OOS Sharpe</th><th>PF</th><th>İşlem</th><th>Haber</th><th>Durum</th></tr></thead><tbody id="bt-body"></tbody></table></div></div>
  <div id="bt-det"></div>
  <details class="panel"><summary class="ph" style="cursor:pointer">Backtest ayarları</summary><div class="pb ctl"><label class="fld">Geçmiş (gün)<select id="bt-days">${[90, 180, 365].map((d) => `<option ${d === BT.days ? "selected" : ""}>${d}</option>`).join("")}</select></label>
    <label class="fld">Komisyon bps<input id="bt-fee" type="number" step="0.5" value="${BT.cfg.fee}" style="width:80px"></label><label class="fld">Kayma bps<input id="bt-slip" type="number" step="0.5" value="${BT.cfg.slip}" style="width:80px"></label><label class="fld">Risk %<input id="bt-risk" type="number" step="0.25" value="${BT.cfg.risk * 100}" style="width:80px"></label>
    <button class="btn pri" id="bt-redo">Hepsini yeniden hesapla</button></div></details>`;
  $("#bt-redo").onclick = () => { BT.days = +$("#bt-days").value; BT.cfg.fee = +$("#bt-fee").value; BT.cfg.slip = +$("#bt-slip").value; BT.cfg.risk = Math.max(0.001, +$("#bt-risk").value / 100); LSb.set("nera_bt_days", BT.days); LSb.set("nera_bt_cfg", BT.cfg); BT.res = {}; LSb.set("nera_bt", {}); BT.q = []; BT.loaded = ""; BT.hash = ""; btFill(); };
  $("#bt-net canvas").onclick = (e) => { const r = e.target.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top; let best = null, bd = 20; for (const p of BTE.pos) { const d = Math.hypot(p.x - x, p.y - y); if (d < bd) { bd = d; best = p.k; } } if (best) { BT.sel = best; btDetail(); BT.hash = ""; updBT(); } };
  $("#bt-net canvas").onmousemove = (e) => { const r = e.target.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top; BTE.hov = null; for (const p of BTE.pos) if (Math.hypot(p.x - x, p.y - y) < 16) BTE.hov = p.k; e.target.style.cursor = BTE.hov ? "pointer" : "default"; };
}
/* Backtest motoru: soldan veri mumları akar, kuyruktaki stratejiler yörüngede sıra bekler, çekirdekte dişliler döner;
   test bitince şok dalgası çıkar, sonuç sağdaki yayda (yeşil kâr / turuncu zayıf / kırmızı zarar) yerini alır ve özkaynak eğrisi çizilir. */
const BTE = { parts: [], sparks: [], pos: [], ph: 0, burst: 0, flash: null, last: null, lastT: 0, hov: null, prog: 0 };
const tCode = (r) => (window.NeraStrat ? NeraStrat.info(r) : null);
function btEngine(dt, t) {
  const cv = $("#bt-net canvas"); if (!cv || !vis(cv)) return; const w = cv.parentElement.clientWidth, h = cv.parentElement.clientHeight || 300; if (w < 50) return; const c = fit(cv, w, h); c.clearRect(0, 0, w, h);
  const mob = w < 640, cx = mob ? w * 0.5 : w * 0.43, cy = h * 0.5, R = Math.min(mob ? w * 0.2 : w * 0.11, h * 0.3), busy = BT.busy; BTE.ph += dt * (busy ? 1.7 : 0.3); const ph = BTE.ph; BTE.prog = busy ? Math.min(0.96, BTE.prog + dt * 0.35 * (1 - BTE.prog)) : 0;
  const A = getComputedStyle(document.body).getPropertyValue("--na").trim() || "#35e0c4", B = getComputedStyle(document.body).getPropertyValue("--nb").trim() || "#8a7bff", rg = (hx, a) => rgba(hx, a);
  c.strokeStyle = rg(B, 0.06); c.lineWidth = 1; for (let x = (-(t * 18) % 28); x < w; x += 28) { c.beginPath(); c.moveTo(x, 0); c.lineTo(x, h); c.stroke(); } for (let y = 14; y < h; y += 28) { c.beginPath(); c.moveTo(0, y); c.lineTo(w, y); c.stroke(); }
  // veri girişi: mum parçacıkları
  if (!mob) { if (busy && Math.random() < dt * 22) BTE.parts.push({ u: 0, y: (Math.random() - 0.5) * h * 0.55, up: Math.random() < 0.5, hgt: 4 + Math.random() * 10, v: 0.5 + Math.random() * 0.5 }); else if (!busy && Math.random() < dt * 1.5) BTE.parts.push({ u: 0, y: (Math.random() - 0.5) * h * 0.55, up: Math.random() < 0.5, hgt: 3 + Math.random() * 6, v: 0.25 }); }
  for (let i = BTE.parts.length - 1; i >= 0; i--) { const p = BTE.parts[i]; p.u += dt * p.v * (busy ? 0.9 : 0.4); if (p.u >= 1) { BTE.parts.splice(i, 1); continue; } const x0 = 24, x1 = cx - R * 1.25, e = p.u * p.u * (3 - 2 * p.u), x = x0 + (x1 - x0) * p.u, y = cy + p.y * (1 - e), a = Math.sin(p.u * Math.PI); c.fillStyle = p.up ? rg("#26c6a0", 0.7 * a) : rg("#f2566a", 0.7 * a); c.fillRect(x - 2, y - p.hgt / 2, 4, p.hgt); c.fillRect(x - 0.5, y - p.hgt / 2 - 3, 1, p.hgt + 6); }
  // kuyruk yörüngesi
  const q = BT.q.slice(0, 10); q.forEach((it, i) => { const a = -Math.PI / 2 - 0.5 - i * 0.32 + Math.sin(ph * 0.5) * 0.02, rr = R * 1.75, x = cx + Math.cos(a) * rr, y = cy + Math.sin(a) * rr * 0.92, tl = tCode(it), col = tl ? tl.col : B; c.fillStyle = rg(col, 0.85); c.beginPath(); c.roundRect ? c.roundRect(x - 13, y - 6, 26, 12, 6) : c.rect(x - 13, y - 6, 26, 12); c.fill(); c.fillStyle = "#0b0e16"; c.font = "700 8px Consolas,monospace"; c.textAlign = "center"; c.fillText(tl ? tl.code.split("-")[0].slice(0, 4) : "#" + i, x, y + 3); });
  if (q.length) { c.fillStyle = rg(B, 0.7); c.font = "9px Consolas,monospace"; c.textAlign = "center"; c.fillText(`KUYRUK · ${BT.q.length}`, cx - R * 1.2, cy - R * 1.95); }
  // çekirdek: dişliler
  const gear = (r, n, rot, col, al, tooth) => { c.save(); c.translate(cx, cy); c.rotate(rot); c.strokeStyle = rg(col, al); c.lineWidth = 1.4; c.beginPath(); for (let i = 0; i <= n * 2; i++) { const a = (i / (n * 2)) * 6.2832, rr = r + (i % 2 ? tooth : 0); i ? c.lineTo(Math.cos(a) * rr, Math.sin(a) * rr) : c.moveTo(Math.cos(a) * rr, Math.sin(a) * rr); } c.closePath(); c.stroke(); c.restore(); };
  const fl = BTE.flash, fk = fl ? Math.max(0, 1 - (t - fl.t) / 1.6) : 0, fc = fl ? fl.col : A;
  const glow = c.createRadialGradient(cx, cy, 0, cx, cy, R * 2.2); glow.addColorStop(0, rg(fk > 0 ? fc : B, 0.28 + 0.3 * fk + (busy ? 0.1 * Math.sin(t * 6) : 0))); glow.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = glow; c.fillRect(cx - R * 2.2, cy - R * 2.2, R * 4.4, R * 4.4);
  gear(R * 1.18, 28, ph * 0.35, B, 0.55, 4); gear(R * 0.92, 18, -ph * 0.6, A, 0.5, 3); c.setLineDash([3, 6]); c.strokeStyle = rg(A, 0.35); c.beginPath(); c.arc(cx, cy, R * 1.42, ph, ph + 6.2); c.stroke(); c.setLineDash([]);
  if (busy) { c.strokeStyle = rg(A, 0.95); c.lineWidth = 3; c.lineCap = "round"; c.beginPath(); c.arc(cx, cy, R * 1.42, -Math.PI / 2, -Math.PI / 2 + BTE.prog * 6.283); c.stroke(); c.lineWidth = 1; }
  const core = c.createRadialGradient(cx - R * 0.2, cy - R * 0.2, R * 0.05, cx, cy, R * 0.7); core.addColorStop(0, rg("#ffffff", 0.85)); core.addColorStop(0.35, rg(fk > 0 ? fc : busy ? A : B, 0.8)); core.addColorStop(1, rg(B, 0.12)); c.fillStyle = core; c.beginPath(); c.arc(cx, cy, R * (0.62 + 0.04 * Math.sin(t * (busy ? 7 : 2))), 0, 6.3); c.fill();
  for (let k = 0; k < 6; k++) { const a = ph * 1.3 + k * 1.047, x = cx + Math.cos(a) * R * 0.92, y = cy + Math.sin(a) * R * 0.92; c.fillStyle = rg(A, 0.8); c.beginPath(); c.arc(x, y, 2.2, 0, 6.3); c.fill(); }
  const cur = BT.busy && BT.cur ? tCode(BT.cur) : null; c.textAlign = "center"; c.fillStyle = "#0b0e16"; c.font = `700 ${Math.max(9, R * 0.2)}px Consolas,monospace`; c.fillText(cur ? cur.code : BT.q.length ? "SIRADA" : "BOŞTA", cx, cy - 2); c.font = `${Math.max(8, R * 0.14)}px Consolas,monospace`; c.fillStyle = "rgba(11,14,22,.75)"; c.fillText(busy ? `%${Math.round(BTE.prog * 100)} · ${BT.days}g` : fl ? fl.txt : "motor hazır", cx, cy + R * 0.22);
  // şok dalgası + kıvılcımlar
  if (fk > 0) { for (let k = 0; k < 2; k++) { const rr = R * (1 + (1 - fk) * (2.2 + k)), al = fk * (0.6 - k * 0.25); c.strokeStyle = rg(fc, al); c.lineWidth = 2; c.beginPath(); c.arc(cx, cy, rr, 0, 6.3); c.stroke(); } }
  for (let i = BTE.sparks.length - 1; i >= 0; i--) { const s = BTE.sparks[i]; if (s.rel) { s.x = cx; s.y = cy; s.rel = 0; } s.l -= dt; if (s.l <= 0) { BTE.sparks.splice(i, 1); continue; } s.x += s.vx * dt; s.y += s.vy * dt; s.vx *= 0.96; s.vy *= 0.96; c.fillStyle = rg(s.col, s.l); c.beginPath(); c.arc(s.x, s.y, 1.8, 0, 6.3); c.fill(); }
  if (busy && Math.random() < dt * 14) { const a = Math.random() * 6.283; BTE.sparks.push({ x: cx + Math.cos(a) * R * 0.65, y: cy + Math.sin(a) * R * 0.65, vx: Math.cos(a) * 60, vy: Math.sin(a) * 60, l: 0.7, col: Math.random() < 0.5 ? "#26c6a0" : "#f2566a" }); }
  // sonuç yayı (tamamlananlar)
  const rows = (BT.items || []).map((r) => ({ r, k: bkey(r), x: BT.res[bkey(r)] })).filter((o) => o.x && o.x.m); BTE.pos = [];
  const arcR = mob ? 0 : R * 2.05; rows.slice(0, 16).forEach((o, i, arr) => { const n = arr.length, a = mob ? 0 : -1.05 + (n > 1 ? (i / (n - 1)) * 2.1 : 1.05), x = mob ? 18 + (i + 0.5) * ((w - 36) / n) : cx + Math.cos(a) * arcR, y = mob ? h - 18 : cy + Math.sin(a) * arcR * 0.95, good = o.x.oos.avgR > 0.03 && o.x.oos.pf > 1.1, mid = o.x.oos.avgR > 0, col = good ? "#35e0c4" : mid ? "#ffb04a" : "#f2566a", sel = o.k === BT.sel || o.k === BTE.hov;
    c.strokeStyle = rg(col, 0.12 + (sel ? 0.4 : 0)); c.beginPath(); c.moveTo(cx + (x - cx) * 0.55, cy + (y - cy) * 0.55); c.lineTo(x, y); c.stroke(); const pr = (Math.sin(t * 2 + i) + 1) / 2, pu = (t * 0.6 + i * 0.13) % 1; c.fillStyle = rg(col, 0.6 * (1 - pu)); c.beginPath(); c.arc(cx + (x - cx) * (0.55 + 0.45 * pu), cy + (y - cy) * (0.55 + 0.45 * pu), 1.6, 0, 6.3); c.fill();
    const gg = c.createRadialGradient(x, y, 0, x, y, 14 + pr * 4); gg.addColorStop(0, rg(col, sel ? 0.6 : 0.35)); gg.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = gg; c.fillRect(x - 18, y - 18, 36, 36); c.fillStyle = col; c.beginPath(); c.arc(x, y, sel ? 6.5 : 4.5, 0, 6.3); c.fill(); if (sel) { c.strokeStyle = "#fff"; c.lineWidth = 1.2; c.beginPath(); c.arc(x, y, 9, 0, 6.3); c.stroke(); }
    BTE.pos.push({ x, y, k: o.k }); });
  // son sonucun özkaynak eğrisi (sağ panel)
  const L = BTE.last; if (L && !mob) { const bx = cx + R * 2.75, bw = w - bx - 16, by = cy - h * 0.3, bh = h * 0.6; if (bw > 80) { c.strokeStyle = rg(B, 0.25); c.strokeRect(bx, by, bw, bh); const ys = L.eq.map((p) => p[1]), lo = Math.min(...ys), hi = Math.max(...ys), n = L.eq.length, rv = Math.min(1, (t - L.t) / 1.6); c.save(); c.beginPath(); c.rect(bx, by, bw * rv, bh); c.clip(); c.strokeStyle = L.good ? "#35e0c4" : "#f2566a"; c.lineWidth = 1.8; c.beginPath(); L.eq.forEach((p, i) => { const x = bx + (i / (n - 1)) * bw, y = by + bh - 6 - ((p[1] - lo) / (hi - lo || 1)) * (bh - 12); i ? c.lineTo(x, y) : c.moveTo(x, y); }); c.stroke(); c.restore(); c.fillStyle = rg("#c3cbe0", 0.85); c.font = "10px Consolas,monospace"; c.textAlign = "left"; c.fillText(`${L.code} · ${L.ret}`, bx + 6, by + 14); } }
}
TICKS.push((dt, t) => btEngine(dt, t));
/* merdiven testi botun o anki ayarıyla yapılır; ayar değişince test yenilenir */
function ladCfg() {
  const c = window.__xmCfg; if (!c && !BT._lf && !window.LOCAL_API && !window.Capacitor) { BT._lf = 1; fetch("/api/bot").then((r) => r.json()).then((s) => { window.__xmCfg = s.cfg; }).catch(() => {}); }
  if (!c) return null; return { step_mode: c.step_mode, atr_k: c.atr_k, steps: c.steps, partial: c.partial, be_buf: c.be_buf, growth: c.growth, reverse: c.reverse, max_hold_min: c.max_hold_min || 0, step: c.step };
}
const btCfg = () => Object.assign({}, BT.cfg, { lad: ladCfg() });
const ladSig = () => JSON.stringify(ladCfg());
/* bot Lab sinyalini yalnız kendi çıkışıyla (merdiven) da kârlı, birden çok dönemde tutarlı ve gelecek veri kullanmayan stratejide açar */
function botCheck(x) {
  if (!x || !x.lad) return { ok: false, why: "merdiven testi bekleniyor" }; const L = x.lad, w = L.wf || {};
  if (x.la && x.la.bad) return { ok: false, why: "gelecek veri testi geçemedi" };
  if (L.m.n < 15) return { ok: false, why: `merdivende yalnız ${L.m.n} işlem` };
  if (!(L.m.avgR > 0 && L.m.pf >= 1.1)) return { ok: false, why: `merdivende kâr yok (ort ${f1(L.m.avgR)}R)` };
  if (!(L.oos.avgR > 0)) return { ok: false, why: "merdiven OOS'ta zararda" };
  if (w.pos * 2 <= w.valid) return { ok: false, why: `dönem tutarsız (${w.pos}/${w.valid})` };
  return { ok: true, why: `merdiven ort ${f1(L.m.avgR)}R · dönem ${w.pos}/${w.valid}` };
}
window.NeraBT = { get: (r) => BT.res[bkey(r)], bot: (r) => botCheck(BT.res[bkey(r)]) };
function btFill() {
  BT.items = [...Lab.book.filter((r) => r.status === "kept"), ...Lab.book.filter((r) => r.status !== "kept")].slice(0, 16);         // kalıcılar önce: Pulsar/Süpernova onayı backtest ister
  const now = Date.now();
  for (const r of BT.items) { const k = bkey(r), have = BT.res[k], old = have && !have.fail && have.ladSig !== ladSig(); if ((!have || old || now - have.at > 90 * 60000) && !BT.q.some((x) => bkey(x) === k) && !(BT.cur && bkey(BT.cur) === k)) BT.q.push(r); }
  BT.q.sort((a, b) => (a.sym + a.tf).localeCompare(b.sym + b.tf));
}
function btPump() {
  if (BT.busy || !BT.q.length) return; if (!BT.w) { BT.w = new Worker("lab/labcore.js"); BT.w.onmessage = (e) => btMsg(e.data); BT.w.onerror = (e) => { BT.err = e.message || "worker"; BT.busy = false; }; }
  const it = BT.q.shift(); BT.cur = it; BT.busy = true; const key = it.sym + it.tf + BT.days;
  if (BT.loaded !== key) { BT.loaded = ""; BT.pend = key; BT.w.postMessage({ cmd: "load", sym: it.sym, tf: it.tf, days: BT.days }); } else BT.w.postMessage({ cmd: "report", g: it.g, cfg: btCfg(), rid: 1 });
}
function btMsg(m) {
  if (m.ev === "data") { BT.loaded = BT.pend; BT.w.postMessage({ cmd: "report", g: BT.cur.g, cfg: btCfg(), rid: 1 }); }
  else if (m.ev === "error") { if (BT.cur) BT.res[bkey(BT.cur)] = { at: Date.now(), fail: m.msg }; BT.busy = false; BT.loaded = ""; BT.err = m.msg; LSb.set("nera_bt", BT.res); }
  else if (m.ev === "report") {
    const r = m.rep, k = bkey(BT.cur), n = BT.cur.name;
    BT.res[k] = { at: Date.now(), m: { ret: r.m.ret, dd: r.m.dd, sh: r.m.sh, n: r.m.n, win: r.m.win, pf: r.m.pf, avgR: r.m.avgR, sqn: r.m.sqn }, is: r.is, oos: r.oos, eq: ds(r.eq, 90), dd: ds(r.dd, 90), bh: ds(r.bh, 90), roll: ds(r.roll, 60), mon: r.mon, hist: r.hist, why: r.why, monN: r.monN, mc: r.mc, split: r.split, t0: r.t0, t1: r.t1, last: r.last.slice(0, 12), bars: r.bars, days: BT.days, wf: r.wf, la: r.la, ladSig: ladSig(), lad: Object.assign({}, r.lad, { eq: ds(r.lad.eq, 90) }) };
    { const good = r.oos.avgR > 0.03 && r.oos.pf > 1.1, col = good ? "#35e0c4" : r.oos.avgR > 0 ? "#ffb04a" : "#f2566a", tl = tCode(BT.cur), now = performance.now() / 1000; BTE.flash = { t: now, col, txt: `OOS Sharpe ${f1(r.oos.sh)}` }; BTE.last = { t: now, eq: ds(r.eq, 90), good: r.m.ret >= 0, code: tl ? tl.code : "", ret: pc(r.m.ret, 1) }; for (let k = 0; k < 26; k++) { const a = Math.random() * 6.283, v = 80 + Math.random() * 120; BTE.sparks.push({ x: 0, y: 0, vx: Math.cos(a) * v, vy: Math.sin(a) * v, l: 1, col, rel: 1 }); } }
    LSb.set("nera_bt", BT.res); BT.busy = false; BT.pulse = bkey(BT.cur); Office.act("bt", `${n.slice(0, 34)}: OOS Sharpe ${f1(r.oos.sh)}`, 2500); LM.event("bt", { color: r.oos.avgR > 0.03 ? "#35e0c4" : "#4dd0e1", msg: "Backtest tamamlandı" }); if (BT.sel === k) btDetail();
  }
}
const spark = (eq, good) => { if (!eq || eq.length < 2) return ""; const ys = eq.map((p) => p[1]), lo = Math.min(...ys), hi = Math.max(...ys), n = eq.length; return `<svg class="spk" viewBox="0 0 100 24" preserveAspectRatio="none"><polyline fill="none" stroke="${good ? "#35e0c4" : "#f2566a"}" stroke-width="1.6" vector-effect="non-scaling-stroke" pathLength="100" points="${eq.map((p, i) => `${(i / (n - 1) * 100).toFixed(1)},${(22 - (p[1] - lo) / (hi - lo || 1) * 20).toFixed(1)}`).join(" ")}"/></svg>`; };
function updBT() {
  if (!$("#bt-body")) return; btFill();
  const rows = BT.items.map((r) => ({ r, k: bkey(r), x: BT.res[bkey(r)] })), done = rows.filter((x) => x.x && x.x.m), pos = done.filter((x) => x.x.oos.avgR > 0.03 && x.x.oos.pf > 1.1), avg = done.length ? done.reduce((a, x) => a + x.x.oos.sh, 0) / done.length : null;
  const K = (l, v, s, cl = "") => `<div class="kp ${cl}"><div class="l">${l}</div><div class="v">${v}</div><div class="s">${s}</div></div>`;
  const kh = K("Defterde", rows.length, "otomatik izlenen", "") + K("Backtest edilen", done.length, `${BT.days} gün · ${BT.cfg.fee}+${BT.cfg.slip} bps`, "a") + K("OOS pozitif", pos.length, "PF ≥ 1.1 · ort R > 0.03", "b") + K("Ort. OOS Sharpe", avg == null ? "—" : f1(avg), "kapalı kutu", "c") + K("Kuyruk", BT.q.length + (BT.busy ? 1 : 0), BT.busy ? "bir test çalışıyor" : "boşta", ""); const ke = $("#bt-kpis"); if (ke._h !== kh) { ke._h = kh; ke.innerHTML = kh; }
  const hn = $("#bt-now"); const tx = BT.busy && BT.cur ? `çalışıyor: ${BT.cur.name.slice(0, 60)}` : rows.length ? (BT.q.length ? "sırada bekleyenler var" : "hepsi güncel") : "Strateji Defteri boş: laboratuvar aday bulunca burada otomatik test edilir"; if (hn.textContent !== tx) hn.textContent = tx;
  // ağ
  const hash = rows.map((x) => x.k + (x.x ? (x.x.fail ? "f" : Math.round(x.x.oos ? x.x.oos.sh * 10 : 0)) : "-")).join(",") + (BT.sel || "");
  if (hash !== BT.hash) BT.hash = hash; BT.pulse = null;
  // tablo
  const sorted = rows.slice().sort((a, b) => (b.x && b.x.oos ? b.x.oos.sh : -99) - (a.x && a.x.oos ? a.x.oos.sh : -99));
  BT.sorted = sorted; const th = sorted.map((x, ix) => { const e = x.x, run = BT.busy && BT.cur && bkey(BT.cur) === x.k, q = BT.q.some((y) => bkey(y) === x.k), nm = Lab.newsSum && Lab.newsSum[x.r.sym], nws = nm && nm.n ? `<span class="${nm.score > 0.15 ? "na" : nm.score < -0.15 ? "down" : "muted"}">${nm.score >= 0 ? "+" : ""}${nm.score.toFixed(2)}</span>` : "—";
    const st = run ? '<span class="chip vio blink">hesaplanıyor</span>' : e && e.fail ? '<span class="chip bad">hata</span>' : e && e.m ? '<span class="chip ok">tamam</span>' : q ? '<span class="chip">sırada</span>' : '<span class="chip">—</span>';
    const tl = tCode(x.r); return `<tr data-i="${ix}" class="bkrow ${x.k === BT.sel ? "selrow" : ""}" style="--i:${ix}"><td style="max-width:320px">${tl ? `<div class="sname"><span class="tier t-${tl.k}">${tl.glyph} ${tl.label}</span><b>${tl.code}</b></div>` : ""}${esc(x.r.name)}</td><td>${x.r.sym.replace("USDT", "")} ${x.r.tf}</td><td style="width:130px">${e && e.eq ? spark(e.eq, e.m.ret >= 0) : ""}</td><td class="${e && e.m ? (e.m.ret >= 0 ? "na" : "down") : ""}">${e && e.m ? pc(e.m.ret, 1) : "—"}</td><td>${e && e.m ? pc(e.m.dd, 1) : "—"}</td><td>${e && e.oos ? f1(e.oos.sh) : "—"}</td><td>${e && e.m ? f1(e.m.pf) : "—"}</td><td>${e && e.m ? e.m.n : "—"}</td><td>${nws}</td><td>${st}</td></tr>`; }).join("") || `<tr><td colspan="10" class="empty2">Henüz strateji yok. Laboratuvar elekten geçen bir tarif bulunca burada kendiliğinden test edilir.</td></tr>`;
  const b = $("#bt-body"); if (b._h !== th) { b._h = th; b.innerHTML = th; $$("tr[data-i]", b).forEach((tr) => (tr.onclick = () => { BT.sel = BT.sorted[+tr.dataset.i].k; btDetail(); BT.hash = ""; b._h = ""; })); }
}
function monthTable(x) {
  const mm = Object.entries(x.mon || {}).sort(), mn = x.monN || {}; if (!mm.length) return ""; const mx = Math.max(0.0001, ...mm.map(([, v]) => Math.abs(v))); let cum = 0; const best = mm.reduce((a, b) => (b[1] > a[1] ? b : a)), worst = mm.reduce((a, b) => (b[1] < a[1] ? b : a));
  const rows = mm.map(([k, v], i) => { cum += v; return `<div class="mrow" style="--i:${i}"><span>${k}</span><span class="muted">${mn[k] || 0} işlem</span><div class="mbar2"><i class="${v >= 0 ? "p" : "n"}" data-w="${(Math.abs(v) / mx * 49).toFixed(1)}"></i></div><span class="${v >= 0 ? "pp" : "nn2"}" data-cu="${(v * 100).toFixed(2)}">0.00%</span><span class="muted" style="text-align:right" data-cu="${(cum * 100).toFixed(2)}" data-cum="1">0.00%</span></div>`; }).join("");
  return `<div class="panel detin"><div class="ph">Aylık kâr / zarar <small>en iyi ${best[0]}: ${(best[1] * 100).toFixed(1)}% · en kötü ${worst[0]}: ${(worst[1] * 100).toFixed(1)}% · risk %${(BT.cfg.risk * 100).toFixed(1)}/işlem varsayımıyla</small></div><div class="mrow h"><span>ay</span><span>işlem</span><span>getiri</span><span style="text-align:right">aylık</span><span style="text-align:right">kümülatif</span></div>${rows}</div>`;
}
function animMonths(root) {
  requestAnimationFrame(() => $$(".mbar2 i", root).forEach((i) => (i.style.width = i.dataset.w + "%")));
  $$("[data-cu]", root).forEach((e, n) => { const to = +e.dataset.cu, t0 = performance.now() + (n % 40) * 28, dur = 1100; (function step(now) { const p = Math.min(1, Math.max(0, (now - t0) / dur)), v = to * (1 - Math.pow(1 - p, 3)); e.textContent = (v >= 0 && !e.dataset.cum ? "+" : "") + v.toFixed(2) + "%"; if (p < 1 && e.isConnected) requestAnimationFrame(step); })(performance.now()); });
}
/* sabit çıkış ile botun merdiveni aynı sinyallerde yan yana; dönem çubukları ve testler */
function ladPanel(x) {
  const L = x.lad; if (!L) return `<div class="panel detin lad-p"><div class="ph">Botun çıkışı: merdiven</div><div class="pb muted">Bu sonuç eski; merdiven testi sırada.</div></div>`;
  const v = botCheck(x), a = x.m, b = L.m, why = Object.entries(L.why || {}).map(([k, n]) => `${k}: ${n}`).join(" · ");
  const row = (n, va, vb, fmt, hi, i) => { const w = hi ? vb > va : vb < va, tie = Math.abs(vb - va) < 1e-9; return `<div class="lad-r" style="--i:${i}"><span>${n}</span><b class="${!tie && !w ? "win" : ""}">${fmt(va)}</b><b class="${!tie && w ? "win" : ""}">${fmt(vb)}</b></div>`; };
  const bars = (w) => (w && w.f ? w.f.map((f, i) => `<i class="${f.n < 3 ? "e" : f.avgR > 0 ? "p" : "n"}" style="--h:${f.n < 3 ? 8 : Math.min(100, 18 + Math.abs(f.avgR) * 120)}%;--i:${i}" title="${i + 1}. dönem: ${f.n} işlem · ort ${f1(f.avgR)}R"></i>`).join("") : "");
  return `<div class="panel detin lad-p ${v.ok ? "ok" : "no"}"><div class="ph">Botun çıkışı: merdiven <small>aynı sinyaller · ort. ${f1(L.avgK)} basamak · aynı mumda önce stop</small><span class="lad-v">${v.ok ? "✓ bot açabilir" : "✕ bot açmaz"}</span></div>
    <div class="lad-g"><div class="lad-t"><div class="lad-r h"><span></span><em>sabit çıkış</em><em>merdiven</em></div>${row("Toplam getiri", a.ret, b.ret, (q) => pc(q, 1), 1, 0)}${row("Ort. işlem", a.avgR, b.avgR, (q) => f1(q) + "R", 1, 1)}${row("Profit faktörü", a.pf, b.pf, f1, 1, 2)}${row("Kazanma", a.win, b.win, (q) => pc(q), 1, 3)}${row("Maks düşüş", a.dd, b.dd, (q) => pc(q, 1), 0, 4)}${row("OOS ort.", x.oos.avgR, L.oos.avgR, (q) => f1(q) + "R", 1, 5)}${row("İşlem", a.n, b.n, (q) => q, 1, 6)}</div>
    <div class="lad-s"><div class="lad-box"><label>Dönem tutarlılığı <b>${L.wf.pos}/${L.wf.valid}</b></label><div class="lad-b">${bars(L.wf)}</div></div>
    <div class="lad-box"><label>Gelecek veri testi <b class="${x.la && !x.la.bad ? "na" : "nc"}">${x.la ? (x.la.bad ? `${x.la.bad} hata` : "temiz") : "—"}</b></label><span class="muted">${x.la ? `${x.la.n} noktada veri kesilip sinyal yeniden hesaplandı` : ""}</span></div>
    <div class="lad-box"><label>Karar</label><span>${esc(v.why)}</span></div></div></div>
    <div class="lad-f muted">Çıkış nedenleri: ${why || "—"}. XM spreadi ve dolar hedefi (hedef modu) modellenmez; maliyet ${BT.cfg.fee}+${BT.cfg.slip} bps. Altın, gümüş ve EUR/USD testleri Binance verisiyle olabilir.</div></div>`;
}
function btDetail() {
  const el = $("#bt-det"), x = BT.res[BT.sel], r = BT.items.find((y) => bkey(y) === BT.sel); if (!el || !x || !x.m || !r) { if (el) el.innerHTML = ""; return; }
  const m = x.m, K = (l, v, s, cl = "") => `<div class="kp ${cl}"><div class="l">${l}</div><div class="v">${v}</div><div class="s">${s}</div></div>`, mon = Object.entries(x.mon || {}).sort(), hist = Object.entries(x.hist || {}).sort((a, b) => +a[0] - +b[0]), hm = Math.max(...hist.map((q) => q[1]), 1), why = Object.entries(x.why || {}).map(([k, v]) => `${k}: ${v}`).join(" · "), ex = x.mc;
  el.innerHTML = `<div class="panel detin"><div class="ph">${esc(r.name)} <small>${new Date(x.t0).toLocaleDateString("tr-TR")} → ${new Date(x.t1).toLocaleDateString("tr-TR")} · ${nf(x.bars)} mum</small></div>
    <div class="kpis" style="margin:0;border:0;border-radius:0">${K("Toplam getiri", pc(m.ret, 1), "maliyetli, bileşik", m.ret > 0 ? "a" : "d")}${K("Maks düşüş", pc(m.dd, 1), "tepeden", "d")}${K("Sharpe", f1(m.sh), "yıllık", "b")}${K("İşlem", m.n, "kazanma " + pc(m.win), "")}${K("Profit faktörü", f1(m.pf), "brüt kâr/zarar", "")}${K("Ort. işlem", f1(m.avgR) + "R", "beklenti", m.avgR > 0 ? "a" : "d")}${K("SQN", f1(m.sqn), "", "")}</div></div>
    ${ladPanel(x)}
    ${monthTable(x)}
    <div class="two detin"><div class="panel"><div class="ph">IS (görülen)</div><div class="pb mono" style="font-size:12px">${x.is.n} işlem · ort ${f1(x.is.avgR)}R · PF ${f1(x.is.pf)} · Sharpe ${f1(x.is.sh)} · getiri ${pc(x.is.ret, 1)}</div></div><div class="panel"><div class="ph">OOS (hiç görülmemiş)</div><div class="pb mono" style="font-size:12px">${x.oos.n} işlem · ort ${f1(x.oos.avgR)}R · PF ${f1(x.oos.pf)} · Sharpe ${f1(x.oos.sh)} · getiri ${pc(x.oos.ret, 1)}</div></div></div>
    <div class="panel detin"><div class="ph">Özkaynak eğrisi <small>strateji vs. al-ve-tut</small></div><div class="pb cv"><canvas id="bt-eq"></canvas><div class="legend" style="padding:6px 0 0"><span><i style="background:#35e0c4"></i>sabit çıkış</span><span><i style="background:#ffb04a"></i>merdiven (bot)</span><span><i style="background:#8a7bff"></i>al-ve-tut</span></div></div></div>
    <div class="two detin"><div class="panel"><div class="ph">Düşüş</div><div class="pb cv"><canvas id="bt-dd"></canvas></div></div><div class="panel"><div class="ph">Kayan Sharpe <small>30 gün</small></div><div class="pb cv"><canvas id="bt-rs"></canvas></div></div></div>
    <div class="two detin"><div class="panel"><div class="ph">Aylık getiri</div><div class="pb"><div class="heat" style="grid-template-columns:repeat(auto-fill,minmax(78px,1fr))">${mon.map(([k, v]) => `<div style="background:${v >= 0 ? `rgba(38,198,160,${Math.min(0.9, 0.2 + Math.abs(v) * 8)})` : `rgba(242,86,106,${Math.min(0.9, 0.2 + Math.abs(v) * 8)})`}">${k}<br><b>${(v * 100).toFixed(1)}%</b></div>`).join("") || '<span class="muted">işlem yok</span>'}</div></div></div>
    <div class="panel"><div class="ph">İşlem dağılımı <small>R</small></div><div class="pb"><div class="hist">${hist.map(([k, v]) => `<i class="${+k < 0 ? "neg" : ""}" style="height:${v / hm * 100}%" title="${k}R: ${v}"><span>${k}</span></i>`).join("")}</div><div class="muted" style="font-size:11px;margin-top:18px">Çıkış nedenleri: ${why || "—"}</div></div></div></div>
    <div class="panel detin"><div class="ph">Monte Carlo <small>işlemler 300 kez karıştırıldı</small></div><div class="pb mono" style="font-size:12px">${ex ? `Getiri %5 / medyan / %95: <b class="${ex.p5 > 0 ? "na" : "nc"}">${pc(ex.p5, 0)}</b> / ${pc(ex.p50, 0)} / ${pc(ex.p95, 0)} · medyan düşüş ${pc(ex.ddMed, 0)} · %95 kötü durum düşüş ${pc(ex.dd95, 0)} · >%25 düşüş olasılığı <b class="${ex.pDD25 > 0.2 ? "nc" : "na"}">${pc(ex.pDD25, 0)}</b>` : "Yeterli işlem yok"}</div></div>`;
  requestAnimationFrame(() => { animMonths(el); chart($("#bt-eq"), [{ pts: x.bh, col: "#8a7bff", lw: 1.2 }, ...(x.lad && x.lad.eq ? [{ pts: x.lad.eq, col: "#ffb04a", lw: 1.6, step: true }] : []), { pts: x.eq, col: "#35e0c4", lw: 1.8, step: true }], { h: 230, split: x.split, fmt: (v) => ((v - 1) * 100).toFixed(0) + "%" }); chart($("#bt-dd"), [{ pts: x.dd, col: "#f2566a", lw: 1.3, step: true, fill: "rgba(242,86,106,.18)" }], { h: 160, zero: true, fmt: (v) => (v * 100).toFixed(0) + "%" }); chart($("#bt-rs"), [{ pts: x.roll && x.roll.length ? x.roll : [[x.t0, 0], [x.t1, 0]], col: "#4dd0e1", lw: 1.4 }], { h: 160, zero: true }); });
  el.scrollIntoView({ behavior: "smooth", block: "start" });
}
DT.on("lab:book", () => { btFill(); });
DT.on("bt:open", (r) => { BT.sel = bkey(r); BT.hash = ""; btDetail(); });
DT.on("view", (v) => { if (v === "bt") { BT.hash = ""; updBT(); } });

/* ================================================================ BİLGİ BANKASI */
const KB = [
  ["Jakeschincariol/day-trader-skill", "https://github.com/Jakeschincariol/day-trader-skill", "ok", "MIT · 11 beceri (tarayıcı, giriş, çıkış, zaman makinesi, risk kapısı…)", ["<b>ORB tarifi</b>: 15 dk açılış aralığı kırılımı, stop = aralık orta noktası, hedef 1R, gün sonu kapanış → Laboratuvar'da 'ORB' yapı taşı", "<b>Risk kapısı</b> (PASS/BLOCK): işlem başı zarar, ödül/risk, düşüş, işlem sayısı → Denetim istasyonu + Risk Müdürü", "<b>Zaman makinesi</b> fikri: kuralı geçmiş oturumlarda yeniden oynatmak → Backtest Stüdyosu", "Güvenlik tasarımı: kağıt-önce, emir yok → uygulamada hiçbir emir yolu yok"]],
  ["AI4Finance-Foundation/FinRL", "https://github.com/ai4finance-foundation/finrl", "part", "Finansal pekiştirmeli öğrenme · market env + ajan + uygulama", ["<b>Train / test / trade ayrımı</b> → IS / OOS / canlı izleme", "<b>Durum-aksiyon-ödül</b> düşüncesi → NN etiketi: 24 mumda +1.5 ATR / −1 ATR üçlü bariyer", "Teknik gösterge özellikleri (RSI, MACD, ADX…) → NN girdileri", "<b>Henüz yok:</b> A2C/PPO/SAC gibi DRL ajanları. Sinir Ağı bölümü denetimli MLP'dir; DRL ayrı bir iş."]],
  ["virattt/ai-hedge-fund", "https://github.com/virattt/ai-hedge-fund", "ok", "Analist kişilikleri + portföy yöneticisi + risk yöneticisi + backtester", ["<b>Rol ayrımı</b> → Ajan Ofisi'ndeki 10 ajan", "<b>Portföy yöneticisi</b> son kararı verir → Portföy Müdürü (deftere al / aday)", "<b>Backtester</b> + özkaynak vs. kıyas → Backtest Stüdyosu (al-ve-tut karşılaştırması)"]],
  ["TauricResearch/TradingAgents", "https://github.com/tauricresearch/tradingagents", "part", "Analistler → boğa/ayı tartışması → trader → risk ekibi → PM", ["<b>Boğa / Ayı tartışması</b> → Toplantı odası (gerçek metriklerden üretilen argümanlar)", "Risk ekibi → Risk Müdürü; karar günlüğü → Motor günlüğü", "<b>Henüz yok:</b> dil modeliyle serbest metin tartışma (API anahtarı + maliyet gerekir); mevcut ajanlar kural/istatistik tabanlı"]],
  ["LLMQuant/awesome-trading-agents", "https://github.com/LLMQuant/awesome-trading-agents", "ok", "Ajan, MCP ve beceri koleksiyonu · ortak tasarım kalıpları", ["<b>Sert limitler kodda:</b> risk kuralları dil modeline bırakılmaz → risk kapısı deterministik", "<b>Önce simülasyon, insan onayı, denetim izi</b> → emir yok, tüm kararlar günlükte", "<b>Hafıza / kendini gözden geçirme</b> → Strateji Defteri + toplam test sayacı (şans sınırı hesabına girer)"]],
  ["microsoft/qlib", "https://github.com/microsoft/qlib", "part", "Quant araştırma platformu · Alpha158 · LightGBM/MLP · backtest · RD-Agent", ["<b>Özellik mühendisliği</b> (Alpha158 ruhu) → 8 özellik × 4 gecikme", "<b>Model + IC/analiz</b> → NN OOS doğruluk, karışıklık matrisi", "<b>RD-Agent (otomatik faktör/tarif madenciliği)</b> → Laboratuvar'ın evrimsel araması", "<b>Henüz yok:</b> LightGBM ve LSTM/GRU modelleri (Python gerektirir; tarayıcıda MLP var)"]],
];
const PLAT = [["QuantConnect (LEAN)", "Olay tabanlı motor, gerçekçi dolum/komisyon/kayma, walk-forward, tekrar üretilebilir", "Kod ağırlıklı, bulut/hesap gerektirir", "SEÇİLDİ · motor tasarımı", "ok"], ["Portfolio Visualizer", "Rapor: düşüş, aylık tablo, kayan istatistik, Monte Carlo, kıyas", "Gün içi işlem motoru yok", "SEÇİLDİ · rapor düzeni", "ok"], ["TradingView", "En iyi grafik", "Strateji testi çubuk içi varsayımlara bağlı, geçmiş derinliği sınırlı", "Grafik için kullanılıyor (Piyasa)", "vio"], ["MetaTrader 5", "Tick modelli güçlü test", "MQL5, Windows, kendi verisi", "Kullanılmadı", "warn"], ["Forex Tester", "Elle bar-bar tekrar oynatma", "Otomatik arama için uygun değil", "Kullanılmadı", "warn"], ["TrendSpider", "Kodsuz otomasyon", "Kapalı, ücretli, dışa aktarım zayıf", "Kullanılmadı", "warn"]];
function buildKB() {
  $("#pg-kb").innerHTML = `<div class="eyebrow">Araçlar · neyi nereden aldık</div><h1>Bilgi Bankası</h1><p class="lead">Kaynak repolar ve platformlar; uygulamada olan/olmayan kısımlar.</p>
  <div class="kbg">${KB.map(([n, u, st, d, li]) => `<div class="kbc"><div style="display:flex;gap:8px;align-items:center"><h4>${n}</h4><span class="chip ${st === "ok" ? "ok" : "warn"}">${st === "ok" ? "eklendi" : "kısmen"}</span></div><a href="${u}" target="_blank" rel="noopener">${u}</a><div class="muted" style="font-size:11.5px;margin-top:5px">${d}</div><ul>${li.map((x) => `<li>${x}</li>`).join("")}</ul></div>`).join("")}</div>
  <div class="panel" style="margin-top:18px"><div class="ph">Backtest platformu seçimi <small>altı aday</small></div><div style="overflow:auto"><table class="tbl"><thead><tr><th>Platform</th><th>Güçlü yan</th><th>Zayıf yan</th><th>Karar</th></tr></thead><tbody>${PLAT.map(([a, b, c, d, k]) => `<tr><td><b>${a}</b></td><td>${b}</td><td>${c}</td><td><span class="chip ${k}">${d}</span></td></tr>`).join("")}</tbody></table></div><div class="pb muted" style="font-size:12px">Hiçbiri doğrudan gömülmedi (çoğu kapalı/bulut). Seçilen iki platformun yöntemi uygulamanın içinde yeniden yazıldı: LEAN'in dürüst dolum mantığı ve Portfolio Visualizer'ın rapor düzeni.</div></div>`;
}

/* ================================================================ kurulum */
function boot() { Office.init(); buildBT(); buildKB(); setInterval(() => { Office.upd(); }, 300); setInterval(btPump, 1200); setInterval(() => { if (visible("bt")) updBT(); }, 1000); setInterval(btFill, 15000); btFill(); }
window.addEventListener("DOMContentLoaded", boot);

})();


