"use strict";
/* Kanıt Lab: strateji üretimi yerine ölçüm. Sinyal karnesi (ledger), maliyet haritası, bot karnesi, yapay zekâ karnesi, araştırma notları.
   Hiçbiri kâr kanıtı değildir; amaç neyin işe yaradığını ve yaramadığını dürüstçe göstermek. */
(() => {
const $ = (s, r = document) => r.querySelector(s);
const esc = (s) => String(s).replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c]));
const COST_BPS = { BTCUSDT: 5.1, ETHUSDT: 13.1, XAUUSDT: 1.4, XAGUSDT: 13.6, EURUSD: 1.8 };     // pro_agents.COST_BPS ile aynı (XM spreadi, gidiş-dönüş)
const NM = { XAUUSDT: "Altın", XAGUSDT: "Gümüş", BTCUSDT: "BTC", ETHUSDT: "ETH", EURUSD: "EUR/USD" };
const TFS = ["5m", "15m", "1h", "4h"], HORIZON = 3 * 3600e3, LOGKEY = "nera_llm_log";
const num = (x, d = 2, sign = false) => (x == null || !isFinite(x) ? "—" : (sign && x > 0 ? "+" : "") + Number(x).toFixed(d).replace(".", ","));
const pct = (x) => (x == null || !isFinite(x) ? "—" : "%" + Math.round(x * 100));
const cls = (x) => (x > 0.005 ? "up" : x < -0.005 ? "down" : "mut");
const costR = (s) => ((COST_BPS[s.sym] ?? 5) * 1e-4 * s.entry) / s.risk;
const med = (a) => { if (!a.length) return null; const b = [...a].sort((x, y) => x - y), m = b.length >> 1; return b.length % 2 ? b[m] : (b[m - 1] + b[m]) / 2; };
const K = { sigs: [], bot: null, llm: [], at: 0, busy: false };

/* ---- veri */
function agg(a) {
  const n = a.length; if (!n) return { n: 0 };
  const net = a.map((s) => s.net_r), cost = a.map(costR), m = net.reduce((x, y) => x + y, 0) / n, sd = n > 1 ? Math.sqrt(net.reduce((x, y) => x + (y - m) ** 2, 0) / (n - 1)) : 0;
  const mc = cost.reduce((x, y) => x + y, 0) / n;
  return { n, win: a.filter((s) => s.status === "TP1").length / n, net: m, ci: 1.96 * sd / Math.sqrt(n), cost: mc, gross: m + mc, sum: net.reduce((x, y) => x + y, 0), medCost: med(cost) };
}
const verdict = (g) => (!g.n ? "Henüz çözülmüş sinyal yok." : g.n < 30 ? `Örnek az (${g.n}); sonuç için en az 30 sinyal gerekir.` : Math.abs(g.net) <= g.ci ? "Fark ölçülebilir değil: ortalama net R, belirsizlik aralığının içinde." : g.net > 0 ? "Ortalama net R pozitif ve belirsizlikten büyük; yine de kâr garantisi değildir." : "Ortalama net R negatif ve belirsizlikten büyük: bu sinyaller maliyetten sonra kaybettiriyor.");

async function llmResolve() {
  let a = []; try { a = JSON.parse(localStorage.getItem(LOGKEY) || "[]"); } catch (e) { a = []; }
  const now = Date.now(), need = a.filter((x) => x.r == null && now - x.t >= HORIZON && now - x.t < 5 * 864e5), bySym = {};
  need.forEach((x) => (bySym[x.sym] = 1));
  for (const sym of Object.keys(bySym)) {
    const j = await NAPI(`/api/chart?sym=${sym}&tf=15m`); if (!j || !j.candles || !j.candles.length) continue;
    const c = j.candles;
    need.filter((x) => x.sym === sym).forEach((x) => { const t = (x.t + HORIZON) / 1000, k = c.find((q) => q.time >= t); if (k && k.time - t < 1800) x.r = k.close > x.px ? 1 : k.close < x.px ? -1 : 0; });
  }
  a = a.filter((x) => now - x.t < 14 * 864e5); try { localStorage.setItem(LOGKEY, JSON.stringify(a.slice(-3000))); } catch (e) { /* dolu */ }
  K.llm = a;
}

async function load() {
  if (K.busy) return; K.busy = true;
  try {
    const j = await NAPI("/api/signals"); if (j && j.sigs) K.sigs = j.sigs.filter((s) => ["TP1", "SL", "süre"].includes(s.status) && s.net_r != null && s.risk > 0 && s.entry > 0);
    const b = await NAPI("/api/bot"); K.bot = b && (b.tot !== undefined || b.ptot) ? b : null;
    await llmResolve();
    K.at = Date.now(); cloudSync();
  } catch (e) { /* ağ yok */ }
  K.busy = false; draw();
}

/* ---- çizim */
const kp = (l, v, s = "", c = "") => `<div class="kp"><div class="l">${l}</div><div class="v ${c}">${v}</div><div class="s">${s}</div></div>`;
function spark(vals, w = 320, h = 54) {
  if (vals.length < 2) return "";
  let mn = Math.min(0, ...vals), mx = Math.max(0, ...vals); if (mx === mn) mx = mn + 1;
  const X = (i) => (i / (vals.length - 1)) * w, Y = (v) => h - 3 - ((v - mn) / (mx - mn)) * (h - 6), z = Y(0), last = vals[vals.length - 1];
  return `<svg viewBox="0 0 ${w} ${h}" width="100%" height="${h}" preserveAspectRatio="none"><line x1="0" y1="${z}" x2="${w}" y2="${z}" stroke="var(--line2)" stroke-dasharray="3 3"/><polyline fill="none" stroke="${last >= 0 ? "var(--up)" : "var(--down)"}" stroke-width="1.6" points="${vals.map((v, i) => X(i).toFixed(1) + "," + Y(v).toFixed(1)).join(" ")}"/></svg>`;
}
function secSig() {
  const a = K.sigs.slice().sort((x, y) => x.ts - y.ts), g = agg(a);
  if (!g.n) return `<div class="panel"><div class="ph">Sinyal karnesi <small>gerçek sonuçlar, kâğıt üstünde</small></div><div class="pb"><div class="muted">Henüz çözülmüş sinyal yok. Sinyaller Piyasa & Sinyal ekranından gelir ve hedef/stop olunca burada sayılır.</div></div></div>`;
  let cum = 0; const line = a.map((s) => (cum += s.net_r));
  const rows = []; Object.keys(NM).forEach((sym) => TFS.forEach((tf) => { const x = agg(a.filter((s) => s.sym === sym && s.tf === tf)); if (x.n) rows.push(`<tr><td>${NM[sym]} ${tf}</td><td>${x.n}</td><td>${pct(x.win)}</td><td class="${cls(x.gross)}">${num(x.gross, 2, true)}R</td><td class="mut">−${num(x.cost)}R</td><td class="${cls(x.net)}"><b>${num(x.net, 2, true)}R</b> <span class="mut">±${num(x.ci)}</span></td></tr>`); }));
  return `<div class="panel"><div class="ph">Sinyal karnesi <small>${g.n} çözülmüş sinyal · komisyon yerine XM spreadi</small></div>
  <div class="kpis">${kp("Kazanma (hedef 1)", pct(g.win), "stop ve süre dışı")}${kp("Ort. net R", num(g.net, 2, true), `±${num(g.ci)} (%95)`, cls(g.net))}${kp("Brüt R", num(g.gross, 2, true), "maliyet öncesi", cls(g.gross))}${kp("Maliyet", "−" + num(g.cost), "ortalama R", "mut")}${kp("Toplam net R", num(g.sum, 1, true), "tüm sinyaller", cls(g.sum))}</div>
  <div class="pb"><div class="mini" style="margin-bottom:6px">Kümülatif net R</div>${spark(line)}<div class="honest" style="margin-top:8px">${verdict(g)}</div></div>
  <div class="pb"><table class="tbl"><thead><tr><th>Sembol / dönem</th><th>n</th><th>Kazanma</th><th>Brüt</th><th>Maliyet</th><th>Net</th></tr></thead><tbody>${rows.join("")}</tbody></table></div></div>`;
}
function secCost() {
  const a = K.sigs, cell = (sym, tf) => { const x = a.filter((s) => s.sym === sym && s.tf === tf).map(costR); if (!x.length) return `<td class="mut">—</td>`; const m = med(x); return `<td class="${m > 0.15 ? "down" : m > 0.08 ? "nc" : "up"}">${num(m)}R <span class="mut">(${x.length})</span></td>`; };
  return `<div class="panel"><div class="ph">Maliyet haritası <small>spread, stop mesafesinin kaçta kaçı (medyan, sinyal sayısı)</small></div><div class="pb"><table class="tbl"><thead><tr><th>Sembol</th><th>XM spread (bps)</th>${TFS.map((t) => `<th>${t}</th>`).join("")}</tr></thead><tbody>${Object.keys(NM).map((s) => `<tr><td>${NM[s]}</td><td class="mut">${COST_BPS[s]}</td>${TFS.map((t) => cell(s, t)).join("")}</tr>`).join("")}</tbody></table>
  <div class="mini" style="margin-top:6px">Kırmızı: 0,15R üstü. Bu eşikten pahalı sinyaller maliyet kapısı ile verilmiyor (Ayarlar › Sinyaller). Geçmiş testte kaybın esas nedeni maliyetti.</div></div></div>`;
}
function secBot() {
  const b = K.bot;
  if (!b) return `<div class="panel"><div class="ph">Bot karnesi <small>XM Nera</small></div><div class="pb"><div class="muted">Bot verisi bu cihazda yok (masaüstü uygulamasında görünür) ya da henüz işlem yok.</div></div></div>`;
  const t = b.tot || { n: 0, w: 0, pnl: 0, best: 0 }, pt = Object.entries(b.ptot || {}), sk = Object.entries(b.skips || {});
  return `<div class="panel"><div class="ph">Bot karnesi <small>${t.n} kapanan işlem</small></div>
  <div class="kpis">${kp("İşlem", t.n)}${kp("Kazanma", t.n ? pct(t.w / t.n) : "—", `${t.w} / ${t.n}`)}${kp("Toplam K/Z", (t.pnl >= 0 ? "+" : "") + num(t.pnl) + " $", "kapanmış işlemler", cls(t.pnl))}${kp("En iyi işlem", "+" + num(t.best) + " $", "", "up")}</div>
  <div class="pb">${pt.length ? `<table class="tbl"><thead><tr><th>Parite</th><th>İşlem</th><th>Kazanç</th><th>K/Z</th></tr></thead><tbody>${pt.map(([s, x]) => `<tr><td>${esc(NM[s] || s)}</td><td>${x.n}</td><td>${x.n ? pct(x.w / x.n) : "—"}</td><td class="${cls(x.pnl)}">${(x.pnl >= 0 ? "+" : "") + num(x.pnl)} $</td></tr>`).join("")}</tbody></table>` : ""}
  ${sk.length ? `<div class="mini" style="margin:10px 0 4px">Atlanan sinyaller: koruma devreye girmeseydi ne olurdu?</div><table class="tbl"><thead><tr><th>Neden</th><th>Atlanan</th><th>Sonuçlanan</th><th>Toplam R</th></tr></thead><tbody>${sk.map(([w, x]) => `<tr><td>${esc(w)}</td><td>${x.n}</td><td>${x.done}</td><td class="${cls(x.sum)}">${num(x.sum, 1, true)}R</td></tr>`).join("")}</tbody></table>` : ""}
  <div class="honest" style="margin-top:8px">${t.n < 30 ? "Örnek az: " + t.n + " işlemle bot hakkında karar verilemez." : "İşlem sayısı yeterli görünüyor; yine de dönem ve sembol dağılımına bak."}</div></div></div>`;
}
function llmStats() {
  const by = {}; K.llm.forEach((x) => { const b = (by[x.k] = by[x.k] || { calls: 0, wait: 0, done: 0, ok: 0, pending: 0 }); b.calls++; if (!x.v) b.wait++; if (x.r == null) b.pending++; else if (x.v && x.r) { b.done++; if (Math.sign(x.v) === x.r) b.ok++; } });
  return by;
}
function secLlm() {
  const by = llmStats(), ks = Object.keys(by);
  const rows = ks.map((k) => { const b = by[k], acc = b.done ? b.ok / b.done : null, se = b.done ? Math.sqrt(0.25 / b.done) * 1.96 : 0; return `<tr><td>${esc(k)}</td><td>${b.calls}</td><td>${b.wait}</td><td>${b.done}</td><td>${b.pending}</td><td class="${acc == null ? "mut" : Math.abs(acc - 0.5) > se ? (acc > 0.5 ? "up" : "down") : "mut"}"><b>${pct(acc)}</b> <span class="mut">±${Math.round(se * 100)}</span></td></tr>`; }).join("");
  return `<div class="panel"><div class="ph">Yapay zekâ karnesi <small>konsey üyelerinin yönü, 3 saat sonraki fiyatla</small></div><div class="pb">${ks.length ? `<table class="tbl"><thead><tr><th>Üye</th><th>Çağrı</th><th>BEKLE</th><th>Sonuçlanan</th><th>Bekleyen</th><th>Doğru</th></tr></thead><tbody>${rows}</tbody></table>
  <div class="mini" style="margin-top:6px">Yazı tura %50. "±" yaklaşık %95 belirsizlik: doğru oranı bu aralığın dışına çıkmadıkça üyenin yazı turadan iyi olduğu söylenemez. Güvenilir sonuç için üye başına en az 100 sonuçlanan çağrı gerekir.</div>` : `<div class="muted">Henüz kayıt yok. Sinyal Beyni'nde (Ajan Ofisi) anahtarı girilmiş yapay zekâ üyeleri her görüş verdiğinde burada kaydedilir; 3 saat sonra gerçek fiyatla karşılaştırılır. Bu karne zamanla dolar.</div>`}</div></div>`;
}
function secNotes() {
  return `<div class="panel"><div class="ph">Araştırma notları <small>ne denendi, ne çıkmadı</small></div><div class="pb"><ul class="why">
  <li><b>Yön tahmini:</b> sinyal skoru ile sonraki fiyat arasındaki korelasyon +0,01. 12 seride (BTC, ETH, altın, gümüş; 15 dk, 1 sa, 4 sa; 180-900 gün) yaklaşık 60 eşik/kapı/ajan/saat ayarı eğitim ve test dönemlerinde kalıcı kâr vermedi; ters yön de aynı.</li>
  <li><b>Maliyet:</b> ham sonuç ≈ +0,04R, XM maliyetiyle −0,12R. Kayıp esas olarak spread. Maliyet kapısı (≤0,15R) ortalamayı −0,03R'ye indirdi, hâlâ negatif.</li>
  <li><b>Geri çekilme girişi:</b> entry∓k·ATR limit giriş, piyasadan girişten kötü çıktı; eklenmedi.</li>
  <li><b>Strateji üretimi (eski Laboratuvar):</b> yaklaşık 1 milyon test, 6-7 kalıcı; şans sınırı çoğunu eledi. Kaldırıldı.</li>
  <li><b>10.000 simülasyon:</b> yön bilmeyen bir piyasada stop/hedefin ne kadar tuttuğunu gösterir; yön tahmini değildir.</li>
  <li><b>Yapay zekâ yorumu:</b> hazır ajan skorlarını başka sözlerle tekrarlar. Ham mum verisiyle yön doğruluğu ölçülmedi.</li></ul>
  <div class="honest">Bu sayfadaki hiçbir sayı kâr kanıtı değildir. Gerçek parayla kullanma kararı yalnız sana aittir.</div>
  <div style="margin-top:10px"><button class="btn" id="kn-bt">Backtest Stüdyosu'nu aç</button> <button class="btn" id="kn-re">Yenile</button></div></div></div>`;
}
/* ---- kanıt beyni: 7 ajan → koordinatör → maliyet kapısı → sinyal → sonuç. Canlı oylar ajanları boyar, çözülen her sinyal sonuç düğümünü yakar. */
const AGN = [["trend", "Trend"], ["momentum", "Momentum"], ["flow", "Order flow"], ["ict", "ICT"], ["liquidity", "Likidite"], ["pa", "Price action"], ["news", "Haber"]];
const BR = { g: null, ev: null, seen: null };
const vcol = (v) => (v > 0.05 ? "#26c6a0" : v < -0.05 ? "#f2566a" : "#8c96af");
function mkBrain() {
  const cv = $("#kn-cv"); if (!cv || BR.g || typeof NeuroGraph === "undefined") return;
  const nd = AGN.map(([id, nm], i) => ({ id, label: nm, x: 0.08, y: 0.07 + (i * 0.86) / 6, r: 4.5, col: "#8a7bff" }));
  nd.push({ id: "hub", label: "koordinatör", x: 0.36, y: 0.5, r: 8, col: "#ffb04a" }, { id: "gate", label: "maliyet kapısı", x: 0.56, y: 0.5, r: 6, col: "#35e0c4" }, { id: "sig", label: "sinyal", x: 0.74, y: 0.5, r: 7, col: "#4dd0e1" },
    { id: "tp", label: "hedef", x: 0.92, y: 0.2, r: 6, col: "#26c6a0" }, { id: "sl", label: "stop", x: 0.92, y: 0.5, r: 6, col: "#f2566a" }, { id: "to", label: "süre", x: 0.92, y: 0.8, r: 6, col: "#8c96af" });
  BR.g = new NeuroGraph(cv, nd, [...AGN.map(([id]) => [id, "hub"]), ["hub", "gate"], ["gate", "sig"], ["sig", "tp"], ["sig", "sl"], ["sig", "to"]], { idle: true, curve: 10, labels: true, dur: 0.7, h: 300 });
}
function brainLive() {
  const g = BR.g; if (!g) return; const S = window.__S ? window.__S() : {}, ev = S.ana && S.ana.eval;
  if (ev && ev !== BR.ev) {
    BR.ev = ev; (ev.agents || []).slice(0, 7).forEach((a, i) => { const n = g.byId[AGN[i][0]]; if (!n) return; n.col = vcol(a.vote); n.label = `${AGN[i][1]} ${a.vote >= 0 ? "+" : ""}${a.vote.toFixed(2)}`; g.fire(AGN[i][0], n.col, 0.5 + Math.abs(a.vote) * 0.6, 0); });
    const h = g.byId.hub; h.label = `koordinatör · ${ev.state}`; h.col = ev.state === "LONG" ? "#26c6a0" : ev.state === "SHORT" ? "#f2566a" : "#ffb04a"; g.fire("hub", h.col, 1, 0);
    if (ev.plan && ev.plan.cost_r != null) { const k = g.byId.gate; k.label = `maliyet ${ev.plan.cost_r.toFixed(2)}R`; k.col = ev.plan.cost_r > 0.15 ? "#f2566a" : "#35e0c4"; }
  }
  const a = K.sigs, n = (st) => a.filter((s) => s.status === st).length, tot = a.length || 1;
  g.byId.tp.label = `hedef ${n("TP1")} (${Math.round((100 * n("TP1")) / tot)}%)`; g.byId.sl.label = `stop ${n("SL")} (${Math.round((100 * n("SL")) / tot)}%)`; g.byId.to.label = `süre ${n("süre")}`; g.byId.sig.label = `sinyal ${a.length}`;
  if (!BR.seen) BR.seen = new Set(a.map((s) => s.id));
  else a.forEach((s) => { if (BR.seen.has(s.id)) return; BR.seen.add(s.id); const to = s.status === "TP1" ? "tp" : s.status === "SL" ? "sl" : "to"; g.fire("sig", g.byId[to].col, 1.2, 0, to); });
}
/* ---- sinyal bulutu: her nokta bir sinyal (yeşil hedef, kırmızı stop, gri süre); yavaş döner, sürüklenir, yeni sinyal parlar */
const CL = { P: [], dust: [], yaw: 0.6, pit: 0.35, drag: null, seen: null, T: { tp: 0, sl: 0, to: 0 } };
const hash = (n) => { const x = Math.sin(n * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); };
for (let i = 0; i < 200; i++) { const u = hash(i + 0.3) * 2 - 1, th = hash(i + 7.7) * 6.283, r = 1.15 + 0.4 * hash(i + 3.1), q = Math.sqrt(1 - u * u); CL.dust.push({ x: q * Math.cos(th) * r, y: u * r, z: q * Math.sin(th) * r }); }
function cloudSync() {
  const old = new Map(CL.P.map((p) => [p.id, p])), fresh = new Set(CL.seen ? K.sigs.filter((s) => !CL.seen.has(s.id)).map((s) => s.id) : []);
  CL.seen = new Set(K.sigs.map((s) => s.id)); CL.T = { tp: 0, sl: 0, to: 0 };
  CL.P = K.sigs.slice(-700).map((s) => {
    const k = s.status === "TP1" ? "tp" : s.status === "SL" ? "sl" : "to"; CL.T[k]++;
    const o = old.get(s.id); if (o) return o;
    const u = hash(s.id) * 2 - 1, th = hash(s.id + 0.5) * 6.283, rr = 0.45 + 0.55 * Math.cbrt(hash(s.id + 0.9)), q = Math.sqrt(1 - u * u);
    return { id: s.id, x: q * Math.cos(th) * rr, y: u * rr, z: q * Math.sin(th) * rr, col: k === "tp" ? "#26c6a0" : k === "sl" ? "#f2566a" : "#8c96af", r: 1 + Math.min(1.5, Math.abs(s.net_r) * 0.6), f: fresh.has(s.id) ? 1 : 0 };
  });
}
function cloudFrame(dt, t) {
  const cv = $("#kn-cl"); if (!cv || typeof vis === "function" && !vis(cv)) return;
  const w = cv.parentElement.clientWidth, h = cv.parentElement.clientHeight; if (w < 10 || h < 10) return;
  const c = fitCanvas(cv, w, h); c.clearRect(0, 0, w, h); if (!CL.drag) CL.yaw += dt * 0.16;
  const cy = Math.cos(CL.yaw), sy = Math.sin(CL.yaw), cp = Math.cos(CL.pit), sp = Math.sin(CL.pit), R = Math.min(w, h) * 0.34;
  const pr = (p) => { const x = p.x * cy - p.z * sy; let z = p.x * sy + p.z * cy; const y = p.y * cp - z * sp; z = p.y * sp + z * cp; const k = 1 / (1.9 - z * 0.55); return { x: w / 2 + x * R * 1.9 * k, y: h / 2 + y * R * 1.9 * k, k, z }; };
  c.fillStyle = "#7a8cff"; CL.dust.forEach((d) => { const q = pr(d); c.globalAlpha = 0.1 + 0.16 * q.k; c.beginPath(); c.arc(q.x, q.y, 0.9 * q.k, 0, 6.3); c.fill(); }); c.globalAlpha = 1;
  const pts = CL.P.map((p) => ({ p, q: pr(p) })).sort((a, b) => a.q.z - b.q.z), mid = { x: w / 2, y: h / 2 };
  pts.forEach(({ p, q }) => { if (p.f > 0) { c.strokeStyle = p.col; c.globalAlpha = 0.5 * p.f; c.beginPath(); c.moveTo(mid.x, mid.y); c.lineTo(q.x, q.y); c.stroke(); } });
  pts.forEach(({ p, q }) => {
    const r = p.r * (0.6 + 0.6 * q.k) * (1 + p.f * 2.6); c.globalAlpha = Math.min(1, 0.35 + 0.65 * q.k * (0.8 + 0.2 * Math.sin(t * 1.6 + p.id)));
    if (p.f > 0) { const g = c.createRadialGradient(q.x, q.y, 0, q.x, q.y, r * 4); g.addColorStop(0, p.col); g.addColorStop(1, "rgba(0,0,0,0)"); c.globalAlpha = 0.55 * p.f; c.fillStyle = g; c.fillRect(q.x - r * 4, q.y - r * 4, r * 8, r * 8); c.globalAlpha = 1; p.f = Math.max(0, p.f - dt * 0.35); }
    c.fillStyle = p.col; c.beginPath(); c.arc(q.x, q.y, r, 0, 6.3); c.fill();
  }); c.globalAlpha = 1;
  c.font = '600 11px "Segoe UI",sans-serif'; c.textAlign = "left";
  [["#26c6a0", `hedef ${CL.T.tp}`], ["#f2566a", `stop ${CL.T.sl}`], ["#8c96af", `süre ${CL.T.to}`]].forEach(([col, tx], i) => { c.fillStyle = col; c.beginPath(); c.arc(16, h - 14 - i * 16, 4, 0, 6.3); c.fill(); c.fillStyle = "rgba(200,208,228,.85)"; c.fillText(tx, 26, h - 10 - i * 16); });
  if (!CL.P.length) { c.fillStyle = "rgba(200,208,228,.6)"; c.textAlign = "center"; c.fillText("Sinyaller sonuçlandıkça bulut dolar", w / 2, h / 2); }
}
function cloudInit() {
  const cv = $("#kn-cl"); if (!cv || cv._i) return; cv._i = 1; cv.style.cursor = "grab"; cv.style.touchAction = "none";
  cv.addEventListener("pointerdown", (e) => { CL.drag = { x: e.clientX, y: e.clientY }; try { cv.setPointerCapture(e.pointerId); } catch (x) { /* */ } });
  cv.addEventListener("pointermove", (e) => { if (!CL.drag) return; CL.yaw += (e.clientX - CL.drag.x) * 0.01; CL.pit = Math.max(-1.2, Math.min(1.2, CL.pit + (e.clientY - CL.drag.y) * 0.01)); CL.drag = { x: e.clientX, y: e.clientY }; });
  const up = () => { CL.drag = null; }; cv.addEventListener("pointerup", up); cv.addEventListener("pointercancel", up);
}
function draw() {
  const pg = $("#pg-kanit"); if (!pg) return;
  if (!$("#kn-body")) {
    pg.innerHTML = `<div class="eyebrow">Beyin · ölçüm ve kanıt</div><h1>Kanıt Lab</h1><p class="lead">Strateji üretmek yerine, elimizdeki sinyalin ve botun gerçekte ne yaptığını ölç. <span id="kn-at"></span></p>
    <div class="panel"><div class="ph">Kanıt beyni <small>ajanların canlı oyları → karar → gerçek sonuç</small></div><div id="kn-brain" style="position:relative;height:300px"><canvas id="kn-cv"></canvas></div></div>
    <div class="panel"><div class="ph">Sinyal bulutu <small>her nokta bir sinyal · sürükleyerek çevir</small></div><div style="position:relative;height:300px"><canvas id="kn-cl"></canvas></div></div><div id="kn-body"></div>`;
    mkBrain(); cloudInit();
  }
  const at = $("#kn-at"); if (at) at.textContent = "Güncelleme: " + (K.at ? new Date(K.at).toLocaleTimeString("tr-TR") : "…");
  const body = $("#kn-body"), h = `${secSig()}${secCost()}${secBot()}${secLlm()}${secNotes()}`;
  if (body._h !== h) { body._h = h; body.innerHTML = h; const b = $("#kn-bt"); if (b) b.onclick = () => Lab.go("bt"); const r = $("#kn-re"); if (r) r.onclick = () => load(); }
  brainLive();
}

/* ---- Kozmos gezegeni ve açılış */
window.Kanit = {
  info() { const g = agg(K.sigs); if (!g.n) return { v: "—", rows: [["Durum", "sonuçlanan sinyal yok"]] }; return { v: num(g.net, 2, true) + "R", rows: [["Sinyal", g.n], ["Kazanma", pct(g.win)], ["Brüt R", num(g.gross, 2, true)], ["Maliyet", "−" + num(g.cost)], ["Net R", `${num(g.net, 2, true)} ±${num(g.ci)}`]] }; },
  load,
};
window.addEventListener("DOMContentLoaded", () => {
  if (typeof TICKS !== "undefined") TICKS.push(cloudFrame);
  if (window.DT) DT.on("view", (v) => { if (v === "kanit") { draw(); if (Date.now() - K.at > 20000) load(); } });
  setTimeout(load, 4000); setInterval(() => { if (document.body.dataset.view === "kanit") load(); else if (Date.now() - K.at > 5 * 60000) load(); }, 60000); setInterval(() => { if (document.body.dataset.view === "kanit") brainLive(); }, 3000);
});
})();
