# Nera web arayüzü: üçüncü parti (çevrimdışı gömülü)

| Dosya | Paket | Sürüm | Lisans |
|---|---|---|---|
| `vendor/gsap.min.js`, `CustomEase`, `Flip`, `ScrollTrigger`, `SplitText`, `Observer`, `DrawSVGPlugin` | [GSAP](https://github.com/greensock/gsap) | 3.15.1 | GreenSock "Standard no charge license" (gsap.com/standard-license): bu uygulamada kullanıma uygun; GSAP'ı rakip bir görsel animasyon aracı yapmak için kullanma. |
| `vendor/lenis.min.js` | [Lenis](https://github.com/darkroomengineering/lenis) | 1.3.27 | MIT |
| `vendor/three.module.min.js` | [Three.js](https://github.com/mrdoob/three.js) | r160 | MIT |
| `ui3/fonts/*` | Geist, Geist Mono (Vercel), Instrument Serif (Instrument) | fontsource 5.x | SIL OFL 1.1 |
| `vendor/lw.js` (kök `lw.js`) | TradingView Lightweight Charts | – | Apache-2.0 (uygulama altında atıf var) |

## Esinlenilenler (kod kopyalanmadı)
- **React Bits** (MIT + Commons Clause): SplitText/BlurText, Magnet, ClickSpark, SpotlightCard davranışları düz JavaScript ile yeniden yazılır (`ui3/`). Bileşenler ayrı satılamaz/dağıtılamaz; bu uygulamanın parçası olarak kullanım serbest.
- **Gather · 聚 by DAO** (https://gather.be-of-dao.com/): parçacıkların derinlik haritasına göre toplanıp dağılması dili (Gather, Swarm, Trails, Links, Scan). Kod kütüphanesi değildir; efektler kendi Three.js shader'ımızla yeniden yazılır.
- **GetLayers AI** (getlayers.ai): yalnız herkese açık önizlemeler görülerek yön esinlendi (Stride, Prisma, Clarix, AI Studio). Ücretli prompt/kaynak kullanılmadı.
- **Flowsurface** (GPL-3.0): NeraFlow panolarının türü ve varsayılan ayarları örnek alındı; kod kopyalanmadı.
