"use strict";
/* Strateji kademeleri ve kod adları · Lab Sinyalleri (testten geçen stratejilerin canlı LONG/SHORT sinyalleri) · özel bildirim
   · strateji galaksisi (Defter + Lab Sinyalleri) · tema simgeleri · tema efektleri. Emir yok; kâr garantisi yok. */
(function () {
const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s).replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c])), f1 = (x, d = 2) => (x == null || !isFinite(x) ? "—" : Number(x).toFixed(d));
const LS = { get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } }, set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* dolu */ } } };
const IS_M = () => matchMedia("(max-width:900px)").matches;
const NAME = { BTCUSDT: "BTC", ETHUSDT: "ETH", XAUUSDT: "Altın XAU", XAGUSDT: "Gümüş XAG", EURUSD: "EUR/USD" };
const fp = (x, sym) => (x == null || !isFinite(x) ? "—" : Number(x).toLocaleString("en-US", { minimumFractionDigits: sym === "BTCUSDT" ? 1 : sym === "XAGUSDT" ? 3 : 2, maximumFractionDigits: sym === "BTCUSDT" ? 1 : sym === "XAGUSDT" ? 3 : 2 }));

/* ================================================================ kademeler + kod adları */
const STARS = ["Vega", "Rigel", "Altair", "Deneb", "Sirius", "Antares", "Polaris", "Capella", "Arcturus", "Bellatrix", "Aldebaran", "Spica", "Procyon", "Mira", "Castor", "Pollux", "Lyra", "Orion", "Draco", "Cygnus", "Hydra", "Carina", "Lupus", "Ara", "Norma", "Pavo", "Indus", "Tucana", "Fornax", "Mensa"];
const TIERS = {
  supernova: { glyph: "★", label: "SÜPERNOVA", col: "#ffd166", rank: 0, desc: "Kalıcı (şans sınırını aştı) + görülmemiş veride güçlü kâr + 180 gün backtestte kazanma ≥ %50 ve PF ≥ 1.3 · sinyal verir" },
  pulsar: { glyph: "✦", label: "PULSAR", col: "#4dd0e1", rank: 1, desc: "Kalıcı + görülmemiş veride kârlı + 180 gün backtestte kârlı (PF ≥ 1.15) · sinyal verir" },
  nebula: { glyph: "◆", label: "NEBULA", col: "#b388ff", rank: 2, desc: "Kalıcı ve görülmemiş veride kârlı ama backtest onayı yok ya da zayıf · yalnız gözlem, sinyal vermez" },
  dust: { glyph: "·", label: "TOZ", col: "#7a8199", rank: 3, desc: "Şans sınırını geçmedi ya da kâr kanıtı yok · sinyal vermez" },
};
const hsh = (s) => { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; };
const skey = (r) => r.sym + "|" + r.tf + "|" + JSON.stringify(r.g);
const NeraStrat = window.NeraStrat = {
  TIERS,
  info(r) {
    const h = hsh(skey(r)), code = `${STARS[h % STARS.length]}-${String((h >>> 9) % 100).padStart(2, "0")}`, bt = window.NeraBT ? NeraBT.get(r) : null;
    // yalnız şans sınırını geçmiş (kalıcı) ve hem görülmemiş veride hem bağımsız backtestte kendini kanıtlamış stratejiler sinyal verir
    const kept = r.status === "kept", o = r.oos || {}, prof = o.avgR > 0 && (o.pf == null || o.pf > 1.1), strong = o.avgR >= 0.1 && (o.pf == null || o.pf >= 1.3), m = bt && bt.m;
    const btOk = m && m.ret > 0 && m.pf >= 1.15 && bt.oos && bt.oos.avgR > 0, btStar = btOk && m.pf >= 1.3 && m.win >= 0.5 && m.n >= 20;
    const clean = !(bt && bt.la && bt.la.bad), k = !clean ? "dust" : kept && strong && btStar ? "supernova" : kept && prof && btOk ? "pulsar" : kept && prof ? "nebula" : "dust";
    return Object.assign({ k, code, sig: k === "supernova" || k === "pulsar" }, TIERS[k]);
  },
};

/* ================================================================ Lab Sinyalleri: ayrı labcore worker'ı stratejileri kendi sembol/aralığında canlı izler */
const TF_DAYS = { "1m": 2, "3m": 4, "5m": 5, "15m": 12, "30m": 22, "1h": 42, "2h": 80, "4h": 160, "1d": 950 }, TF_SEC = { "1m": 60, "3m": 180, "5m": 300, "15m": 900, "30m": 1800, "1h": 3600, "2h": 7200, "4h": 14400, "1d": 86400 };
const LabSig = window.LabSig = {
  w: null, st: LS.get("nera_ls_st", {}), hist: LS.get("nera_ls_hist", []), q: [], groups: {}, busy: false, cur: null, err: "", status: "bekliyor",
  active() { return (window.Lab ? Lab.book : []).filter((r) => NeraStrat.info(r).sig); },
  stateOf(r) { const s = this.st[skey(r)]; if (!s || !s.ls) return { side: 0, s }; const fresh = Date.now() - s.lt < 6 * (TF_SEC[r.tf] || 900) * 1000; return { side: fresh ? s.ls : 0, s }; },
  summary() { const t = { supernova: 0, pulsar: 0, nebula: 0, dust: 0 }; let L = 0, S = 0; (window.Lab ? Lab.book : []).forEach((r) => { const i = NeraStrat.info(r); t[i.k]++; if (i.sig) { const s = this.stateOf(r).side; if (s > 0) L++; else if (s < 0) S++; } }); const h = this.hist[0]; return { live: t.supernova + t.pulsar, t, L, S, last: h ? `${h.side > 0 ? "LONG" : "SHORT"} ${NAME[h.sym] || h.sym} · ${h.code}` : "" }; },
  schedule() {
    const now = Date.now(), act = this.active(); const keys = new Set(act.map((r) => r.sym + "|" + r.tf));
    keys.forEach((gk) => { const g = this.groups[gk] = this.groups[gk] || { next: 0 }; if (now >= g.next && !this.q.includes(gk) && !(this.cur && this.cur.gk === gk)) this.q.push(gk); });
    this.pump();
  },
  pump() {
    if (this.busy || !this.q.length) { if (!this.busy) this.status = this.active().length ? "izleniyor · sonraki mum kapanışı bekleniyor" : "izlenecek strateji yok"; return; }
    if (!this.w) { try { this.w = new Worker("lab/labcore.js"); } catch (e) { this.err = String(e.message || e); return; } this.w.onmessage = (e) => this.msg(e.data); this.w.onerror = (e) => { this.err = e.message || "worker"; this.busy = false; }; }
    const gk = this.q.shift(), [sym, tf] = gk.split("|"); this.cur = { gk, sym, tf, rs: this.active().filter((r) => r.sym === sym && r.tf === tf) }; if (!this.cur.rs.length) { this.cur = null; return this.pump(); }
    this.busy = true; this.status = `${NAME[sym] || sym} ${tf} kontrol ediliyor…`; this.w.postMessage({ cmd: "load", sym, tf, days: TF_DAYS[tf] || 12 });
  },
  msg(m) {
    const cur = this.cur; if (!cur) return;
    if (m.ev === "data") { cur.t1 = m.t1; this.w.postMessage({ cmd: "live", gs: cur.rs.map((r) => r.g), rid: 7 }); }
    else if (m.ev === "live") {
      const tfs = (TF_SEC[cur.tf] || 900) * 1000; (m.res || []).forEach((res, i) => { const r = cur.rs[i]; if (!r || !res) return; const k = skey(r), prev = this.st[k] || {}, s = Object.assign({}, prev, { side: res.side, price: res.price, stop: res.stop, tp: res.tp, t: res.t, chk: Date.now() });
        if (res.side && prev.lt !== res.t) { s.ls = res.side; s.lt = res.t; s.lp = res.price; s.lstop = res.stop; s.ltp = res.tp; const fresh = Date.now() - (res.t + 2 * tfs) < tfs * 1.5; if (fresh && prev.chk) this.fire(r, s); }
        this.st[k] = s; });
      LS.set("nera_ls_st", this.st); this.groups[cur.gk].next = (cur.t1 || Date.now()) + 2 * tfs + 8000; this.busy = false; this.cur = null; this.err = ""; this.pump();
    } else if (m.ev === "error") { this.groups[cur.gk].next = Date.now() + 90000; this.err = m.msg; this.busy = false; this.cur = null; this.pump(); }
  },
  fire(r, s) {
    const TL = NeraStrat.info(r), side = s.ls, S = window.__S ? __S() : null, w = S && S.tk && S.tk.watch && S.tk.watch[r.sym]; if (w && w.closed) return;
    const e = { at: Date.now(), code: TL.code, k: TL.k, label: TL.label, glyph: TL.glyph, col: TL.col, sym: r.sym, tf: r.tf, side, price: s.lp, stop: s.lstop, tp: s.ltp, name: r.name };
    this.hist.unshift(e); if (this.hist.length > 120) this.hist.length = 120; LS.set("nera_ls_hist", this.hist);
    DT.emit("labsig", e); if (!window.LOCAL_API && window.NeraBT && NeraBT.bot(r).ok) fetch("/api/bot/sig", { method: "POST", body: JSON.stringify({ sym: r.sym, tf: r.tf, side, entry: e.price, stop: e.stop, code: TL.code, ts: Date.now() / 1000 }) }).catch(() => {}); try { LM.event("labsig", { color: TL.col, msg: `${TL.label} ${side > 0 ? "LONG" : "SHORT"}` }); } catch (x) { /* */ }
    if (localStorage.getItem("nera_ls_notify") === "0") return; pop(e); chime(e);
    try { const LN = window.Capacitor && Capacitor.Plugins && Capacitor.Plugins.LocalNotifications; if (LN) LN.schedule({ notifications: [{ id: (e.at % 2000000000) + 7, title: `${TL.glyph} ${TL.label} · ${side > 0 ? "LONG" : "SHORT"} · ${NAME[r.sym] || r.sym} ${r.tf}`, body: `${TL.code} · giriş ${fp(e.price, r.sym)} · stop ${fp(e.stop, r.sym)} · hedef ${fp(e.tp, r.sym)} · tavsiye değil`, channelId: "sinyal2", schedule: { at: new Date(Date.now() + 300) } }] }); } catch (x) { /* */ }
  },
  forSym(sym) {
    const rs = (window.Lab ? Lab.book : []).filter((r) => r.sym === sym).map((r) => ({ r, i: NeraStrat.info(r) })).filter((o) => o.i.sig).sort((a, b) => a.i.rank - b.i.rank);
    if (!rs.length) return `<div class="r muted">Bu varlıkta kendini kanıtlamış (Süpernova/Pulsar) strateji yok.</div>`;
    return rs.slice(0, 6).map(({ r, i }) => { const sd = this.stateOf(r).side; return `<div class="r"><span class="tier t-${i.k}">${i.glyph} ${i.label}</span><span class="t"><b>${i.code}</b> <span class="muted">${r.tf}</span></span>${sd ? `<span class="chip ${sd > 0 ? "ok" : "bad"} blink">${sd > 0 ? "LONG" : "SHORT"}</span>` : '<span class="muted">bekle</span>'}</div>`; }).join("");
  },
};
setInterval(() => LabSig.schedule(), 15000); setTimeout(() => LabSig.schedule(), 6000); DT.on("lab:book", () => setTimeout(() => LabSig.schedule(), 1500));

/* özel bildirim: yörünge halkaları, parlayan kademe simgesi, parçacık patlaması */
function pop(e) {
  let host = $("#ls-host"); if (!host) { host = document.createElement("div"); host.id = "ls-host"; document.body.appendChild(host); }
  const el = document.createElement("div"); el.className = `lsp t-${e.k} ${e.side > 0 ? "L" : "S"}`; el.style.setProperty("--tc", e.col);
  el.innerHTML = `<div class="lsp-orb"><i></i><i></i><i></i><b>${e.glyph}</b></div><div class="lsp-tx"><small>${e.label} SİNYALİ · ${e.code}</small><h3>${e.side > 0 ? "LONG ▲" : "SHORT ▼"} <span>${NAME[e.sym] || e.sym} · ${e.tf}</span></h3><p>giriş <b>${fp(e.price, e.sym)}</b> · stop <b>${fp(e.stop, e.sym)}</b> · hedef <b>${fp(e.tp, e.sym)}</b></p><em>${esc(e.name).slice(0, 90)} · tavsiye değildir</em></div><button class="lsp-x" aria-label="Kapat">✕</button><div class="lsp-bar"></div>${Array.from({ length: 16 }, (_, i) => `<s style="--a:${(i / 16) * 360}deg;--d:${60 + Math.random() * 80}px"></s>`).join("")}`;
  host.appendChild(el); const close = () => { el.classList.add("out"); setTimeout(() => el.remove(), 700); };
  el.onclick = (ev) => { if (ev.target.closest(".lsp-x")) { close(); return; } close(); if (window.Lab) Lab.go("labsig"); }; setTimeout(close, 10000);
  while (host.children.length > 3) host.firstChild.remove();
}
function chime(e) { try { if (!window.Sound || !Sound.on) return; const up = e.side > 0, sc = up ? [523.3, 659.3, 784, 1046.5, 1318.5] : [1318.5, 1046.5, 784, 622.3, 523.3]; sc.forEach((f, i) => { Sound.tone(f, 0.11, 2.4, "sine", i * 0.075); Sound.tone(f * 1.5, 0.03, 1.6, "triangle", i * 0.075 + 0.02); }); Sound.tone(up ? 130.8 : 110, 0.16, 2.6, "triangle", 0); Sound.tone(e.k === "supernova" ? 2093 : 1568, 0.04, 3, "sine", 0.45); } catch (x) { /* */ } }
LabSig.test = (k = "supernova", side = 1) => { const T = TIERS[k]; pop({ code: "Vega-07", k, label: T.label, glyph: T.glyph, col: T.col, sym: "XAUUSDT", tf: "15m", side, price: 3994.2, stop: 3980.5, tp: 4021.6, name: "Deneme bildirimi" }); chime({ side, k }); };

/* ================================================================ strateji galaksisi (Defter ve Lab Sinyalleri) */
function galaxy(cv, list, t, opt = {}) {
  if (!cv || !cv.isConnected || !vis(cv)) return; const w = cv.parentElement.clientWidth, h = opt.h || cv.parentElement.clientHeight || 240; if (w < 60) return; const c = Lab.fitCanvas(cv, w, h); c.clearRect(0, 0, w, h);
  const cx = w / 2, cy = h / 2, sq = 0.5, nr = opt.noDust ? 5.32 : 6.95, R0 = Math.min((w / 2 - 20) / nr, (h / 2 - 16) / (nr * sq)), rot = t * 0.02;
  const g = c.createRadialGradient(cx, cy, 0, cx, cy, R0 * 1.4); g.addColorStop(0, "rgba(255,255,255,.55)"); g.addColorStop(0.25, rgba(CA, 0.4)); g.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = g; c.fillRect(cx - R0 * 1.4, cy - R0 * 1.4, R0 * 2.8, R0 * 2.8);
  const rings = ["supernova", "pulsar", "nebula", "dust"]; rings.forEach((k, i) => { if (opt.noDust && k === "dust") return; const rr = R0 * (1.1 + i * 0.85); c.strokeStyle = rgba(TIERS[k].col, 0.16); c.setLineDash([2, 6]); c.beginPath(); c.ellipse(cx, cy, rr * 1.9, rr * 1.9 * sq, 0, 0, 6.3); c.stroke(); c.setLineDash([]); });
  const pos = []; list.forEach((r, idx) => { const i = NeraStrat.info(r); if (opt.noDust && !i.sig) return; const ri = TIERS[i.k].rank, rr = R0 * (1.1 + ri * 0.85) * 1.9, a = (hsh(skey(r)) % 628) / 100 + rot * (1.6 - ri * 0.3), x = cx + Math.cos(a) * rr, y = cy + Math.sin(a) * rr * sq, sd = LabSig.stateOf(r).side, tw = 0.6 + 0.4 * Math.sin(t * 2 + idx), sz = (ri === 0 ? 4.2 : ri === 1 ? 3.4 : ri === 2 ? 2.8 : 1.8) * (Math.sin(a) > 0 ? 1.15 : 0.85);
    pos.push({ x, y, r, i, sd }); const gg = c.createRadialGradient(x, y, 0, x, y, sz * 5); gg.addColorStop(0, rgba(i.col, 0.55 * tw)); gg.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = gg; c.fillRect(x - sz * 5, y - sz * 5, sz * 10, sz * 10); c.fillStyle = rgba("#ffffff", 0.6 + 0.4 * tw); c.beginPath(); c.arc(x, y, sz * 0.6, 0, 6.3); c.fill();
    if (ri === 0) { c.strokeStyle = rgba(i.col, 0.6 * tw); c.lineWidth = 1; c.beginPath(); c.moveTo(x - sz * 2.4, y); c.lineTo(x + sz * 2.4, y); c.moveTo(x, y - sz * 2.4); c.lineTo(x, y + sz * 2.4); c.stroke(); }
    if (sd) { const ph = (t * 0.8 + idx * 0.3) % 1, col = sd > 0 ? "#26c6a0" : "#f2566a"; c.strokeStyle = rgba(col, 1 - ph); c.lineWidth = 2; c.beginPath(); c.arc(x, y, sz * 2 + ph * 22, 0, 6.3); c.stroke(); }
    if (i.sig && w > 420) { c.fillStyle = rgba("#c8d0e6", 0.75); c.font = "9px Consolas,monospace"; c.textAlign = "center"; c.fillText(i.code + (sd ? (sd > 0 ? " ▲" : " ▼") : ""), x, y - sz - 7); } });
  for (let a = 0; a < pos.length; a++) for (let b = a + 1; b < pos.length; b++) { const p = pos[a], q = pos[b]; if (p.r.sym !== q.r.sym || !p.i.sig || !q.i.sig) continue; c.strokeStyle = rgba(CB, 0.1); c.lineWidth = 1; c.beginPath(); c.moveTo(p.x, p.y); c.quadraticCurveTo(cx, cy, q.x, q.y); c.stroke(); }
}
TICKS.push((dt, t) => { const v = document.body.dataset.view; if (v === "book") galaxy($("#bk-gal"), window.Lab ? Lab.book : [], t, {}); else if (v === "labsig") galaxy($("#ls-gal"), window.Lab ? Lab.book : [], t, { noDust: true }); });

/* ================================================================ Lab Sinyalleri ekranı */
function buildLS() {
  const el = $("#pg-labsig"); if (!el) return;
  el.innerHTML = `<div class="eyebrow">Laboratuvar · testten geçen stratejiler · canlı</div><h1>Lab Sinyalleri</h1>
  <p class="lead">Yalnız ★ Süpernova ve ✦ Pulsar stratejileri sinyal verir. Emir gönderilmez; kâr garantisi yoktur.</p>
  <div class="tiers" id="ls-tiers"></div>
  <div class="panel"><div class="ph">Takımyıldız <small id="ls-status">—</small></div><div class="ls-galw"><canvas id="ls-gal"></canvas></div></div>
  <div class="panel"><div class="ph">Canlı strateji kartları <small>kademe sırasına göre</small><div class="sp"><button class="btn" id="ls-test">Bildirimi dene</button></div></div><div class="lsgrid" id="ls-grid"></div></div>
  <div class="panel"><div class="ph">Sinyal geçmişi <small>bu cihazda</small></div><div id="ls-hist"></div></div>`;
  $("#ls-test").onclick = () => LabSig.test(["supernova", "pulsar", "nebula"][Math.floor(Math.random() * 3)], Math.random() < 0.5 ? 1 : -1);
}
function updLS() {
  if (document.body.dataset.view !== "labsig") return; if (!$("#ls-grid")) buildLS(); const sm = LabSig.summary();
  const th = ["supernova", "pulsar", "nebula", "dust"].map((k) => { const T = TIERS[k]; return `<div class="tcard t-${k}" style="--tc:${T.col}"><b>${T.glyph}</b><div><span>${T.label}</span><em>${sm.t[k]}</em></div><p>${T.desc}</p></div>`; }).join(""); const te = $("#ls-tiers"); if (te._h !== th) { te._h = th; te.innerHTML = th; }
  const st = $("#ls-status"), tx = (LabSig.err ? "hata: " + LabSig.err + " · " : "") + LabSig.status; if (st.textContent !== tx) st.textContent = tx;
  const rs = LabSig.active().map((r) => ({ r, i: NeraStrat.info(r) })).sort((a, b) => a.i.rank - b.i.rank);
  const gh = rs.map(({ r, i }, n) => { const so = LabSig.stateOf(r), s = so.s || {}, sd = so.side, ago = s.lt ? Math.round((Date.now() - s.lt) / 60000) : null;
    return `<div class="lsc t-${i.k} ${sd > 0 ? "L" : sd < 0 ? "S" : ""}" style="--tc:${i.col};--i:${n}"><div class="lsc-h"><span class="tier t-${i.k}">${i.glyph} ${i.label}</span><b>${i.code}</b><em>${NAME[r.sym] || r.sym} · ${r.tf}</em></div>
      <div class="lsc-s">${sd ? `<span class="big ${sd > 0 ? "up" : "dn"}">${sd > 0 ? "LONG ▲" : "SHORT ▼"}</span><span class="muted">${ago != null ? ago + " dk önce" : ""}</span>` : `<span class="big w">BEKLE</span><span class="muted">${s.chk ? "kontrol " + new Date(s.chk).toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" }) : "ilk kontrol bekleniyor"}</span>`}</div>
      ${sd ? `<div class="lsc-p"><span>giriş <b>${fp(s.lp, r.sym)}</b></span><span>stop <b>${fp(s.lstop, r.sym)}</b></span><span>hedef <b>${fp(s.ltp, r.sym)}</b></span></div>` : ""}
      <div class="lsc-m">OOS ${r.oos.n} işlem · ort <b class="${r.oos.avgR > 0 ? "na" : "down"}">${f1(r.oos.avgR)}R</b> · Sharpe ${f1(r.oos.sh)}</div><div class="lsc-bot ${window.NeraBT && NeraBT.bot(r).ok ? "ok" : ""}">${window.NeraBT && NeraBT.bot(r).ok ? "✓ XM Nera açabilir" : "XM Nera açmaz"} · ${esc(window.NeraBT ? NeraBT.bot(r).why : "")}</div><div class="lsc-n">${esc(r.name)}</div></div>`; }).join("") || `<div class="empty2">Henüz kendini kanıtlamış strateji yok. Bir strateji şans sınırını geçip backtestte de kârlı çıkınca (Süpernova / Pulsar) burada canlı izlenir. Bu az görülür; dürüst sonuç budur.</div>`;
  const ge = $("#ls-grid"); if (ge._h !== gh) { ge._h = gh; ge.innerHTML = gh; }
  const hh = LabSig.hist.slice(0, 30).map((e) => `<div class="lsh" style="--tc:${e.col}"><span class="tier t-${e.k}">${e.glyph} ${e.label}</span><b>${e.code}</b><span class="${e.side > 0 ? "na" : "down"}">${e.side > 0 ? "LONG" : "SHORT"}</span><span>${NAME[e.sym] || e.sym} ${e.tf}</span><span class="muted">${fp(e.price, e.sym)}</span><span class="muted">${new Date(e.at).toLocaleString("tr-TR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" })}</span></div>`).join("") || '<div class="empty2">Henüz sinyal yok.</div>'; const he = $("#ls-hist"); if (he._h !== hh) { he._h = hh; he.innerHTML = hh; }
}
setInterval(updLS, 1000); DT.on("view", (v) => { if (v === "labsig") updLS(); });

/* ================================================================ çevrimiçi güncelleme (Ayarlar paneli + "güncelleme hazır" bildirimi)
   PC: yerel sunucu /api/update (arayüz paketi indirilir, sayfa yenilenince yeni sürüm açılır). Telefon: native ota.js (window.NeraOTA). */
const UPDI = {
  async st() { if (window.NeraOTA) return NeraOTA.status(); try { const r = await fetch("/api/update", { cache: "no-store" }); return await r.json(); } catch (e) { return null; } },
  async setUrl(u) { if (window.NeraOTA) { NeraOTA.setUrl(u); return NeraOTA.check(); } try { await fetch("/api/update", { method: "POST", body: JSON.stringify({ url: u }) }); } catch (e) { /* */ } },
  async check() { if (window.NeraOTA) return NeraOTA.check(); try { await fetch("/api/update", { method: "POST", body: "{}" }); } catch (e) { /* */ } },
  async apply() { if (window.NeraOTA) return NeraOTA.apply(); location.reload(); },
};
let updToast = 0;
async function updPanel() {
  const host = $("#pg-set"); if (!host || window.LOCAL_API && !window.NeraOTA) return; let p = $("#upd-panel");
  if (!p) { p = document.createElement("div"); p.className = "panel"; p.id = "upd-panel"; p.innerHTML = `<div class="ph">Güncelleme <small id="up-st">denetleniyor…</small></div><div class="pb"><div class="up-row"><div class="up-v"><span>Kurulu</span><b id="up-cur">—</b></div><div class="up-v"><span>Sunucuda</span><b id="up-av">—</b></div><div class="up-n" id="up-notes"></div></div>
    <label class="fld" style="margin-top:10px">Güncelleme adresi (manifest.json)<input id="up-url" placeholder="https://raw.githubusercontent.com/PazZ58/Nera/main/manifest.json"></label>
    <div class="ctl" style="margin-top:10px"><button class="btn" id="up-save">Kaydet ve denetle</button><button class="btn pri" id="up-go" style="display:none">Yeni sürümü aç</button><span class="muted" style="font-size:11.5px">Kendiliğinden denetlenir; kurulum gerekmez.</span></div></div>`;
    const lead = host.querySelector(".lead"); if (lead) lead.after(p); else host.prepend(p);
    $("#up-save").onclick = async () => { await UPDI.setUrl($("#up-url").value.trim()); setTimeout(updPanel, 2500); }; $("#up-go").onclick = () => UPDI.apply(); }
  const s = await UPDI.st(); if (!s) return; const inp = $("#up-url"); if (inp && document.activeElement !== inp && !inp.value) inp.value = s.url || "";
  $("#up-cur").textContent = "Beta"; $("#up-av").textContent = s.avail > s.cur ? "Yeni Beta" : s.avail ? "Güncel" : "—"; $("#up-notes").textContent = s.notes || "";
  $("#up-st").textContent = s.busy ? "indiriliyor…" : s.ready ? "yeni sürüm indirildi · açmaya hazır" : s.err ? (/404|Not Found/.test(s.err) ? "henüz yayınlanmış güncelleme yok" : s.err) : s.avail && s.avail <= s.cur ? `güncel · ${s.src || ""}` : s.checked ? "denetlendi" : "bekliyor";
  $("#up-go").style.display = s.ready ? "" : "none";
}
/* XM (MetaTrader 5) · yalnız PC, yalnız veri okur; bot kapalı */
async function xmPanel() {
  const host = $("#pg-set"); if (!host || window.LOCAL_API) return; let s; try { s = await (await fetch("/api/xm", { cache: "no-store" })).json(); } catch (e) { return; } let p = $("#xm-panel");
  if (!p) { p = document.createElement("div"); p.className = "panel"; p.id = "xm-panel"; p.innerHTML = `<div class="ph">XM bağlantısı (MT5) <small id="xm-st">—</small></div><div class="pb"><div class="up-row"><div class="up-v"><span>Veri</span><b id="xm-on">—</b></div><div class="up-v"><span>Hesap</span><b id="xm-acc" style="font-size:15px">—</b></div><div class="up-v"><span>Bot</span><b style="color:var(--muted)">KAPALI</b></div><div class="up-n" id="xm-syms"></div></div>
    <label class="fld" style="margin-top:10px">MT5 terminal yolu (boş = otomatik)<input id="xm-path" placeholder="C:\\Program Files\\XM Global MT5\\terminal64.exe"></label>
    <div class="ctl" style="margin-top:10px"><button class="btn pri" id="xm-go">Bağlan</button><button class="btn" id="xm-off">Kes</button><span class="muted" style="font-size:11.5px">MT5 açık ve hesaba girilmiş olmalı. Altın, gümüş ve EUR/USD verisi XM'den gelir; emir gönderilmez.</span></div></div>`;
    const up = $("#upd-panel"); if (up) up.after(p); else { const lead = host.querySelector(".lead"); if (lead) lead.after(p); else host.prepend(p); }
    const go = async (on) => { $("#xm-st").textContent = on ? "bağlanıyor…" : "kesiliyor…"; try { await fetch("/api/xm", { method: "POST", body: JSON.stringify({ on, path: $("#xm-path").value.trim() }) }); } catch (e) { /* */ } xmPanel(); };
    $("#xm-go").onclick = () => go(true); $("#xm-off").onclick = () => go(false); }
  const inp = $("#xm-path"); if (inp && document.activeElement !== inp && !inp.value) inp.value = s.path || "";
  $("#xm-on").textContent = s.ok ? "XM" : "Binance"; $("#xm-on").style.color = s.ok ? "var(--na)" : ""; $("#xm-acc").textContent = s.ok ? `${s.acc.login} · ${s.acc.server}` : "—";
  $("#xm-syms").textContent = s.ok ? Object.entries(s.syms).map(([a, b]) => `${a.replace("USDT", "")} → ${b}`).join(" · ") : "";
  $("#xm-st").textContent = s.ok ? "bağlı · yalnız okuma" : s.err ? s.err : s.on ? "bağlanıyor…" : "kapalı";
}
async function updWatch() { const s = await UPDI.st(); if (!s || !s.ready || updToast === s.avail) return; updToast = s.avail; if (window.NeraNotify) NeraNotify.push({ kind: "upd", title: "Yeni Nera Beta güncellemesi hazır", body: s.notes || "İndirildi ve doğrulandı.", sticky: true, action: ["Şimdi aç", () => UPDI.apply()] }); else if (window.Lab && Lab.toast) Lab.toast(`<b>Nera Beta güncellemesi hazır</b><br>${esc(s.notes || "")}`, "#35e0c4"); }
DT.on("view", (v) => { if (v === "set") setTimeout(() => { updPanel(); xmPanel(); }, 200); }); setInterval(() => { if (document.body.dataset.view === "set") { updPanel(); xmPanel(); } }, 5000); setInterval(updWatch, 60000); setTimeout(updWatch, 12000);

/* ================================================================ tema simgeleri */
window.THEME_ICONS = {
  neon: {
    brain: '<path class="i-ring" d="M12 2.5l8.2 4.75v9.5L12 21.5l-8.2-4.75v-9.5z"/><circle class="i-core" cx="12" cy="12" r="3"/>',
    market: '<path d="M3 20h18"/><path class="i-l1" d="M3 16l5-6 4 3 5-7 4 4"/><circle class="i-tw" cx="17" cy="6" r="1.2"/>',
    lab: '<path d="M12 3l8.5 15h-17z"/><path class="i-l1" d="M7.5 14h9"/><circle class="i-b1" cx="11" cy="16" r="1"/><circle class="i-b2" cx="13.5" cy="16.5" r=".8"/>',
    office: '<path class="i-gear" d="M12 2.5l9.5 9.5-9.5 9.5L2.5 12z"/><circle class="i-f1" cx="12" cy="12" r="2.4"/>',
    news: '<path d="M4 5h16v14H4z"/><path class="i-l1" d="M7 9h10"/><path class="i-l2" d="M7 12.5h10"/><path class="i-l3" d="M7 16h6"/>',
    friends: '<path class="i-f1" d="M8 4l4.5 8h-9z"/><path class="i-f2" d="M16 8l4.5 8h-9z"/><path d="M3 20h18"/>',
    set: '<path class="i-gear" d="M12 3l2 3.5 4-.5.5 4L22 12l-3.5 2 .5 4-4-.5L12 21l-2-3.5-4 .5-.5-4L2 12l3.5-2-.5-4 4 .5z"/><circle cx="12" cy="12" r="2.5"/>',
    menu: '<path class="i-d1" d="M3.5 12l2-2 2 2-2 2z"/><path class="i-d2" d="M10 12l2-2 2 2-2 2z"/><path class="i-d3" d="M16.5 12l2-2 2 2-2 2z"/>',
    book: '<path d="M5 3h12l2 2v16H5z"/><path class="i-l1" d="M8 8h8"/><path class="i-l2" d="M8 12h8"/><path class="i-l3" d="M8 16h5"/>',
    bt: '<path d="M3 21h18M3 3v18"/><path class="i-l1" d="M6 17l4-6 3 3 6-8"/><path class="i-tw" d="M19 3v4M17 5h4"/>',
    kb: '<path d="M12 3l8 4.5v9L12 21l-8-4.5v-9z"/><path class="i-l1" d="M4 7.5l8 4.5 8-4.5M12 12v9"/>',
    labsig: '<path class="i-core" d="M12 3l2.4 6.3H21l-5.4 4 2 6.7L12 16l-5.6 4 2-6.7L3 9.3h6.6z"/>',
  },
  ocean: {
    brain: '<g class="i-gh"><path d="M5 12a7 7 0 0 1 14 0z"/><path d="M7 12c0 3-1 5-2 8M10 12c0 3 .5 5 0 8M14 12c0 3-.5 5 0 8M17 12c0 3 1 5 2 8"/></g>',
    market: '<path class="i-l1" d="M2 16c2.5-3 4.5-3 7 0s4.5 3 7 0 4.5-3 6 0"/><path class="i-l2" d="M2 20c2.5-3 4.5-3 7 0s4.5 3 7 0 4.5-3 6 0"/><path d="M5 10l4-4 3 3 6-6"/>',
    lab: '<path d="M9 3h6M10 3v6l-5 9a2 2 0 0 0 1.8 3h10.4a2 2 0 0 0 1.8-3l-5-9V3"/><path class="i-l1" d="M6.5 15c2-1.3 3.5-1.3 5.5 0s3.5 1.3 5.5 0"/><circle class="i-b1" cx="11" cy="18" r="1"/><circle class="i-b2" cx="14" cy="18.5" r=".8"/>',
    office: '<path class="i-f1" d="M3 8.5c2-2 5-2 7 0-2 2-5 2-7 0zM10 8.5l2-1.5v3z"/><path class="i-f2" d="M10 15.5c2-2 5-2 7 0-2 2-5 2-7 0zM17 15.5l2-1.5v3z"/><circle class="i-b1" cx="19" cy="7" r="1"/>',
    news: '<path d="M10 3h4v3l2.5 3v10a2 2 0 0 1-2 2h-5a2 2 0 0 1-2-2V9L10 6z"/><path class="i-l1" d="M9.5 12h5M9.5 15h5"/>',
    friends: '<path class="i-gh" d="M3 14c3-6 10-8 16-5l2-3v6c-2 4-8 7-14 5l-4 3z"/><circle cx="16" cy="10" r=".8"/>',
    set: '<g class="i-gear"><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.5"/><path d="M12 2v5M12 17v5M2 12h5M17 12h5M4.9 4.9l3.5 3.5M15.6 15.6l3.5 3.5M19.1 4.9l-3.5 3.5M8.4 15.6l-3.5 3.5"/></g>',
    menu: '<circle class="i-b1" cx="6" cy="14" r="2"/><circle class="i-b2" cx="12" cy="13" r="2"/><circle class="i-b3" cx="18" cy="14" r="2"/>',
    book: '<path d="M12 4c-5 0-8 6-8 11h16c0-5-3-11-8-11z"/><path class="i-l1" d="M12 4v11M8.5 6l2 9M15.5 6l-2 9"/><path d="M8 15v3h8v-3"/>',
    bt: '<circle cx="12" cy="5" r="2"/><path d="M12 7v14M8 10h8M4 14c0 4 4 7 8 7s8-3 8-7"/><path class="i-l1" d="M4 14l-1.5 1.5M20 14l1.5 1.5"/>',
    kb: '<path d="M4 11h16v9H4zM4 11a8 5 0 0 1 16 0"/><path d="M11 13h2v3h-2z"/><circle class="i-tw" cx="18.5" cy="4.5" r="1"/>',
    labsig: '<path class="i-gh" d="M12 3l2 6 6 .5-4.7 3.8 1.7 6.2L12 16l-5 3.5 1.7-6.2L4 9.5l6-.5z"/>',
  },
  forest: {
    brain: '<path class="i-gh" d="M12 3c-4 0-6 3-5.5 5.5C4.5 9.5 4 13 6.5 14.5 7 17 10 17.5 12 16.5c2 1 5 .5 5.5-2C20 13 19.5 9.5 17.5 8.5 18 6 16 3 12 3z"/><path d="M12 16.5V21M12 13l-2.5-2M12 12l2.5-2.5"/>',
    market: '<path d="M3 20h18"/><path class="i-l1" d="M5 16l4-4 3 2 6-7"/><path class="i-f1" d="M18 7c0-2 1.5-3.5 3-3.5 0 2-1.5 3.5-3 3.5z"/>',
    lab: '<path class="i-pk" d="M3.5 12a8.5 7 0 0 1 17 0z"/><path d="M9.5 12v6a2.5 2.5 0 0 0 5 0v-6"/><circle class="i-tw" cx="9" cy="8.5" r="1"/><circle class="i-tw" cx="15" cy="9" r=".8"/>',
    office: '<path d="M6 8l-1-4 3.5 2.5h7L19 4l-1 4c1.3 1.5 2 3.4 2 5.5 0 4-3.6 7.5-8 7.5s-8-3.5-8-7.5c0-2.1.7-4 2-5.5z"/><circle class="i-eye" cx="9.5" cy="11" r="1.6"/><circle class="i-eye" cx="14.5" cy="11" r="1.6"/><path d="M11.3 14l.7 1 .7-1"/>',
    news: '<path d="M5 19C5 9 11 4 20 4c0 9-5 15-15 15z"/><path class="i-l1" d="M5 19L14 10"/>',
    friends: '<path class="i-f1" d="M4 9h7c0 4.5-1.8 7.5-3.5 7.5S4 13.5 4 9zM4 9a3.5 2.2 0 0 1 7 0"/><path class="i-f2" d="M13 11h7c0 4.5-1.8 7.5-3.5 7.5S13 15.5 13 11zM13 11a3.5 2.2 0 0 1 7 0"/><path d="M7.5 6.8V5M16.5 8.8V7"/>',
    set: '<g class="i-gear"><circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="5.5"/><circle cx="12" cy="12" r="2.4"/><path d="M12 3.5v3"/></g>',
    menu: '<path class="i-d1" d="M4 13c0-2 1-3.5 3-3.5 0 2-1 3.5-3 3.5z"/><path class="i-d2" d="M10.5 13c0-2 1-3.5 3-3.5 0 2-1 3.5-3 3.5z"/><path class="i-d3" d="M17 13c0-2 1-3.5 3-3.5 0 2-1 3.5-3 3.5z"/>',
    book: '<path d="M5 4h11a3 3 0 0 1 3 3v13H8a3 3 0 0 1-3-3z"/><path class="i-gh" d="M9 15c0-3 2-5 5-5 0 3-2 5-5 5zM9 15l3-3"/>',
    bt: '<path d="M2 20l6-9 4 5 3-4 7 8z"/><path class="i-l1" d="M5 20c2-3 5-3 7-6"/><circle class="i-tw" cx="18" cy="5" r="1.4"/>',
    kb: '<path d="M6 9h12c0 6-3 11-6 11s-6-5-6-11z"/><path d="M5 9a7 4 0 0 1 14 0z"/><path class="i-l1" d="M12 5V3"/>',
    labsig: '<path d="M12 8c-2 0-3 1.5-3 3.5S10 16 12 16s3-2.5 3-4.5S14 8 12 8z"/><path class="i-bat" d="M9 10c-3-2-6-1-6 1s3 2 6 1M15 10c3-2 6-1 6 1s-3 2-6 1"/><circle class="i-core" cx="12" cy="18.5" r="2"/>',
  },
  sunset: {
    brain: '<circle class="i-core" cx="12" cy="14" r="4.5"/><path class="i-ray" d="M12 4v3M4.5 7.5l2 2M19.5 7.5l-2 2M2 14h3M19 14h3"/><path d="M2 20h20"/>',
    market: '<path d="M2 20h20"/><path class="i-l1" d="M3 16l5-5 4 3 4-6 5 4"/><circle class="i-tw" cx="18" cy="5" r="1.5"/>',
    lab: '<path d="M4 4h16l-8 9z"/><path d="M12 13v7M8 20h8"/><circle class="i-b1" cx="11" cy="7" r=".9"/><circle class="i-b2" cx="13.5" cy="8" r=".7"/>',
    office: '<path d="M12 21c0-5 .5-9 1-12"/><g class="i-bat"><path d="M13 9c-2-3-6-3-8-1 3 0 5 .5 8 1zM13 9c1-3 5-4 7-2-3 0-5 1-7 2zM13 9c0-3-2-5-4-5.5 1 2 2.5 3.5 4 5.5z"/></g><path d="M6 21h12"/>',
    news: '<path class="i-bat" d="M3 10c2-2 3.5-2 5 0 1.5-2 3-2 5 0"/><path class="i-bat" d="M11 15c1.5-1.5 2.5-1.5 3.5 0 1-1.5 2-1.5 3.5 0"/><path d="M3 20h18"/>',
    friends: '<path d="M12 3v13H5z"/><path d="M13 6l6 10h-6"/><path class="i-l1" d="M3 19c2-1.5 4-1.5 6 0s4 1.5 6 0 4-1.5 6 0"/>',
    set: '<g class="i-gear"><circle cx="12" cy="12" r="4"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2"/></g>',
    menu: '<circle class="i-d1" cx="5" cy="12" r="1.9"/><circle class="i-d2" cx="12" cy="12" r="1.9"/><circle class="i-d3" cx="19" cy="12" r="1.9"/>',
    book: '<path d="M5 4h14v17H5z"/><path d="M8 14a4 4 0 0 1 8 0"/><path class="i-ray" d="M12 8v1.5M8.5 10l1 1M15.5 10l-1 1"/><path d="M7 17h10"/>',
    bt: '<path d="M3 20h18"/><path d="M6 20a6 6 0 0 1 12 0"/><path class="i-l1" d="M3 9l5 3 4-4 4 3 5-5"/>',
    kb: '<path d="M9 21l1.5-12h3L15 21z"/><path d="M8.5 9h7M10 5h4v4h-4z"/><path class="i-ray" d="M14 6l6-2M14 7.5l6 1"/>',
    labsig: '<path class="i-core" d="M15 4l1.3 3.4 3.7.2-2.9 2.3 1 3.6L15 11.4l-3.1 2.1 1-3.6L10 7.6l3.7-.2z"/><path class="i-l1" d="M10 13l-6 6M8 11l-5 3M12 15l-3 5"/>',
  },
  matrix: {
    brain: '<path d="M4 4h16v16H4z"/><path class="i-l1" d="M7 9l3 3-3 3"/><path class="i-ray" d="M12 15h5"/>',
    market: '<path d="M5 20V10M10 20V5M15 20v-8M20 20V8"/><path class="i-tw" d="M5 6.5v1M10 2v.8M15 8v1M20 4v1"/>',
    lab: '<path d="M8 4c-2 0-2 2-2 4s-2 3-2 4 2 2 2 4 0 4 2 4M16 4c2 0 2 2 2 4s2 3 2 4-2 2-2 4 0 4-2 4"/><circle class="i-d1" cx="9" cy="12" r="1"/><circle class="i-d2" cx="12" cy="12" r="1"/><circle class="i-d3" cx="15" cy="12" r="1"/>',
    office: '<rect class="i-f1" x="9.5" y="3" width="5" height="5"/><rect class="i-f2" x="3" y="16" width="5" height="5"/><rect class="i-f1" x="16" y="16" width="5" height="5"/><path class="i-l1" d="M12 8v4M5.5 16v-4h13v4"/>',
    news: '<path d="M4 4h16v16H4z"/><path class="i-l1" d="M7 8h10"/><path class="i-l2" d="M7 12h6"/><path class="i-l3" d="M7 16h8"/>',
    friends: '<circle cx="12" cy="8" r="4"/><path class="i-eye" d="M8.5 8h2.6M12.9 8h2.6"/><path d="M4 21c.5-4 3.8-6 8-6s7.5 2 8 6"/>',
    set: '<g class="i-gear"><path d="M12 3v3M12 18v3M3 12h3M18 12h3"/><rect x="7" y="7" width="10" height="10"/></g><circle class="i-core" cx="12" cy="12" r="2"/>',
    menu: '<rect class="i-d1" x="3" y="10.5" width="3" height="3"/><rect class="i-d2" x="10.5" y="10.5" width="3" height="3"/><rect class="i-d3" x="18" y="10.5" width="3" height="3"/>',
    book: '<path d="M5 3h14v18H5z"/><path class="i-l1" d="M8 7h1M11 7h5M8 11h3M13 11h3M8 15h6"/>',
    bt: '<path d="M3 20h18M3 4v16"/><path class="i-l1" d="M6 16h3v-4h3V9h3V6h3"/>',
    kb: '<ellipse cx="12" cy="6" rx="7" ry="3"/><path d="M5 6v12c0 1.7 3.1 3 7 3s7-1.3 7-3V6"/><path class="i-l1" d="M5 12c0 1.7 3.1 3 7 3s7-1.3 7-3"/>',
    labsig: '<path d="M12 3l8 4.5v9L12 21l-8-4.5v-9z"/><path class="i-core" d="M9 12l2 2 4-4"/>',
  },
};

/* ================================================================ tema efektleri (Cadılar Bayramı yarasaları gibi, her temaya özgü) */
let fxTh = null;
window.themeFx = function (th) {
  if (th === fxTh) return; fxTh = th; let el = $("#tfx"); if (el) el.remove(); if (th === "halloween") return;
  el = document.createElement("div"); el.id = "tfx"; el.className = "fx-" + th; const R = (a, b) => (a + Math.random() * (b - a)).toFixed(2), m = IS_M(), n = (d, mm) => (m ? mm : d); let h = "";
  const mk = (cls, k, fn) => { for (let i = 0; i < k; i++) h += `<i class="${cls}" style="${fn(i)}"></i>`; };
  if (th === "dark" || th === "light") mk("shoot", n(4, 2), () => `--x:${R(5, 85)}vw;--y:${R(2, 40)}vh;--d:${R(7, 14)}s;--dl:${R(0, 12)}s`);
  if (th === "black") mk("tw", n(30, 14), () => `--x:${R(0, 100)}vw;--y:${R(0, 100)}vh;--d:${R(2, 5)}s;--dl:${R(0, 5)}s;--s:${R(1, 2.4)}px`);
  if (th === "light") mk("bokeh", n(8, 4), () => `--x:${R(0, 95)}vw;--y:${R(0, 95)}vh;--d:${R(14, 26)}s;--dl:${R(0, 10)}s;--s:${R(30, 90)}px`);
  if (th === "neon") { mk("scan", 2, (i) => `--d:${8 + i * 5}s;--dl:${i * 3}s`); mk("tri", n(8, 4), () => `--x:${R(0, 96)}vw;--d:${R(14, 26)}s;--dl:${R(0, 14)}s;--s:${R(8, 18)}px`); }
  if (th === "ocean") mk("bub", n(18, 9), () => `--x:${R(0, 98)}vw;--d:${R(9, 20)}s;--dl:${R(0, 16)}s;--s:${R(5, 16)}px`);
  if (th === "forest") { mk("fly", n(16, 8), () => `--x:${R(0, 96)}vw;--y:${R(10, 95)}vh;--d:${R(6, 12)}s;--dl:${R(0, 8)}s;--dx:${R(-60, 60)}px;--dy:${R(-50, 50)}px`); mk("leaf", n(4, 2), () => `--x:${R(5, 90)}vw;--d:${R(14, 24)}s;--dl:${R(0, 14)}s`); }
  if (th === "sunset") { mk("ember", n(16, 8), () => `--x:${R(0, 98)}vw;--d:${R(10, 20)}s;--dl:${R(0, 14)}s`); for (let i = 0; i < n(3, 2); i++) h += `<svg class="bird" style="--y:${R(6, 34)}vh;--d:${R(22, 36)}s;--dl:${R(0, 20)}s" viewBox="0 0 30 12"><path d="M1 8c4-5 8-5 14 0 6-5 10-5 14 0"/></svg>`; }
  if (th === "matrix") { const g = "01ﾊﾐﾋｰｳｼﾅﾓﾆｻﾜﾂｵﾘｱﾎﾃﾏｹﾒｴｶｷﾑﾕﾗｾﾈｽﾀﾇﾍ"; for (let i = 0; i < n(12, 6); i++) { let s = ""; for (let k = 0; k < 18; k++) s += g[Math.floor(Math.random() * g.length)] + "<br>"; h += `<b class="code" style="--x:${R(0, 98)}vw;--d:${R(9, 18)}s;--dl:${R(0, 12)}s">${s}</b>`; } }
  el.innerHTML = h; document.body.appendChild(el);
};
})();
