"use strict";
/* NeraFlow ekranı (yalnız PC). Binance USDⓈ-M vadeli CANLI verisi, tahmin yok:
   - işlemler: aggTrade akışı + geçmiş için REST aggTrades (canlı akışın ilk kimliğinden geriye, kesintisiz) → mum × fiyat seviyesi alış/satış (footprint)
   - emir defteri: REST snapshot + depth@100ms farkları (Binance'in anlattığı senkron sırası; kimlik zinciri bozulursa yeniden kurar) → ısı haritası, DOM
   - mumlar: REST klines (açılış/yüksek/düşük/kapanış, taker alış hacmi gerçek)
   Footprint hücresi yalnız işlem verisi olan aralıkta çizilir; verinin başladığı mum "kısmi" etiketlenir, öncesi yalnız mumdur (uydurma dolgu yok).
   Kod Flowsurface'ten kopyalanmadı (GPL); yalnız pano türleri ve davranışı örnek alınarak kendi kodumuzla yazıldı. Ortak: NFX (bu dosya), çizim: lab/nflow_draw.js. */
(function () {
if (window.Capacitor || window.LOCAL_API) return;
const SY = [["BTCUSDT", "BTC", "₿"], ["ETHUSDT", "ETH", "Ξ"], ["XAUUSDT", "Altın", "Au"], ["XAGUSDT", "Gümüş", "Ag"]];
const TFS = { "1m": 60, "5m": 300, "15m": 900, "30m": 1800, "1h": 3600 };
const API = "https://fapi.binance.com/fapi/v1/";
const TICK0 = { BTCUSDT: 0.1, ETHUSDT: 0.01, XAUUSDT: 0.01, XAGUSDT: 0.001 };
/* Varsayılanlar Flowsurface'in kendi varsayılanlarıdır (kaynak okunarak alındı, kod değil): mum 5 dk; DOM/ısı haritası fiyat grubu = en küçük adımın ×10'u;
   footprint dengesizlik eşiği %200 (karşı çaprazın 3 katından FAZLA, sıfırlar yok sayılır); büyük işlem eşiği 2.500.000 $ (10 bin – 25 mn arası ayarlanır);
   ısı haritası işlem filtresi 0 (hepsi). Hiçbiri bizim seçimimiz değil; Ayarlar düğmesinden değiştirilir. */
const MULTS = [1, 2, 5, 10, 25, 50, 100], MULT0 = 10;
const CFG0 = { imb: 200, big: 2500000, dot: 0 };
const COLS_KEEP = 1400, COL_MS = 500, BACK_PAGES = 80;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const store = (k, d) => { try { return localStorage.getItem(k) || d; } catch (e) { return d; } };
const N = { sym: store("nf_sym", "BTCUSDT"), tf: store("nf_tf", "5m"), mult: {}, cfg: Object.assign({}, CFG0), win: +store("nf_win", 300), tick: Object.assign({}, TICK0), tk: {}, H: null, gen: 0, ws: [], ui: false };
SY.forEach(([s]) => { N.mult[s] = +store("nf_mult_" + s, MULT0); });
try { Object.assign(N.cfg, JSON.parse(store("nf_cfg", "{}"))); } catch (e) { /* varsayılan */ }
N.saveCfg = () => { try { localStorage.setItem("nf_cfg", JSON.stringify(N.cfg)); } catch (e) { /* */ } };
window.NFX = N;

function newHub(sym) {
  return { sym, gen: N.gen, dead: false, bars: {}, lists: {}, trades: [], bigs: [], dots: [], dotIdx: new Map(), liqs: [], cnt: 0, px: 0, firstId: 0, lastId: 0, cov: Infinity, pages: 0, backDone: false,
    bids: new Map(), asks: new Map(), dbuf: [], dready: false, snapBusy: false, snapAt: 0, backErr: 0, lastU: 0, resyncs: 0, cols: [], cmax: 1, liveT: 0, ver: 0, vol60: [] };
}
function bar(h, tf, t) {
  const B = h.bars[tf] || (h.bars[tf] = new Map());
  let b = B.get(t);
  if (!b) { b = { t, o: 0, h: -Infinity, l: Infinity, c: 0, t0: Infinity, t1: -Infinity, cells: new Map(), B: 0, S: 0, n: 0, kl: null }; B.set(t, b); h.lists[tf] = null; }
  return b;
}
/* her işlem tüm zaman dilimlerinin mumlarına yazılır; mum fiyatı ilk/son işlem zamanına göre kurulur, sıralama gelişinden bağımsızdır */
function addTrade(h, p, q, sell, T, live) {
  const k = Math.round(p / N.tick[h.sym]);
  for (const tf in TFS) {
    const b = bar(h, tf, Math.floor(T / 1000 / TFS[tf]) * TFS[tf]);
    let c = b.cells.get(k);
    if (!c) b.cells.set(k, (c = [0, 0]));
    if (sell) { c[1] += q; b.S += q; } else { c[0] += q; b.B += q; }
    b.n++;
    if (p > b.h) b.h = p;
    if (p < b.l) b.l = p;
    if (T < b.t0) { b.t0 = T; b.o = p; }
    if (T >= b.t1) { b.t1 = T; b.c = p; }
  }
  if (T < h.cov) h.cov = T;
  const usd = p * q;
  /* ısı haritası noktaları: 500 ms sütun × fiyat satırı toplamı (Flowsurface ısı haritası işlemleri de böyle toplar) */
  const col = Math.floor(T / COL_MS) * COL_MS, key = col + ":" + k;
  let dt = h.dotIdx.get(key);
  if (!dt) { dt = { T: col, k, B: 0, S: 0 }; h.dotIdx.set(key, dt); h.dots.push(dt); }
  if (sell) dt.S += usd; else dt.B += usd;
  if (h.dots.length > 7000) { h.dots.splice(0, 1500).forEach((d) => h.dotIdx.delete(d.T + ":" + d.k)); }
  if (live) {
    h.px = p; h.liveT = T;
    h.trades.push({ T, p, q, sell, usd });
    if (h.trades.length > 600) h.trades.splice(0, 100);
    h.cnt++;
    if (usd >= N.cfg.big) { h.bigs.push({ T, p, usd, sell }); if (h.bigs.length > 300) h.bigs.splice(0, 100); }
  }
  h.ver++;
}
function list(h, tf) {
  if (!h.lists[tf]) h.lists[tf] = [...(h.bars[tf] || new Map()).values()].sort((a, b) => a.t - b.t);
  return h.lists[tf];
}
/* mum değerleri: klines varsa onların açılışı; yüksek/düşük işlemlerle birleşir; kapanış, klines'tan sonra işlem geldiyse işlemden */
function ohlc(b) {
  const k = b.kl;
  if (!k) return { o: b.o, h: b.h, l: b.l, c: b.c };
  return { o: k.o, h: Math.max(k.h, b.h), l: Math.min(k.l, b.l === Infinity ? k.l : b.l), c: b.t1 > k.at ? b.c : k.c };
}
function totals(b, full) {
  if (b.kl && !full) return { v: b.kl.v, buy: b.kl.tbv, sell: b.kl.v - b.kl.tbv };
  return { v: b.B + b.S, buy: b.B, sell: b.S };
}

/* ---------- emir defteri: snapshot + diff senkronu */
function setLvl(m, p, q) { if (q === 0) m.delete(p); else m.set(p, q); }
function applyDepth(h, d) { d.b.forEach(([p, q]) => setLvl(h.bids, Math.round(+p / N.tick[h.sym]), +q)); d.a.forEach(([p, q]) => setLvl(h.asks, Math.round(+p / N.tick[h.sym]), +q)); }
function onDepth(h, d) {
  if (h.dead) return;
  if (!h.dready) { h.dbuf.push(d); if (h.dbuf.length > 3000) h.dbuf.splice(0, 1000); if (!h.snapBusy && Date.now() >= h.snapAt) snap(h); return; }
  if (d.pu !== h.lastU) { h.resyncs++; h.dready = false; h.dbuf = [d]; if (!h.snapBusy && Date.now() >= h.snapAt) snap(h); return; }
  applyDepth(h, d); h.lastU = d.u;
}
/* anlık görüntü en çok 3 sn'de bir istenir (Binance hız sınırı: başarısızlıkta her olayda yeniden istemek IP engeli getirir); 418/429'da 60 sn beklenir */
async function snap(h) {
  h.snapBusy = true; h.snapAt = Date.now() + 3000;
  try {
    const r = await fetch(`${API}depth?symbol=${h.sym}&limit=1000`);
    if (r.status === 418 || r.status === 429) { h.snapAt = Date.now() + 60000; h.snapBusy = false; return; }
    const j = await r.json();
    if (h.dead || !j.bids) { h.snapBusy = false; return; }
    /* anlık görüntü akıştan biraz ileride olabilir: onu kapsayan olayın gelmesini bekle (en çok 4 sn) */
    let buf = [];
    for (let i = 0; i < 40 && !h.dead; i++) { buf = h.dbuf.filter((e) => e.u >= j.lastUpdateId); if (buf.length) break; await sleep(100); }
    if (h.dead || !buf.length || buf[0].U > j.lastUpdateId) { h.snapBusy = false; return; }
    h.bids.clear(); h.asks.clear();
    const tk = N.tick[h.sym];
    j.bids.forEach(([p, q]) => h.bids.set(Math.round(+p / tk), +q));
    j.asks.forEach(([p, q]) => h.asks.set(Math.round(+p / tk), +q));
    let prev = 0;
    for (const e of buf) { if (prev && e.pu !== prev) { h.snapBusy = false; return; } applyDepth(h, e); prev = e.u; }
    h.lastU = prev; h.dbuf = []; h.dready = true;
  } catch (e) { /* ağ: bir sonraki olayda (3 sn sonra) yeniden dener */ }
  h.snapBusy = false;
}
function bestBook(h) {
  let bb = -Infinity, ba = Infinity;
  h.bids.forEach((q, k) => { if (k > bb) bb = k; });
  h.asks.forEach((q, k) => { if (k < ba) ba = k; });
  return bb === -Infinity || ba === Infinity ? null : { bb, ba };
}
/* her 500 ms bir ısı haritası sütunu: mid çevresinde ±%3, taraf başına en çok 600 seviye (alış +, satış −) */
function sample(h) {
  if (!h.dready) return;
  const bk = bestBook(h); if (!bk) return;
  const tk = N.tick[h.sym], mid = (bk.bb + bk.ba) / 2 * tk, lim = mid * 0.03 / tk;
  const bs = [...h.bids.entries()].filter(([k]) => bk.bb - k <= lim).sort((a, b) => b[0] - a[0]).slice(0, 600);
  const as = [...h.asks.entries()].filter(([k]) => k - bk.ba <= lim).sort((a, b) => a[0] - b[0]).slice(0, 600);
  const n = bs.length + as.length, K = new Int32Array(n), Q = new Float32Array(n);
  let i = 0, mx = 0;
  bs.forEach(([k, q]) => { K[i] = k; Q[i++] = q; });
  as.forEach(([k, q]) => { K[i] = k; Q[i++] = -q; });
  for (let j = 0; j < n; j++) { const a = Math.abs(Q[j]); if (a > mx && Math.abs(K[j] - (bk.bb + bk.ba) / 2) < lim * 0.1) mx = a; }
  h.cmax = h.cmax * 0.98 + mx * 0.02 || mx || 1;
  h.cols.push({ T: Date.now(), mid, bb: bk.bb * tk, ba: bk.ba * tk, K, Q });
  if (h.cols.length > COLS_KEEP) h.cols.splice(0, h.cols.length - COLS_KEEP);
  h.ver++;
}

/* ---------- bağlantı */
function openWS(h, urls, onmsg) {
  let i = 0;
  const go = () => {
    if (h.dead) return;
    let ws, got = false;
    try { ws = new WebSocket(urls[i++ % urls.length]); } catch (e) { setTimeout(go, 4000); return; }
    h.socks.push(ws);
    ws.onmessage = (e) => { got = true; N.ok = Date.now(); let m; try { m = JSON.parse(e.data); } catch (er) { return; } if (m && m.data) onmsg(m.data); };
    ws.onclose = () => { if (!h.dead) setTimeout(go, 2500); };
    ws.onerror = () => { try { ws.close(); } catch (e) { /* */ } };
    setTimeout(() => { if (!got && !h.dead) { try { ws.close(); } catch (e) { /* */ } } }, 9000);
  };
  go();
}
async function ticks() {
  try {
    const c = JSON.parse(store("nf_ticks", "null"));
    if (c && Date.now() - c.t < 86400000) { Object.assign(N.tick, c.v); return; }
    const j = await (await fetch(API + "exchangeInfo")).json(), v = {};
    j.symbols.forEach((s) => { const f = s.filters.find((x) => x.filterType === "PRICE_FILTER"); if (f && N.tick[s.symbol] !== undefined) v[s.symbol] = +f.tickSize; });
    Object.assign(N.tick, v);
    try { localStorage.setItem("nf_ticks", JSON.stringify({ t: Date.now(), v })); } catch (e) { /* */ }
  } catch (e) { /* sabit tablo */ }
}
async function klines(h) {
  for (const tf in TFS) {
    try {
      const a = await (await fetch(`${API}klines?symbol=${h.sym}&interval=${tf}&limit=300`)).json(), at = Date.now();
      a.forEach((x) => { const b = bar(h, tf, Math.floor(x[0] / 1000)); b.kl = { o: +x[1], h: +x[2], l: +x[3], c: +x[4], v: +x[5], tbv: +x[9], at }; });
      h.ver++;
    } catch (e) { /* bir sonraki bağlantıda */ }
  }
}
/* canlı akışın ilk işlem kimliğinden geriye 1000'lik sayfalar: kimlikler kesintisiz olduğu için canlıyla çakışma ve boşluk olmaz */
async function backfill(h) {
  while (!h.firstId && !h.dead) await sleep(200);
  if (Date.now() < (N.ban || 0)) { h.backErr = 418; h.backDone = true; return; }
  let from = h.firstId - 1000;
  /* sayfa başına 1,5 sn: aggTrades ağırlığı 20, dakikada ~800 (sınır 2400); Nera'nın diğer istekleriyle birlikte güvenli */
  for (let n = 0; n < BACK_PAGES && !h.dead; n++) {
    try {
      const r = await fetch(`${API}aggTrades?symbol=${h.sym}&fromId=${Math.max(0, from)}&limit=1000`);
      if (r.status === 418 || r.status === 429) { h.backErr = r.status; N.ban = Date.now() + 180000; break; }
      if (!r.ok) break;
      const a = await r.json(); if (!a.length) break;
      a.forEach((t) => { if (t.a < h.firstId) addTrade(h, +t.p, +t.q, !!t.m, t.T, false); });
      h.pages++;
      if (from <= 0) break;
      from -= 1000;
    } catch (e) { break; }
    await sleep(1500);
  }
  h.backDone = true;
}
function connect() {
  if (N.H) { N.H.dead = true; (N.H.socks || []).forEach((w) => { try { w.close(); } catch (e) { /* */ } }); clearInterval(N.H.timer); }
  N.gen++;
  const h = newHub(N.sym); h.socks = []; N.H = h;
  const ls = N.sym.toLowerCase(), mini = SY.map(([s]) => s.toLowerCase() + "@miniTicker");
  const onm = (d) => {
    if (h.dead) return;
    if (d.e === "aggTrade") { if (!h.firstId) h.firstId = d.a; addTrade(h, +d.p, +d.q, !!d.m, d.T, true); h.lastId = d.a; }
    else if (d.e === "forceOrder") { const o = d.o; if (o && o.s === h.sym) { const q = +(o.z || o.q), p = +(o.ap || o.p); h.liqs.push({ T: d.E, p, q, usd: p * q, sell: o.S === "SELL" }); if (h.liqs.length > 200) h.liqs.splice(0, 50); } }
    else if (d.e === "24hrMiniTicker") N.tk[d.s] = { last: +d.c, open: +d.o, vol: +d.q };
    else if (d.e === "depthUpdate") onDepth(h, d);
  };
  const mk = (path, st) => `wss://fstream.binance.com/${path}stream?streams=` + st.join("/");
  openWS(h, [mk("market/", [ls + "@aggTrade", ls + "@forceOrder"].concat(mini)), mk("", [ls + "@aggTrade", ls + "@forceOrder"].concat(mini))], onm);
  openWS(h, [mk("public/", [ls + "@depth@100ms"]), mk("", [ls + "@depth@100ms"]), mk("market/", [ls + "@depth@100ms"])], onm);
  h.timer = setInterval(() => sample(h), COL_MS);
  klines(h); backfill(h);
}
N.setSym = (s) => { N.sym = s; try { localStorage.setItem("nf_sym", s); } catch (e) { /* */ } connect(); };
N.start = async () => { if (N.ui) return; N.ui = true; await ticks(); connect(); };
N.stop = () => { if (N.H) { N.H.dead = true; (N.H.socks || []).forEach((w) => { try { w.close(); } catch (e) { /* */ } }); clearInterval(N.H.timer); } N.ui = false; };
N.list = list; N.ohlc = ohlc; N.totals = totals; N.bestBook = bestBook; N.SY = SY; N.TFS = TFS; N.MULTS = MULTS;
window.NFD = { sleep, store };
})();
