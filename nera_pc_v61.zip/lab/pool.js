"use strict";
/* Nera · Bilardo (8 top). Arkadaşlar ekranında. 2–4 oyuncu, A/B takımı (sıra takımlar arasında döner), izleyiciler.
   Ağ: arkadaş grubunun ntfy konusu <grup>_pool. Atışı yapan cihaz fiziği hesaplar ve sonucu (topların son yeri + kural durumu) yayınlar;
   diğerleri aynı atışı canlandırıp sonuca oturur (yetkili atıcı). Lobi: masa kur → takım seç → Hazır; takımlardaki herkes hazırsa oyun başlar.
   Kurallar: standart 8 top (düz 1-7 / çizgili 9-15), faulde rakibe "top elde", 8'i erken ya da faulle sokan kaybeder. */
(function () {
const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s == null ? "" : s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const F = () => window.NeraFriends || {}, NT = "https://ntfy.sh/";
const W = 1000, H = 500, R = 11, RAIL = 44, MU = 92, VMAX = 2500, DT = 1 / 240;
const PK = [[-7, -7, 23], [W / 2, -11, 19], [W + 7, -7, 23], [-7, H + 7, 23], [W / 2, H + 11, 19], [W + 7, H + 7, 23]];
const COL = { 1: "#f5c518", 2: "#1f5fd6", 3: "#e0262b", 4: "#5b2a86", 5: "#f07d1a", 6: "#18864b", 7: "#7a1f1f", 8: "#111", 9: "#f5c518", 10: "#1f5fd6", 11: "#e0262b", 12: "#5b2a86", 13: "#f07d1a", 14: "#18864b", 15: "#7a1f1f" };
const grp = (n) => (n >= 1 && n <= 7 ? "solid" : n >= 9 ? "stripe" : n === 8 ? "eight" : "cue"), GRN = { solid: "Düzler (1-7)", stripe: "Çizgililer (9-15)" };
const CUES = [["classic", "Klasik"], ["neon", "Neon"], ["halloween", "Cadı"], ["matrix", "Matrix"], ["ocean", "Okyanus"], ["forest", "Orman"], ["sunset", "Gün batımı"], ["gold", "Altın"]];
const themeNow = () => (document.body.className.match(/theme-(\w+)/) || [])[1] || "dark";
const P = { tables: {}, cur: null, view: "lobby", G: null, anim: null, pend: null, aim: 0, pow: 0, press: null, placed: false, es: null, seen: new Set(), mine: null, cue: localStorage.getItem("nera_cue") || null, practice: false, fx: [], t: 0, mouse: null };
const myCue = () => P.cue || ({ neon: "neon", halloween: "halloween", matrix: "matrix", ocean: "ocean", forest: "forest", sunset: "sunset" }[themeNow()] || "classic");
const rng = (a) => () => { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };

/* ---------------- fizik ---------------- */
function rack(seed) {
  const r = rng(seed), rest = [1, 2, 3, 4, 5, 6, 7, 9, 10, 11, 12, 13, 14, 15]; for (let i = rest.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [rest[i], rest[j]] = [rest[j], rest[i]]; }
  const solids = rest.filter((n) => n < 8), stripes = rest.filter((n) => n > 8), order = []; const cornerA = solids.pop(), cornerB = stripes.pop(); const mid = rest.filter((n) => n !== cornerA && n !== cornerB);
  const B = [{ n: 0, x: W * 0.25, y: H / 2, vx: 0, vy: 0, in: false }], ax = W * 0.72, dx = R * 2 * 0.866 + 0.4; let k = 0;
  for (let row = 0; row < 5; row++) for (let i = 0; i <= row; i++) { let n; if (row === 2 && i === 1) n = 8; else if (row === 4 && i === 0) n = cornerA; else if (row === 4 && i === 4) n = cornerB; else n = mid[k++]; order.push(n); B.push({ n, x: ax + row * dx, y: H / 2 + (i - row / 2) * (R * 2 + 0.4), vx: 0, vy: 0, in: false }); }
  return B;
}
function step(B, ev) {
  for (const b of B) { if (b.in) continue; b.x += b.vx * DT; b.y += b.vy * DT; const sp = Math.hypot(b.vx, b.vy); if (sp > 0) { const ns = Math.max(0, sp - MU * DT); b.vx *= ns / sp; b.vy *= ns / sp; } }
  for (let i = 0; i < B.length; i++) { const a = B[i]; if (a.in) continue; for (let j = i + 1; j < B.length; j++) { const b = B[j]; if (b.in) continue; const dx = b.x - a.x, dy = b.y - a.y, d = Math.hypot(dx, dy); if (d >= 2 * R || d === 0) continue;
    const nx = dx / d, ny = dy / d, rv = (a.vx - b.vx) * nx + (a.vy - b.vy) * ny, ov = (2 * R - d) / 2; a.x -= nx * ov; a.y -= ny * ov; b.x += nx * ov; b.y += ny * ov; if (rv <= 0) continue; const jm = rv * (1 + 0.95) / 2;
    a.vx -= jm * nx; a.vy -= jm * ny; b.vx += jm * nx; b.vy += jm * ny;
    if (ev) { if (ev.first == null && (a.n === 0 || b.n === 0)) { ev.first = a.n === 0 ? b.n : a.n; const sp = ev.spin; if (sp && sp.y) { const cu = a.n === 0 ? a : b, ob = a.n === 0 ? b : a, os = Math.hypot(ob.vx, ob.vy); cu.vx += sp.dx * sp.y * 0.6 * os; cu.vy += sp.dy * sp.y * 0.6 * os; } } ev.hits.push(rv); if (ev.hp) ev.hp.push([(a.x + b.x) / 2, (a.y + b.y) / 2, rv]); } } }          // üst/alt falso: beyaz çarpışmadan sonra ilerler / geri gelir
  for (const b of B) { if (b.in) continue; for (const [px, py, pr] of PK) if (Math.hypot(b.x - px, b.y - py) < pr) { b.in = true; b.vx = b.vy = 0; if (ev) ev.pot.push(b.n); break; } if (b.in) continue;
    const mouthX = b.x < 34 || b.x > W - 34 || Math.abs(b.x - W / 2) < 24, mouthY = b.y < 34 || b.y > H - 34;
    const side = b.n === 0 && ev && ev.spin && ev.spin.x ? ev.spin.x * 0.22 : 0;          // yan falso: bant dönüşünü saptırır
    if (b.x < R && !(mouthY && b.x < 34)) { b.x = R; b.vx = -b.vx * 0.84; b.vy += side * Math.abs(b.vx); if (ev) ev.rail = 1; } if (b.x > W - R && !(mouthY && b.x > W - 34)) { b.x = W - R; b.vx = -b.vx * 0.84; b.vy -= side * Math.abs(b.vx); if (ev) ev.rail = 1; }
    if (b.y < R && !mouthX) { b.y = R; b.vy = -b.vy * 0.84; b.vx -= side * Math.abs(b.vy); if (ev) ev.rail = 1; } if (b.y > H - R && !mouthX) { b.y = H - R; b.vy = -b.vy * 0.84; b.vx += side * Math.abs(b.vy); if (ev) ev.rail = 1; }
    if (b.x < -40 || b.x > W + 40 || b.y < -40 || b.y > H + 40) { b.in = true; b.vx = b.vy = 0; if (ev) ev.pot.push(b.n); } }
  return B.every((b) => b.in || Math.hypot(b.vx, b.vy) < 3);
}
const clone = (B) => B.map((b) => Object.assign({}, b)), cueB = (G) => G.balls.find((b) => b.n === 0);
function shoot(G, ang, pow, cx, cy, spin) { const B = clone(G.balls), c = B.find((b) => b.n === 0); if (cx != null) { c.x = cx; c.y = cy; c.in = false; } const v = Math.max(0.03, Math.min(1, pow)) * VMAX; c.vx = Math.cos(ang) * v; c.vy = Math.sin(ang) * v; const sp = spin ? { x: +spin[0] || 0, y: +spin[1] || 0, dx: Math.cos(ang), dy: Math.sin(ang) } : null; return { B, ev: { first: null, pot: [], hits: [], hp: [], rail: 0, spin: sp }, steps: 0 }; }
function runAll(S) { let k = 0; while (!step(S.B, S.ev) && k < 240 * 40) k++; S.B.forEach((b) => { b.vx = b.vy = 0; }); return S; }

/* ---------------- kurallar (atıcı uygular) ---------------- */
const teamOf = (G, id) => G.teams[id], curId = (G) => G.order[G.turn % G.order.length], other = (t) => (t === "A" ? "B" : "A");
const cleared = (G, team, B) => { const g = G.groups[team]; return !!g && B.filter((b) => grp(b.n) === g).every((b) => b.in); };
function rules(G, S) {
  const id = curId(G), T = teamOf(G, id), g = G.groups[T], pot = S.ev.pot, first = S.ev.first, before = cleared(G, T, G.balls), B = S.B;
  const N = Object.assign({}, G, { balls: B, n: G.n + 1, groups: Object.assign({}, G.groups), bih: false, brk: false, tt: Date.now() });
  const scratch = pot.includes(0); let foul = false, why = "";
  if (scratch) { foul = true; why = "beyaz top deliğe girdi"; }
  else if (first == null) { foul = true; why = "hiçbir topa değmedi"; }
  else if (g && before && first !== 8) { foul = true; why = "grubun bitti, önce 8'e değmeliydi"; }
  else if (g && !before && grp(first) !== g) { foul = true; why = `önce kendi grubuna (${GRN[g]}) değmeliydi`; }
  else if (!g && first === 8 && !G.brk) { foul = true; why = "grup belli değilken önce 8'e değdi"; }
  if (pot.includes(8)) {
    if (G.brk && !scratch) { const e = B.find((b) => b.n === 8); e.in = false; e.x = W * 0.72; e.y = H / 2; }
    else { const win = !foul && before; N.win = win ? T : other(T); N.msg = win ? `${T} takımı 8'i sokup kazandı!` : `${T} takımı 8'i ${foul ? "faulle" : "erken"} soktu · ${other(T)} kazandı`; N.foul = foul; N.mvp = win; N.potted = pot.filter((n) => n); N.by = id; return N; }
  }
  const objs = pot.filter((n) => n !== 0 && n !== 8);
  if (!foul && !g && !G.brk && objs.length) { const ng = grp(objs[0]); N.groups[T] = ng; N.groups[other(T)] = ng === "solid" ? "stripe" : "solid"; }
  const keep = !foul && (G.brk ? objs.length > 0 : objs.some((n) => grp(n) === N.groups[T]));
  if (scratch) { const c = B.find((b) => b.n === 0); c.in = false; c.x = W * 0.25; c.y = H / 2; }
  if (foul) { N.turn = G.turn + 1; N.bih = true; N.msg = `Faul: ${why} · ${other(T)} takımına top elde`; }
  else if (keep) N.msg = `${objs.length} top girdi · sıra devam`;
  else { N.turn = G.turn + 1; N.msg = objs.length ? "Rakibin topu girdi · sıra geçti" : "Top girmedi · sıra geçti"; }
  if (G.brk && !foul) N.msg = (keep ? "Açılışta top girdi · sıra devam" : "Açılış yapıldı · sıra geçti") + " · masa açık";
  if (!N.groups[T] && N.groups.A) N.msg += ` · ${T}: ${GRN[N.groups[T]] || ""}`;
  if (N.groups[T] && !G.groups[T]) N.msg += ` · ${T} takımı ${GRN[N.groups[T]]}`;
  N.foul = foul; N.potted = objs; N.by = id; N.cleared = !!(N.groups[T] && !before && cleared(N, T, B)); return N;
}
function newGame(tid, order, teams, seed, cues) { return { tid, balls: rack(seed), order, teams, cues: cues || {}, turn: 0, groups: { A: null, B: null }, bih: true, brk: true, win: null, n: 0, msg: "Açılış: beyaz topu sol çeyreğe yerleştir ve vur", t0: Date.now() }; }

/* ---------------- ağ ---------------- */
const topic = () => (F().pre ? F().pre() + "_pool" : "nera7_genel_pool");
const pub = (o) => { const me = F().me ? F().me() : "", key = o.k === "pl" ? `pl_${o.tid}_${me}` : o.k === "tbl" ? `tbl_${o.tid}` : null;          // lobi kayıtları üstüne yazılır (birikmez)
  return NeraNet.pub(topic(), Object.assign({ t: Date.now() }, o), key ? { key } : {}).then(() => { P.quota = false; }).catch((e) => { P.quota = /429/.test(e.message); }); };
function onMsg(m, replay) {
  if (!m || m.event !== "message" || P.seen.has(m.id)) return; P.seen.add(m.id); let o; try { o = JSON.parse(m.message); } catch (e) { return; } if (!o || !o.tid) return;
  const T = P.tables[o.tid] = P.tables[o.tid] || { tid: o.tid, players: {}, st: "lobby", t: o.t };
  if (o.k === "tbl") { Object.assign(T, { host: o.host, hostNick: o.hostNick, st: o.st || T.st, t: Math.max(T.t || 0, o.t) }); }
  else if (o.k === "pl") { T.players[o.id] = { nick: o.nick, team: o.team || null, ready: !!o.ready, cue: o.cue, t: o.t }; T.t = Math.max(T.t || 0, o.t); maybeStart(T); }
  else if (o.k === "lv") { delete T.players[o.id]; }
  else if (o.k === "go") { T.st = "game"; T.G = newGame(o.tid, o.order, o.teams, o.seed, o.cues); if (P.cur === o.tid) { P.G = T.G; P.view = "game"; if (!replay) { P.fx.push({ k: "break", t: 0 }); sfx(330, 0.2); } } }
  else if (o.k === "shot") { if (!replay && P.cur === o.tid && P.G && o.n === P.G.n + 1 && o.by !== F().me()) { P.anim = shoot(P.G, o.ang, o.pow, o.cx, o.cy, o.spin); P.anim.by = o.by; P.anim.ang = o.ang; P.anim.cue = o.cue; P.anim.strike = 0; } }
  else if (o.k === "res") { const G = o.G; if (!T.G || G.n > T.G.n) { T.G = G; if (G.win) T.st = "over"; } if (P.cur === o.tid && P.G && G.n > P.G.n) { if (P.anim && !replay) P.pend = G; else { P.G = G; P.anim = null; if (!replay) afterShot(G); } } }
  else if (o.k === "close") { T.st = "closed"; }
  if (!replay) render();
}
async function connect() {
  if (!F().me || !F().me()) return; if (P.es) P.es(); let rp = true; setTimeout(() => { rp = false; if (P.cur && P.tables[P.cur] && P.tables[P.cur].G && !P.G) { P.G = P.tables[P.cur].G; P.view = P.tables[P.cur].st === "lobby" ? "lobby" : "game"; } render(); }, 2500);
  P.es = NeraNet.listen([[topic(), Date.now() - 3 * 3600e3]], (m, replay) => onMsg(m, replay || rp)); render();
}
const live = (T) => Object.entries(T.players).filter(([, p]) => Date.now() - p.t < 200000);
function maybeStart(T) {
  if (!F().me || T.host !== F().me() || T.st !== "lobby") return; const L = live(T), A = L.filter(([, p]) => p.team === "A"), B = L.filter(([, p]) => p.team === "B");
  if (A.length && B.length && A.length + B.length <= 4 && [...A, ...B].every(([, p]) => p.ready)) { clearTimeout(T._go); T._go = setTimeout(() => { const L2 = live(T), a = L2.filter(([, p]) => p.team === "A").map(([i]) => i), b = L2.filter(([, p]) => p.team === "B").map(([i]) => i); if (!a.length || !b.length) return; const order = []; for (let i = 0; i < Math.max(a.length, b.length); i++) order.push(a[i % a.length], b[i % b.length]); const teams = {}, cues = {}; L2.forEach(([i, p]) => { if (p.team) teams[i] = p.team; cues[i] = p.cue; }); pub({ k: "tbl", tid: T.tid, host: T.host, hostNick: T.hostNick, st: "game" }); const go = { k: "go", tid: T.tid, order, teams, cues, seed: (Math.random() * 1e9) | 0, t: Date.now() }; pub(go); onMsg({ event: "message", id: "loc" + go.seed, message: JSON.stringify(go) }); }, 1800); }
}
function myPl(patch) { const T = P.tables[P.cur]; if (!T) return; const me = F().me(), cur = T.players[me] || { team: null, ready: false }; const o = Object.assign({ k: "pl", tid: P.cur, id: me, nick: F().nick(), team: cur.team, ready: cur.ready, cue: myCue() }, patch); T.players[me] = { nick: o.nick, team: o.team, ready: o.ready, cue: o.cue, t: Date.now() }; pub(o); maybeStart(T); render(); }
function createTable() { const me = F().me(); if (!me) return alert("Önce profilde takma adını kaydet."); const tid = "t" + Math.random().toString(36).slice(2, 8); P.tables[tid] = { tid, host: me, hostNick: F().nick(), players: {}, st: "lobby", t: Date.now() }; P.cur = tid; P.view = "lobby"; pub({ k: "tbl", tid, host: me, hostNick: F().nick(), st: "lobby" }); myPl({ team: "A", ready: false }); }
function leave() { if (P.cur && !P.practice) { pub({ k: "lv", tid: P.cur, id: F().me() }); const T = P.tables[P.cur]; if (T && T.host === F().me() && T.st === "lobby") pub({ k: "close", tid: P.cur }); } P.cur = null; P.G = null; P.anim = null; P.practice = false; P.view = "lobby"; render(); }
setInterval(() => { if (P.cur && !P.practice && F().me && F().me()) { const T = P.tables[P.cur]; if (T && T.players[F().me()]) myPl({}); if (T && T.host === F().me()) pub({ k: "tbl", tid: T.tid, host: T.host, hostNick: T.hostNick, st: T.st }); } }, 75000);

/* ---------------- atış (yerel) ---------------- */
const myTurn = () => P.G && !P.G.win && !P.anim && (P.practice || curId(P.G) === F().me());
function doShot() {
  const G = P.G, c = cueB(G), pow = P.pow; if (pow < 0.03) return; const placed = G.bih ? [c.x, c.y] : [null, null];
  const spin = P.spin && (P.spin[0] || P.spin[1]) ? P.spin.slice() : null; P.anim = shoot(G, P.aim, pow, placed[0], placed[1], spin); P.anim.by = F().me ? F().me() : "ben"; P.anim.ang = P.aim; P.anim.cue = myCue(); P.anim.strike = 0; P.anim.mine = true; P.pow = 0; P.press = null; P.placed = false;
  if (!P.practice) pub({ k: "shot", tid: G.tid, n: G.n + 1, by: F().me(), ang: P.aim, pow, cx: placed[0], cy: placed[1], cue: myCue(), spin }); P.spin = [0, 0]; spinUI(); P.turnT = 0;
}
function settle() {
  const A = P.anim; if (!A) return; if (A.mine) { let N; if (P.practice) { N = Object.assign({}, P.G, { balls: A.B, n: P.G.n + 1, bih: A.ev.pot.includes(0), brk: false, potted: A.ev.pot.filter((n) => n), foul: A.ev.pot.includes(0), msg: A.ev.pot.filter((n) => n).length ? `${A.ev.pot.filter((n) => n).length} top girdi` : "Antrenman" }); if (A.ev.pot.includes(0)) { const c = A.B.find((b) => b.n === 0); c.in = false; c.x = W * 0.25; c.y = H / 2; } if (A.B.filter((b) => b.n).every((b) => b.in)) { N.balls = rack((Math.random() * 1e9) | 0); N.msg = "Masa temizlendi! Yeni dizilim"; } }
    else { N = rules(P.G, A); pub({ k: "res", tid: P.G.tid, n: N.n, by: F().me(), G: N }); } P.G = N; if (P.tables[N.tid]) P.tables[N.tid].G = N; }
  else if (P.pend) { P.G = P.pend; P.pend = null; } else { P.G = Object.assign({}, P.G, { balls: A.B }); }
  P.anim = null; afterShot(P.G); render();
}
function sfx(f, d, v) { try { if (window.Sound && Sound.tone) Sound.tone(f, d || 0.06, v || 0.25); } catch (e) { /* */ } }

/* ---------------- çizim ---------------- */
const FELT = { dark: ["#0f6b4c", "#0a4a35", "#5a3a22"], black: ["#1d2a24", "#111814", "#2a2a2a"], light: ["#1c8a62", "#126447", "#8a5a34"], halloween: ["#3b1a52", "#240f33", "#ff8a1f"], neon: ["#1b0f3a", "#0e0824", "#ff2bd6"], ocean: ["#0f5f8a", "#093f5d", "#d9c9a3"], forest: ["#2d5a1f", "#1d3d14", "#6b4a2a"], sunset: ["#7a2b46", "#4f1b2e", "#ffb070"], matrix: ["#031a0b", "#010d05", "#39ff7a"] };
function drawCue(c, x, y, ang, back, id, sc) {
  const L = 380 * sc, w0 = 3.2 * sc, w1 = 7 * sc, d0 = (R + 6 + back) * sc; c.save(); c.translate(x, y); c.rotate(ang + Math.PI); c.translate(d0, 0);
  const g = c.createLinearGradient(0, 0, L, 0), set = { classic: [["#f3e7c9", 0], ["#c9a46a", 0.08], ["#8a5a2b", 0.62], ["#1a1008", 0.66], ["#3b2210", 1]], neon: [["#fff", 0], ["#00f0ff", 0.1], ["#5b1bd6", 0.6], ["#ff2bd6", 0.66], ["#14001f", 1]], halloween: [["#fff", 0], ["#ff8a1f", 0.1], ["#111", 0.45], ["#ff8a1f", 0.6], ["#111", 1]], matrix: [["#d6ffe2", 0], ["#39ff7a", 0.1], ["#03200c", 0.6], ["#39ff7a", 0.64], ["#010d05", 1]], ocean: [["#fff", 0], ["#7fdcff", 0.1], ["#0f5f8a", 0.6], ["#d9c9a3", 0.64], ["#062c45", 1]], forest: [["#f0f5e0", 0], ["#b7d98a", 0.1], ["#3a5a1f", 0.62], ["#6b4a2a", 0.66], ["#24180c", 1]], sunset: [["#fff", 0], ["#ffcf6b", 0.1], ["#ff7a59", 0.5], ["#a62a5c", 0.66], ["#2a0a1c", 1]], gold: [["#fff", 0], ["#ffe08a", 0.1], ["#b8862b", 0.6], ["#2a1e08", 0.66], ["#ffd27a", 1]] }[id] || [];
  set.forEach(([col, o]) => g.addColorStop(o, col)); c.fillStyle = g; if (id === "neon" || id === "matrix") { c.shadowColor = id === "neon" ? "#ff2bd6" : "#39ff7a"; c.shadowBlur = 14 * sc; }
  c.beginPath(); c.moveTo(0, -w0 / 2); c.lineTo(L, -w1 / 2); c.lineTo(L, w1 / 2); c.lineTo(0, w0 / 2); c.closePath(); c.fill(); c.shadowBlur = 0; c.fillStyle = "#e9eef5"; c.fillRect(0, -w0 / 2, 6 * sc, w0); c.fillStyle = "#2b6cb0"; c.fillRect(-1.5 * sc, -w0 / 2, 2 * sc, w0);
  if (id === "halloween") { c.fillStyle = "#ff8a1f"; c.beginPath(); c.arc(L - 26 * sc, 0, 5 * sc, 0, 6.283); c.fill(); } if (id === "forest") { c.fillStyle = "#9be15d"; c.beginPath(); c.ellipse(L - 30 * sc, 0, 7 * sc, 3 * sc, 0.5, 0, 6.283); c.fill(); } c.restore();
}
/* ---- gerçek 3B top: her pikselde küre normali → topun kendi ekseni (kuaterniyon) → renk/şerit/numara diski + ışık ---- */
const qmul = (a, b) => [a[0] * b[0] - a[1] * b[1] - a[2] * b[2] - a[3] * b[3], a[0] * b[1] + a[1] * b[0] + a[2] * b[3] - a[3] * b[2], a[0] * b[2] - a[1] * b[3] + a[2] * b[0] + a[3] * b[1], a[0] * b[3] + a[1] * b[2] - a[2] * b[1] + a[3] * b[0]];
const qnorm = (q) => { const l = Math.hypot(q[0], q[1], q[2], q[3]) || 1; return [q[0] / l, q[1] / l, q[2] / l, q[3] / l]; };
const qmat = (q) => { const [w, x, y, z] = q; return [1 - 2 * (y * y + z * z), 2 * (x * y - w * z), 2 * (x * z + w * y), 2 * (x * y + w * z), 1 - 2 * (x * x + z * z), 2 * (y * z - w * x), 2 * (x * z - w * y), 2 * (y * z + w * x), 1 - 2 * (x * x + y * y)]; };
const hex3 = (h) => { const n = parseInt(h.slice(1), 16); return [n >> 16, (n >> 8) & 255, n & 255]; };
P.rot = {};
function roll(b, dt) {          // yuvarlanma: eksen = yukarı × hareket, açı = yol / R; durunca 0,3 sn sonra numara yukarı dönecek şekilde yavaşça döner
  const o = P.rot[b.n] = P.rot[b.n] || { q: [1, 0, 0, 0], px: b.x, py: b.y, still: 0 }; const mx = b.x - o.px, my = b.y - o.py, d = Math.hypot(mx, my); o.px = b.x; o.py = b.y;
  if (d > 0.02 && d < 200) { const a = d / R, ax = -my / d, ay = mx / d, s = Math.sin(a / 2); o.q = qnorm(qmul([Math.cos(a / 2), ax * s, ay * s, 0], o.q)); o.still = 0; o.ver = (o.ver || 0) + 1; }
  else if (d >= 200) { o.q = [1, 0, 0, 0]; o.ver = (o.ver || 0) + 1; }
  else { o.still += dt; if (o.still > 0.3 && (Math.abs(o.q[0]) < 0.9995)) { const t = Math.min(1, dt * 3.2), sg = o.q[0] < 0 ? -1 : 1; o.q = qnorm([o.q[0] + (sg - o.q[0]) * t, o.q[1] * (1 - t), o.q[2] * (1 - t), o.q[3] * (1 - t)]); o.ver = (o.ver || 0) + 1; } }
  return o;
}
const LIGHT = (() => { const l = [-0.42, -0.55, 0.72], n = Math.hypot(...l); return l.map((v) => v / n); })(), HALF = (() => { const h = [LIGHT[0], LIGHT[1], LIGHT[2] + 1], n = Math.hypot(...h); return h.map((v) => v / n); })();
function ball(c, b, X, Y, sc, _r, scale) {
  const o = P.rot[b.n] || { q: [1, 0, 0, 0], ver: 0 }, r = R * sc * (scale || 1), size = Math.max(6, Math.ceil(r * 2) + 2), key = size + ":" + (o.ver || 0) + ":" + b.n;
  let cv = o.cv; if (!cv || cv._k !== key) { if (!cv) cv = o.cv = document.createElement("canvas"); if (cv.width !== size) { cv.width = cv.height = size; } cv._k = key; P.rot[b.n] = o;
    const cx = cv.getContext("2d"), img = cx.createImageData(size, size), D = img.data, M = qmat(o.q), col = b.n === 0 ? [247, 244, 236] : hex3(COL[b.n]), wh = [247, 244, 236], stripe = b.n > 8, h = size / 2;
    for (let py = 0; py < size; py++) for (let px = 0; px < size; px++) { const u = (px + 0.5 - h) / r, v = (py + 0.5 - h) / r, rr = u * u + v * v; if (rr > 1.04) continue; const nz = Math.sqrt(Math.max(0, 1 - rr)), nu = rr > 1 ? u / Math.sqrt(rr) : u, nv = rr > 1 ? v / Math.sqrt(rr) : v;
      const lx = M[0] * nu + M[3] * nv + M[6] * nz, ly = M[1] * nu + M[4] * nv + M[7] * nz, lz = M[2] * nu + M[5] * nv + M[8] * nz, disc = b.n && Math.abs(lz) > 0.86;
      const base = b.n === 0 ? wh : disc ? wh : stripe ? (Math.abs(ly) < 0.5 ? col : wh) : col, dif = Math.max(0, nu * LIGHT[0] + nv * LIGHT[1] + nz * LIGHT[2]), spc = Math.pow(Math.max(0, nu * HALF[0] + nv * HALF[1] + nz * HALF[2]), 46), sh = (0.32 + 0.78 * dif) * (0.62 + 0.38 * nz);
      const k = (py * size + px) * 4, a = rr > 1 ? Math.max(0, 1 - (Math.sqrt(rr) - 1) * r) : 1; D[k] = Math.min(255, base[0] * sh + spc * 240); D[k + 1] = Math.min(255, base[1] * sh + spc * 240); D[k + 2] = Math.min(255, base[2] * sh + spc * 240); D[k + 3] = a * 255; }
    cx.putImageData(img, 0, 0);
    if (b.n) for (const sgn of [1, -1]) { const pz = M[8] * sgn, pxx = M[2] * sgn, pyy = M[5] * sgn; if (pz < 0.2) continue; const ex = [M[0], M[3]], fy = [M[1] * sgn, M[4] * sgn], k = (r * 0.46) / 10;
      cx.save(); cx.globalAlpha = Math.min(1, (pz - 0.2) * 2.5); cx.setTransform(ex[0] * k, ex[1] * k, fy[0] * k, fy[1] * k, h + pxx * r * 0.93, h + pyy * r * 0.93); cx.fillStyle = "#14161c"; cx.font = "800 12px Segoe UI,Arial,sans-serif"; cx.textAlign = "center"; cx.textBaseline = "middle"; cx.fillText(String(b.n), 0, 0.8); cx.restore(); } }
  c.drawImage(cv, X(b.x) - size / 2, Y(b.y) - size / 2);
}
/* ---- gerçekçi masa: temaya göre ahşap/karbon/neon çerçeve, kauçuk bant, deri cepler, kumaş dokusu, lamba; boyut/tema değişince bir kez çizilir ---- */
const TABLES = { dark: { felt: ["#1a8a5e", "#0d5a3c"], wood: ["#6b3f1f", "#3a2010", "#8c5a30"], cush: "#0f6e4a", pk: "#c9a46a", dia: "#f1e7cf" }, black: { felt: ["#2b2f36", "#15181d"], wood: ["#1c1c1f", "#0a0a0c", "#3a3a40"], cush: "#22262c", pk: "#9aa3b2", dia: "#d7dbe3", carbon: 1 },
  light: { felt: ["#2a7fd4", "#16579c"], wood: ["#c99a62", "#8a5f31", "#e7c08a"], cush: "#1f68b3", pk: "#e9d3a6", dia: "#fff" }, halloween: { felt: ["#4a1f6b", "#26103b"], wood: ["#1a1014", "#07040a", "#3a1f2a"], cush: "#3a1755", pk: "#ff8a1f", dia: "#ff8a1f", glow: "#ff8a1f" },
  neon: { felt: ["#1c1047", "#0b0624"], wood: ["#0d0b1a", "#05040b", "#1d1838"], cush: "#160c3a", pk: "#00f0ff", dia: "#ff2bd6", glow: "#ff2bd6" }, ocean: { felt: ["#127a8a", "#0a4a5a"], wood: ["#b9a27a", "#7a6646", "#e2d1aa"], cush: "#0f6676", pk: "#f0e3c2", dia: "#7fdcff" },
  forest: { felt: ["#3c7a2a", "#214a16"], wood: ["#5a3a1c", "#2d1c0c", "#7d5530"], cush: "#336a24", pk: "#c9d98a", dia: "#e9ff8a" }, sunset: { felt: ["#8a2a46", "#4f1428"], wood: ["#c8902c", "#7a5410", "#f0c060"], cush: "#76223c", pk: "#ffd27a", dia: "#fff3c4" },
  matrix: { felt: ["#062a12", "#020d06"], wood: ["#06120a", "#010603", "#0f2a18"], cush: "#04200d", pk: "#39ff7a", dia: "#39ff7a", glow: "#39ff7a", grid: 1 } };
let TB = null;
function tableBg(sc) {
  const th = themeNow(), w = Math.round(LW * sc), h = Math.round(LH * sc), key = th + w + "x" + h; if (TB && TB._k === key) return TB; const T = TABLES[th] || TABLES.dark, cv = document.createElement("canvas"), d = Math.min(2, devicePixelRatio || 1); cv.width = w * d; cv.height = h * d; cv._k = key; const c = cv.getContext("2d"); c.scale(d, d);
  const X = (x) => (x + RAIL) * sc, Y = (y) => (y + RAIL) * sc, fr = 18 * sc;
  // çerçeve (ahşap damar / karbon / neon kenar)
  const wg = c.createLinearGradient(0, 0, 0, h); wg.addColorStop(0, T.wood[2]); wg.addColorStop(0.12, T.wood[0]); wg.addColorStop(0.88, T.wood[0]); wg.addColorStop(1, T.wood[1]); c.fillStyle = wg; roundRect(c, 0, 0, w, h, fr); c.fill();
  c.save(); roundRect(c, 0, 0, w, h, fr); c.clip(); const rnd = rng(7);
  if (T.carbon) { c.globalAlpha = 0.18; for (let x = 0; x < w; x += 6 * sc) for (let y = 0; y < h; y += 6 * sc) { c.fillStyle = (Math.floor(x / (6 * sc)) + Math.floor(y / (6 * sc))) % 2 ? "#3a3a44" : "#111"; c.fillRect(x, y, 6 * sc, 6 * sc); } }
  else { c.globalAlpha = 0.16; c.strokeStyle = T.wood[1]; for (let k = 0; k < 90; k++) { const y0 = rnd() * h; c.lineWidth = (0.6 + rnd() * 1.6) * sc; c.beginPath(); c.moveTo(0, y0); for (let x = 0; x <= w; x += 30 * sc) c.lineTo(x, y0 + Math.sin(x / (40 * sc) + k) * 3 * sc); c.stroke(); } }
  c.restore(); c.globalAlpha = 1; c.strokeStyle = "rgba(255,255,255,.18)"; c.lineWidth = 1.5 * sc; roundRect(c, 1.5 * sc, 1.5 * sc, w - 3 * sc, h - 3 * sc, fr); c.stroke();
  if (T.glow) { c.save(); c.shadowColor = T.glow; c.shadowBlur = 18 * sc; c.strokeStyle = T.glow; c.lineWidth = 2 * sc; roundRect(c, 6 * sc, 6 * sc, w - 12 * sc, h - 12 * sc, fr * 0.8); c.stroke(); c.restore(); }
  // kumaş + doku + lamba
  const fx0 = X(-14), fy0 = Y(-14), fw = (W + 28) * sc, fh = (H + 28) * sc, fg = c.createRadialGradient(w / 2, h / 2, 10, w / 2, h / 2, w * 0.62); fg.addColorStop(0, T.felt[0]); fg.addColorStop(1, T.felt[1]); c.fillStyle = fg; c.fillRect(fx0, fy0, fw, fh);
  c.save(); c.beginPath(); c.rect(fx0, fy0, fw, fh); c.clip(); for (let k = 0; k < 3500; k++) { c.fillStyle = rnd() < 0.5 ? "rgba(255,255,255,.035)" : "rgba(0,0,0,.05)"; c.fillRect(fx0 + rnd() * fw, fy0 + rnd() * fh, sc, sc); }
  if (T.grid) { c.strokeStyle = "rgba(57,255,122,.07)"; c.lineWidth = 1; for (let x = 0; x < W; x += 50) { c.beginPath(); c.moveTo(X(x), Y(0)); c.lineTo(X(x), Y(H)); c.stroke(); } for (let y = 0; y < H; y += 50) { c.beginPath(); c.moveTo(X(0), Y(y)); c.lineTo(X(W), Y(y)); c.stroke(); } }
  const lg = c.createRadialGradient(w / 2, h * 0.45, 10, w / 2, h / 2, w * 0.55); lg.addColorStop(0, "rgba(255,255,240,.13)"); lg.addColorStop(1, "rgba(0,0,0,.28)"); c.fillStyle = lg; c.fillRect(fx0, fy0, fw, fh); c.restore();
  // kauçuk bantlar (cep ağızlarında açılı kesik)
  const cushion = (pts) => { c.beginPath(); pts.forEach(([x, y], k) => (k ? c.lineTo(X(x), Y(y)) : c.moveTo(X(x), Y(y)))); c.closePath(); const g = c.createLinearGradient(X(pts[0][0]), Y(pts[0][1]), X(pts[2][0]), Y(pts[2][1])); g.addColorStop(0, T.cush); g.addColorStop(1, "rgba(0,0,0,.45)"); c.fillStyle = T.cush; c.fill(); c.fillStyle = g; c.globalAlpha = 0.5; c.fill(); c.globalAlpha = 1; c.strokeStyle = "rgba(255,255,255,.12)"; c.lineWidth = sc; c.stroke(); };
  const m = 30, mm = 22, t = 14;
  cushion([[m, -t], [W / 2 - mm, -t], [W / 2 - mm - 6, 0], [m + 8, 0]]); cushion([[W / 2 + mm, -t], [W - m, -t], [W - m - 8, 0], [W / 2 + mm + 6, 0]]);
  cushion([[m + 8, H], [W / 2 - mm - 6, H], [W / 2 - mm, H + t], [m, H + t]]); cushion([[W / 2 + mm + 6, H], [W - m - 8, H], [W - m, H + t], [W / 2 + mm, H + t]]);
  cushion([[-t, m], [0, m + 8], [0, H - m - 8], [-t, H - m]]); cushion([[W, m + 8], [W + t, m], [W + t, H - m], [W, H - m - 8]]);
  // elmas işaretler
  const dia = (x, y) => { const s2 = 4 * sc, g = c.createLinearGradient(x - s2, y - s2, x + s2, y + s2); g.addColorStop(0, "#fff"); g.addColorStop(1, T.dia); c.fillStyle = g; c.beginPath(); c.moveTo(x, y - s2); c.lineTo(x + s2 * 0.6, y); c.lineTo(x, y + s2); c.lineTo(x - s2 * 0.6, y); c.closePath(); c.fill(); };
  for (let i = 1; i < 8; i++) if (i !== 4) { dia(X((W * i) / 8), Y(0) - 30 * sc); dia(X((W * i) / 8), Y(H) + 30 * sc); } for (let i = 1; i < 4; i++) { dia(X(0) - 30 * sc, Y((H * i) / 4)); dia(X(W) + 30 * sc, Y((H * i) / 4)); }
  c.strokeStyle = "rgba(255,255,255,.1)"; c.setLineDash([3 * sc, 5 * sc]); c.beginPath(); c.moveTo(X(W * 0.25), Y(0)); c.lineTo(X(W * 0.25), Y(H)); c.stroke(); c.setLineDash([]); c.fillStyle = "rgba(255,255,255,.25)"; c.beginPath(); c.arc(X(W * 0.72), Y(H / 2), 2.4 * sc, 0, 6.283); c.fill();
  // cepler: metal/deri kapak + derin delik
  PK.forEach(([px, py, pr]) => { const x = X(px), y = Y(py), rr = pr * 1.18 * sc, cap = c.createRadialGradient(x - rr * 0.3, y - rr * 0.3, rr * 0.2, x, y, rr * 1.7); cap.addColorStop(0, T.pk); cap.addColorStop(0.55, T.pk); cap.addColorStop(1, "rgba(0,0,0,.6)"); c.fillStyle = cap; c.beginPath(); c.arc(x, y, rr * 1.45, 0, 6.283); c.fill();
    const hole = c.createRadialGradient(x, y + rr * 0.15, 0, x, y, rr); hole.addColorStop(0, "#000"); hole.addColorStop(0.7, "#050506"); hole.addColorStop(1, "#1d1d22"); c.fillStyle = hole; c.beginPath(); c.arc(x, y, rr, 0, 6.283); c.fill(); c.strokeStyle = "rgba(255,255,255,.18)"; c.lineWidth = 1.2 * sc; c.beginPath(); c.arc(x, y, rr, Math.PI * 1.1, Math.PI * 1.9); c.stroke(); });
  TB = cv; return cv;
}
const LW = W + 2 * RAIL, LH = H + 2 * RAIL;
function geo() {          // tam ekranda telefon dikse masa dikey çizilir
  const cv = $("#pool-cv"), wrap = cv.parentElement, fs = $("#pool-root").classList.contains("pool-fs"), aw = wrap.clientWidth, ah = fs ? wrap.clientHeight : Infinity, vert = fs && innerHeight > innerWidth * 1.1;
  const sc = vert ? Math.min(aw / LH, ah / LW) : Math.min(aw / LW, ah / LH); return { sc, vert, cw: (vert ? LH : LW) * sc, ch: (vert ? LW : LH) * sc };
}
function frame(dt) {
  const cv = $("#pool-cv"); if (!cv || !vis(cv) || !P.G) return; P.t += dt; if (myTurn()) P.turnT = (P.turnT || 0) + dt; const gm = geo(), c = fitCanvas(cv, gm.cw, gm.ch), sc = gm.sc, cw = LW * sc, ch = LH * sc, X = (x) => (x + RAIL) * sc, Y = (y) => (y + RAIL) * sc; P.vert = gm.vert;
  c.save(); if (gm.vert) { c.translate(gm.cw, 0); c.rotate(Math.PI / 2); }
  if (P.anim) { P.anim.strike = Math.min(1, P.anim.strike + dt * 6); if (P.anim.strike >= 1) { const nw = performance.now(), el = P.anim.lt ? (nw - P.anim.lt) / 1000 : dt; P.anim.lt = nw; const n = Math.min(720, Math.max(1, Math.round(el * 240))); let done = false; const h0 = P.anim.ev.hits.length, p0 = P.anim.ev.pot.length; for (let i = 0; i < n && !done; i++) done = step(P.anim.B, P.anim.ev); if (P.anim.ev.hits.length > h0) sfx(900 + Math.random() * 200, 0.03, Math.min(0.35, P.anim.ev.hits[P.anim.ev.hits.length - 1] / 2500)); if (P.anim.ev.pot.length > p0) P.anim.ev.pot.slice(p0).forEach((n) => { const b = P.anim.B.find((q) => q.n === n), pk = PK.reduce((a, q) => (Math.hypot(q[0] - b.x, q[1] - b.y) < Math.hypot(a[0] - b.x, a[1] - b.y) ? q : a)); sfx(n === 0 ? 140 : 220, 0.14, 0.32); P.fx.push({ k: "drop", t: 0, b: Object.assign({}, b), px: pk[0], py: pk[1] }); burst(n === 0 ? "foul" : "pot", pk[0], pk[1], n === 0 ? 14 : 26); }); P.anim.steps += n; if (done || P.anim.steps > 240 * 40) settle(); } }
  const B = P.anim ? P.anim.B : P.G.balls, th = FELT[themeNow()] || FELT.dark;
  B.forEach((b) => { if (!b.in) roll(b, dt); });
  if (P.shake > 0) { P.shake = Math.max(0, P.shake - dt); const k = P.shake * 14 * sc; c.translate((Math.random() - 0.5) * k, (Math.random() - 0.5) * k); }
  c.clearRect(-20, -20, cw + 40, ch + 40); c.drawImage(tableBg(sc), 0, 0, cw, ch);
  const cbm = B.find((q) => q.n === 0); if (P.anim && cbm && !cbm.in) { P.trail = P.trail || []; P.trail.push([cbm.x, cbm.y]); if (P.trail.length > 18) P.trail.shift(); } else if (P.trail && P.trail.length) P.trail.shift();
  if (P.trail && P.trail.length > 1) { for (let k = 1; k < P.trail.length; k++) { c.strokeStyle = `rgba(255,255,255,${(k / P.trail.length) * 0.25})`; c.lineWidth = R * sc * 1.4 * (k / P.trail.length); c.lineCap = "round"; c.beginPath(); c.moveTo(X(P.trail[k - 1][0]), Y(P.trail[k - 1][1])); c.lineTo(X(P.trail[k][0]), Y(P.trail[k][1])); c.stroke(); } }
  B.forEach((b) => { if (b.in) return; const g = c.createRadialGradient(X(b.x) + 3 * sc, Y(b.y) + 4 * sc, 0, X(b.x) + 3 * sc, Y(b.y) + 4 * sc, R * sc * 1.5); g.addColorStop(0, "rgba(0,0,0,.5)"); g.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = g; c.beginPath(); c.arc(X(b.x) + 3 * sc, Y(b.y) + 4 * sc, R * sc * 1.5, 0, 6.283); c.fill(); });
  B.forEach((b) => { if (!b.in) ball(c, b, X, Y, sc); });
  if (P.anim && P.anim.ev.hp && P.anim.ev.hp.length > (P.anim.hpi || 0)) { P.anim.ev.hp.slice(P.anim.hpi || 0).forEach(([hx, hy, rv]) => { if (rv > 120) P.fx.push({ k: "spark", t: 0, x: hx, y: hy, s: Math.min(1, rv / 1600) }); if (rv > 1500) P.shake = Math.max(P.shake || 0, 0.25); }); P.anim.hpi = P.anim.ev.hp.length; }
  // nişan + ıstaka
  const cb = B.find((b) => b.n === 0), mine = myTurn();
  if (mine && cb && !cb.in) { if (P.G.bih && !P.placed && P.mouse && !P.press) { const m = P.mouse, ok = validPlace(m[0], m[1]); cb.x = m[0]; cb.y = m[1]; c.strokeStyle = ok ? "rgba(255,255,255,.7)" : "#f2566a"; c.setLineDash([4, 4]); c.beginPath(); c.arc(X(cb.x), Y(cb.y), (R + 5) * sc, 0, 6.283); c.stroke(); c.setLineDash([]); }
    else { if (P.mouse && !P.press && P.hover !== false && !P.fine) P.aim = Math.atan2(P.mouse[1] - cb.y, P.mouse[0] - cb.x); guide(c, B, cb, P.aim, X, Y, sc); drawCue(c, X(cb.x), Y(cb.y), P.aim, P.pow * 90, myCue(), sc); } }
  else if (P.anim && P.anim.strike < 1 && cb) drawCue(c, X(cb.x), Y(cb.y), P.anim.ang, (1 - P.anim.strike) * 60, P.anim.cue || "classic", sc);
  if (mine && P.press) { const bw = 10 * sc, bh = ch * 0.6, bx = cw - 24 * sc, by = (ch - bh) / 2; c.fillStyle = "rgba(0,0,0,.5)"; roundRect(c, bx, by, bw, bh, 5 * sc); c.fill(); const pg = c.createLinearGradient(0, by + bh, 0, by); pg.addColorStop(0, "#3ddc84"); pg.addColorStop(0.6, "#ffd27a"); pg.addColorStop(1, "#f2566a"); c.fillStyle = pg; roundRect(c, bx, by + bh * (1 - P.pow), bw, bh * P.pow, 5 * sc); c.fill(); }
  for (let i = P.fx.length - 1; i >= 0; i--) { const f = P.fx[i]; f.t += dt / (f.k === "win" ? 2.5 : 0.8); if (f.t >= 1) { P.fx.splice(i, 1); continue; }
    if (f.k === "pot") { c.strokeStyle = `rgba(255,210,122,${1 - f.t})`; c.lineWidth = 3; c.beginPath(); c.arc(X(f.x), Y(f.y), (10 + f.t * 40) * sc, 0, 6.283); c.stroke(); }
    else if (f.k === "spark") { for (let k = 0; k < 6; k++) { const an = k * 1.05 + f.x, d = (6 + f.t * 26 * f.s) * sc; c.strokeStyle = `rgba(255,250,220,${(1 - f.t) * f.s})`; c.lineWidth = 1.6 * sc; c.beginPath(); c.moveTo(X(f.x) + Math.cos(an) * d * 0.4, Y(f.y) + Math.sin(an) * d * 0.4); c.lineTo(X(f.x) + Math.cos(an) * d, Y(f.y) + Math.sin(an) * d); c.stroke(); } c.fillStyle = `rgba(255,255,255,${(1 - f.t) * 0.6 * f.s})`; c.beginPath(); c.arc(X(f.x), Y(f.y), (3 + f.t * 6) * sc, 0, 6.283); c.fill(); }
    else if (f.k === "drop") { if (f.b.n && f.t > 0.35) { const k2 = (f.t - 0.35) / 0.65; c.save(); c.globalAlpha = 1 - k2; c.font = `900 ${18 * sc}px Segoe UI,sans-serif`; c.textAlign = "center"; c.fillStyle = COL[f.b.n] || "#fff"; c.shadowColor = COL[f.b.n] || "#fff"; c.shadowBlur = 12; c.fillText("+" + f.b.n, X(f.px), Y(f.py) - (14 + k2 * 40) * sc); c.restore(); } const e = Math.min(1, f.t * 1.6), b = Object.assign({}, f.b, { x: f.b.x + (f.px - f.b.x) * e, y: f.b.y + (f.py - f.b.y) * e }); c.globalAlpha = 1 - e * 0.7; ball(c, b, X, Y, sc, 0, 1 - e * 0.65); c.globalAlpha = 1; c.strokeStyle = `rgba(255,255,255,${0.8 * (1 - f.t)})`; c.lineWidth = 2; c.beginPath(); c.arc(X(f.px), Y(f.py), (16 + f.t * 26) * sc, 0, 6.283); c.stroke(); }
    else if (f.k === "win" || f.k === "break") for (let k = 0; k < 40; k++) { const a = k * 2.4, d = f.t * cw * 0.45; c.fillStyle = `hsla(${(k * 37) % 360},90%,60%,${1 - f.t})`; c.fillRect(cw / 2 + Math.cos(a) * d, ch / 2 + Math.sin(a) * d * 0.6 - f.t * 30, 5, 5); } }
  drawParts(c, X, Y, sc, dt); c.restore(); banners(c, gm.cw, gm.ch, dt); powUI();
}
/* ---- tema animasyonları ---- */
const THM = { dark: ["#ffd27a", "#fff3c4"], black: ["#e8e8e8", "#ffd27a"], light: ["#ffb04a", "#35e0c4"], halloween: ["#ff8a1f", "#7b2cbf"], neon: ["#00f0ff", "#ff2bd6"], ocean: ["#7fdcff", "#ffffff"], forest: ["#9be15d", "#e9ff8a"], sunset: ["#ffcf6b", "#ff5e7a"], matrix: ["#39ff7a", "#b6ffcf"] };
P.parts = [];
function burst(kind, x, y, n) { const th = themeNow(), big = kind === "mvp" || kind === "win"; for (let i = 0; i < n; i++) { const a = Math.random() * 6.283, v = (big ? 260 : 120) + Math.random() * (big ? 520 : 220); P.parts.push({ x: x == null ? Math.random() * W : x, y: y == null ? Math.random() * H : y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - (th === "ocean" || th === "sunset" ? 120 : 0), t: 0, life: (big ? 1.6 : 0.9) + Math.random() * 0.8, rot: Math.random() * 6, th, kind, ch: "ﾈ01ｱﾐ7ﾗ"[i % 7] }); } if (P.parts.length > 700) P.parts.splice(0, P.parts.length - 700); }
function drawParts(c, X, Y, sc, dt) {
  for (let i = P.parts.length - 1; i >= 0; i--) { const q = P.parts[i]; q.t += dt; if (q.t > q.life) { P.parts.splice(i, 1); continue; } q.x += q.vx * dt; q.y += q.vy * dt; q.vx *= 0.96; q.vy = q.vy * 0.96 + (q.th === "ocean" ? -60 : q.th === "matrix" ? 120 : 30) * dt; q.rot += dt * 6; const a = 1 - q.t / q.life, col = q.kind === "foul" ? "#f2566a" : (THM[q.th] || THM.dark)[i % 2], x = X(q.x), y = Y(q.y), s = sc * (q.kind === "mvp" || q.kind === "win" ? 1.6 : 1);
    c.save(); c.globalAlpha = a; c.translate(x, y); c.rotate(q.rot); c.fillStyle = col; c.strokeStyle = col;
    if (q.kind === "foul") { c.fillRect(-3 * s, -3 * s, 6 * s, 6 * s); }
    else if (q.th === "halloween") { c.fillStyle = i % 3 ? "#120612" : "#ff8a1f"; c.beginPath(); c.moveTo(0, 0); c.quadraticCurveTo(-7 * s, -6 * s, -12 * s, 0); c.quadraticCurveTo(-7 * s, -2 * s, 0, 3 * s); c.quadraticCurveTo(7 * s, -2 * s, 12 * s, 0); c.quadraticCurveTo(7 * s, -6 * s, 0, 0); c.fill(); }
    else if (q.th === "neon") { c.shadowColor = col; c.shadowBlur = 10 * s; c.fillRect(-7 * s, -1 * s, 14 * s, 2 * s); }
    else if (q.th === "matrix") { c.rotate(-q.rot); c.font = `700 ${12 * s}px monospace`; c.shadowColor = col; c.shadowBlur = 6; c.fillText(q.ch, 0, 0); }
    else if (q.th === "ocean") { c.lineWidth = 1.4 * s; c.beginPath(); c.arc(0, 0, 4 * s * (1 + q.t), 0, 6.283); c.stroke(); }
    else if (q.th === "forest") { c.beginPath(); c.ellipse(0, 0, 6 * s, 2.6 * s, 0, 0, 6.283); c.fill(); }
    else if (q.th === "sunset") { c.shadowColor = col; c.shadowBlur = 8 * s; c.fillRect(-2.5 * s, -2.5 * s, 5 * s, 5 * s); }
    else { c.beginPath(); for (let k = 0; k < 5; k++) { const r = k % 2 ? 2 * s : 5 * s, an = (k * Math.PI) / 2.5; c.lineTo(Math.cos(an) * r, Math.sin(an) * r); } c.fill(); }
    c.restore(); }
}
P.bn = [];
function banner(txt, sub, kind, dur) { P.bn.push({ txt, sub, kind, t: 0, dur: dur || 2 }); }
function banners(c, w, h, dt) {
  for (let i = P.bn.length - 1; i >= 0; i--) { const b = P.bn[i]; b.t += dt; if (b.t > b.dur) { P.bn.splice(i, 1); continue; } const e = Math.min(1, b.t * 4), out = Math.max(0, (b.t - b.dur + 0.35) / 0.35), k = (1 - out) * (0.6 + 0.4 * (1 - Math.pow(1 - e, 3))), th = themeNow(), C = THM[th] || THM.dark;
    const col = b.kind === "foul" ? "#f2566a" : b.kind === "last" ? "#35e0c4" : C[0], fs = Math.min(w, h) * (b.kind === "mvp" ? 0.17 : b.kind === "foul" ? 0.14 : 0.1);
    c.save(); c.globalAlpha = 1 - out; if (b.kind === "foul") { const g = c.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.2, w / 2, h / 2, Math.max(w, h) * 0.7); g.addColorStop(0, "rgba(242,86,106,0)"); g.addColorStop(1, `rgba(242,86,106,${0.45 * (1 - out)})`); c.fillStyle = g; c.fillRect(0, 0, w, h); }
    if (b.kind === "mvp") { c.fillStyle = `rgba(0,0,0,${0.35 * (1 - out)})`; c.fillRect(0, 0, w, h); for (let r = 0; r < 3; r++) { c.strokeStyle = col; c.globalAlpha = (1 - out) * (0.6 - r * 0.18); c.lineWidth = 3; c.beginPath(); c.arc(w / 2, h / 2, (b.t * 0.9 + r * 0.15) * Math.max(w, h) * 0.5, 0, 6.283); c.stroke(); } c.globalAlpha = 1 - out; }
    const shake = b.kind === "foul" && b.t < 0.5 ? Math.sin(b.t * 70) * 8 * (0.5 - b.t) : 0; c.translate(w / 2 + shake, h / 2); c.scale(k, k);
    c.font = `900 ${fs}px "Segoe UI",sans-serif`; c.textAlign = "center"; c.textBaseline = "middle"; c.shadowColor = col; c.shadowBlur = 30; c.lineWidth = fs * 0.08; c.strokeStyle = "rgba(0,0,0,.6)"; c.strokeText(b.txt, 0, 0); c.fillStyle = col; c.fillText(b.txt, 0, 0);
    if (b.sub) { c.shadowBlur = 10; c.font = `700 ${fs * 0.28}px "Segoe UI",sans-serif`; c.fillStyle = "#fff"; c.fillText(b.sub, 0, fs * 0.72); } c.restore(); }
}
/* atış sonrası: faul / son top / MVP / kazanan ekranı + istatistik */
function afterShot(G) {
  if (!G) return; const nm = (i) => { const T = P.tables[G.tid] || { players: {} }; return (T.players[i] || {}).nick || (i === (F().me && F().me()) ? F().nick() : i); };
  if (G.win) { const shooter = nm(G.by); if (G.mvp) { banner("MVP VURUŞ", `${shooter} · ${G.win} takımı kazandı`, "mvp", 3.2); burst("mvp", null, null, 160); sfx(523, 0.2, 0.4); setTimeout(() => sfx(659, 0.2, 0.4), 150); setTimeout(() => sfx(784, 0.4, 0.45), 300); }
    else { banner("OYUN BİTTİ", G.msg, "foul", 2.6); burst("win", null, null, 80); }
    stats(G); setTimeout(() => winScreen(G), 2400); return; }
  if (G.foul) { banner("FAUL", String(G.msg || "").replace(/^Faul:\s*/, "").split(" · ")[0], "foul", 2); sfx(110, 0.25, 0.4); if (navigator.vibrate) try { navigator.vibrate(120); } catch (e) { /* */ } return; }
  if (G.cleared) { banner("SON TOP!", "grubun bitti · sıra 8 numarada", "last", 2.2); burst("pot", W / 2, H / 2, 60); sfx(880, 0.15, 0.35); return; }
  if (G.potted && G.potted.length) banner(G.potted.length > 1 ? `${G.potted.length} TOP!` : "GİRDİ!", "", "pot", 1.1);
}
function stats(G) {
  const me = F().me ? F().me() : ""; if (P.practice || !me || !G.order.includes(me)) return; const done = JSON.parse(localStorage.getItem("nera_pool_done") || "[]"); if (done.includes(G.tid)) return; done.push(G.tid); localStorage.setItem("nera_pool_done", JSON.stringify(done.slice(-50)));
  const st = Object.assign({ w: 0, l: 0 }, JSON.parse(localStorage.getItem("nera_pool_st") || "{}")); if (G.teams[me] === G.win) st.w++; else st.l++; localStorage.setItem("nera_pool_st", JSON.stringify(st)); if (window.NERA_SAVE) NERA_SAVE();
  try { if (window.NeraNet && NeraNet.on()) NeraNet.profile.save({ pool: st }); } catch (e) { /* */ }
}
function winScreen(G) {
  const root = $("#pool-root"); if (!root || !P.G || P.G.tid !== G.tid) return; const me = F().me ? F().me() : "", T = P.tables[G.tid] || { players: {} }, ro = F().roster ? F().roster() : [], ph = (i) => (ro.find((u) => u.uid === i) || {}).photo || (i === me && F().photo ? F().photo() : "");
  const nick = (i) => (T.players[i] || {}).nick || (i === me ? F().nick() : i), mine = G.order.includes(me), won = G.teams[me] === G.win, team = (t) => [...new Set(G.order.filter((i) => G.teams[i] === t))];
  const card = (i, k) => `<div class="pw-p" style="--d:${0.3 + k * 0.15}s"><span class="avt" style="width:74px;height:74px;font-size:28px;background:${ph(i) ? `url(${ph(i)}) center/cover` : `hsl(${[...String(nick(i))].reduce((a, ch) => a + ch.charCodeAt(0), 0) * 37 % 360},60%,45%)`}">${ph(i) ? "" : esc(String(nick(i)).slice(0, 2).toUpperCase())}</span><b>${esc(nick(i))}</b>${G.mvp && G.by === i ? '<em>MVP</em>' : ""}</div>`;
  const el = document.createElement("div"); el.className = "pool-wins"; el.innerHTML = `<div class="pw-card"><div class="pw-crown">🏆</div><div class="pw-t">${G.win} TAKIMI KAZANDI</div>${mine ? `<div class="pw-me ${won ? "w" : "l"}">${won ? "Tebrikler, kazandın!" : "Bu sefer olmadı"}</div>` : ""}<div class="pw-team">${team(G.win).map(card).join("")}</div>
    <div class="pw-lose">${team(G.win === "A" ? "B" : "A").map((i) => esc(nick(i))).join(" · ")}</div><div class="pw-bar"><i></i></div><div class="pw-c">Masa kapanıyor…</div><button class="btn" id="pw-x">Şimdi kapat</button></div>`;
  root.appendChild(el); requestAnimationFrame(() => el.classList.add("on")); const close = () => { clearTimeout(tm); el.classList.remove("on"); setTimeout(() => el.remove(), 400); if (P.G && P.G.tid === G.tid) { const T2 = P.tables[G.tid]; if (T2 && T2.host === me) pub({ k: "close", tid: G.tid }); if (root.classList.contains("pool-fs")) fsToggle(); leave(); } };
  const tm = setTimeout(close, 9000); $("#pw-x", el).onclick = close;
}
function roundRect(c, x, y, w, h, r) { c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); }
function validPlace(x, y) { if (x < R || x > W - R || y < R || y > H - R) return false; if (P.G.brk && x > W * 0.25) return false; return P.G.balls.every((b) => b.n === 0 || b.in || Math.hypot(b.x - x, b.y - y) > 2 * R + 1); }
function guide(c, B, cb, ang, X, Y, sc) {
  const dx = Math.cos(ang), dy = Math.sin(ang); let best = 1e9, hit = null; B.forEach((b) => { if (b.in || b.n === 0) return; const fx = b.x - cb.x, fy = b.y - cb.y, t = fx * dx + fy * dy; if (t <= 0) return; const d2 = fx * fx + fy * fy - t * t; if (d2 > 4 * R * R) return; const tt = t - Math.sqrt(4 * R * R - d2); if (tt < best) { best = tt; hit = b; } });
  const wall = Math.min(dx > 0 ? (W - R - cb.x) / dx : dx < 0 ? (R - cb.x) / dx : 1e9, dy > 0 ? (H - R - cb.y) / dy : dy < 0 ? (R - cb.y) / dy : 1e9), L = Math.min(best, wall), gx = cb.x + dx * L, gy = cb.y + dy * L;
  c.strokeStyle = "rgba(255,255,255,.55)"; c.setLineDash([6, 6]); c.lineWidth = 1.4; c.beginPath(); c.moveTo(X(cb.x), Y(cb.y)); c.lineTo(X(gx), Y(gy)); c.stroke(); c.setLineDash([]); c.beginPath(); c.arc(X(gx), Y(gy), R * sc, 0, 6.283); c.stroke();
  if (hit && best <= wall) { const nx = (hit.x - gx) / (2 * R), ny = (hit.y - gy) / (2 * R); c.strokeStyle = "rgba(255,210,122,.8)"; c.beginPath(); c.moveTo(X(hit.x), Y(hit.y)); c.lineTo(X(hit.x + nx * 90), Y(hit.y + ny * 90)); c.stroke(); }
}

/* ---------------- arayüz ---------------- */
function toTable(e) { const cv = $("#pool-cv"), r = cv.getBoundingClientRect(); if (P.vert) { const sc = r.height / LW; return [(e.clientY - r.top) / sc - RAIL, (r.width - (e.clientX - r.left)) / sc - RAIL]; } const sc = r.width / LW; return [(e.clientX - r.left) / sc - RAIL, (e.clientY - r.top) / sc - RAIL]; }
function bindCanvas() {
  const cv = $("#pool-cv"); if (!cv || cv._b) return; cv._b = 1;
  cv.addEventListener("pointermove", (e) => { P.mouse = toTable(e); if (P.press && myTurn()) { if (P.press.touch) { const cb = cueB(P.G); P.aim = Math.atan2(P.mouse[1] - cb.y, P.mouse[0] - cb.x); return; } const d = Math.hypot(P.mouse[0] - P.press[0], P.mouse[1] - P.press[1]); P.pow = Math.min(1, d / 260); } });
  cv.addEventListener("pointerdown", (e) => { if (!myTurn()) return; try { cv.setPointerCapture(e.pointerId); } catch (x) { /* */ } P.mouse = toTable(e); const cb = cueB(P.G); if (P.G.bih && !P.placed) { if (validPlace(P.mouse[0], P.mouse[1])) { cb.x = P.mouse[0]; cb.y = P.mouse[1]; P.placed = true; sfx(600, 0.04); } return; } P.aim = Math.atan2(P.mouse[1] - cb.y, P.mouse[0] - cb.x); P.press = P.mouse.slice(); P.press.touch = e.pointerType !== "mouse"; P.pow = 0; });
  const up = () => { if (P.press && !P.press.touch && myTurn()) doShot(); P.press = null; }; cv.addEventListener("pointerup", up); cv.addEventListener("pointercancel", () => { P.press = null; P.pow = 0; }); cv.addEventListener("pointerleave", () => { if (!P.press) P.mouse = null; });
}
function cuePicker() { return `<div class="pool-cues">${CUES.map(([k, n]) => `<button class="pool-cue ${myCue() === k ? "on" : ""}" data-c="${k}"><canvas width="160" height="26" data-cue="${k}"></canvas><span>${n}</span></button>`).join("")}</div>`; }
function paintCues() { $$("canvas[data-cue]").forEach((cv) => { const c = cv.getContext("2d"); c.clearRect(0, 0, 160, 26); drawCue(c, 168, 13, Math.PI, -150, cv.dataset.cue, 0.42); }); }
const rulesHTML = `<details class="pool-rules"><summary>8 top kuralları</summary><ul><li>Takımlar sırayla atar; aynı takımdaki oyuncular da kendi aralarında sırayla oynar.</li><li>Açılışta beyaz top sol çeyrekte istenen yere konur. Açılıştan sonra ilk sokulan top takımın grubunu belirler: düzler (1-7) ya da çizgililer (9-15).</li><li>Kendi grubundan top sokarsan sıra sende kalır; sokamazsan sıra geçer.</li><li>Faul: beyaz top deliğe girerse, hiçbir topa değmezsen ya da önce rakibin topuna (veya 8'e) değersen. Faulde rakip takım beyaz topu masada istediği yere koyar.</li><li>Grubunu bitiren takım 8'i sokarsa kazanır. 8'i erken ya da faulle sokan takım kaybeder. Açılışta 8 girerse yerine konur.</li><li>Nişan: fareyle/parmakla yönü seç, basılı tutup çek (güç), bırak = vur.</li></ul></details>`;
function render() {
  const root = $("#pool-root"); if (!root || !root.classList.contains("on")) return; const me = F().me ? F().me() : "";
  if (P.view === "game" && P.G) return renderGame(root);
  const T = P.cur && P.tables[P.cur];
  if (T) { const L = live(T), col = (team) => L.filter(([, p]) => p.team === team).map(([i, p]) => `<div class="pool-pl ${p.ready ? "rdy" : ""}"><span class="avt" style="width:30px;height:30px;font-size:12px;background:hsl(${[...String(p.nick)].reduce((a, ch) => a + ch.charCodeAt(0), 0) * 37 % 360},60%,45%)">${esc(String(p.nick).slice(0, 2).toUpperCase())}</span><b>${esc(p.nick)}${i === T.host ? " 👑" : ""}</b><em>${p.ready ? "HAZIR" : "bekliyor"}</em></div>`).join("") || '<div class="muted pool-empty">boş</div>';
    const mp = T.players[me] || {}, specs = L.filter(([, p]) => !p.team);
    const h = `<div class="pool-lobby"><div class="pool-head"><div><div class="eyebrow">Bilardo · 8 top</div><h3>${esc(T.hostNick || "Masa")} masası</h3></div><button class="btn" data-a="leave">Masadan ayrıl</button></div>
      <div class="pool-teams"><div class="pool-team A"><h4>A takımı</h4>${col("A")}<button class="btn" data-a="A" ${mp.team === "A" ? "disabled" : ""}>A'ya geç</button></div><div class="pool-vs">VS</div><div class="pool-team B"><h4>B takımı</h4>${col("B")}<button class="btn" data-a="B" ${mp.team === "B" ? "disabled" : ""}>B'ye geç</button></div></div>
      <div class="pool-specs">İzleyiciler: ${specs.map(([, p]) => esc(p.nick)).join(", ") || "yok"} <button class="btn" data-a="spec" ${!mp.team ? "disabled" : ""}>İzleyici ol</button></div>
      <div class="pool-go">${mp.team ? `<button class="btn ${mp.ready ? "warn" : "pri"} pool-ready" data-a="ready">${mp.ready ? "Hazır değilim" : "Hazırım"}</button>` : ""}<span class="muted">Takımlardaki herkes hazır olunca oyun başlar (en çok 4 oyuncu). ${T.host === me ? "Masayı sen kurdun." : ""}</span></div>
      <h5>Istakan</h5>${cuePicker()}${rulesHTML}</div>`;
    if (root._h !== h) { root._h = h; root.innerHTML = h; paintCues(); bindLobby(root); } return; }
  const list = Object.values(P.tables).filter((t) => t.st !== "closed" && Date.now() - (t.t || 0) < 3 * 3600e3 && live(t).length).sort((a, b) => b.t - a.t);
  const h = `<div class="pool-lobby">${P.quota ? '<div class="pool-quota">Ücretsiz mesaj sunucusunun (ntfy.sh) bu internet bağlantısı için günlük kotası doldu. Türkiye saatiyle 03:00&#39;te kendiliğinden açılır; o zamana kadar çok oyunculu masa ve sohbet çalışmaz. Antrenman çalışır.</div>' : ""}<div class="pool-head"><div><div class="eyebrow">Arkadaş grubu</div><h3>Bilardo masaları</h3></div><div class="ctl"><button class="btn pri" data-a="new">Masa kur</button><button class="btn" data-a="solo">Antrenman</button></div></div>
    <div class="pool-tables">${list.map((t) => { const L = live(t); return `<div class="pool-tc ${t.st}"><div><b>${esc(t.hostNick || "Masa")} masası</b><span class="muted">${t.st === "game" ? "oyunda" : t.st === "over" ? "bitti" : "lobide"} · ${L.filter(([, p]) => p.team === "A").length} vs ${L.filter(([, p]) => p.team === "B").length} · ${L.filter(([, p]) => !p.team).length} izleyici</span></div><button class="btn" data-t="${t.tid}">${t.st === "lobby" ? "Katıl" : "İzle"}</button></div>`; }).join("") || '<div class="muted pool-empty">Açık masa yok. "Masa kur" ile başlat; aynı grup kodundaki arkadaşların görür.</div>'}</div>
    <h5>Istakan</h5>${cuePicker()}${rulesHTML}</div>`;
  if (root._h !== h) { root._h = h; root.innerHTML = h; paintCues(); bindLobby(root); }
}
function bindLobby(root) {
  $$("[data-a]", root).forEach((b) => (b.onclick = () => { const a = b.dataset.a; if (a === "new") createTable(); else if (a === "solo") { P.practice = true; P.cur = "solo"; P.G = newGame("solo", [F().me() || "ben"], { [F().me() || "ben"]: "A" }, (Math.random() * 1e9) | 0); P.G.msg = "Antrenman: kurallar yok, istediğin gibi vur"; P.view = "game"; render(); }
    else if (a === "leave") leave(); else if (a === "A" || a === "B") myPl({ team: a, ready: false }); else if (a === "spec") myPl({ team: null, ready: false }); else if (a === "ready") myPl({ ready: !((P.tables[P.cur].players[F().me()] || {}).ready) }); }));
  $$("[data-t]", root).forEach((b) => (b.onclick = () => { const T = P.tables[b.dataset.t]; P.cur = b.dataset.t; if (T.st !== "lobby" && T.G) { P.G = T.G; P.view = "game"; myPl({ team: null, ready: false }); } else { P.view = "lobby"; myPl({ team: null, ready: false }); } render(); }));
  $$(".pool-cue", root).forEach((b) => (b.onclick = () => { P.cue = b.dataset.c; localStorage.setItem("nera_cue", P.cue); if (P.cur && !P.practice) myPl({}); root._h = ""; render(); }));
}
function renderGame(root) {
  const G = P.G, me = F().me ? F().me() : "", T = P.tables[G.tid] || { players: {} }, nick = (i) => (T.players[i] || {}).nick || (i === me ? F().nick() : i), cur = curId(G), team = (t) => G.order.filter((i, k) => G.order.indexOf(i) === k && G.teams[i] === t);
  if (!root.querySelector("#pool-cv")) { root._h = ""; root.innerHTML = `<div class="pool-game"><div class="pool-sb" id="pool-sb"></div><div class="pool-tray" id="pool-tray"></div><div class="pool-main"><div class="pool-tw"><canvas id="pool-cv"></canvas></div>
      <div class="pool-side"><div class="pool-pow" id="pool-pow"><div class="pp-track"><i class="pp-fill"></i><b class="pp-knob"></b></div><span>GÜÇ</span></div>
        <button class="pool-spin" id="pool-spin" title="Falso"><i></i></button><div class="pool-fine"><button data-f="-1">◀</button><button data-f="1">▶</button></div></div></div>
      <div class="pool-st" id="pool-st"></div><div class="ctl pool-gc"><button class="btn pri" data-g="fs">⛶ Tam ekran</button><button class="btn" data-g="leave">${P.practice ? "Antrenmandan çık" : "Masadan ayrıl"}</button><button class="btn" data-g="rack" style="${P.practice ? "" : "display:none"}">Yeniden diz</button><button class="btn" data-g="skip" style="display:none">Sırayı geç</button><span class="muted">Yön: masaya dokun/sürükle · güç: sağdaki çubuğu aşağı çek, bırak = vur · ◀ ▶ ince ayar · beyaz top: falso</span></div>
      <div class="pool-spinpick" id="pool-spinpick"><div class="psp-ball" id="psp-ball"><i></i></div><span>Beyaz topun neresine vurulacağını seç · üst: ilerler · alt: geri gelir · yan: banttan sapar</span><button class="btn" id="psp-ok">Tamam</button></div></div>`;
    bindSide(root);
    bindCanvas(); $$("[data-g]", root).forEach((b) => (b.onclick = () => { const a = b.dataset.g; if (a === "fs") return fsToggle(); if (a === "leave") { if (root.classList.contains("pool-fs")) fsToggle(); leave(); } else if (a === "rack") { P.G = Object.assign({}, P.G, { balls: rack((Math.random() * 1e9) | 0), bih: true, brk: true }); } else if (a === "skip" && P.tables[G.tid] && P.tables[G.tid].host === me) { const N = Object.assign({}, P.G, { n: P.G.n + 1, turn: P.G.turn + 1, bih: true, msg: "Sıra geçildi (oyuncu yanıt vermedi)" }); pub({ k: "res", tid: G.tid, n: N.n, by: me, G: N }); P.G = N; render(); } })); }
  const gi = (t) => (G.groups[t] ? `<span class="pool-gi ${G.groups[t]}">${G.groups[t] === "solid" ? "● düz" : "◐ çizgili"} · ${G.balls.filter((b) => grp(b.n) === G.groups[t] && b.in).length}/7</span>` : '<span class="pool-gi">grup açık</span>');
  const tb = (t) => `<div class="pool-sbt ${t} ${G.teams[cur] === t && !G.win ? "turn" : ""} ${G.win === t ? "won" : ""}"><b>${t} takımı</b>${gi(t)}<span>${team(t).map((i) => `<i class="${i === cur && !G.win ? "on" : ""}">${esc(nick(i))}</i>`).join("")}</span></div>`;
  const sb = P.practice ? `<div class="pool-sbt A turn"><b>Antrenman</b><span>${G.balls.filter((b) => b.n && b.in).length} top girdi</span></div>` : `${tb("A")}<div class="pool-turn">${G.win ? "🏆" : myTurn() ? "SIRA SENDE" : `sıra: ${esc(nick(cur))}`}${G.order.includes(me) || P.practice ? "" : '<em>izliyorsun</em>'}</div>${tb("B")}`;
  const se = $("#pool-sb"); if (se._h !== sb) { se._h = sb; se.innerHTML = sb; }
  const tray = ["solid", "stripe"].map((g) => `<div class="pt-${g}">${G.balls.filter((b) => grp(b.n) === g && b.in).map((b) => `<i style="--c:${COL[b.n]}" class="${b.n > 8 ? "st" : ""}">${b.n}</i>`).join("")}</div>`).join(""); const te = $("#pool-tray"); if (te._h !== tray) { te._h = tray; te.innerHTML = tray; }
  const msg = (G.win ? `<b class="pool-win">${esc(G.msg)}</b>` : esc(G.msg || "")) + (myTurn() && G.bih && !P.placed ? " · <b>Beyaz topu yerleştir</b>" : ""); const st = $("#pool-st"); if (st._h !== msg) { st._h = msg; st.innerHTML = msg; st.classList.remove("pop"); void st.offsetWidth; st.classList.add("pop"); }
  const sk = root.querySelector('[data-g="skip"]'); if (sk) sk.style.display = !P.practice && T.host === me && !G.win && Date.now() - (G.tt || G.t0 || 0) > 90000 ? "" : "none";
}

/* yan kontroller */
function powUI() { const p = $("#pool-pow"); if (!p) return; const on = myTurn() && !(P.G.bih && !P.placed); p.classList.toggle("off", !on); const v = P.pow || 0; if (p._v !== v) { p._v = v; p.querySelector(".pp-fill").style.height = v * 100 + "%"; p.querySelector(".pp-knob").style.top = v * 100 + "%"; } const ring = $(".pool-sbt i.on"); if (ring && !P.practice) ring.style.setProperty("--tp", Math.min(1, (P.turnT || 0) / 45)); }
function spinUI() { const b = $("#pool-spin i"), k = $("#psp-ball i"), s = P.spin || [0, 0]; [b, k].forEach((e) => { if (e) { e.style.left = 50 + s[0] * 34 + "%"; e.style.top = 50 - s[1] * 34 + "%"; } }); }
function bindSide(root) {
  P.spin = P.spin || [0, 0]; const pw = $("#pool-pow", root), tr = $(".pp-track", pw); let drag = false;
  const at = (e) => { const r = tr.getBoundingClientRect(); P.pow = Math.max(0, Math.min(1, (e.clientY - r.top) / r.height)); };
  pw.addEventListener("pointerdown", (e) => { if (!myTurn() || (P.G.bih && !P.placed)) return; drag = true; try { pw.setPointerCapture(e.pointerId); } catch (x) { /* */ } at(e); e.preventDefault(); });
  pw.addEventListener("pointermove", (e) => { if (drag) at(e); }); const end = () => { if (!drag) return; drag = false; if (P.pow > 0.03 && myTurn()) doShot(); else P.pow = 0; }; pw.addEventListener("pointerup", end); pw.addEventListener("pointercancel", () => { drag = false; P.pow = 0; });
  const pick = $("#pool-spinpick", root); $("#pool-spin", root).onclick = () => pick.classList.toggle("on"); $("#psp-ok", root).onclick = () => pick.classList.remove("on");
  const ball = $("#psp-ball", root); const setS = (e) => { const r = ball.getBoundingClientRect(), x = ((e.clientX - r.left) / r.width - 0.5) * 2, y = -((e.clientY - r.top) / r.height - 0.5) * 2, d = Math.hypot(x, y), k = d > 0.85 ? 0.85 / d : 1; P.spin = [+(x * k).toFixed(2), +(y * k).toFixed(2)]; spinUI(); };
  let sd = false; ball.addEventListener("pointerdown", (e) => { sd = true; setS(e); }); ball.addEventListener("pointermove", (e) => { if (sd) setS(e); }); ball.addEventListener("pointerup", () => (sd = false)); ball.ondblclick = () => { P.spin = [0, 0]; spinUI(); };
  $$(".pool-fine button", root).forEach((b) => { let iv = 0; const nudge = () => { P.fine = true; P.aim += +b.dataset.f * 0.0035; }; b.addEventListener("pointerdown", () => { nudge(); iv = setInterval(nudge, 60); }); ["pointerup", "pointerleave", "pointercancel"].forEach((ev) => b.addEventListener(ev, () => clearInterval(iv))); });
  $("#pool-cv", root).addEventListener("pointerdown", () => (P.fine = false)); spinUI();
}
function fsToggle() { const r = $("#pool-root"), on = !r.classList.contains("pool-fs");
  if (on) document.body.appendChild(r); else { const g = $("#pg-friends .frgrid"); if (g) g.after(r); } r.classList.toggle("pool-fs", on); document.body.classList.toggle("pool-fs-on", on); const b = r.querySelector('[data-g="fs"]'); if (b) b.textContent = on ? "✕ Tam ekrandan çık" : "⛶ Tam ekran";
  try { if (on && document.documentElement.requestFullscreen) document.documentElement.requestFullscreen().catch(() => {}); else if (!on && document.fullscreenElement) document.exitFullscreen(); } catch (e) { /* */ } }

/* Arkadaşlar ekranına "Sohbet | Bilardo" anahtarı */
function mount() {
  const pg = $("#pg-friends"); if (!pg || $("#pool-root")) return; const grid = pg.querySelector(".frgrid"); if (!grid) return;
  const sw = document.createElement("div"); sw.className = "seg pool-sw"; sw.innerHTML = '<button data-m="chat" class="on">💬 Sohbet</button><button data-m="pool">🎱 Bilardo</button>'; grid.before(sw);
  const root = document.createElement("div"); root.id = "pool-root"; root.className = "panel"; grid.after(root);
  $$("button", sw).forEach((b) => (b.onclick = () => { const on = b.dataset.m === "pool"; $$("button", sw).forEach((x) => x.classList.toggle("on", x === b)); grid.style.display = on ? "none" : ""; root.classList.toggle("on", on); if (on) { if (!P.es) connect(); root._h = ""; render(); } }));
}
window.addEventListener("DOMContentLoaded", () => { setTimeout(mount, 400); TICKS.push(frame); setInterval(() => { if ($("#pool-root.on")) render(); }, 1500); window.DT.on("theme", () => { const r = $("#pool-root"); if (r) { r._h = ""; render(); } }); });
window.NeraPool = { P, _t: { shoot, runAll, rules, newGame, afterShot, ball, roll }, _msg: (o) => onMsg({ event: "message", id: "t" + Math.random(), message: JSON.stringify(o) }) };
})();
