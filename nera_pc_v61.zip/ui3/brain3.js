"use strict";
/* NERA 3 · Beyin: açılışla AYNI sahne (NeraSwarm.swarm). Kozmos'un VERİSİNİ aynen kullanır: Cosmos.P (gezegen listesi/renk), Cosmos.go/focus/hot, Lab.planetInfo(k,true).v, Lab.stats.rate.
   Parçacık küre = çekirdek; gezegenler = düğümler; çekirdekten düğümlere kavisli bağ ve akan ışık darbeleri; olay/sinyalde küre dağılıp toplanır (Scatter).
   Seçim/gezinme/bilgi kartı DOM'da olduğu gibi çalışır. WebGL yoksa eski Kozmos çizimi sürer. Veri/iş mantığı değişmez. */
(function () {
const U = window.NeraUI, S = window.NeraSwarm; if (!U || !S || !document.body.classList.contains("u3")) return;
const B = (window.NeraBrain3 = { on: false, yaw: 0, pitch: 0.01, D: 10.6, zoom: 1, enterP: 0, nodes: [], pulses: [], labs: {}, vals: {}, vt: 0, act: 0.3, hover: null, drag: null, mx: -1, my: -1 });
const rnd = (a, b) => a + Math.random() * (b - a);
const hex = (T, f) => new T.Color(f());

function glowTex(T) { const c = document.createElement("canvas"); c.width = c.height = 128; const x = c.getContext("2d"), g = x.createRadialGradient(64, 64, 0, 64, 64, 64); g.addColorStop(0, "rgba(255,255,255,1)"); g.addColorStop(0.3, "rgba(255,255,255,.45)"); g.addColorStop(1, "rgba(255,255,255,0)"); x.fillStyle = g; x.fillRect(0, 0, 128, 128); return new T.CanvasTexture(c); }


/* ---- gezegen kimlikleri: her düğümün kendine özgü parçacık biçimi (Gather'ın "Marks/Line/Swarm" dilinden esinlenen, bize ait üretim) ---- */
const FN = 160;
function formPoints(k) {
  const P = new Float32Array(FN * 3), put = (i, x, y, z) => { P[i * 3] = x; P[i * 3 + 1] = y; P[i * 3 + 2] = z; };
  for (let i = 0; i < FN; i++) {
    const u = i / FN, r1 = Math.random(), r2 = Math.random();
    if (k === "mk") put(i, (u - 0.5) * 2.6, Math.sin(u * 14) * 0.28, (r1 - 0.5) * 0.25);                                   /* piyasa akışı: dalga şeridi */
    else if (k === "hist") { const ring = i % 5, a = u * 6.283 * 9; put(i, Math.cos(a) * (0.35 + ring * 0.2), (ring - 2) * 0.16, Math.sin(a) * (0.35 + ring * 0.2)); }   /* geçmiş veri: üst üste halkalar (katmanlar) */
    else if (k === "kb") { const n = 5, c = i % (n * n * n); put(i, (c % n - 2) * 0.3, (Math.floor(c / n) % n - 2) * 0.3, (Math.floor(c / (n * n)) - 2) * 0.3); }   /* bilgi bankası: kafes (raflar) */
    else if (k === "sig") { const th = r1 * 6.283, ph = Math.acos(2 * r2 - 1), L = i % 4 === 0 ? 1.5 : 0.5 + Math.random() * 0.5; put(i, Math.sin(ph) * Math.cos(th) * L, Math.cos(ph) * L, Math.sin(ph) * Math.sin(th) * L); }   /* sinyal defteri: ışın patlaması */
    else if (k === "idea") { const th = r1 * 6.283, ph = Math.acos(2 * r2 - 1), L = 0.3 + Math.pow(Math.random(), 0.5) * 1.1; put(i, Math.sin(ph) * Math.cos(th) * L, Math.cos(ph) * L, Math.sin(ph) * Math.sin(th) * L); }   /* fikir: saçılan kıvılcımlar */
    else if (k === "test") { const a = u * 6.283 * 3, y = (u - 0.5) * 2.2, s = i % 2 ? 0 : 3.14; put(i, Math.cos(a + s) * 0.45, y, Math.sin(a + s) * 0.45); }   /* test: çift sarmal */
    else if (k === "rej") put(i, (r1 - 0.5) * 1.6, (r2 - 0.5) * 2.2, (Math.random() - 0.5) * 0.8);                           /* elenen: düşen parçalar */
    else if (k === "labsig") { const ring = i % 3, a = u * 6.283 * 12, R = 0.5 + ring * 0.32; put(i, Math.cos(a) * R, Math.sin(a) * R * 0.35 * (ring + 1) * 0.5, Math.sin(a) * R); }   /* lab sinyalleri: iç içe yörünge halkaları */
    else { const th = r1 * 6.283, ph = Math.acos(2 * r2 - 1); put(i, Math.sin(ph) * Math.cos(th) * 0.8, Math.cos(ph) * 0.8, Math.sin(ph) * Math.sin(th) * 0.8); }
  }
  return P;
}
function makeForm(T, p, col, tex) {
  const base = formPoints(p.k), pos = new Float32Array(base), geo = new T.BufferGeometry(); geo.setAttribute("position", new T.BufferAttribute(pos, 3));
  const o = new T.Points(geo, new T.PointsMaterial({ color: col, size: 0.09, map: tex, transparent: true, opacity: 0.85, blending: T.AdditiveBlending, depthWrite: false }));
  const sc = 0.4 + p.pr * 1.15; o.scale.setScalar(sc); o.rotation.set(Math.random() * 3, Math.random() * 3, 0);
  return { o, base, pos, geo, k: p.k, sc };
}
function stepForm(f, t, dt, e) {
  const o = f.o, k = f.k; o.rotation.y += dt * (k === "test" ? 0.3 : k === "hist" ? 0.2 : k === "labsig" ? 0.3 : k === "idea" || k === "rej" ? 0.12 : 0.25); o.scale.setScalar(f.sc * (1 + e * 0.35 + (k === "sig" || k === "idea" ? 0.06 * Math.sin(t * 0.9) : 0)));
  if (k === "mk") { for (let i = 0; i < FN; i++) f.pos[i * 3 + 1] = Math.sin(f.base[i * 3] * 5.4 + t * 0.9) * 0.28; f.geo.attributes.position.needsUpdate = true; }
  else if (k === "rej") { for (let i = 0; i < FN; i++) { let y = f.base[i * 3 + 1] - ((t * 0.07 + i * 0.013) % 1) * 2.2; if (y < -1.1) y += 2.2; f.pos[i * 3 + 1] = y; } f.geo.attributes.position.needsUpdate = true; }
}

function build() {
  const sw = S.swarm, T = S.T, P = (window.Cosmos && Cosmos.P) || []; if (!sw || !P.length || B.built) return; B.built = true;
  const tex = (B.tex = glowTex(T)), add = T.AdditiveBlending, grp = (B.grp = new T.Group()); sw.scene.add(grp);
  P.forEach((p, i) => {
    const col = hex(T, p.col), g = new T.Group(), body = new T.Mesh(new T.SphereGeometry(0.06 + p.pr * 0.3, 20, 14), new T.MeshBasicMaterial({ color: col })), halo = new T.Sprite(new T.SpriteMaterial({ map: tex, color: col, transparent: true, opacity: 0.55, blending: add, depthWrite: false }));
    halo.scale.setScalar(0.45 + p.pr * 2.1); g.add(body, halo); const form = makeForm(T, p, col, tex); g.add(form.o); body.scale.setScalar(0.55);
    if (p.ring) { const ring = new T.Mesh(new T.RingGeometry(0.2 + p.pr * 1.1, 0.215 + p.pr * 1.1, 64), new T.MeshBasicMaterial({ color: col, side: T.DoubleSide, transparent: true, opacity: 0.5, blending: add, depthWrite: false })); ring.rotation.x = 1.15; g.add(ring); }
    grp.add(g);
    const pts = new Float32Array(49 * 3), geo = new T.BufferGeometry(); geo.setAttribute("position", new T.BufferAttribute(pts, 3));
    const line = new T.Line(geo, new T.LineBasicMaterial({ color: col, transparent: true, opacity: 0.3, blending: add, depthWrite: false })); grp.add(line);
    B.nodes.push({ form, p, g, body, halo, line, pts, geo, col, a: p.a, e: 0, w: new T.Vector3(), cs: null });
    const el = document.createElement("div"); el.className = "nb-lab"; el.style.setProperty("--pc", p.col()); el.innerHTML = `<i></i><b>${p.n}</b><span>—</span><em></em>`; B.lab.appendChild(el); B.labs[p.k] = el;
  });
  B.pg = new T.BufferGeometry(); B.pmax = 64; B.pg.setAttribute("position", new T.BufferAttribute(new Float32Array(B.pmax * 3), 3)); B.pg.setAttribute("color", new T.BufferAttribute(new Float32Array(B.pmax * 3), 3));
  grp.add(new T.Points(B.pg, new T.PointsMaterial({ size: 0.3, map: tex, vertexColors: true, transparent: true, blending: add, depthWrite: false })));
  if (window.Cosmos && !Cosmos._h3b) { Cosmos._h3b = Cosmos.hot; Cosmos.hot = function (k, s) { Cosmos._h3b.call(this, k, s); B.pulse(k, s); }; }
}
B.pulse = (k, s) => { const n = B.nodes.find((x) => x.p.k === k); if (!n) return; n.e = Math.min(1, n.e + 0.3 * (s || 1)); if (B.pulses.length < 40) B.pulses.push({ n, t: 0, dir: n.p.role < 0 ? 1 : -1, v: rnd(0.45, 0.8) }); };
B.scatter = (k) => { const sw = S.swarm; if (!sw || !window.gsap) return; gsap.killTweensOf(sw.u.uScatter); gsap.fromTo(sw.u.uScatter, { value: 0 }, { value: k || 0.45, duration: 0.35, ease: "nera.out", yoyo: true, repeat: 1, repeatDelay: 0.05, onComplete: () => { sw.u.uScatter.value = 0; } }); };
function pick(mx, my) {
  let best = null, bd = 1e9; B.nodes.forEach((n) => { const v = n.w.clone().project(S.swarm.cam); if (v.z > 1) return; const sx = (v.x * 0.5 + 0.5) * S.w, sy = (-v.y * 0.5 + 0.5) * S.h, d = Math.hypot(sx - mx, sy - my); if (d < Math.max(34, 96 / (B.D / 10.6)) && d < bd) { bd = d; best = n; } }); return best;
}
function wire() {
  const core = document.getElementById("bv-core"); if (!core || core._b3) return; core._b3 = 1;
  const orb = document.getElementById("orb-big"); if (orb) { orb.style.pointerEvents = "none"; orb.style.opacity = "0"; }
  core.setAttribute("data-lenis-prevent", "");
  core.addEventListener("pointerdown", (e) => { if (e.target.closest("#cos-ui .cos-nav, #cos-ui .cos-card")) return; B.drag = { x: e.clientX, y: e.clientY, lx: e.clientX, ly: e.clientY, m: 0 }; try { core.setPointerCapture(e.pointerId); } catch (x) { /* */ } });
  core.addEventListener("pointermove", (e) => { B.mx = e.clientX; B.my = e.clientY; if (!B.drag) return; const dx = e.clientX - B.drag.lx, dy = e.clientY - B.drag.ly; B.drag.m += Math.abs(dx) + Math.abs(dy); B.drag.lx = e.clientX; B.drag.ly = e.clientY; if (B.drag.m > 6) { B.yaw -= dx * 0.006; B.pitch = Math.max(-1.1, Math.min(1.1, B.pitch + dy * 0.005)); } });
  const up = (e) => { if (!B.drag) return; const moved = B.drag.m > 6; B.drag = null; if (moved) return; const h = pick(e.clientX, e.clientY); if (window.Cosmos) Cosmos.go(h ? h.p.k : null); };
  core.addEventListener("pointerup", up); core.addEventListener("pointercancel", () => { B.drag = null; }); core.addEventListener("pointerleave", () => { B.mx = B.my = -1; });
  core.addEventListener("wheel", (e) => { if (window.Cosmos && Cosmos.focus) return; e.preventDefault(); B.zoom = Math.max(0.65, Math.min(1.6, B.zoom * (e.deltaY > 0 ? 0.93 : 1.07))); }, { passive: false });
}
B.enter = () => { B.enterP = 0; B.enterT = performance.now(); if (B.grp) B.grp.visible = true; };
/* açılış sırasında sahneyi gizli kur ve gölgelendiricileri derle: devir anında tek karede 170 ms takılma olmasın */
B.prebuild = () => {
  const sw = S.swarm; if (!sw || B.built || !S.r || !window.Cosmos || !Cosmos.P || !Cosmos.P.length) return;
  if (!B.lab) { B.lab = document.createElement("div"); B.lab.id = "u3-labels"; document.body.appendChild(B.lab); }
  build(); wire(); if (!B.grp) return; try { S.r.compile(sw.scene, sw.cam); } catch (e) { /* derleme yedeği: ilk karede */ } B.grp.visible = false;
};
function frame(mode, dt, now) {
  if (mode !== "swarm") return; const sw = S.swarm, T = S.T, C = window.Cosmos; if (!sw || !B.on || S.layer === "splash" && !B.built) return;
  if (!B.lab) { B.lab = document.createElement("div"); B.lab.id = "u3-labels"; document.body.appendChild(B.lab); }
  build(); wire();
  const rate = (window.Lab && Lab.stats && +Lab.stats.rate) || 0; B.act += (Math.min(1, rate / 12) - B.act) * 0.03; S.bloom = 0.68 + B.act * 0.3;
  if (B.enterP < 1) B.enterP = Math.min(1, (performance.now() - (B.enterT || 0)) / 1500); const ee = 1 - Math.pow(1 - B.enterP, 3);
  const foc = C && C.focus ? B.nodes.find((n) => n.p === C.focus) : null;
  B.nodes.forEach((n, i) => {
    const p = n.p, R = p.orbit * 1.12 * ee, ic = p.inc * 2.8; n.a += dt * p.sp * (U.reduced() ? 0.3 : 0.6);
    n.g.position.set(Math.cos(n.a) * R, Math.sin(n.a) * R * Math.sin(ic), Math.sin(n.a) * R * Math.cos(ic)); n.w.copy(n.g.position); n.e *= 0.965;
    if (n.form) stepForm(n.form, now / 1000, dt, n.e); n.g.scale.setScalar(1 + n.e * 0.5 + (foc === n ? 0.35 : 0) + (B.hover === n ? 0.2 : 0)); n.halo.material.opacity = 0.45 + n.e * 0.5 + (foc === n ? 0.2 : 0);
    const a = n.g.position, dir = a.clone().normalize(), s0 = dir.clone().multiplyScalar(1.7), ctrl = a.clone().multiplyScalar(0.5).add(new T.Vector3(-dir.z, 0.55 + 0.25 * Math.sin(i), dir.x).multiplyScalar(0.8)), pts = n.pts;
    for (let q = 0; q <= 48; q++) { const u = q / 48, w1 = (1 - u) * (1 - u), w2 = 2 * u * (1 - u), w3 = u * u; pts[q * 3] = w1 * s0.x + w2 * ctrl.x + w3 * a.x; pts[q * 3 + 1] = w1 * s0.y + w2 * ctrl.y + w3 * a.y; pts[q * 3 + 2] = w1 * s0.z + w2 * ctrl.z + w3 * a.z; }
    n.geo.attributes.position.needsUpdate = true; n.line.material.opacity = (0.2 + 0.25 * n.e + (foc === n ? 0.3 : 0)) * ee; n.cs = [s0, ctrl, a];
    const el = B.labs[p.k];
  });
  if (!U.reduced() && B.nodes.length && Math.random() < dt * (0.6 + B.act * 2)) B.pulse(B.nodes[Math.floor(Math.random() * B.nodes.length)].p.k, 0.3);
  const pp = B.pg.attributes.position.array, pc = B.pg.attributes.color.array; let m = 0;
  for (let i = B.pulses.length - 1; i >= 0; i--) {
    const u = B.pulses[i]; u.t += dt * u.v; if (u.t >= 1) { B.pulses.splice(i, 1); continue; }
    const tt = u.dir > 0 ? 1 - u.t : u.t, [s0, ctrl, a] = u.n.cs || [], q = 1 - tt; if (!a || m >= B.pmax) continue;
    pp[m * 3] = q * q * s0.x + 2 * q * tt * ctrl.x + tt * tt * a.x; pp[m * 3 + 1] = q * q * s0.y + 2 * q * tt * ctrl.y + tt * tt * a.y; pp[m * 3 + 2] = q * q * s0.z + 2 * q * tt * ctrl.z + tt * tt * a.z;
    const f = Math.sin(Math.PI * u.t); pc[m * 3] = u.n.col.r * f + f * 0.3; pc[m * 3 + 1] = u.n.col.g * f + f * 0.3; pc[m * 3 + 2] = u.n.col.b * f + f * 0.3; m++;
  }
  B.pg.setDrawRange(0, m); B.pg.attributes.position.needsUpdate = true; B.pg.attributes.color.needsUpdate = true;
  /* kamera: giriş yaklaşımı, yavaş otomatik dönüş, seçili gezegene uçuş */
  const tgtPitch = 0.28; if (!B.drag) B.pitch += (tgtPitch - B.pitch) * Math.min(1, dt * 0.9);
  if (!B.drag && !(C && C.focus) && !U.reduced()) B.yaw += dt * 0.04; sw.pts.rotation.y += dt * 0.05;
  const tgt = foc ? foc.w : new T.Vector3(0, 0, 0), D = foc ? 4.6 : 10.6 * B.zoom; B.D += (D - B.D) * Math.min(1, dt * 2.6); if (!B.tgt) B.tgt = new T.Vector3(); B.tgt.lerp(tgt, Math.min(1, dt * 3));
  const cy = Math.cos(B.pitch), cam = sw.cam; cam.position.set(B.tgt.x + Math.sin(B.yaw) * cy * B.D, B.tgt.y + Math.sin(B.pitch) * B.D, B.tgt.z + Math.cos(B.yaw) * cy * B.D); cam.lookAt(B.tgt);
  /* etiketler + değerler (Lab.planetInfo ~0,6 sn'de bir) */
  B.hover = B.mx >= 0 && !B.drag ? pick(B.mx, B.my) : null;
  if (now - B.vt > 600) { B.vt = now; if (window.Lab && Lab.planetInfo) B.nodes.forEach((n) => { try { const v = Lab.planetInfo(n.p.k, true); B.vals[n.p.k] = v && v.v != null ? v.v : "—"; } catch (e) { /* */ } }); if (C && C.card) C.card(); }
  B.nodes.forEach((n) => { const el = B.labs[n.p.k]; if (!el) return; const v = n.w.clone().project(cam), on = v.z < 1 && ee > 0.4; el.style.opacity = on ? (foc && foc !== n ? 0.3 : 1) : 0; if (!on) return; el.style.transform = `translate(${((v.x * 0.5 + 0.5) * S.w).toFixed(1)}px, ${((-v.y * 0.5 + 0.5) * S.h).toFixed(1)}px) translate(-50%, 16px)`; if ((B.fc = (B.fc || 0) + 1) % 8 === 0) { const em = el.lastChild; if (em) em.textContent = String(B.nodes.indexOf(n) + 1).padStart(2, "0") + " TRACK " + v.x.toFixed(2) + " " + v.y.toFixed(2) + " " + (v.z * 10 - 9).toFixed(2); } const sp = el.lastChild, nv = String(B.vals[n.p.k] == null ? "—" : B.vals[n.p.k]); if (sp._v !== nv) { sp._v = nv; sp.textContent = nv; } el.classList.toggle("hov", B.hover === n); });
}
/* görünüm yönetimi: yalnız Beyin ekranında ve açılış bittikten sonra sahne çalışır */
function sync() {
  const v = document.body.dataset.view, splash = S.layer === "splash";
  B.on = v === "brain" && !splash && S.ready && !!S.swarm;
  if (S.ready && !splash && S.mode !== "none" && v !== "brain" && v !== "nflow") S.setMode("none");
  if (v === "brain" && !splash && S.swarm) { if (S.mode !== "swarm") S.setMode("swarm"); const core = document.getElementById("bv-core"); if (core) { const r = core.getBoundingClientRect(), key = [r.left, r.top, r.width, r.height].map(Math.round).join("|"); if (key !== B.rk && !S.tweening) { B.rk = key; S.centerOn(core); } } window.NERA_3D = true; }
  if (B.lab) B.lab.style.display = B.on ? "" : "none";
  document.body.classList.toggle("u3-brain3", B.on);
}
S.cbs.push(frame);
U.tick(sync, { fps: 8 });
if (window.DT) { DT.on("signal", (e) => { B.scatter(0.5); }); DT.on("view", (v) => { if (v === "brain") { B.enter(); } }); }
addEventListener("resize", () => { const core = document.getElementById("bv-core"); if (B.on && core) S.centerOn(core); });
/* WebGL kullanılamıyorsa eski Kozmos sürer */
if (!S.available) window.NERA_3D = false;
})();
