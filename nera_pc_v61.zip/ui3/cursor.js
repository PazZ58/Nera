"use strict";
/* NERA 3 · imleç efekti (4. tur, baştan): imleç arkasında parlayan, incelen bir ŞERİT bırakır; yol boyunca YILDIZ TOZU saçılır, yakın tozlar ince çizgilerle bağlanır ve sönerek dağılır.
   Tıklayınca toz halka şeklinde patlar. Üstte tek tuval, çizim 'lighter'. Dokunmatikte ve azaltılmış harekette kapalı. Yerel imleç kalır. */
(function () {
const U = window.NeraUI; if (!U || !document.body.classList.contains("u3") || U.reduced() || U.mobile() || matchMedia("(pointer:coarse)").matches) return;
const cv = document.createElement("canvas"); cv.id = "u3-fxc"; document.body.appendChild(cv); const x = cv.getContext("2d");
let W = 0, H = 0; const size = () => { const d = Math.min(devicePixelRatio || 1, 1.5); W = innerWidth; H = innerHeight; cv.width = W * d; cv.height = H * d; cv.style.width = W + "px"; cv.style.height = H + "px"; x.setTransform(d, 0, 0, d, 0, 0); }; size(); addEventListener("resize", size);
const css = (k, d) => getComputedStyle(document.body).getPropertyValue(k).trim() || d;
const rgb = (hex) => { const h = hex.replace("#", ""), n = parseInt(h.length === 3 ? h.replace(/./g, "$&$&") : h, 16); return [n >> 16, (n >> 8) & 255, n & 255]; };
let trail = [], dust = [], c1 = rgb("#7cf2ff"), c2 = rgb("#a98bff"), lx = -1, ly = -1, acc = 0, idle = 0;
const mix = (t) => c1.map((v, i) => (v + (c2[i] - v) * t) | 0);
addEventListener("pointermove", (e) => {
  const now = performance.now(); trail.push({ x: e.clientX, y: e.clientY, t: now }); if (trail.length > 36) trail.shift(); idle = 0;
  if (lx >= 0) { const d = Math.hypot(e.clientX - lx, e.clientY - ly); acc += d; while (acc > 14) { acc -= 14; dust.push({ x: e.clientX + (Math.random() - 0.5) * 8, y: e.clientY + (Math.random() - 0.5) * 8, vx: (Math.random() - 0.5) * 0.5, vy: (Math.random() - 0.5) * 0.5 - 0.1, l: 1, k: Math.random(), r: 0.8 + Math.random() * 1.6 }); } if (dust.length > 90) dust.splice(0, dust.length - 90); }
  lx = e.clientX; ly = e.clientY;
}, { passive: true });
addEventListener("pointerdown", (e) => { for (let i = 0; i < 18; i++) { const a = (i / 18) * 6.283 + Math.random() * 0.3, s = 1.6 + Math.random() * 1.6; dust.push({ x: e.clientX, y: e.clientY, vx: Math.cos(a) * s, vy: Math.sin(a) * s, l: 1, k: Math.random(), r: 1.2 + Math.random() * 1.6 }); } }, true);
U.tick((now) => {
  if (!trail.length && !dust.length) { if (cv._d) { x.clearRect(0, 0, W, H); cv._d = 0; } return; } cv._d = 1;
  if (Math.random() < 0.05) { c1 = rgb(css("--u3-acc", "#7cf2ff")); c2 = rgb(css("--u3-acc2", "#a98bff")); }
  x.clearRect(0, 0, W, H); x.globalCompositeOperation = "lighter"; x.lineCap = "round"; x.lineJoin = "round";
  while (trail.length && now - trail[0].t > 420) trail.shift();
  /* şerit: yaşlandıkça incelir ve söner */
  for (let i = 1; i < trail.length; i++) { const a = trail[i - 1], b = trail[i], age = (now - b.t) / 420, f = Math.max(0, 1 - age), c = mix(i / trail.length); x.strokeStyle = `rgba(${c[0]},${c[1]},${c[2]},${(0.75 * f).toFixed(3)})`; x.lineWidth = 1 + 7 * f * (i / trail.length); x.beginPath(); x.moveTo(a.x, a.y); x.lineTo(b.x, b.y); x.stroke(); }
  if (trail.length) { const p = trail[trail.length - 1], f = Math.max(0, 1 - (now - p.t) / 420); if (f > 0) { const g = x.createRadialGradient(p.x, p.y, 0, p.x, p.y, 22); g.addColorStop(0, `rgba(255,255,255,${0.55 * f})`); g.addColorStop(0.4, `rgba(${c1[0]},${c1[1]},${c1[2]},${0.3 * f})`); g.addColorStop(1, "rgba(0,0,0,0)"); x.fillStyle = g; x.fillRect(p.x - 22, p.y - 22, 44, 44); } }
  /* yıldız tozu + bağlar */
  for (let i = dust.length - 1; i >= 0; i--) { const d = dust[i]; d.x += d.vx; d.y += d.vy; d.vx *= 0.985; d.vy *= 0.985; d.l -= 0.011; if (d.l <= 0) { dust.splice(i, 1); continue; } }
  for (let i = 0; i < dust.length; i++) { const a = dust[i], c = mix(a.k); for (let j = i + 1; j < dust.length; j++) { const b = dust[j], dd = Math.hypot(a.x - b.x, a.y - b.y); if (dd < 64) { x.strokeStyle = `rgba(${c[0]},${c[1]},${c[2]},${(0.28 * (1 - dd / 64) * Math.min(a.l, b.l)).toFixed(3)})`; x.lineWidth = 0.7; x.beginPath(); x.moveTo(a.x, a.y); x.lineTo(b.x, b.y); x.stroke(); } } x.fillStyle = `rgba(${c[0]},${c[1]},${c[2]},${a.l.toFixed(3)})`; x.beginPath(); x.arc(a.x, a.y, a.r * (0.5 + a.l * 0.5), 0, 6.283); x.fill(); }
  x.globalCompositeOperation = "source-over";
}, { fps: 60 });
})();
