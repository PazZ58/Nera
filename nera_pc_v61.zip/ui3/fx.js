"use strict";
/* NERA 3 · NeraFx: Gather · 聚 by DAO'nun görsel dilinden (Drift, Links, Trails, Splash, Gather, Scan) esinlenen, kendi yazdığımız hafif 2B parçacık efektleri.
   Kod kopyalanmadı. Brain/NeraFlow'daki WebGL sahnesinin dışındaki ekranlar için: ortam (Drift+Links), patlama (Splash+Trails), boş durum (Gather), ekran girişi (Scan).
   Tek zamanlayıcı: NeraUI.tick. Azaltılmış harekette (nera_fx=0) hepsi kapalı. */
(function () {
const U = window.NeraUI; if (!U || !document.body.classList.contains("u3")) return;
const css = (k, d) => (getComputedStyle(document.body).getPropertyValue(k).trim() || d);
const rgba = (hex, a) => { const h = hex.replace("#", ""), n = parseInt(h.length === 3 ? h.replace(/./g, "$&$&") : h, 16); return `rgba(${n >> 16},${(n >> 8) & 255},${n & 255},${a})`; };
const F = (window.NeraFx = {});

/* ---- ortam: Drift + Links (Brain/NeraFlow dışındaki ekranların arkasında, çok seyrek) ---- */
const amb = document.createElement("canvas"); amb.id = "u3-amb"; document.body.prepend(amb);
const ax = amb.getContext("2d"); let AW = 0, AH = 0, pts = [];
function ambSize() { const d = Math.min(devicePixelRatio || 1, 1.5); AW = amb.width = Math.round(innerWidth * d); AH = amb.height = Math.round(innerHeight * d); pts = Array.from({ length: U.mobile() ? 28 : (window.NeraGather && NeraGather.density() === "dense" ? 130 : 70) }, () => ({ x: Math.random() * AW, y: Math.random() * AH, vx: (Math.random() - 0.5) * 0.25, vy: (Math.random() - 0.5) * 0.25, r: 0.6 + Math.random() * 1.4 })); }
ambSize(); addEventListener("resize", ambSize); F.resize = ambSize;
function ambFrame() {
  if (U.lite()) { amb.style.display = "none"; return; }
  const v = document.body.dataset.view, off = v === "brain" || v === "nflow" || document.body.classList.contains("u3-splash") || document.hidden || U.reduced();
  amb.style.opacity = off ? "0" : "1"; if (off) return;
  ax.clearRect(0, 0, AW, AH); const c1 = css("--u3-acc", "#7cf2ff"), c2 = css("--u3-acc2", "#a98bff"), L = 150 * (AW / 1920 + 0.4);
  for (const p of pts) { p.x += p.vx; p.y += p.vy; if (p.x < 0) p.x = AW; if (p.x > AW) p.x = 0; if (p.y < 0) p.y = AH; if (p.y > AH) p.y = 0; }
  for (let i = 0; i < pts.length; i++) { const a = pts[i]; for (let j = i + 1; j < pts.length; j++) { const b = pts[j], d = Math.hypot(a.x - b.x, a.y - b.y); if (d < L) { ax.strokeStyle = rgba(c2, 0.14 * (1 - d / L)); ax.beginPath(); ax.moveTo(a.x, a.y); ax.lineTo(b.x, b.y); ax.stroke(); } } ax.fillStyle = rgba(c1, 0.5); ax.beginPath(); ax.arc(a.x, a.y, a.r, 0, 6.283); ax.fill(); }
}
U.tick(ambFrame, { fps: 24 });

/* ---- patlama: Splash + Trails. Bir öğenin merkezinden renkli parçacıklar saçılır, iz bırakıp söner ---- */
const bc = document.createElement("canvas"); bc.id = "u3-burst"; document.body.appendChild(bc); const bx = bc.getContext("2d"); let bp = [];
function bSize() { bc.width = innerWidth; bc.height = innerHeight; } bSize(); addEventListener("resize", bSize);
F.burst = (x, y, col, n = 46, power = 1) => { if (U.reduced()) return; const c = col || css("--u3-acc", "#7cf2ff"); for (let i = 0; i < n; i++) { const a = Math.random() * 6.283, s = (1 + Math.random() * 4.2) * power; bp.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, life: 1, d: 0.012 + Math.random() * 0.016, c, r: 1 + Math.random() * 1.6 }); } if (bp.length > 400) bp.splice(0, bp.length - 400); };
F.burstEl = (el, col, n, p) => { if (!el || !el.getBoundingClientRect) return; const r = el.getBoundingClientRect(); F.burst(r.left + r.width / 2, r.top + r.height / 2, col, n, p); };
U.tick(() => {
  if (!bp.length) { if (bc._d) { bx.clearRect(0, 0, bc.width, bc.height); bc._d = 0; } return; } bc._d = 1;
  bx.globalCompositeOperation = "destination-out"; bx.fillStyle = "rgba(0,0,0,.14)"; bx.fillRect(0, 0, bc.width, bc.height); bx.globalCompositeOperation = "lighter";
  for (let i = bp.length - 1; i >= 0; i--) { const p = bp[i]; p.x += p.vx; p.y += p.vy; p.vx *= 0.955; p.vy *= 0.955; p.vy += 0.015; p.life -= p.d; if (p.life <= 0) { bp.splice(i, 1); continue; } bx.fillStyle = rgba(p.c, p.life * 0.9); bx.beginPath(); bx.arc(p.x, p.y, p.r, 0, 6.283); bx.fill(); }
}, { fps: 45 });

/* ---- boş durum: Gather. Dağınık noktalar bir halkaya (Nera yörüngesi) toplanır, tarama çizgisi geçer ---- */
const empties = new Set();
function mkEmpty(el) {
  if (U.lite()) return;
  if (window.NeraGather && !el._fx) { el._fx = 1; window.NeraGather.mount(el, { w: 300, h: 130 }); return; }
  if (el._fx || U.reduced()) return; el._fx = 1; const c = document.createElement("canvas"); c.className = "u3-empty-cv"; c.width = 240; c.height = 56; el.prepend(c);
  const N = 70, P = Array.from({ length: N }, (_, i) => { const a = (i / N) * 6.283, k = i % 2; return { sx: Math.random() * 240, sy: Math.random() * 56, tx: 120 + Math.cos(a) * 54, ty: 28 + Math.sin(a) * (k ? 9 : 17), s: Math.random() }; });
  empties.add({ el, c, P, t0: performance.now() });
}
F.scan = () => { const e = document.createElement("div"); e.className = "u3-scan"; document.body.appendChild(e); if (window.gsap) gsap.fromTo(e, { xPercent: -100, opacity: 1 }, { xPercent: 100, opacity: 0, duration: 1.1, ease: "nera.inOut", onComplete: () => e.remove() }); else setTimeout(() => e.remove(), 1200); };
U.tick(() => {
  const now = performance.now(), col = css("--u3-acc", "#7cf2ff");
  empties.forEach((o) => { if (!o.el.isConnected) { empties.delete(o); return; } if (o.el.offsetParent === null) return; const x = o.c.getContext("2d"), t = ((now - o.t0) / 1000) % 6, g = Math.min(1, t / 2.2), e = 1 - Math.pow(1 - g, 3), br = Math.sin(now / 900) * 2;
    x.clearRect(0, 0, 240, 56); const sc = ((t - 2.4) / 1.2) * 280 - 20;
    o.P.forEach((p) => { const px = p.sx + (p.tx - p.sx) * e + Math.cos(now / 700 + p.s * 9) * (1 - e) * 4, py = p.sy + (p.ty - p.sy) * e + br * (e > 0.9 ? 0.4 : 0), lit = Math.abs(px - sc) < 14; x.fillStyle = rgba(col, lit ? 1 : 0.35 + 0.4 * e); x.fillRect(px, py, lit ? 2.2 : 1.4, lit ? 2.2 : 1.4); }); });
}, { fps: 24 });

/* ---- bağlar: yeni .empty, bildirim kartı, modal, sinyal ---- */
new MutationObserver((ms) => ms.forEach((m) => m.addedNodes.forEach((n) => {
  if (n.nodeType !== 1) return;
  if (n.matches(".empty")) mkEmpty(n); else n.querySelectorAll && n.querySelectorAll(".empty").forEach(mkEmpty);
  if (n.matches(".nn-card")) setTimeout(() => { const r = n.getBoundingClientRect(); F.burst(r.left + 20, r.top + r.height / 2, n.classList.contains("k-xm") ? css("--u3-warn", "#ffc77a") : css("--u3-acc", "#7cf2ff"), 26, 0.7); }, 120);
  if (n.matches(".wn-card")) setTimeout(() => F.burstEl(n, css("--u3-acc2", "#a98bff"), 60, 1.2), 200);
}))).observe(document.body, { childList: true, subtree: true });
document.querySelectorAll(".empty").forEach(mkEmpty);
if (window.DT) { DT.on("signal", () => F.burst(innerWidth * 0.6, 120, css("--u3-acc3", "#ff7ad9"), 70, 1.4)); }
})();
