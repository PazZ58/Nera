"use strict";
/* NERA 3 · NeraGather: Gather · 聚 by DAO'nun görsel dilinden esinlenen, kendi yazdığımız 2B nokta (stipple) motoru. Kod kopyalanmadı.
   Kaynak görüntü (Nera küresi) parlaklığa göre noktalara dökülür; parlaklık = derinlik. Özellikler Gather'daki adlarıyla:
   Drift (salınım), Splash (tıkla: patla), Gather (toplan), Depth (imleçle paralaks), Draw (halka çizilir), Track (izleyici kutuları + koordinat),
   Links (yakın noktalar arası bağ), Scan (tarama çizgisi), Trails (iz), Marks (köşe artıları + cetvel), Sparse/Dense (yoğunluk, Ayarlar),
   Travel Swarm/Melt (basılı tut: erir, bırak: sürü toplanır), Negative (açık temada ters renk). Tek zamanlayıcı: NeraUI.tick. */
(function () {
const U = window.NeraUI; if (!U || !document.body.classList.contains("u3")) return;
const css = (k, d) => (getComputedStyle(document.body).getPropertyValue(k).trim() || d);
const rgba = (hex, a) => { const h = hex.replace("#", ""), n = parseInt(h.length === 3 ? h.replace(/./g, "$&$&") : h, 16); return `rgba(${n >> 16},${(n >> 8) & 255},${n & 255},${a})`; };
const ease = (t) => 1 - Math.pow(1 - Math.min(1, Math.max(0, t)), 3);
const G = (window.NeraGather = { views: new Set() });
G.density = () => { try { return localStorage.getItem("nera_gd") || "sparse"; } catch (e) { return "sparse"; } };
G.setDensity = (d) => { try { localStorage.setItem("nera_gd", d); } catch (e) { /* */ } G.views.forEach((v) => v.build()); if (window.NeraFx && NeraFx.resize) NeraFx.resize(); };

/* kaynak: Nera küresi (disk + eğik halka), parlaklık haritası */
function source(W, H) {
  const c = document.createElement("canvas"); c.width = W; c.height = H; const x = c.getContext("2d", { willReadFrequently: true });
  x.fillStyle = "#000"; x.fillRect(0, 0, W, H);
  const cx = W / 2, cy = H / 2, R = H * 0.3, g = x.createRadialGradient(cx - R * 0.35, cy - R * 0.4, R * 0.1, cx, cy, R);
  g.addColorStop(0, "#fff"); g.addColorStop(0.6, "#9a9a9a"); g.addColorStop(1, "#2a2a2a"); x.fillStyle = g; x.beginPath(); x.arc(cx, cy, R, 0, 6.283); x.fill();
  x.save(); x.translate(cx, cy); x.rotate(-0.42); x.strokeStyle = "#d8d8d8"; x.lineWidth = H * 0.035; x.beginPath(); x.ellipse(0, 0, R * 1.95, R * 0.62, 0, 0, 6.283); x.stroke(); x.restore();
  return x.getImageData(0, 0, W, H).data;
}

G.mount = function (host, o = {}) {
  if (host._gv || U.reduced() || U.lite()) return; const cv = document.createElement("canvas"); cv.className = "gv-cv"; host.prepend(cv);
  const W = o.w || 300, H = o.h || 120, V = { host, cv, x: cv.getContext("2d"), W, H, t0: performance.now(), px: 0.5, py: 0.5, melt: 0, splash: 0, sp: [0, 0], P: [], T: [] };
  host._gv = V; G.views.add(V); cv.width = W * 2; cv.height = H * 2; cv.style.width = W + "px"; cv.style.height = H + "px";
  const SRC = source(W, H);
  V.build = () => {
    const N = G.density() === "dense" ? 4200 : 1800, cand = []; for (let y = 0; y < H; y += 2) for (let x = 0; x < W; x += 2) { const b = SRC[(y * W + x) * 4] / 255; if (b > 0.12) cand.push([x, y, b]); }
    V.P = Array.from({ length: N }, () => { const c = cand[Math.floor(Math.random() * cand.length)], a = Math.random() * 6.283; return { hx: c[0] + Math.random() * 2, hy: c[1] + Math.random() * 2, z: c[2], sx: Math.random() * W, sy: Math.random() * H, ph: Math.random() * 6.283, vy: 0 }; });
    const hi = V.P.filter((p) => p.z > 0.8); V.T = [[0.26, 0.3], [0.5, 0.5], [0.76, 0.62]].map(([fx, fy]) => hi.reduce((m, p) => (Math.hypot(p.hx - fx * W, p.hy - fy * H) < Math.hypot(m.hx - fx * W, m.hy - fy * H) ? p : m), hi[0] || V.P[0]));
    V.t0 = performance.now();
  };
  V.build();
  host.addEventListener("pointermove", (e) => { const r = cv.getBoundingClientRect(); V.px = (e.clientX - r.left) / r.width; V.py = (e.clientY - r.top) / r.height; });
  host.addEventListener("pointerleave", () => { V.px = 0.5; V.py = 0.5; });
  host.addEventListener("pointerdown", (e) => { const r = cv.getBoundingClientRect(); V.sp = [(e.clientX - r.left) / r.width * W, (e.clientY - r.top) / r.height * H]; V.splash = 1; V.down = true; });
  addEventListener("pointerup", () => { V.down = false; });
  return V;
};

U.tick((now) => {
  G.views.forEach((V) => {
    if (!V.host.isConnected) { G.views.delete(V); return; } if (V.host.offsetParent === null || document.hidden) return;
    const { x, W, H, P } = V, t = now - V.t0, g = ease(t / 2400), scan = ((t - 2600) / 1500) * (W + 80) - 40, acc = css("--u3-acc", "#7cf2ff"), acc2 = css("--u3-acc2", "#a98bff"), light = document.body.classList.contains("theme-light");
    V.melt += ((V.down ? 1 : 0) - V.melt) * 0.08; V.splash *= 0.93;
    x.setTransform(2, 0, 0, 2, 0, 0); x.globalCompositeOperation = "destination-out"; x.fillStyle = "rgba(0,0,0,.32)"; x.fillRect(0, 0, W, H); x.globalCompositeOperation = light ? "source-over" : "lighter";
    const base = light ? "#14123a" : "#ffffff";
    /* Marks: köşe artıları + alt cetvel */
    x.strokeStyle = rgba(acc, 0.35); x.lineWidth = 1; [[6, 6], [W - 6, 6], [6, H - 6], [W - 6, H - 6]].forEach(([a, b]) => { x.beginPath(); x.moveTo(a - 4, b); x.lineTo(a + 4, b); x.moveTo(a, b - 4); x.lineTo(a, b + 4); x.stroke(); });
    x.strokeStyle = rgba(acc, 0.18); x.beginPath(); for (let i = 0; i <= 20; i++) { const xx = 12 + (W - 24) * i / 20; x.moveTo(xx, H - 3); x.lineTo(xx, H - (i % 5 ? 5 : 8)); } x.stroke();
    /* noktalar: Gather + Drift + Depth + Splash + Melt */
    const px = (V.px - 0.5) * 2, py = (V.py - 0.5) * 2;
    for (const p of P) {
      const dr = Math.sin(t / 900 + p.ph) * (1.6 - g * 1.1), dc = Math.cos(t / 1100 + p.ph) * (1.6 - g * 1.1);
      let X = p.sx + (p.hx - p.sx) * g + dr + px * p.z * 9, Y = p.sy + (p.hy - p.sy) * g + dc + py * p.z * 6;
      if (V.melt > 0.02) { p.vy += 0.03 * V.melt; Y += p.vy * 8 * V.melt; } else p.vy *= 0.9;
      if (V.splash > 0.05) { const dx = X - V.sp[0], dy = Y - V.sp[1], d = Math.hypot(dx, dy) + 1; X += dx / d * V.splash * 26 * p.z; Y += dy / d * V.splash * 26 * p.z; }
      const lit = Math.abs(X - scan) < 14 ? 1 : 0, a = (0.22 + p.z * 0.6) * (0.4 + 0.6 * g) + lit * 0.5;
      x.fillStyle = lit ? rgba(acc, Math.min(1, a)) : rgba(base, a * (light ? 0.9 : 0.8)); const s = 0.5 + p.z * 0.8 + lit * 0.6; x.fillRect(X, Y, s, s); p._x = X; p._y = Y;
    }
    /* Links: bir altküme arasında yakın olanlar */
    x.strokeStyle = rgba(acc2, 0.16 * g); x.lineWidth = 0.6; x.beginPath(); for (let i = 0; i < 90; i++) { const a = P[i * 7 % P.length], b = P[(i * 7 + 13) % P.length]; if (Math.hypot(a._x - b._x, a._y - b._y) < 38) { x.moveTo(a._x, a._y); x.lineTo(b._x, b._y); } } x.stroke();
    /* Track: üç izleyici kutusu + koordinat */
    x.font = "500 8px " + css("--mono", "monospace"); V.T.forEach((p, k) => { if (g < 0.8 || !p._x) return; const bx = p._x, by = p._y, s = 9 + Math.sin(t / 500 + k) * 1.5; x.strokeStyle = rgba(acc, 0.9); x.lineWidth = 1; [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([sx, sy]) => { x.beginPath(); x.moveTo(bx + sx * s, by + sy * (s - 4)); x.lineTo(bx + sx * s, by + sy * s); x.lineTo(bx + sx * (s - 4), by + sy * s); x.stroke(); }); x.fillStyle = rgba(acc, 0.9); const tx = bx + s + 4 + 74 > W ? bx - s - 78 : bx + s + 4; x.fillText("0" + (k + 3) + " SEEK  " + (bx / W - 0.5).toFixed(2) + " " + (0.5 - by / H).toFixed(2), tx, by - s + 8); });
  });
}, { fps: 40 });
})();
