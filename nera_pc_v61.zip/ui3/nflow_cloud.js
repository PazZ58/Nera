"use strict";
/* NERA 3 · NeraFlow bulutu: GPU parçacık sistemi (NeraSwarm.flow). Eski 2B sprite bulutun yerine. Gerçek akışa bağlı (NFX):
   alış payı → renk dengesi (üst/alt renk), işlem hızı → akış hızı ve parlama, defter dengesi → eğim, satış baskısı → "Melt" (parçacıklar aşağı sarkar), alış baskısı → yukarı toplanma,
   büyük işlem/tasfiye → şok dalgası (NeraFlowCloud.shock). Üç iz kopyası (Trails). Yalnız çizer; veri/olay mantığı lab/nflow.js ve nflow_fx.js'te kalır. */
(function () {
const U = window.NeraUI, S = window.NeraSwarm; if (!U || !S || !document.body.classList.contains("u3")) return;
const N = window.NFX; const C = (window.NeraFlowCloud = { on: false, yaw: 0, pitch: 0.2, zoom: 1, drag: null, shocks: [], buy: 0.5, spd: 1, imb: 0, melt: 0, act: 0.3 });
const rnd = (a, b) => a + Math.random() * (b - a);
C.shock = (side, kind) => { const f = S.flow; if (!f || !C.on) return; if (C.shocks.length >= 3) C.shocks.shift(); C.shocks.push({ t: 0, side, k: kind === "liq" ? 1.25 : 1 }); };
function wire() {
  const pg = document.getElementById("pg-nflow"); if (!pg || pg._cl) return; pg._cl = 1;
  const own = (e) => e.target === pg || e.target.closest(".nf-grid") === null && !e.target.closest("button,select,input,.nf-pane,#nf-hud,.nf-cfg,.nf-top");
  pg.addEventListener("pointerdown", (e) => { if (!own(e)) return; C.drag = { x: e.clientX, y: e.clientY, lx: e.clientX, ly: e.clientY }; try { pg.setPointerCapture(e.pointerId); } catch (x) { /* */ } });
  pg.addEventListener("pointermove", (e) => { if (!C.drag) return; C.yaw -= (e.clientX - C.drag.lx) * 0.006; C.pitch = Math.max(-1, Math.min(1, C.pitch + (e.clientY - C.drag.ly) * 0.004)); C.drag.lx = e.clientX; C.drag.ly = e.clientY; });
  const up = () => { C.drag = null; }; pg.addEventListener("pointerup", up); pg.addEventListener("pointercancel", up);
  pg.addEventListener("wheel", (e) => { if (!pg.classList.contains("nf-cloudmode")) return; e.preventDefault(); C.zoom = Math.max(0.6, Math.min(1.7, C.zoom * (e.deltaY > 0 ? 1.07 : 0.93))); }, { passive: false });
  pg.setAttribute("data-lenis-prevent", "");
}
function frame(mode, dt, now) {
  if (mode !== "flow" || !C.on) return; const f = S.flow, T = S.T; if (!f) return; const u = f.u;
  const buy = N ? N.pressure : 0.5, act = N ? N.act : 0.3, imb = N ? N.imb : 0, rate = N ? N.rate || 0 : 0;
  C.buy += (buy - C.buy) * Math.min(1, dt * 2); C.act += (act - C.act) * Math.min(1, dt * 1.5); C.imb += (imb - C.imb) * Math.min(1, dt * 1.5);
  const meltT = C.buy < 0.5 ? Math.min(0.55, (0.5 - C.buy) * 1.2) : -Math.min(0.35, (C.buy - 0.5) * 0.7); C.melt += (meltT - C.melt) * Math.min(1, dt * 1.2);
  u.uBuy.value = C.buy; u.uSpeed.value = 0.7 + C.act * 1.6 + Math.min(0.8, rate * 0.05); u.uImb.value = C.imb; u.uMelt.value = C.melt; u.uBreath.value = 0.6 + C.act * 1.2;
  S.bloom = 0.85 + C.act * 0.5;
  C.shocks.forEach((s, i) => { s.t += dt / 2.4; const e = 1 - Math.pow(1 - Math.min(1, s.t), 3); u.uShock.value[i].set(0.4 + e * 6.2, (1 - s.t) * 1.1 * s.k * (s.side > 0 ? 1 : -0.7), 0, 0); });
  C.shocks = C.shocks.filter((s) => s.t < 1); for (let i = C.shocks.length; i < 3; i++) u.uShock.value[i].set(0, 0, 0, 0);
  if (!C.drag && !U.reduced()) C.yaw += dt * 0.05; f.pts.rotation.y = C.yaw; f.pts.rotation.x = C.pitch * 0.5;
  const D = 9.6 / C.zoom, cam = f.cam; cam.position.set(0, 2.0, D); cam.lookAt(0, 0, 0);
}
function sync() {
  const v = document.body.dataset.view, on = v === "nflow" && S.layer !== "splash" && S.available;
  if (on && !C.on) { C.on = true; S.buildFlow().then((f) => { if (f && document.body.dataset.view === "nflow") { S.setMode("flow"); wire(); } }); }
  if (!on && C.on) { C.on = false; }
  if (on && S.flow && S.mode !== "flow") S.setMode("flow");
  if (on && S.flow) { const pg = document.getElementById("pg-nflow"); if (pg) { const r = pg.getBoundingClientRect(); const key = r.left + "|" + r.top + "|" + r.width + "|" + r.height; if (key !== C.rk) { C.rk = key; S.centerOn(pg); } } }
  document.body.classList.toggle("u3-flow3", on && !!S.flow);
}
S.cbs.push(frame);
U.tick(sync, { fps: 6 });
})();
