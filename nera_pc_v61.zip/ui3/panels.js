"use strict";
/* NERA 3 · panel animasyonları (GSAP): her panel türünün kendine özgü açılış/kapanışı. Yalnız transform/opacity/clip-path; iş mantığı ve sınıf anahtarları aynı.
   Yenilikler: kart alttan maske açılımı + satırlar kademeli, kapanışta içe çökme. Beyin bilgi kartı: sağdan maske + değerler kademeli. Sekmeler: içerik katman katman. */
(function () {
const U = window.NeraUI, gs = window.gsap; if (!U || !gs || !document.body.classList.contains("u3")) return;
const on = (el, cls) => el.classList && el.classList.contains(cls);
const kids = (el, sel, n = 10) => [...el.querySelectorAll(sel)].slice(0, n);
function wnOpen(m) { const c = m.querySelector(".wn-card"); if (!c || U.reduced()) return; c.style.transition = "none"; c.style.transform = "none";
  gs.fromTo(c, { clipPath: "inset(100% 0 0 0 round 18px)", y: 30, scale: 0.97 }, { clipPath: "inset(0% 0 0 0 round 18px)", y: 0, scale: 1, duration: 0.9, ease: "nera.out", clearProps: "clipPath,transform" });
  gs.fromTo(kids(c, ".wn-hd > *, .wn-e, .wn-ok", 14), { y: 18, opacity: 0 }, { y: 0, opacity: 1, duration: 0.7, stagger: 0.06, delay: 0.25, ease: "nera.out", clearProps: "transform,opacity" }); }
function wnClose(m) { const c = m.querySelector(".wn-card"); if (!c || U.reduced()) return; gs.to(c, { scale: 0.94, y: 20, opacity: 0, filter: "blur(6px)", duration: 0.4, ease: "nera.inOut" }); }
function cardOpen(c) { if (U.reduced()) return; gs.fromTo(c, { clipPath: "inset(0 0 0 100% round 14px)", x: 24 }, { clipPath: "inset(0 0 0 0% round 14px)", x: 0, duration: 0.7, ease: "nera.out", clearProps: "clipPath,transform" }); gs.fromTo(kids(c, ".cc-h, .cc-v, .cc-s, .cc-b, p, li, div", 8), { y: 12, opacity: 0 }, { y: 0, opacity: 1, duration: 0.55, stagger: 0.05, delay: 0.15, ease: "nera.out", clearProps: "transform,opacity" }); }
function tabIn(t) { if (U.reduced()) return; const ks = kids(t, ":scope > *", 9); if (ks.length) gs.fromTo(ks, { y: 16, opacity: 0 }, { y: 0, opacity: 1, duration: 0.55, stagger: 0.045, ease: "nera.out", clearProps: "transform,opacity", overwrite: "auto" }); }
const seen = new WeakMap();
new MutationObserver((ms) => ms.forEach((m) => {
  const t = m.target; if (m.type === "childList") { m.addedNodes.forEach((n) => { if (n.nodeType === 1 && n.id === "wn-modal") { /* .on sınıfı sonraki karede eklenir */ } }); return; }
  const was = seen.get(t) || "", now = t.className || ""; if (was === now) return; seen.set(t, now);
  const had = (c) => was.split(" ").includes(c), has = (c) => now.split(" ").includes(c);
  if (t.id === "wn-modal") { if (has("on") && !had("on")) wnOpen(t); if (has("off") && !had("off")) wnClose(t); }
  else if (t.id === "cos-card") { if (has("show") && !had("show")) cardOpen(t); }
  else if (t.classList.contains("tab") && has("active") && !had("active")) tabIn(t);
})).observe(document.body, { attributes: true, attributeFilter: ["class"], subtree: true, childList: true });
})();
