"use strict";
/* NERA 3 · Aurora sesleri: cam çıngırağı + hava (filtreli gürültü) süpürmeleri. brain.js Sound nesnesinin yöntemlerini yerinde değiştirir;
   Ayarlar'daki ses anahtarı (Sound.on) ve ses bağlamı aynı kalır. Tüm sesler kısa, yumuşak, pentatonik (A majör) ve ana sesin altında. */
(function () {
const S = window.Sound; if (!S) return;
const ok = () => S.on && S.ctxOk();
let nb = null;
const noise = (c) => { if (nb) return nb; const n = c.sampleRate * 2; nb = c.createBuffer(1, n, c.sampleRate); const d = nb.getChannelData(0); for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1; return nb; };
/* cam çıngırağı: temel + hafif ayrık üst ton, hızlı atak, uzun sönüm */
const glass = (f, vol = 0.07, dur = 1.4, delay = 0) => { if (!ok()) return; const c = S.ctx, t = c.currentTime + delay; [[1, 1], [2.01, 0.35], [3.98, 0.12]].forEach(([m, k]) => { const o = c.createOscillator(), g = c.createGain(); o.type = "sine"; o.frequency.value = f * m; g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol * k, t + 0.012); g.gain.exponentialRampToValueAtTime(0.0001, t + dur / m ** 0.5); o.connect(g); g.connect(S.master || c.destination); o.start(t); o.stop(t + dur + 0.1); }); };
/* hava süpürmesi: bant geçiren filtre yukarı (up) ya da aşağı süpürülür */
const sweep = (up, dur = 0.35, vol = 0.05, f0 = 500, f1 = 3400) => { if (!ok()) return; const c = S.ctx, t = c.currentTime, s = c.createBufferSource(), bp = c.createBiquadFilter(), g = c.createGain(); s.buffer = noise(c); bp.type = "bandpass"; bp.Q.value = 1.4; bp.frequency.setValueAtTime(up ? f0 : f1, t); bp.frequency.exponentialRampToValueAtTime(up ? f1 : f0, t + dur); g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + dur * 0.35); g.gain.exponentialRampToValueAtTime(0.0001, t + dur); s.connect(bp); bp.connect(g); g.connect(S.master || c.destination); s.start(t); s.stop(t + dur + 0.05); };
const PENTA = [440, 493.9, 554.4, 659.3, 740, 880, 987.8, 1108.7, 1318.5];
S.fx = { glass, sweep };
S.intro = function () { if (!ok()) return; sweep(true, 3.2, 0.09, 180, 5200); [[0.9, 0], [1.4, 3], [1.9, 5], [2.4, 7], [2.9, 8]].forEach(([d, i]) => glass(PENTA[i], 0.06, 2, d)); setTimeout(() => this.land && this.land(), 3300); };
S.land = function () { if (!ok()) return; const c = S.ctx, t = c.currentTime, o = c.createOscillator(), g = c.createGain(); o.type = "sine"; o.frequency.setValueAtTime(110, t); o.frequency.exponentialRampToValueAtTime(45, t + 0.9); g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.16, t + 0.05); g.gain.exponentialRampToValueAtTime(0.0001, t + 1.1); o.connect(g); g.connect(S.master || c.destination); o.start(t); o.stop(t + 1.2); glass(1318.5, 0.05, 2.2, 0.05); };
S.signal = function (side) { const seq = side > 0 ? [0, 2, 3, 5, 7] : [7, 5, 3, 2, 0]; seq.forEach((i, k) => glass(side > 0 ? PENTA[i] : PENTA[i] * 0.84, 0.08, 1.8, k * 0.09)); sweep(side > 0, 0.5, 0.04); };
S.link = function (col) { if (!S.linkOn || !ok()) return; glass(PENTA[3], 0.05, 1.3); glass(PENTA[5], 0.04, 1.6, 0.12); };
S.nav = () => { sweep(true, 0.22, 0.035, 700, 2800); glass(PENTA[5], 0.035, 0.9, 0.04); };
S.open = () => { sweep(true, 0.3, 0.04); glass(PENTA[7], 0.04, 1.1, 0.08); };
S.close = () => { sweep(false, 0.25, 0.03); glass(PENTA[3], 0.03, 0.8, 0.02); };
S.tick = () => glass(PENTA[6], 0.018, 0.35);
/* arayüz bağları */
document.addEventListener("click", (e) => { if (e.target.closest("#rail .rn, #mtab button, #msheet [data-v]")) S.nav(); else if (e.target.closest(".tab-btn, #tabs button, .tfb, .symtab")) S.tick(); }, true);
document.addEventListener("keydown", (e) => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") S.open(); }, true);
new MutationObserver((ms) => ms.forEach((m) => m.addedNodes.forEach((n) => { if (n.nodeType === 1 && n.matches && n.matches(".wn-card, .modal, #mmodal.open")) S.open(); }))).observe(document.body, { childList: true, subtree: true });
})();
