"use strict";
/* NERA 3 · kabuk: ray menüdeki etkin gösterge (GSAP Flip), üst durum satırı, Ctrl+K komut paleti.
   Yalnız görünüm. Ekran değiştirme mantığı lab.js'te (go); burada DT "view" olayını dinlerim, yerine koymam. */
(function () {
const U = window.NeraUI; if (!U || !document.body.classList.contains("u3")) return;
const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
const gs = window.gsap;
const NAME = { brain: "Beyin", market: "Piyasa & Sinyal", nflow: "NeraFlow", xbot: "XM Nera", news: "Haber", friends: "Arkadaşlar", lab: "Laboratuvar", office: "Ajan Ofisi", labsig: "Lab Sinyalleri", book: "Strateji Defteri", bt: "Backtest Stüdyosu", kb: "Bilgi Bankası", set: "Ayarlar" };
const SYM = [["XAUUSDT", "XAU"], ["XAGUSDT", "XAG"], ["BTCUSDT", "BTC"], ["ETHUSDT", "ETH"], ["EURUSD", "EUR"]];

/* ---- ray: eski simgeler yerine mono numara; etkin gösterge Flip ile kayar */
const ind = document.createElement("i"); ind.className = "u3-ind";
function setActive(v) {
  const btn = $(`#rail .rn[data-v="${v}"]`); if (!btn || btn.contains(ind)) return;
  if (gs && window.Flip && !U.reduced() && ind.isConnected) { const st = Flip.getState(ind); btn.appendChild(ind); Flip.from(st, { duration: 0.65, ease: "nera.inOut", absolute: true }); } else btn.appendChild(ind);
}
function build() {
  const rail = $("#rail"); if (!rail || rail._u3) return; rail._u3 = 1;
  const logo = document.createElement("a"); logo.className = "u3-logo";
  /* canlı logo: nefes alan küre + içinde mini sinir ağı, dönen eğik halka ve halkada gezen uydu, küre üzerinden geçen ince ışık. Renkler temadan (--u3-acc, --u3-acc2). */
  const N = [[22, 19], [31, 22], [34, 31], [27, 36], [18, 33], [16, 25], [25, 27]], E = [[0, 1], [1, 2], [2, 3], [3, 4], [4, 5], [5, 0], [6, 0], [6, 2], [6, 4], [1, 6]];
  const net = E.map(([a, b]) => `<line x1="${N[a][0]}" y1="${N[a][1]}" x2="${N[b][0]}" y2="${N[b][1]}"/>`).join("") + N.map(([x, y], k) => `<circle class="nd" style="animation-delay:${(k * 0.55).toFixed(2)}s" cx="${x}" cy="${y}" r="1.35"/>`).join("");
  logo.innerHTML = `<svg class="u3-mark" viewBox="0 0 56 56" aria-hidden="true"><defs>
    <radialGradient id="u3g" cx="38%" cy="32%" r="75%"><stop offset="0" stop-color="var(--u3-acc)" stop-opacity=".95"/><stop offset=".55" stop-color="var(--u3-acc2)" stop-opacity=".55"/><stop offset="1" stop-color="var(--u3-acc2)" stop-opacity=".12"/></radialGradient>
    <linearGradient id="u3r" x1="0" x2="1"><stop offset="0" stop-color="var(--u3-acc2)" stop-opacity=".1"/><stop offset=".5" stop-color="var(--u3-acc)"/><stop offset="1" stop-color="var(--u3-acc2)" stop-opacity=".1"/></linearGradient>
    <clipPath id="u3c"><circle cx="28" cy="28" r="13"/></clipPath><linearGradient id="u3s" x1="0" x2="1"><stop offset="0" stop-color="#fff" stop-opacity="0"/><stop offset=".5" stop-color="#fff" stop-opacity=".55"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient></defs>
    <g transform="rotate(-24 28 28)"><path class="rb" d="M4 28A24 8 0 0 1 52 28"/></g>
    <g class="orb"><circle class="body" cx="28" cy="28" r="13" fill="url(#u3g)"/><g clip-path="url(#u3c)"><g class="net" transform="translate(6 6)">${net}</g><rect class="sh" x="-30" y="12" width="22" height="32" transform="rotate(20 28 28)" fill="url(#u3s)"/></g></g>
    <g transform="rotate(-24 28 28)"><path class="rf" d="M4 28A24 8 0 0 0 52 28"/><circle class="sat" r="2.3"><animateMotion dur="7s" repeatCount="indefinite" path="M4 28A24 8 0 1 0 52 28A24 8 0 1 0 4 28"/></circle></g></svg><span>Nera</span>`; rail.prepend(logo);
  if (gs && !U.reduced()) { gs.fromTo(logo.querySelector(".orb"), { scale: 0.3, opacity: 0, transformOrigin: "50% 50%" }, { scale: 1, opacity: 1, duration: 1.2, ease: "nera.spring", delay: 0.3 }); if (window.DrawSVGPlugin) gs.fromTo(logo.querySelectorAll(".rb,.rf"), { drawSVG: "0%" }, { drawSVG: "100%", duration: 1.6, ease: "nera.inOut", delay: 0.2 }); gs.fromTo(logo.querySelector("span"), { opacity: 0, x: -8 }, { opacity: 1, x: 0, duration: 0.9, ease: "nera.out", delay: 0.6 }); }
  else { const sat = logo.querySelector(".sat animateMotion"); if (sat) sat.remove(); }
  /* ikonlar: hover/aktifte çizgiler DrawSVG ile yeniden çizilir */
  const draw = (b) => { if (!gs || !window.DrawSVGPlugin || U.reduced()) return; const ps = b.querySelectorAll("svg path,svg circle,svg ellipse,svg rect"); if (ps.length) gs.fromTo(ps, { drawSVG: "0%" }, { drawSVG: "100%", duration: 0.7, stagger: 0.06, ease: "nera.out", overwrite: true }); };
  $$(".rn", rail).forEach((b) => { b.addEventListener("mouseenter", () => draw(b)); b.addEventListener("click", () => draw(b)); });
  setActive(document.body.dataset.view || "brain");
  /* üst durum satırı */
  const top = document.createElement("div"); top.id = "u3-top";
  top.innerHTML = `<span class="vt" id="u3-vt">Beyin</span><div class="px" id="u3-px"></div><span class="cn"><i id="u3-cn"></i><span id="u3-cnt">bağlanıyor</span></span>`;
  $("#stage").prepend(top);
  cmdBuild();
}
/* ---- üst satır verisi: yalnız OKUR (__S().tk.watch, DT olayları), hiçbir şeyi değiştirmez */
const fmt = (p) => (p == null ? "—" : p >= 1000 ? p.toLocaleString("tr-TR", { maximumFractionDigits: 2 }) : p >= 10 ? p.toFixed(2) : p.toFixed(4));
function status() {
  const vt = $("#u3-vt"); if (!vt) return; const v = document.body.dataset.view || "brain"; if (vt.textContent !== (NAME[v] || v)) vt.textContent = NAME[v] || v;
  let S = {}; try { S = window.__S ? __S() : {}; } catch (e) { /* */ }
  const w = (S.tk && S.tk.watch) || {}, px = $("#u3-px");
  const html = SYM.map(([k, n]) => { const x = w[k]; return `<span>${n}<b>${x && x.price ? fmt(x.price) : "—"}</b></span>`; }).join("");
  if (px && px._h !== html) { px._h = html; px.innerHTML = html; }
  const live = !!(S.tk && (Date.now() - (S.tkAt || Date.now()) < 8000)); const ok = Object.keys(w).length > 0;
  const c = $("#u3-cn"), t = $("#u3-cnt"); if (c) c.classList.toggle("ok", ok); if (t) t.textContent = ok ? "canlı" : "bağlanıyor";
}
/* ---- komut paleti */
let sel = 0, items = [];
function cmdBuild() {
  const el = document.createElement("div"); el.id = "u3-cmd"; el.innerHTML = `<div class="box"><input id="u3-q" placeholder="Nereye gidelim?" autocomplete="off" spellcheck="false"><ul id="u3-l"></ul></div>`; document.body.appendChild(el);
  el.addEventListener("pointerdown", (e) => { if (e.target === el) cmd(false); });
  $("#u3-q").addEventListener("input", list);
  $("#u3-q").addEventListener("keydown", (e) => { if (e.key === "Escape") cmd(false); else if (e.key === "ArrowDown") { sel = Math.min(items.length - 1, sel + 1); paint(); e.preventDefault(); } else if (e.key === "ArrowUp") { sel = Math.max(0, sel - 1); paint(); e.preventDefault(); } else if (e.key === "Enter" && items[sel]) go(items[sel][0]); });
  $("#u3-l").addEventListener("click", (e) => { const li = e.target.closest("li"); if (li) go(li.dataset.v); });
}
const tr = (s) => s.toLocaleLowerCase("tr").normalize("NFD").replace(/[̀-ͯ]/g, "");
function list() {
  const q = tr($("#u3-q").value.trim()); items = Object.entries(NAME).filter(([k, n]) => !q || tr(n).includes(q) || k.includes(q) || (k === "set" && "tasarim tema hareket".includes(q)));
  sel = 0; $("#u3-l").innerHTML = items.map(([k, n], i) => `<li data-v="${k}"><i>${String(i + 1).padStart(2, "0")}</i>${n}<em>${k === document.body.dataset.view ? "şu an" : ""}</em></li>`).join(""); paint();
}
function paint() { $$("#u3-l li").forEach((li, i) => li.classList.toggle("sel", i === sel)); const s = $("#u3-l li.sel"); if (s) s.scrollIntoView({ block: "nearest" }); }
function go(v) { cmd(false); if (window.Lab && Lab.go) Lab.go(v); }
function cmd(open) {
  const el = $("#u3-cmd"); if (!el) return; if (open === el.classList.contains("on")) return;
  if (open) { el.classList.add("on"); $("#u3-q").value = ""; list(); if (gs && !U.reduced()) { gs.fromTo(el, { opacity: 0 }, { opacity: 1, duration: 0.25 }); gs.fromTo($(".box", el), { y: 14, opacity: 0 }, { y: 0, opacity: 1, duration: 0.45 }); } setTimeout(() => $("#u3-q").focus(), 30); }
  else { if (gs && !U.reduced()) gs.to(el, { opacity: 0, duration: 0.18, onComplete: () => el.classList.remove("on") }); else el.classList.remove("on"); }
}
addEventListener("keydown", (e) => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") { e.preventDefault(); cmd(!$("#u3-cmd").classList.contains("on")); } });
if (window.DT) DT.on("view", (v) => { setActive(v); status(); });
const init = () => { build(); status(); };
if (document.readyState === "complete") setTimeout(init, 0); else addEventListener("load", () => setTimeout(init, 0));
U.tick(status, { fps: 2 });
U.cmd = cmd;
})();
