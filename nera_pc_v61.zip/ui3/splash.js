"use strict";
/* NERA 3 · açılış: ayrı perde yok, TEK sahne. Dağınık parçacıklar (Drift) derinlik haritasına göre "Nera" yazısına toplanır (Gather), bir ışık çizgisi geçer (Scan),
   yazı küreye dönüşür (Melt/Morph), kamera geri çekilir ve aynı sahne Beyin ekranının çekirdeği olarak kalır.
   Sözleşme eski Splash ile aynı: window.Splash.finish() (veri hazır), DT "splash-done". Veri yükleme paralel sürer, sahne veri beklemez (en geç 3,4 sn + veri). Atlama yok: her açılışta tam oynar. */
(function () {
const U = window.NeraUI, S = window.NeraSwarm; if (!U || !S || !document.body.classList.contains("u3")) return;
const el = document.getElementById("splash"), gs = window.gsap, shell = document.getElementById("shell");
/* brain.js eski Splash'i "const Splash" ile tanımlar; çıplak "Splash" (app.js) o nesneye bakar. Bu yüzden nesneyi DEĞİŞTİRMEK yerine yerinde yeniden tanımlarım. */
const Sp = (window.Splash = window.Splash || {});
Object.assign(Sp, { active: true, st: "run", want: false, init() {}, frame() {}, finish() { Sp.want = true; if (Sp.tl && Sp.tl.progress() >= 1) Sp.end(); } });
let ended = false;
const done = () => { if (ended) return; ended = true; Sp.active = false; if (el) el.remove(); if (shell) { shell.style.opacity = ""; shell.style.visibility = ""; } try { DT.emit("splash-done"); } catch (e) { /* */ } };
if (!el || !gs || U.reduced()) { done(); return; }
/* telefon: hafif sürüm (WebGL yok). Aynı hikâye 2B tuvalde: dağınık noktalar "Nera" yazısına toplanır (Gather), tarama ışığı geçer, yazı nefes alır;
   VERİ HAZIR OLANA kadar bekler (Splash.finish), sonra noktalar dağılır ve perde kalkar. Yavaş: toplanma 2,8 sn, en az 3,8 sn. */
if (U.mobile() || !S.available) {
  const cv = document.createElement("canvas"); cv.className = "sp-mc"; el.prepend(cv); const x = cv.getContext("2d"), d = Math.min(devicePixelRatio || 1, 1.5), W = innerWidth, H = innerHeight; cv.width = W * d; cv.height = H * d; cv.style.width = W + "px"; cv.style.height = H + "px"; x.setTransform(d, 0, 0, d, 0, 0);
  const rest = [el.querySelector(".sp-sub"), el.querySelector(".note"), el.querySelector(".sp-bar")].filter(Boolean); gs.set(el, { background: "#050505" }); gs.set(rest, { opacity: 0 });
  let P = [], T0 = performance.now(), want = false, dis = 0, over = false, minOk = false;
  const build = () => {
    const tw = Math.min(W * 0.9, 460), th = tw * 0.42, oc = document.createElement("canvas"); oc.width = Math.round(tw); oc.height = Math.round(th); const o = oc.getContext("2d", { willReadFrequently: true });
    o.fillStyle = "#000"; o.fillRect(0, 0, oc.width, oc.height); o.fillStyle = "#fff"; o.font = 'italic 400 ' + Math.round(th * 0.95) + 'px "Instrument Serif", Georgia, serif'; o.textAlign = "center"; o.textBaseline = "alphabetic"; o.fillText("Nera", oc.width / 2, th * 0.8);
    const a = o.getImageData(0, 0, oc.width, oc.height).data, cand = []; for (let yy = 0; yy < oc.height; yy += 2) for (let xx = 0; xx < oc.width; xx += 2) if (a[(yy * oc.width + xx) * 4] > 140) cand.push(xx, yy);
    const n = Math.min(3800, cand.length / 2), ox = (W - oc.width) / 2, oy = H * 0.46 - oc.height / 2; P = Array.from({ length: n }, () => { const k = Math.floor(Math.random() * (cand.length / 2)) * 2; return { hx: ox + cand[k] + Math.random() * 2, hy: oy + cand[k + 1] + Math.random() * 2, sx: Math.random() * W, sy: Math.random() * H, ph: Math.random() * 6.283, v: Math.random() }; });
  };
  try { Promise.race([document.fonts.load('italic 120px "Instrument Serif"'), new Promise((r) => setTimeout(r, 700))]).then(build, build); } catch (e) { build(); }
  gs.to(rest, { opacity: 1, duration: 0.8, stagger: 0.15, delay: 1.8 }); setTimeout(() => { minOk = true; }, 3800);
  const stop = U.tick((now) => {
    if (!P.length) return; const t = (now - T0) / 1000, g = Math.min(1, t / 2.8), e = 1 - Math.pow(1 - g, 3), scan = ((t - 2.6) / 1.4) * (W + 80) - 40; x.clearRect(0, 0, W, H); x.globalCompositeOperation = "lighter";
    if (!over && want && minOk && !dis) { dis = performance.now(); }
    const dd = dis ? Math.min(1, (performance.now() - dis) / 900) : 0;
    for (const p of P) {
      const wob = Math.sin(t * 1.1 + p.ph) * (1 - e * 0.85) * 4 + (g >= 1 ? Math.sin(t * 1.6 + p.ph) * 0.7 : 0);
      let X = p.sx + (p.hx - p.sx) * e + wob, Y = p.sy + (p.hy - p.sy) * e + Math.cos(t * 0.9 + p.ph) * (1 - e * 0.85) * 4 + (g >= 1 ? Math.cos(t * 1.4 + p.ph) * 0.7 : 0);
      if (dd) { X += (X - W / 2) * dd * 1.4 * p.v; Y += (Y - H * 0.46) * dd * 1.4 * p.v - dd * 30; }
      const lit = Math.abs(X - scan) < 16, al = (0.35 + 0.55 * e) * (1 - dd) + (lit ? 0.4 : 0); x.fillStyle = lit ? `rgba(255,255,255,${al})` : p.v < 0.5 ? `rgba(200,255,61,${al})` : `rgba(255,79,216,${al * 0.9})`; x.fillRect(X, Y, 1.5, 1.5);
    }
    x.globalCompositeOperation = "source-over";
    if (dd >= 1 && !over) { over = true; stop(); gs.to(el, { opacity: 0, duration: 0.5, onComplete: done }); }
  });
  Object.assign(Sp, { finish() { want = true; } }); setTimeout(() => { want = true; }, 12000);
  return;
}

if (shell) shell.style.opacity = "0";
S.setLayer("splash");
Sp.end = () => {
  if (ended) return; performance.mark("sp-end"); Sp.st = "tween";
  /* devir: tuval sayfanın arkasına iner, küre Beyin çekirdeğinin ortasına süzülür, kabuk görünür olur */
  S.setLayer("page");
  const core = document.getElementById("bv-core"), p = { dx: S.dx, dy: S.dy }, view = document.body.dataset.view;
  if (view === "brain" && core) { const r = core.getBoundingClientRect(); S.tweening = true; gs.to(p, { dx: r.left + r.width / 2 - S.w / 2, dy: r.top + r.height / 2 - S.h / 2, duration: 1.3, ease: "nera.inOut", onUpdate: () => S.shift(p.dx, p.dy), onComplete: () => { S.tweening = false; } }); }
  if (shell) gs.fromTo(shell, { opacity: 0 }, { opacity: 1, duration: 0.9, delay: 0.15, ease: "nera.out", onComplete: () => { shell.style.opacity = ""; } });
  gs.to(el, { opacity: 0, duration: 0.5, ease: "nera.out", onComplete: () => { done(); } });
  setTimeout(() => { U.enter(view || "brain"); if (window.NeraBrain3) NeraBrain3.enter(); }, 250);
};
S.buildSwarm().then((sw) => {
  performance.mark("sp-built");
  setTimeout(() => { if (window.NeraBrain3 && NeraBrain3.prebuild && !ended) NeraBrain3.prebuild(); }, 1600);
  if (!sw) { done(); return; }
  const u = sw.u, cam = sw.cam;
  /* açılış renkleri: eski Swarm paleti (kireç + magenta); morph sırasında temanın rengine geçer */
  const T = S.T, c1 = new T.Color("#c8ff3d"), c2 = new T.Color("#ff4fd8"), k1 = u.uC1.value.clone(), k2 = u.uC2.value.clone(); u.uC1.value.copy(c1); u.uC2.value.copy(c2);
  S.setMode("swarm"); u.uGather.value = 0; u.uMix.value = 0; u.uTint.value = 0.15; u.uScan.value = -5; cam.position.set(0, 0.1, 9.8); cam.lookAt(0, 0, 0); S.shift(0, 0);
  sw.pts.rotation.set(0, 0, 0);
  const sub = el.querySelector(".sp-sub"), note = el.querySelector(".note"), bar = el.querySelector(".sp-bar");
  [sub, note, bar].forEach((e) => e && gs.set(e, { opacity: 0, y: 10 }));
  const tl = (Sp.tl = gs.timeline({ onComplete: () => { if (Sp.want) Sp.end(); } }));
  tl.to(u.uGather, { value: 1, duration: 2.4, ease: "nera.out" }, 0.1)
    .to(cam.position, { z: 8.7, duration: 3.8, ease: "nera.inOut" }, 0)
    .to(u.uTint, { value: 0.5, duration: 1.2, ease: "nera.out" }, 1.1)
    .fromTo(u.uScan, { value: -4.6 }, { value: 4.6, duration: 1.2, ease: "nera.inOut" }, 1.3)
    .to([sub, bar, note].filter(Boolean), { opacity: 1, y: 0, duration: 0.8, stagger: 0.12, ease: "nera.out" }, 1.1)
    .addLabel("morph", 2.7)
    .to(u.uMix, { value: 1, duration: 1.6, ease: "nera.inOut" }, "morph")
    .to(u.uTint, { value: 1, duration: 1.1, ease: "nera.out" }, "morph")
    .to(cam.position, { z: 10.6, duration: 1.3, ease: "nera.inOut" }, "morph")
    .to(u.uC1.value, { r: k1.r, g: k1.g, b: k1.b, duration: 1.2, ease: "nera.inOut" }, "morph").to(u.uC2.value, { r: k2.r, g: k2.g, b: k2.b, duration: 1.2, ease: "nera.inOut" }, "morph")
    .to([sub, bar, note].filter(Boolean), { opacity: 0, y: -8, duration: 0.5, stagger: 0.05 }, "morph");
  setTimeout(() => { if (!ended) { Sp.want = true; if (tl.progress() >= 1) Sp.end(); } }, 12000);
}).catch((e) => { console.error("splash", e); done(); });
/* sahne hiç açılamazsa perde yine de kalkar */
setTimeout(() => { if (!S.ready && !S.swarm) done(); }, 8000);
})();
