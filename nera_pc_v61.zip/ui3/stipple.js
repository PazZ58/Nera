"use strict";
/* NERA 3 · NeraStipple: Gather · 聚 by DAO'nun "derinlik haritalı nokta görüntüsü" dilinden esinlenen, kendi yazdığımız 2B küre çizici (kod kopyalanmadı).
   Işıklandırılmış küre + eğik halka binlerce noktaya dökülür; parlaklık = derinlik (ön yüz parlak, arka yüz sönük). Drift (salınım), Scan (süpüren ışık),
   Track (izleyici köşeleri + koordinat), Splash (flare: noktalar dışa itilir). Sinyal Beyni ve Laboratuvar beyninde merkez görsel olarak kullanılır. */
(function () {
const S = (window.NeraStipple = {});
S.make = function (N = 3200, seed = 11) {
  let sd = seed; const rnd = () => ((sd = (sd * 16807) % 2147483647) / 2147483647);
  const P = [], ga = Math.PI * (3 - Math.sqrt(5));
  for (let i = 0; i < N; i++) { const y = 1 - (i / (N - 1)) * 2, r = Math.sqrt(1 - y * y), th = ga * i; P.push({ x: Math.cos(th) * r, y, z: Math.sin(th) * r, ph: rnd() * 6.283, ring: 0 }); }
  const NR = Math.round(N * 0.42); for (let i = 0; i < NR; i++) { const a = rnd() * 6.283, w = 1.6 + rnd() * 0.28, tx = Math.cos(a) * w, tz = Math.sin(a) * w; P.push({ x: tx, y: (rnd() - 0.5) * 0.04, z: tz * 0.34, ph: rnd() * 6.283, ring: 1 }); }
  const T = [P[(N * 0.31) | 0], P[(N * 0.55) | 0], P[(N * 0.78) | 0]];
  return { P, T, fl: 0, flare(s = 1) { this.fl = Math.min(1.5, this.fl + s); },
    render(c, cx, cy, R, t, o = {}) {
      const tint = o.tint || [160, 230, 255], yaw = t * 0.14 + (o.px || 0) * 0.35, tl = -0.34 + (o.py || 0) * 0.2, ca = Math.cos(yaw), sa = Math.sin(yaw), ct = Math.cos(tl), st = Math.sin(tl), tr = -0.42, cr = Math.cos(tr), sr = Math.sin(tr);
      this.fl *= 0.94; const scan = (((t * 0.22) % 1.6) - 0.3) * 2.6 - 1.3, bins = [new Path2D(), new Path2D(), new Path2D(), new Path2D(), new Path2D()], A = [0.14, 0.3, 0.5, 0.75, 1]; let tk = [];
      for (const p of this.P) {
        let x = p.x, y = p.y, z = p.z; if (p.ring) { const x2 = x * cr - y * sr; y = x * sr + y * cr; x = x2; }
        const dr = 0.012 * Math.sin(t * 0.9 + p.ph); let x1 = (x + dr) * ca + z * sa, z1 = -(x + dr) * sa + z * ca, y1 = (y + dr * 0.6) * ct - z1 * st, z2 = y * st + z1 * ct;
        const k = 1 / (1 - z2 * 0.28), push = this.fl * 0.12 * (p.ring ? 1.4 : 1); x1 *= 1 + push; y1 *= 1 + push;
        const lit = p.ring ? 0.55 + 0.35 * Math.max(0, z2) : Math.max(0, (x1 * -0.5 + y1 * -0.6 + z2 * 0.62)) * 0.8 + 0.18, back = z2 < -0.15 && !p.ring, sc = Math.abs(y1 - scan * 0.9 + x1 * 0.3) < 0.07 ? 0.5 : 0, d = Math.min(1, Math.max(0, lit + sc + this.fl * 0.15) * (back ? 0.5 : 1)), bi = Math.min(4, (d * 5) | 0), s = (0.55 + d * 1.2) * k * (R / 120), X = cx + x1 * R * k, Y = cy + y1 * R * k;
        bins[bi].rect(X - s / 2, Y - s / 2, s, s); p._q = [X, Y, z2];
      }
      bins.forEach((b, i) => { c.fillStyle = `rgba(${tint[0] + (255 - tint[0]) * (i / 4) * 0.7 | 0},${tint[1] + (255 - tint[1]) * (i / 4) * 0.7 | 0},${tint[2] + (255 - tint[2]) * (i / 4) * 0.7 | 0},${A[i]})`; c.fill(b); });
      if (o.track !== false) { c.lineWidth = 1; c.font = '500 8px "IBM Plex Mono",monospace'; c.textAlign = "left"; this.T.forEach((p, i) => { const q = p._q; if (!q || q[2] < -0.1) return; const s = 9 + Math.sin(t * 2 + i) * 1.3; c.strokeStyle = `rgba(${tint[0]},${tint[1]},${tint[2]},.9)`; [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([a, b]) => { c.beginPath(); c.moveTo(q[0] + a * s, q[1] + b * (s - 4)); c.lineTo(q[0] + a * s, q[1] + b * s); c.lineTo(q[0] + a * (s - 4), q[1] + b * s); c.stroke(); }); c.fillStyle = `rgba(${tint[0]},${tint[1]},${tint[2]},.8)`; c.fillText("0" + (i + 3) + " SEEK " + ((q[0] - cx) / R).toFixed(2) + " " + ((cy - q[1]) / R).toFixed(2), q[0] + s + 4, q[1] - s + 8); }); }
    } };
};

/* Nebula bulutu (Sinyal Beyni / Beyin ile aynı dil): hacimli nokta bulutu + parlayan nöronlar ve bağları, çekirdek ışıması. Laboratuvar beyni kullanır. */
S.cloud = function (N = 1800, seed = 3) {
  let sd = seed; const rnd = () => ((sd = (sd * 16807) % 2147483647) / 2147483647);
  const P = Array.from({ length: N }, () => { const u = rnd() * 2 - 1, th = rnd() * 6.283, s = Math.sqrt(1 - u * u), r = 0.18 + 0.82 * Math.cbrt(rnd()); return { x: s * Math.cos(th) * r, y: u * r, z: s * Math.sin(th) * r, ph: rnd() * 6.283, sz: 0.6 + rnd() * 1.1 }; });
  const NE = Array.from({ length: 30 }, () => { const p = P[(rnd() * N) | 0]; return { p, e: 0, nb: [] }; });
  NE.forEach((n, i) => { const d = NE.map((m, j) => [j, (m.p.x - n.p.x) ** 2 + (m.p.y - n.p.y) ** 2 + (m.p.z - n.p.z) ** 2]).filter((a) => a[0] !== i).sort((a, b) => a[1] - b[1]).slice(0, 2); n.nb = d.map((a) => a[0]); });
  return { P, NE, fl: 0, flare(s = 1) { this.fl = Math.min(1.6, this.fl + s); for (let k = 0; k < 6; k++) { const n = NE[(Math.random() * NE.length) | 0]; n.e = 1; n.nb.forEach((j) => (NE[j].e = Math.max(NE[j].e, 0.7))); } },
    render(c, cx, cy, R, t, o = {}) {
      const tint = o.tint || [120, 235, 215], yaw = t * 0.12 + (o.px || 0) * 0.3, tl = 0.35 + (o.py || 0) * 0.15 + 0.08 * Math.sin(t * 0.2), ca = Math.cos(yaw), sa = Math.sin(yaw), ct = Math.cos(tl), st = Math.sin(tl), br = 1 + 0.035 * Math.sin(t * 0.9), rgb = (a) => `rgba(${tint[0]},${tint[1]},${tint[2]},${a})`;
      this.fl *= 0.95; const g = c.createRadialGradient(cx, cy, 4, cx, cy, R * 2.2); g.addColorStop(0, rgb(0.16 + this.fl * 0.2)); g.addColorStop(0.5, rgb(0.05)); g.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = g; c.fillRect(cx - R * 2.2, cy - R * 2.2, R * 4.4, R * 4.4);
      const bins = [new Path2D(), new Path2D(), new Path2D()], pr = (p) => { const dx = Math.sin(t * 0.5 + p.ph) * 0.02, dy = Math.cos(t * 0.45 + p.ph) * 0.02, x1 = (p.x + dx) * ca + p.z * sa, z1 = -(p.x + dx) * sa + p.z * ca, y1 = (p.y + dy) * ct - z1 * st, z2 = (p.y + dy) * st + z1 * ct, k = 1 / (1 - z2 * 0.42); return [cx + x1 * R * br * k, cy + y1 * R * br * k, z2, k]; };
      for (const p of this.P) { const q = pr(p), b = q[2] < -0.3 ? 0 : q[2] < 0.3 ? 1 : 2, r = p.sz * q[3] * (R / 105); bins[b].rect(q[0] - r / 2, q[1] - r / 2, r, r); p._q = q; }
      [0.3, 0.6, 0.95].forEach((a, i) => { c.fillStyle = rgb(a); c.fill(bins[i]); });
      c.lineWidth = 0.8; this.NE.forEach((n) => { n.e *= 0.94; n.nb.forEach((j) => { const m = this.NE[j], e = Math.max(n.e, m.e); c.strokeStyle = rgb(0.14 + e * 0.7); c.beginPath(); c.moveTo(n.p._q[0], n.p._q[1]); c.lineTo(m.p._q[0], m.p._q[1]); c.stroke(); }); });
      this.NE.forEach((n) => { const q = n.p._q, r = (1.8 + n.e * 3.5) * q[3]; c.fillStyle = n.e > 0.25 ? "#fff" : rgb(0.9); c.beginPath(); c.arc(q[0], q[1], r, 0, 6.3); c.fill(); if (n.e > 0.25) { const gg = c.createRadialGradient(q[0], q[1], 0, q[0], q[1], r * 5); gg.addColorStop(0, rgb(0.5 * n.e)); gg.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = gg; c.fillRect(q[0] - r * 5, q[1] - r * 5, r * 10, r * 10); } });
      if (Math.random() < 0.035) { const n = this.NE[(Math.random() * this.NE.length) | 0]; n.e = 0.8; n.nb.forEach((j) => (this.NE[j].e = Math.max(this.NE[j].e, 0.5))); }
    } };
};
})();
