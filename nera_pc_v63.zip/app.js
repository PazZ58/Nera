"use strict";
const IS_MOB_DPR = matchMedia("(max-width:900px)").matches ? 1.5 : 3;          // mobilde tuval çözünürlüğü sınırı (pil)
/* Nera · arayüz. Grafik: TradingView Lightweight Charts (Apache-2.0). Veri: yerel sunucu (/api/*). Sadece analiz, emir yok. */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const SYMS = ["BTCUSDT", "ETHUSDT", "XAUUSDT", "XAGUSDT", "EURUSD"];
const NAMES = { BTCUSDT: "BTC/USDT", ETHUSDT: "ETH/USDT", XAUUSDT: "Altın XAU", XAGUSDT: "Gümüş XAG", EURUSD: "EUR/USD" };
const TFS = ["1m", "5m", "15m", "30m", "1h", "4h", "1d"];
const TF_LABEL = { "1m": "1m", "5m": "5m", "15m": "15m", "30m": "30m", "1h": "1H", "4h": "4H", "1d": "1D" };
const SCAN = ["5m", "15m", "1h", "4h"];
const OFF = -new Date().getTimezoneOffset() * 60;
const TV = { up: "#089981", down: "#f23645", blue: "#2962ff", orange: "#ff9800", yellow: "#fdd835", purple: "#ab47bc", cyan: "#4dd0e1", muted: "#787b86", text: "#d1d4dc" };
/* grafik görünümü ayarı (Ayarlar › Grafik görünümü): mum renkleri, stil, ızgara, hacim */
const CVW = Object.assign({ up: "#089981", down: "#f23645", style: "fill", grid: 1, vol: 1 }, (() => { try { return JSON.parse(localStorage.getItem("nera_cc") || "{}"); } catch (e) { return {}; } })());
TV.up = CVW.up; TV.down = CVW.down;
const hexA = (h, a) => { const n = parseInt(String(h).replace("#", "").padEnd(6, "0").slice(0, 6), 16); return `rgba(${n >> 16},${(n >> 8) & 255},${n & 255},${a})`; }, UPA = (a) => hexA(TV.up, a), DNA = (a) => hexA(TV.down, a);
const candleOpts = () => ({ upColor: CVW.style === "hollow" ? "rgba(0,0,0,0)" : CVW.up, downColor: CVW.down, borderVisible: CVW.style === "hollow", borderUpColor: CVW.up, borderDownColor: CVW.down, wickUpColor: CVW.up, wickDownColor: CVW.down });
window.__applyCC = (cfg) => { Object.assign(CVW, cfg); try { localStorage.setItem("nera_cc", JSON.stringify(CVW)); } catch (e) { /* */ } TV.up = CVW.up; TV.down = CVW.down; try { C.ser.candle.applyOptions(candleOpts()); C.ser.vol.applyOptions({ visible: !!CVW.vol }); C.main.applyOptions({ grid: { vertLines: { visible: !!CVW.grid }, horzLines: { visible: !!CVW.grid } } }); [C.p1, C.p2].forEach((c) => c && c.applyOptions({ grid: { vertLines: { visible: !!CVW.grid }, horzLines: { visible: !!CVW.grid } } })); } catch (e) { /* grafik henüz yok */ } if (S.data) loadChart(false); };
window.__getCC = () => Object.assign({}, CVW);
const OPTS_DEF = { ema: true, vwap: true, bb: false, ichi: false, st: false, sar: false, ob: true, fvg: true, liq: true, struct: true, pdz: true, vp: true, sr: false, fib: false, sess: true, plan: true, marks: true, cloud: false, liqmap: false, whales: false, pulse2: false, heat: false, exheat: false, money: true, fp: false };
const IND_MENU = [
  ["Hareketli ortalamalar & trend", [["ema", "EMA 21 / 50 / 200"], ["vwap", "VWAP"], ["st", "Supertrend (10,3)"], ["ichi", "Ichimoku (çizgiler)"], ["cloud", "Ichimoku bulutu"], ["sar", "Parabolic SAR"], ["bb", "Bollinger bantları"]]],
  ["ICT / Smart Money", [["struct", "Yapı: HH/HL/LH/LL · BOS · CHoCH"], ["ob", "Order block"], ["fvg", "FVG (adil değer boşluğu)"], ["pdz", "Premium / Discount · OTE"], ["sess", "Kill zone seansları"]]],
  ["Likidite & hacim", [["liq", "Likidite havuzları (EQH/EQL/PDH/PDL…)"], ["vp", "Hacim profili · POC/VAH/VAL"], ["sr", "Destek / direnç kümeleri"], ["fib", "Fibonacci geri çekilme"]]],
  ["Order flow (gerçek Binance verisi)", [["money", "Likidite: para nerede? (emir defteri + akış + stop havuzu)"], ["heat", "Sıcaklık haritası: işlem hacmi + emir defteri geçmişi · dokun: bölge"], ["fp", "Ayak izi: mum içi alış × satış (yakınlaştır)"], ["whales", "Balina haritası (gerçek büyük işlemler)"], ["liqmap", "Tasfiyeler (gerçek) + tasfiye seviyeleri (model)"], ["pulse2", "Pulse v2 (beta)"]]],
  ["Sinyal", [["plan", "Stop / hedef kutusu"], ["marks", "◉ sinyal işaretleri"]]],
];
const S = { sym: localStorage.getItem("sym") || "XAUUSDT", tf: localStorage.getItem("tf") || "15m", data: null, ana: null, tk: null, sigs: [], stats: {}, lastEv: 0, unseen: 0, tab: "sig", ready: false,
  opts: Object.assign({}, OPTS_DEF, JSON.parse(localStorage.getItem("opts") || "{}")), theme: localStorage.getItem("theme") || "dark", sound: localStorage.getItem("sound") === "1",
  pane2: localStorage.getItem("pane2") || "adx", times: [], cal: [], risk: 50, loadedKey: "", candleLast: null, selSig: null };

/* ---------- biçim ---------- */
const dec = (sym) => sym === "BTCUSDT" ? 1 : sym === "ETHUSDT" ? 2 : sym === "XAUUSDT" ? 2 : sym === "XAGUSDT" ? 3 : 5;
const fp = (x, sym = S.sym) => x == null || !isFinite(x) ? "—" : Number(x).toLocaleString("en-US", { minimumFractionDigits: dec(sym), maximumFractionDigits: dec(sym) });
const dist = (x, sym = S.sym) => sym === "EURUSD" ? (x * 10000).toFixed(1) + " pip" : (x >= 100 ? x.toFixed(1) : x >= 1 ? x.toFixed(2) : x.toFixed(3)) + " $";
const pct = (x, d = 1) => (x == null ? "—" : (x * 100).toFixed(d) + "%");
const loc = (t) => t + OFF;
const hhmm = (t) => new Date(t * 1000).toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" });
const dtm = (t) => new Date(t * 1000).toLocaleString("tr-TR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" });
const num = (x) => x == null || !isFinite(x) ? "—" : (Math.abs(x) >= 1e6 ? (x / 1e6).toFixed(2) + "M" : Math.abs(x) >= 1e3 ? (x / 1e3).toFixed(1) + "K" : Math.abs(x) >= 10 ? x.toFixed(0) : x.toFixed(2));
const cls = (v) => (v > 0 ? "up" : v < 0 ? "down" : "mut");
/* Masaüstü: yerel Python sunucusuna fetch. Mobil (APK/PWA): window.LOCAL_API (tarayıcı içi JavaScript motoru) tanımlıdır. */
async function api(path, opt) {
  try {
    if (window.LOCAL_API) return await window.LOCAL_API(path, opt);
    const r = await fetch(path, opt); return await r.json();
  } catch (e) { window.__apiErr = path.split("?")[0] + " · " + String((e && e.message) || e).slice(0, 90); return null; }
}
const IS_MOBILE = () => window.matchMedia("(max-width: 900px)").matches;
window.__S = () => S;

/* ---------- tema ---------- */
const cv = (n) => getComputedStyle(document.getElementById("left") || document.body).getPropertyValue(n).trim();
function chartOpts() {
  return { autoSize: true, layout: { attributionLogo: false, background: { type: "solid", color: window.__bgMedia ? "rgba(0,0,0,0)" : cv("--bg") }, textColor: cv("--muted"), fontFamily: "Trebuchet MS, Segoe UI, sans-serif", fontSize: 12 },
    grid: { vertLines: { color: cv("--grid"), visible: !!CVW.grid }, horzLines: { color: cv("--grid"), visible: !!CVW.grid } }, rightPriceScale: { borderColor: cv("--line"), minimumWidth: 74 },
    timeScale: { borderColor: cv("--line"), timeVisible: true, secondsVisible: false, rightOffset: 8, barSpacing: 8 },
    crosshair: { mode: 0, vertLine: { color: "#758696", labelBackgroundColor: "#2a2e39" }, horzLine: { color: "#758696", labelBackgroundColor: "#2a2e39" } },
    handleScroll: { mouseWheel: true, pressedMouseMove: true, horzTouchDrag: true, vertTouchDrag: !IS_MOBILE() },      // telefonda dikey kaydırma sayfayı kaydırır
    handleScale: { mouseWheel: true, pinch: true, axisPressedMouseMove: true } };
}
function paneOpts() { const o = chartOpts(); o.timeScale = { visible: false, borderColor: cv("--line"), rightOffset: 8, barSpacing: 8 }; o.layout.attributionLogo = false; o.layout.background = { type: "solid", color: cv("--bg") }; return o; }   // atıf logosu ana grafikte duruyor
const THEMES = ["dark", "black", "light", "halloween", "neon", "ocean", "forest", "sunset", "matrix"];
function setThemeClass() { if (!THEMES.includes(S.theme)) S.theme = "dark"; document.documentElement.style.colorScheme = S.theme === "light" ? "light" : "dark"; document.body.classList.remove(...THEMES.map((k) => "theme-" + k)); document.body.classList.add("theme-" + S.theme); }     // diğer sınıfları (mobil "m", "cap") silme
window.__chartRefresh = () => { S._tr = null; C.main && C.main.applyOptions(chartOpts()); [C.p1, C.p2].forEach((c) => c && c.applyOptions(paneOpts())); };
function applyTheme() { S._tr = null;
  setThemeClass();
  C.main && C.main.applyOptions(chartOpts()); [C.p1, C.p2].forEach((c) => c && c.applyOptions(paneOpts()));
}

/* ---------- grafik nesneleri ---------- */
const C = { main: null, p1: null, p2: null, ser: {}, p1s: {}, p2s: {}, lines: [] };
function mk() {
  C.main = LightweightCharts.createChart($("#chart"), chartOpts());
  C.p1 = LightweightCharts.createChart($("#pane1"), paneOpts());
  C.p2 = LightweightCharts.createChart($("#pane2"), paneOpts());
  C.main.subscribeClick((p) => { if (!S.opts.heat || !p.point) return; const z = S.hz; if (z && z.box) { const b = z.box, x = p.point.x, y = p.point.y; if (x >= b.x && x <= b.x + b.w && y >= b.y && y <= b.y + b.h) { if (x > b.x + b.w - 40 && y < b.y + 38) { S.hz = null; drawOverlay(); } return; } } const pr = C.ser && C.ser.candle ? C.ser.candle.coordinateToPrice(p.point.y) : null; S.hz = pr != null && S.data ? zoneAt(pr) : null; drawOverlay(); });
  const s = C.ser;
  s.candle = C.main.addCandlestickSeries(Object.assign(candleOpts(), { priceLineColor: "#787b86" }));
  s.vol = C.main.addHistogramSeries({ visible: !!CVW.vol, priceFormat: { type: "volume" }, priceScaleId: "vol", lastValueVisible: false, priceLineVisible: false });
  C.main.priceScale("vol").applyOptions({ scaleMargins: { top: 0.84, bottom: 0 } });
  const L = (color, w = 1, extra = {}) => C.main.addLineSeries(Object.assign({ color, lineWidth: w, lastValueVisible: false, priceLineVisible: false, crosshairMarkerVisible: false }, extra));
  s.ema21 = L("#ffb74d", 1); s.ema50 = L("#42a5f5", 1); s.ema200 = L("#ab47bc", 2); s.vwap = L("#fdd835", 1, { lineStyle: 2 });
  s.bbu = L("#2962ff", 1); s.bbl = L("#2962ff", 1); s.bbm = L("#2962ff", 1, { lineStyle: 2 });
  s.st = L(TV.up, 2); s.tenkan = L("#2962ff", 1); s.kijun = L("#b71c1c", 1); s.spana = L(UPA(.7), 1); s.spanb = L(DNA(.7), 1);
  s.sar = L("#e0e0e0", 1, { lineVisible: false, pointMarkersVisible: true, pointMarkersRadius: 1.5 });
  // alt paneller
  C.p1s.delta = C.p1.addHistogramSeries({ priceFormat: { type: "volume" }, lastValueVisible: false, priceLineVisible: false });
  C.p1s.cvd = C.p1.addLineSeries({ color: "#fdd835", lineWidth: 1, priceScaleId: "cvd", lastValueVisible: false, priceLineVisible: false });
  C.p1.priceScale("cvd").applyOptions({ scaleMargins: { top: 0.1, bottom: 0.1 } });
  // ana grafikten alt panellere aralık senkronu
  [C.main, C.p1, C.p2].forEach(hookSync);
  C.main.subscribeCrosshairMove((p) => legend(p));
}
const SYNC = { lock: false };
function hookSync(src) {
  src.timeScale().subscribeVisibleLogicalRangeChange((r) => {
    if (SYNC.lock || !r) return; SYNC.lock = true;
    try { [C.main, C.p1, C.p2].filter((c) => c && c !== src).forEach((c) => c.timeScale().setVisibleLogicalRange(r)); } catch (e) { }
    SYNC.lock = false;
  });
}
function visOpts() {
  const o = S.opts, s = C.ser;
  s.ema21.applyOptions({ visible: o.ema }); s.ema50.applyOptions({ visible: o.ema }); s.ema200.applyOptions({ visible: o.ema });
  s.vwap.applyOptions({ visible: o.vwap }); ["bbu", "bbl", "bbm"].forEach((k) => s[k].applyOptions({ visible: o.bb }));
  s.st.applyOptions({ visible: o.st }); ["tenkan", "kijun"].forEach((k) => s[k].applyOptions({ visible: o.ichi })); ["spana", "spanb"].forEach((k) => s[k].applyOptions({ visible: o.ichi || o.cloud }));
  s.sar.applyOptions({ visible: o.sar });
}

/* ---------- veri yükleme ---------- */
const align = (arr, times, key = "value") => { const m = new Map(arr.map((p) => [p.time, p])); return times.map((t) => { const p = m.get(t); return p && p[key] != null ? { time: loc(t), value: p.value } : { time: loc(t) }; }); };
async function loadChart(reset) {
  const j = await api(`/api/chart?sym=${S.sym}&tf=${S.tf}`);
  if (!j || !j.ready) { $("#loader").classList.remove("hidden"); $("#loader").textContent = j && j.reason ? j.reason : "Veri yükleniyor…"; return false; }
  $("#loader").classList.add("hidden"); { const w = $("#chart-wrap"); if (w) w.classList.remove("swap"); }
  S.data = j;
  const times = j.candles.map((c) => c.time);
  S.times = times.map(loc);
  const pf = { type: "price", precision: dec(S.sym), minMove: Math.pow(10, -dec(S.sym)) };
  C.ser.candle.applyOptions({ priceFormat: pf });
  C.ser.candle.setData(j.candles.map((c) => ({ time: loc(c.time), open: c.open, high: c.high, low: c.low, close: c.close })));
  C.ser.vol.setData(j.candles.map((c) => ({ time: loc(c.time), value: c.volume, color: c.close >= c.open ? UPA(.35) : DNA(.35) })));
  const sr = j.series;
  ["ema21", "ema50", "ema200", "vwap", "bbu", "bbl", "bbm", "tenkan", "kijun", "spana", "spanb", "sar"].forEach((k) => C.ser[k].setData(align(sr[k] || [], times)));
  const stm = new Map(sr.st_dir.map((p) => [p.time, p.v]));
  C.ser.st.setData(align(sr.st_line, times).map((p) => (p.value == null ? p : Object.assign(p, { color: stm.get(p.time - OFF) > 0 ? TV.up : TV.down }))));
  const dm = new Map(sr.delta.map((p) => [p.time, p.value]));
  C.p1s.delta.setData(times.map((t) => (dm.has(t) ? { time: loc(t), value: dm.get(t), color: dm.get(t) >= 0 ? UPA(.8) : DNA(.8) } : { time: loc(t) })));
  C.p1s.cvd.setData(align(sr.cvd, times));
  $("#pane1-title").textContent = j.real_flow ? "Delta (taker alış − satış, GERÇEK) + CVD" : "Delta (VEKİL: mum içi konum; gerçek order flow yok) + CVD";
  setPane2();
  visOpts();
  markers();
  if (reset || S.loadedKey !== S.sym + S.tf) {
    const n = j.candles.length;
    C.main.timeScale().setVisibleLogicalRange({ from: Math.max(0, n - 130), to: n + 10 });
    S.loadedKey = S.sym + S.tf;
  }
  S.candleLast = j.candles[j.candles.length - 1];
  return true;
}
function setPane2() {
  if (!S.data) return;
  const times = S.data.candles.map((c) => c.time), sr = S.data.series;
  C.p2.remove(); C.p2 = LightweightCharts.createChart($("#pane2"), paneOpts());
  const L = (c, w = 1, e = {}) => C.p2.addLineSeries(Object.assign({ color: c, lineWidth: w, lastValueVisible: true, priceLineVisible: false }, e));
  const m = S.pane2;
  if (m === "adx") {
    const a = L("#e0e0e0", 2); a.setData(align(sr.adx, times)); a.createPriceLine({ price: 16, color: TV.orange, lineStyle: 2, lineWidth: 1, axisLabelVisible: true, title: "16" }); a.createPriceLine({ price: 25, color: TV.muted, lineStyle: 2, lineWidth: 1, axisLabelVisible: true, title: "25" });
    L(TV.up, 1).setData(align(sr.pdi, times)); L(TV.down, 1).setData(align(sr.mdi, times));
  } else if (m === "rsi") {
    const a = L("#b388ff", 2); a.setData(align(sr.rsi, times)); [30, 50, 70].forEach((p) => a.createPriceLine({ price: p, color: TV.muted, lineStyle: 2, lineWidth: 1, axisLabelVisible: false }));
  } else if (m === "srsi") {
    const a = L("#2962ff", 2); a.setData(align(sr.srsi_k, times)); L("#ff9800", 1).setData(align(sr.srsi_d, times)); [20, 80].forEach((p) => a.createPriceLine({ price: p, color: TV.muted, lineStyle: 2, lineWidth: 1, axisLabelVisible: false }));
  } else if (m === "macd") {
    const h = C.p2.addHistogramSeries({ lastValueVisible: false, priceLineVisible: false }); const hm = new Map(sr.macdh.map((p) => [p.time, p.value]));
    h.setData(times.map((t) => (hm.has(t) ? { time: loc(t), value: hm.get(t), color: hm.get(t) >= 0 ? UPA(.7) : DNA(.7) } : { time: loc(t) })));
    L("#2962ff", 1).setData(align(sr.macd, times)); L("#ff9800", 1).setData(align(sr.macds, times));
  } else if (m === "mfi") {
    const a = L("#4dd0e1", 2); a.setData(align(sr.mfi, times)); [20, 80].forEach((p) => a.createPriceLine({ price: p, color: TV.muted, lineStyle: 2, lineWidth: 1, axisLabelVisible: false }));
    const b = L("#fdd835", 1, { priceScaleId: "cmf" }); b.setData(align(sr.cmf, times));
  } else if (m === "sq") {
    const h = C.p2.addHistogramSeries({ lastValueVisible: false, priceLineVisible: false }); const hm = new Map(sr.sqmom.map((p) => [p.time, p.value]));
    h.setData(times.map((t) => (hm.has(t) ? { time: loc(t), value: hm.get(t), color: hm.get(t) >= 0 ? UPA(.75) : DNA(.75) } : { time: loc(t) })));
  }
  hookSync(C.p2);
  const r = C.main.timeScale().getVisibleLogicalRange(); if (r) C.p2.timeScale().setVisibleLogicalRange(r);
}
function markers() {
  if (!S.opts.marks || !S.data) { C.ser.candle.setMarkers([]); return; }
  const bars = S.times, out = [];
  S.sigs.filter((x) => x.sym === S.sym && x.tf === S.tf).forEach((x) => {
    const t = loc(x.ts); let b = null;
    for (let i = bars.length - 1; i >= 0; i--) if (bars[i] <= t) { b = bars[i]; break; }
    if (b == null) return;
    out.push({ time: b, position: x.side === 1 ? "belowBar" : "aboveBar", color: x.side === 1 ? TV.up : TV.down, shape: x.side === 1 ? "arrowUp" : "arrowDown", text: "◉" + (x.side === 1 ? "LONG" : "SHORT") });
  });
  out.sort((a, b) => a.time - b.time);
  C.ser.candle.setMarkers(out);
}

/* ---------- gösterge menüsü ---------- */
function buildMenu() {
  const m = $("#ind-menu");
  m.innerHTML = IND_MENU.map(([g, items]) => `<div class="grp">${g}</div>` + items.map(([k, n]) => `<label><input type="checkbox" data-k="${k}" ${S.opts[k] ? "checked" : ""}> ${n}</label>`).join("")).join("");
  $$("input", m).forEach((i) => (i.onchange = () => { S.opts[i.dataset.k] = i.checked; localStorage.setItem("opts", JSON.stringify(S.opts)); visOpts(); markers(); drawOverlay(); }));
}

/* ---------- üst çubuk ---------- */
function buildTop() {
  $("#syms").innerHTML = SYMS.map((s) => `<div class="symtab" data-s="${s}"><div class="n"><span>${NAMES[s]}</span><span class="dots" id="dots-${s}"></span></div><div class="p"><span id="px-${s}">—</span><span id="ch-${s}"></span></div></div>`).join("");
  $$(".symtab").forEach((e) => (e.onclick = () => setSym(e.dataset.s))); addEventListener("resize", () => symInd());
  $("#tfs").innerHTML = TFS.map((t) => `<button class="tfb" data-t="${t}">${TF_LABEL[t]}</button>`).join("");
  $$(".tfb").forEach((e) => (e.onclick = () => setTf(e.dataset.t)));
  $("#btn-ind").onclick = (e) => { e.stopPropagation(); $("#ind-menu").classList.toggle("hidden"); };
  document.addEventListener("click", (e) => { if (!e.target.closest(".menu")) $("#ind-menu").classList.add("hidden"); });
  window.setNeraTheme = (th) => { const was = S.theme; S.theme = th; localStorage.setItem("theme", th); if (THEME_PAL[th]) { if (!THEME_PAL[was]) localStorage.setItem("nera_pal_prev", JSON.stringify(getPalette())); applyPalette(THEME_PAL[th]); } else if (THEME_PAL[was]) { let p = null; try { p = JSON.parse(localStorage.getItem("nera_pal_prev")); } catch (e) { /* */ } applyPalette(p || PALDEF); } applyTheme(); setPane2(); DT.emit("theme", th); };
  window.setSignalSound = (on) => { S.sound = !!on; localStorage.setItem("sound", S.sound ? "1" : "0"); if (S.sound) { try { thunder(); if ("Notification" in window && Notification.permission === "default") Notification.requestPermission(); } catch (e) { /* yok */ } } };
  $("#btn-sound").onclick = () => { S.sound = !S.sound; localStorage.setItem("sound", S.sound ? "1" : "0"); $("#btn-sound").textContent = S.sound ? "🔊" : "🔇"; if (S.sound) { thunder(); try { const LN = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.LocalNotifications; if (LN) LN.requestPermissions(); else if ("Notification" in window && Notification.permission === "default") Notification.requestPermission(); } catch (e) { /* yok */ } } };
  S.awake = localStorage.getItem("awake") === "1"; markAwake();
  $("#btn-awake").onclick = () => { S.awake = !S.awake; localStorage.setItem("awake", S.awake ? "1" : "0"); markAwake(); setAwake(S.awake); };
  document.addEventListener("visibilitychange", () => { if (!document.hidden && S.awake) setAwake(true); });
  if (S.awake) setAwake(true);
  $("#btn-sound").textContent = S.sound ? "🔊" : "🔇";
  $("#btn-hist").onclick = () => setTab("hist");
  $$("#tabs button").forEach((b) => (b.onclick = () => setTab(b.dataset.tab)));
  $("#pane2-sel").value = S.pane2;
  $("#pane2-sel").onchange = (e) => { S.pane2 = e.target.value; localStorage.setItem("pane2", S.pane2); setPane2(); };
  markTop();
}
let wakeLock = null;
async function setAwake(on) { try { if (on) { if (navigator.wakeLock) wakeLock = await navigator.wakeLock.request("screen"); } else if (wakeLock) { await wakeLock.release(); wakeLock = null; } } catch (e) { /* desteklenmiyor / izin yok */ } }
function markAwake() { const b = $("#btn-awake"); if (b) { b.style.opacity = S.awake ? 1 : 0.45; b.title = S.awake ? "Ekran açık kalıyor (pil harcar)" : "Ekranı açık tut"; } }
function symInd() { const w = $("#syms"), a = w && w.querySelector(".symtab.active"); if (!w || !a) return; let d = w.querySelector(".sym-ind"); if (!d) { d = document.createElement("i"); d.className = "sym-ind"; w.prepend(d); } d.style.transform = `translateX(${a.offsetLeft}px)`; d.style.width = a.offsetWidth + "px"; d.style.opacity = 1; }
function markTop() { $$(".symtab").forEach((e) => e.classList.toggle("active", e.dataset.s === S.sym)); symInd(); requestAnimationFrame(symInd); $$(".tfb").forEach((e) => e.classList.toggle("active", e.dataset.t === S.tf)); }
function swapOn() { const w = $("#chart-wrap"); if (w) { w.classList.add("swap"); clearTimeout(w._h); w._h = setTimeout(() => w.classList.remove("swap"), 5000); } }
function setSym(s) { swapOn(); S.sym = s; localStorage.setItem("sym", s); S.data = null; S.ana = null; markTop(); reload(true); }
function setTf(t) { swapOn(); S.tf = t; localStorage.setItem("tf", t); S.data = null; S.ana = null; markTop(); reload(true); }
function setTab(t) {
  S.tab = t; document.body.classList.toggle("sig-hide", t !== "sig"); { const g = $("#ag-graph"); if (g) g.classList.toggle("hidden", t !== "agents"); } requestAnimationFrame(inkTo); $$("#tabs button").forEach((b) => b.classList.toggle("active", b.dataset.tab === t)); $$(".tab").forEach((e) => e.classList.toggle("active", e.id === "tab-" + t));
  if (t === "hist") { S.unseen = 0; badge(); renderHist(); }
  renderTabs();
}
function inkTo() { const b = $("#tabs button.active"), k = $("#tab-ink"); if (b && k) { k.style.width = b.offsetWidth + "px"; k.style.transform = `translateX(${b.offsetLeft}px)`; } }
window.addEventListener("resize", () => inkTo());
function badge() { const b = $("#bolt-badge"); b.textContent = S.unseen; b.classList.toggle("hidden", !S.unseen); }
async function reload(reset) { $("#loader").classList.remove("hidden"); await loadChart(reset); await loadAna(); renderTabs(); drawOverlay(); }

/* ---------- ICT / PA / likidite katmanı (tuval) ---------- */
const cvs = $("#overlay");
function sizeOverlay() { const r = $("#chart-wrap").getBoundingClientRect(), d = Math.min(window.devicePixelRatio || 1, IS_MOB_DPR); if (cvs.width !== Math.round(r.width * d) || cvs.height !== Math.round(r.height * d)) { cvs.width = Math.round(r.width * d); cvs.height = Math.round(r.height * d); cvs.style.width = r.width + "px"; cvs.style.height = r.height + "px"; } return d; }
function drawOverlay() {
  const d = sizeOverlay(), ctx = cvs.getContext("2d");
  ctx.setTransform(d, 0, 0, d, 0, 0); ctx.clearRect(0, 0, cvs.width, cvs.height);
  if (!S.data || !C.main) return;
  const ts = C.main.timeScale(), sr = C.ser.candle, W = ts.width(), H = cvs.height / d - 28;
  const X = (t) => { const x = ts.timeToCoordinate(loc(t)); return x == null ? (S.times.length && loc(t) < S.times[0] ? 0 : W) : x; };
  const Y = (p) => sr.priceToCoordinate(p);
  const smc = S.data.smc, o = S.opts;
  if (window.NeraFlow) NeraFlow.focus(S.sym);
  drawHeatBg(X, Y, W, H);
  const band = (x0, x1, y0, y1, fill, stroke, dash) => { if (y0 == null || y1 == null) return; x0 = Math.max(0, Math.min(W, x0)); x1 = Math.max(0, Math.min(W, x1)); if (x1 <= x0) return; ctx.fillStyle = fill; ctx.fillRect(x0, Math.min(y0, y1), x1 - x0, Math.abs(y1 - y0)); if (stroke) { ctx.strokeStyle = stroke; ctx.setLineDash(dash || []); ctx.strokeRect(x0 + .5, Math.min(y0, y1) + .5, x1 - x0, Math.abs(y1 - y0)); ctx.setLineDash([]); } };
  const hline = (p, x0, x1, color, dash, w = 1) => { const y = Y(p); if (y == null) return null; ctx.strokeStyle = color; ctx.lineWidth = w; ctx.setLineDash(dash || []); ctx.beginPath(); ctx.moveTo(Math.max(0, x0), y + .5); ctx.lineTo(Math.min(W, x1), y + .5); ctx.stroke(); ctx.setLineDash([]); ctx.lineWidth = 1; return y; };
  const txt = (s, x, y, color, size = 11, align = "left", bold = false) => { ctx.font = `${bold ? "700 " : ""}${size}px Trebuchet MS, Segoe UI, sans-serif`; ctx.fillStyle = color; ctx.textAlign = align; ctx.fillText(s, x, y); };
  ctx.save(); ctx.beginPath(); ctx.rect(0, 0, W, H + 28); ctx.clip();
  // kill zone seansları
  if (o.sess) {
    const cs = S.data.candles; let seg = null; const segs = [];
    cs.forEach((c) => { const h = new Date(c.time * 1000).getUTCHours(); const k = h >= 7 && h < 10 ? "L" : h >= 12 && h < 15 ? "N" : h >= 1 && h < 5 ? "A" : ""; if (seg && seg.k === k) seg.t1 = c.time; else { seg = { k, t0: c.time, t1: c.time }; segs.push(seg); } });
    const col = { L: "rgba(41,98,255,.07)", N: "rgba(255,152,0,.07)", A: "rgba(171,71,188,.06)" }, nm = { L: "Londra KZ", N: "New York KZ", A: "Asya" };
    segs.forEach((s) => { if (!s.k) return; const x0 = X(s.t0), x1 = X(s.t1) + 6; if (x1 < 0 || x0 > W) return; ctx.fillStyle = col[s.k]; ctx.fillRect(Math.max(0, x0), 0, x1 - Math.max(0, x0), H); if (x1 - x0 > 70) txt(nm[s.k], Math.max(2, x0) + 3, 12, TV.muted, 10); });
  }
  // Ichimoku bulutu
  if (o.cloud) {
    const A = S.data.series.spana, B = S.data.series.spanb, bm = new Map(B.map((p) => [p.time, p.value]));
    let prev = null;
    A.forEach((p) => { const b = bm.get(p.time); if (b == null) { prev = null; return; } const x = X(p.time), ya = Y(p.value), yb = Y(b); if (ya == null || yb == null) { prev = null; return; }
      if (prev && x <= W + 10 && x >= -10) { ctx.fillStyle = p.value >= b ? UPA(.16) : DNA(.16); ctx.beginPath(); ctx.moveTo(prev.x, prev.ya); ctx.lineTo(x, ya); ctx.lineTo(x, yb); ctx.lineTo(prev.x, prev.yb); ctx.closePath(); ctx.fill(); }
      prev = { x, ya, yb }; });
  }
  // premium / discount + OTE
  if (o.pdz && smc.pd) {
    const p = smc.pd; band(0, W, Y(p.hi), Y(p.eq), DNA(.045)); band(0, W, Y(p.eq), Y(p.lo), UPA(.045));
    const ye = hline(p.eq, 0, W, "rgba(120,123,134,.7)", [5, 4]); if (ye != null) txt("EQ 50%", 6, ye - 3, TV.muted, 10);
    band(0, W, Y(p.ote[1]), Y(p.ote[0]), "rgba(255,152,0,.10)"); const yo = Y(p.ote[1]); if (yo != null) txt("OTE", 6, yo + 11, TV.orange, 10);
    txt("PREMIUM", W - 6, (Y(p.hi) || 0) + 12, DNA(.7), 10, "right"); txt("DISCOUNT", W - 6, (Y(p.lo) || 0) - 4, UPA(.8), 10, "right");
  }
  // hacim profili (sağ kenar)
  if (o.vp && smc.vp) {
    const vp = smc.vp, mx = Math.max(...vp.bins.map((b) => b.v)), wmax = W * 0.14;
    vp.bins.forEach((b) => { const y0 = Y(b.hi), y1 = Y(b.lo); if (y0 == null || y1 == null) return; const inVA = b.lo >= vp.val - 1e-9 && b.hi <= vp.vah + 1e-9; ctx.fillStyle = inVA ? "rgba(41,98,255,.28)" : "rgba(120,123,134,.22)"; const w = wmax * b.v / mx; ctx.fillRect(W - w, y0, w, Math.max(1, y1 - y0 - 1)); });
    [[vp.poc, "POC", TV.orange], [vp.vah, "VAH", TV.cyan], [vp.val, "VAL", TV.cyan]].forEach(([p, n, c]) => { const y = hline(p, W * 0.72, W, c, [3, 3]); if (y != null) txt(n + " " + fp(p), W - wmax - 4, y - 2, c, 10, "right"); });
  }
  // order block / FVG
  if (o.ob) smc.obs.forEach((ob) => { const x0 = X(ob.t), c = ob.dir > 0 ? "8,153,129" : "242,54,69"; band(x0, W, Y(ob.hi), Y(ob.lo), `rgba(${c},${ob.fresh ? .22 : .12})`, `rgba(${c},.7)`); const y = Y(ob.hi); if (y != null) txt((ob.dir > 0 ? "Boğa OB" : "Ayı OB") + (ob.fresh ? " ●" : ""), Math.max(4, x0) + 4, y + 11, `rgba(${c},1)`, 10); });
  if (o.fvg) smc.fvgs.forEach((f) => { const x0 = X(f.t), c = f.dir > 0 ? "77,208,225" : "171,71,188"; band(x0, W, Y(f.hi), Y(f.lo), `rgba(${c},.13)`, `rgba(${c},.55)`, [3, 3]); const y = Y(f.hi); if (y != null) txt("FVG" + (f.tested ? " (test)" : ""), Math.max(4, x0) + 4, y + 10, `rgba(${c},1)`, 10); });
  // likidite havuzları
  if (o.liq) {
    const seen = {}, px0 = S.candleLast ? S.candleLast.close : smc.price;
    const lq = smc.liq.filter((q) => !q.swept), up = lq.filter((q) => q.p > px0).sort((a, b) => a.p - b.p).slice(0, 4), dn = lq.filter((q) => q.p <= px0).sort((a, b) => b.p - a.p).slice(0, 4);
    [...up, ...dn].forEach((q) => { const key = Math.round(q.p * 100); if (seen[key]) return; seen[key] = 1; const c = q.side === "buy" ? "#ef5350" : "#26a69a"; const y = hline(q.p, X(q.t), W, c, [2, 4], 1); if (y != null) txt((q.side === "buy" ? "BSL " : "SSL ") + q.k + (q.n > 1 ? " ×" + q.n : "") + " " + fp(q.p), W - 4 - (o.vp ? W * 0.0 : 0), y - 3, c, 10, "right"); });
    smc.sweeps.forEach((s) => { const x = X(s.t); const y = Y(s.ext); if (y == null) return; ctx.fillStyle = s.dir > 0 ? TV.up : TV.down; ctx.beginPath(); ctx.arc(x, y + (s.dir > 0 ? 9 : -9), 4, 0, 7); ctx.fill(); txt("süpürme", x, y + (s.dir > 0 ? 24 : -16), ctx.fillStyle, 9, "center"); });
  }
  if (o.sr) smc.sr.forEach((q) => { const y = hline(q.p, 0, W, "rgba(209,212,220,.35)", [1, 3]); if (y != null) txt(q.k + " " + q.n + "×", 6, y - 2, "rgba(209,212,220,.6)", 9); });
  if (o.fib && smc.fib) Object.entries(smc.fib.lv).forEach(([r, p]) => { const y = hline(p, 0, W, "rgba(253,216,53,.45)", [2, 3]); if (y != null) txt("Fib " + r, 6, y - 2, "rgba(253,216,53,.8)", 9); });
  // yapı
  if (o.struct) {
    smc.events.forEach((e) => { const x0 = X(e.from_t), x1 = X(e.t), y = Y(e.level); if (y == null) return; const c = e.dir > 0 ? TV.up : TV.down; ctx.strokeStyle = c; ctx.setLineDash([4, 3]); ctx.beginPath(); ctx.moveTo(Math.max(0, x0), y); ctx.lineTo(x1, y); ctx.stroke(); ctx.setLineDash([]); txt(e.type, (Math.max(0, x0) + x1) / 2, y + (e.dir > 0 ? -4 : 11), c, 10, "center", e.type === "CHoCH"); });
    smc.swings.forEach((s) => { if (!s.lab) return; const y = Y(s.p); if (y == null) return; txt(s.lab, X(s.t), s.k === "H" ? y - 6 : y + 14, s.lab[0] === "H" ? TV.up : TV.down, 10, "center", true); });
  }
  drawHeat(ctx, o, X, Y, W, H, txt);
  if (o.liqmap || o.whales || o.pulse2) drawMaps(ctx, o, X, Y, W, H, txt);
  if (o.fp) drawFp(ctx, X, Y, W, H, txt);
  if (o.money) drawMoney(ctx, X, Y, W, H, txt); else moneyCard(null);
  // sinyal planı (TradingView pozisyon aracı gibi)
  if (o.plan) { const pl = currentPlan(); if (pl) drawPlan(ctx, pl, X, Y, W, band, hline, txt); }
  ctx.restore();
}
/* ---------- order flow haritaları: Likidasyon · Balina · Pulse v2 (TradingView'daki kapalı kaynaklı göstergelerin kendi hesabımızla yapılan karşılıkları) ---------- */
const usdS = (x) => "$" + (x >= 1e9 ? (x / 1e9).toFixed(2) + "B" : x >= 1e6 ? (x / 1e6).toFixed(2) + "M" : x >= 1e3 ? (x / 1e3).toFixed(0) + "K" : x.toFixed(0));
function feedWh(fl) {                                           // canlı büyük işlem + tasfiye akışını oturum boyunca biriktirir (aynı olay iki kez eklenmez)
  if (!fl) return; const w = S.wh = S.wh || {}, a = w[S.sym] = w[S.sym] || { big: [], liq: [], seen: new Set() };
  [["big", fl.big], ["liq", fl.liq]].forEach(([k, arr]) => (arr || []).forEach((e) => { const id = k + e.t + "|" + e.p + "|" + Math.round(e.usd); if (a.seen.has(id)) return; a.seen.add(id); a[k].push(e); if (a[k].length > 250) a[k].shift(); if (a.seen.size > 2000) a.seen.clear(); }));
}
function liqModel() {                                           // tahmini tasfiye seviyeleri: her mum fiyat-hacim ağırlıklı giriş sayılır; 10/25/50/100x kaldıraç; fiyatın sonradan geçtiği seviye tasfiye edilmiş sayılıp silinir
  const cs = S.data.candles, n = cs.length, key = S.sym + S.tf + cs[n - 1].time + ":" + n; if (S._lm && S._lm.key === key) return S._lm;
  const sl = new Array(n + 1), sh = new Array(n + 1); sl[n] = Infinity; sh[n] = -Infinity; for (let i = n - 1; i >= 0; i--) { sl[i] = Math.min(sl[i + 1], cs[i].low); sh[i] = Math.max(sh[i + 1], cs[i].high); }
  const s0 = Math.max(0, n - 400); let lo = Infinity, hi = -Infinity; for (let i = s0; i < n; i++) { lo = Math.min(lo, cs[i].low); hi = Math.max(hi, cs[i].high); }
  const pad = (hi - lo) * 0.3, a0 = lo - pad, NB = 150, st = (hi + pad - a0) / NB, Lg = new Float64Array(NB), Sh = new Float64Array(NB);
  for (let i = s0; i < n; i++) { const c = cs[i], typ = (c.high + c.low + c.close) / 3, v = c.volume || 1;
    for (const [lev, w] of [[10, 0.15], [25, 0.3], [50, 0.35], [100, 0.2]]) { const pl = typ * (1 - 1 / lev + 0.005), ps = typ * (1 + 1 / lev - 0.005);
      if (sl[i + 1] > pl) { const b = Math.floor((pl - a0) / st); if (b >= 0 && b < NB) Lg[b] += v * w; }
      if (sh[i + 1] < ps) { const b = Math.floor((ps - a0) / st); if (b >= 0 && b < NB) Sh[b] += v * w; } } }
  let mx = 0; for (let b = 0; b < NB; b++) mx = Math.max(mx, Lg[b], Sh[b]);
  const peak = (A) => { let bi = -1; for (let b = 0; b < NB; b++) if (bi < 0 || A[b] > A[bi]) bi = b; return A[bi] > 0 ? a0 + (bi + 0.5) * st : null; };
  return (S._lm = { key, a0, st, NB, Lg, Sh, mx: mx || 1, pl: peak(Lg), ps: peak(Sh) });
}
function pulseModel() {                                         // Pulse (RSI+StochRSI+CCI+MACD bileşiği) 3'lü EMA ile yumuşatılır; ±25 eşik geçişleri sinyal oklarıdır
  const ps = S.data.series.pulse || [], key = S.sym + S.tf + (ps.length ? ps[ps.length - 1].time : 0) + ":" + ps.length; if (S._pm && S._pm.key === key) return S._pm;
  const out = []; let e = null; ps.forEach((p, i) => { e = e == null ? p.value : e + (p.value - e) * 0.5; out.push({ t: p.time, v: e, x: i && out[i - 1].v <= 25 && e > 25 ? 1 : i && out[i - 1].v >= -25 && e < -25 ? -1 : 0 }); });
  return (S._pm = { key, out });
}
/* ---------- order flow: GERÇEK veri (lab/flow.js NeraFlow, Binance vadeli) ----------
   Mum × fiyat satırı gerçekleşen alış/satış (aggTrade; kaydın olmadığı geçmişte 1 dk mumların gerçek taker hacmi, satıra eşit yayılır),
   emir defteri geçmişi (60 sn dilimde bekleyen en büyük tutar), balina işlemleri ve tasfiyeler. Kayıt uygulama açıkken yapılır.
   Altın/gümüş grafiği XM'den geliyorsa Binance fiyatıyla aradaki küçük fark (pxOff) kaydırılır. EUR/USD için order flow yok. */
const NF = () => (window.NeraFlow && window.NeraFlow.has(S.sym) ? window.NeraFlow : null);
function pxOff() { const f = NF(); if (!f || !S.candleLast || (S.sym !== "XAUUSDT" && S.sym !== "XAGUSDT")) return 0; const l = f.last(S.sym); if (!l) return 0; const o = S.candleLast.close - l; return Math.abs(o) < l * 0.005 ? o : 0; }
function flowModel() {
  const f = NF(); if (!f || !S.data || S.data.candles.length < 3) return null;
  const cs = S.data.candles, n = cs.length, stp = cs[1].time - cs[0].time, t0 = cs[Math.max(0, n - 300)].time, key = S.sym + S.tf + f.ver() + ":" + cs[n - 1].time + ":" + Math.floor(Date.now() / 2000);
  if (S._fm && S._fm.key === key) return S._fm;
  const bk = f.buckets(S.sym, stp, t0) || new Map(), off = pxOff(), R = f.ROW[S.sym];
  const q = (arr, k) => { arr.sort((a, b) => a - b); return arr.length ? arr[Math.floor(arr.length * k)] || arr[arr.length - 1] : 1; };
  const va = []; bk.forEach((b) => b.r.forEach((c) => va.push(c[0] + c[1])));
  const bars = new Map(); f.book(S.sym).forEach((sl) => { if (sl.t < t0) return; const bt = Math.floor(sl.t / stp) * stp; let a = bars.get(bt); if (!a) bars.set(bt, (a = new Map())); for (let i = 0; i < sl.v.length; i++) { const v = sl.v[i]; if (!v) continue; const k = sl.r0 + i, o = a.get(k); if (o === undefined || Math.abs(v) > Math.abs(o)) a.set(k, v); } });
  const ba = []; bars.forEach((a) => a.forEach((v) => ba.push(Math.abs(v))));
  const sn = f.snap(S.sym); let wb = null, wa = null; if (sn) { sn.bids.forEach(([p, u]) => { if (!wb || u > wb[1]) wb = [p, u]; }); sn.asks.forEach(([p, u]) => { if (!wa || u > wa[1]) wa = [p, u]; }); }
  let live = 0; bk.forEach((b) => { if (b.live) live++; });
  return (S._fm = { key, bk, ref: q(va, 0.96) || 1, bars, bref: q(ba, 0.93) || 1, R, off, stp, wb, wa, snap: sn, live, since: f.since(S.sym) });
}
const HCOL = [[0, 8, 10, 36, 0], [0.16, 28, 36, 130, 0.38], [0.34, 0, 150, 140, 0.58], [0.52, 105, 205, 45, 0.7], [0.7, 240, 212, 30, 0.8], [0.86, 255, 125, 20, 0.88], [1, 232, 40, 44, 0.94]];
function heatRGBA(k) {                                          // video'daki gibi: koyu → mavi → yeşil → sarı → turuncu → kırmızı
  k = Math.max(0, Math.min(1, k)); let i = 1; while (i < HCOL.length - 1 && HCOL[i][0] < k) i++; const a = HCOL[i - 1], b = HCOL[i], u = (k - a[0]) / (b[0] - a[0] || 1), m = (j) => a[j] + (b[j] - a[j]) * u;
  return `rgba(${Math.round(m(1))},${Math.round(m(2))},${Math.round(m(3))},${(m(4) * 0.72).toFixed(3)})`;
}
function exModel() {                                            // fiyat satırı başına işlem hacmi ($) ve alıcı payı: gerçek akış (flowModel); EUR/USD'de mum hacmi + delta
  const cs = S.data.candles, n = cs.length, fm = flowModel(), key = S.sym + S.tf + cs[n - 1].time + ":" + n + ":" + (fm ? fm.key : ""); if (S._em && S._em.key === key) return S._em;
  const s0 = Math.max(0, n - 300); let lo = Infinity, hi = -Infinity;
  for (let i = s0; i < n; i++) { lo = Math.min(lo, cs[i].low); hi = Math.max(hi, cs[i].high); }
  const pad = (hi - lo) * 0.25, a0 = lo - pad, NB = 110, st = (hi + pad - a0) / NB, rowV = new Float64Array(NB), rowBuy = new Float64Array(NB);
  if (fm) fm.bk.forEach((b) => b.r.forEach((c, k) => { const p = k * fm.R + fm.off, bi = Math.floor((p - a0) / st); if (bi < 0 || bi >= NB) return; rowV[bi] += (c[0] + c[1]) * p; rowBuy[bi] += c[0] * p; }));
  else {
    const dm = new Map((S.data.series.delta || []).map((p) => [p.time, p.value]));
    for (let i = s0; i < n; i++) {
      const c = cs[i], v = (c.volume || 0) * ((c.high + c.low) / 2), d = dm.get(c.time), vv = c.volume || 0, sh = d != null && vv > 0 ? Math.min(1, Math.max(0, (vv + d) / (2 * vv))) : c.close >= c.open ? 0.6 : 0.4;
      const b0 = Math.max(0, Math.floor((c.low - a0) / st)), b1 = Math.min(NB - 1, Math.floor((c.high - a0) / st)), nb = Math.max(1, b1 - b0 + 1);
      for (let b = b0; b <= b1; b++) { rowV[b] += v / nb; rowBuy[b] += (v / nb) * sh; }
    }
  }
  let tot = 0; for (let b = 0; b < NB; b++) tot += rowV[b];
  return (S._em = { key, a0, st, NB, rowV, rowBuy, tot, real: !!fm });
}
function zoneAt(price) {                                        // tıklanan fiyat çevresi (±1 satır): gerçek işlem hacmi, payı, alış/satış baskısı
  const m = flowModel(); if (!m) return null; const k0 = NeraFlow.rowK(S.sym, price - m.off), rows = new Map(); let tot = 0;
  m.bk.forEach((b) => b.r.forEach((c, k) => { tot += c[0] + c[1]; if (Math.abs(k - k0) <= 3) { const o = rows.get(k) || [0, 0]; o[0] += c[0]; o[1] += c[1]; rows.set(k, o); } }));
  let best = k0, bv = -1; rows.forEach((o, k) => { if (Math.abs(k - k0) <= 2 && o[0] + o[1] > bv) { bv = o[0] + o[1]; best = k; } });
  let vol = 0, buy = 0; for (let k = best - 1; k <= best + 1; k++) { const o = rows.get(k); if (o) { vol += o[0] + o[1]; buy += o[0]; } }
  const p = best * m.R + m.off; return { price: p, lo: p - 1.5 * m.R, hi: p + 1.5 * m.R, vol: vol * p, share: tot ? vol / tot : 0, buy: vol ? buy / vol : 0.5 };
}
function ensureHeatBg() { let h = $("#heatbg"); if (!h) { h = document.createElement("canvas"); h.id = "heatbg"; const w = $("#chart-wrap"); w.insertBefore(h, w.firstChild); } return h; }
function setChartBgTransparent(on) { on = on || !!window.__bgMedia; if (S._tr === on) return; S._tr = on; try { C.main.applyOptions({ layout: { background: { type: "solid", color: on ? "rgba(0,0,0,0)" : cv("--bg") } } }); } catch (e) { /* */ } const h = $("#heatbg"); if (h) h.style.display = on ? "block" : "none"; }
function drawHeatBg(X, Y, W, Hh) {
  const o = S.opts, hb = ensureHeatBg(), d = Math.min(window.devicePixelRatio || 1, IS_MOB_DPR), r = $("#chart-wrap").getBoundingClientRect();
  if (hb.width !== Math.round(r.width * d) || hb.height !== Math.round(r.height * d)) { hb.width = Math.round(r.width * d); hb.height = Math.round(r.height * d); hb.style.width = r.width + "px"; hb.style.height = r.height + "px"; }
  const c = hb.getContext("2d"); c.setTransform(d, 0, 0, d, 0, 0); c.clearRect(0, 0, r.width, r.height); if (!o.heat) { setChartBgTransparent(false); return; } setChartBgTransparent(true);
  c.fillStyle = cv("--bg"); c.fillRect(0, 0, r.width, r.height);
  const m = flowModel(); if (!m) return; const ya = Y(m.R + m.off), yb = Y(m.off); if (ya == null || yb == null) return;
  const g = Math.max(1, Math.ceil(4 / Math.max(0.01, Math.abs(yb - ya)))), yr = (gk) => [Y(((gk + 1) * g - 0.5) * m.R + m.off), Y((gk * g - 0.5) * m.R + m.off)];
  const paint = (src, ref, thr, mul, x0, x1) => { const G = new Map(); src.forEach((v, k) => { const gk = Math.floor(k / g); G.set(gk, Math.max(G.get(gk) || 0, v)); }); G.forEach((v, gk) => { const kk = Math.sqrt(v / ref) * mul; if (kk < thr) return; const [y0, y1] = yr(gk); if (y0 == null || y1 == null) return; c.fillStyle = heatRGBA(kk); c.fillRect(x0, y0, Math.max(1, x1 - x0), Math.max(1.5, y1 - y0 + 0.6)); }); };
  const refG = m.ref * Math.min(g, 4);
  m.bk.forEach((b, bt) => { const x0 = X(bt) - 1, x1 = X(bt + m.stp) + 1; if (x1 < 0 || x0 > W) return; const s = new Map(); b.r.forEach((cc, k) => { const gk = Math.floor(k / g) * g; s.set(gk, (s.get(gk) || 0) + cc[0] + cc[1]); }); paint(s, refG, 0.1, 1, x0, x1); });
  m.bars.forEach((a, bt) => { const x0 = X(bt) - 1, x1 = X(bt + m.stp) + 1; if (x1 < 0 || x0 > W) return; const s = new Map(); a.forEach((v, k) => s.set(k, Math.abs(v))); paint(s, m.bref, 0.16, 0.95, x0, x1); });
}
function drawHeat(ctx, o, X, Y, W, H, txt) {                    // üst katman: duvar etiketleri + tıklanan bölge (sarı bant + bilgi kutusu)
  if (!o.heat) return; const m = flowModel();
  if (!m) { txt(S.sym === "EURUSD" ? "EUR/USD: gerçek order flow verisi yok" : "Order flow bağlanıyor…", 6, H - 10, "rgba(255,210,122,.9)", 10, "left", true); }
  else txt(`Gerçek veri (Binance): işlem hacmi + emir defteri · kayıt ${m.since ? dtm(m.since) : "—"}'den beri · öncesi Binance mumlarının taker hacmi`, 6, H - 38, "rgba(180,188,205,.7)", 9);
  if (m && m.wb) { const y = Y(m.wb[0] + m.off); if (y != null) txt(`Alış duvarı ${fp(m.wb[0] + m.off)} · ${usdS(m.wb[1])}`, W - 6, y - 3, "rgba(150,230,255,.95)", 10, "right", true); }
  if (m && m.wa) { const y = Y(m.wa[0] + m.off); if (y != null) txt(`Satış duvarı ${fp(m.wa[0] + m.off)} · ${usdS(m.wa[1])}`, W - 6, y - 3, "rgba(255,190,100,.95)", 10, "right", true); }
  const z = S.hz; if (!z) return; const y0 = Y(z.hi), y1 = Y(z.lo); if (y0 == null || y1 == null) return;
  const g = ctx.createLinearGradient(0, y0, 0, y1); g.addColorStop(0, "rgba(255,196,40,.55)"); g.addColorStop(0.5, "rgba(255,214,70,.95)"); g.addColorStop(1, "rgba(255,196,40,.55)"); ctx.save(); ctx.shadowColor = "rgba(255,190,30,.9)"; ctx.shadowBlur = 14; ctx.fillStyle = g; ctx.fillRect(0, Math.min(y0, y1), W, Math.max(5, Math.abs(y1 - y0))); ctx.restore();
  const bw = Math.min(W - 24, 250), bx = 12, by = Math.max(8, Math.min(y0, y1) - 92), type = z.buy >= 0.5 ? "Alış baskısı bölgesi" : "Satış baskısı bölgesi", col = z.buy >= 0.5 ? "#4fe3b0" : "#ffb04a";
  ctx.fillStyle = "rgba(12,14,22,.94)"; ctx.strokeStyle = "#ff9f2e"; ctx.lineWidth = 2; ctx.beginPath(); (ctx.roundRect ? ctx.roundRect(bx, by, bw, 78, 10) : ctx.rect(bx, by, bw, 78)); ctx.fill(); ctx.stroke(); ctx.lineWidth = 1;
  txt(fp(z.price), bx + 14, by + 26, "#fff", 15, "left", true); txt("Hacim", bx + 14, by + 48, "#9aa3b8", 12); txt(usdS(z.vol), bx + bw - 40, by + 48, "#fff", 14, "right", true); txt(`%${(z.share * 100).toFixed(1)} · ${type}`, bx + 14, by + 68, col, 12, "left", true);
  txt("✕", bx + bw - 16, by + 22, "#cfd5e6", 15, "center"); z.box = { x: bx, y: by, w: bw, h: 78 };
}
/* ---------- Likidite: para nerede? ----------
   Kimin nerede işlem açtığı tek tek görünmez. Paranın toplandığı yeri dört gerçek/vekil kaynaktan birleştiririz:
   1) emir defteri (Binance vadeli, bekleyen limit emirler: aşağıda alış, yukarıda satış duvarları), 2) tahmini tasfiye seviyeleri (liqModel),
   3) stop havuzları (eşit tepe/dipler: üstünde shortların, altında longların stopları birikir), 4) gerçekleşen işlem hacmi (POC, alıcı/satıcı baskın bölge).
   Fiyat çoğu zaman yoğun likiditeye çekilir (mıknatıs); bu bir eğilimdir, kesin değildir. */
function stopPools(cs) {
  const n = cs.length, s0 = Math.max(2, n - 300); let atr = 0; for (let i = n - 14; i < n; i++) atr += cs[i].high - cs[i].low; atr /= 14; const tol = atr * 0.3, H = [], L = [];
  for (let i = s0; i < n - 2; i++) { const c = cs[i]; if (c.high >= cs[i - 1].high && c.high >= cs[i - 2].high && c.high >= cs[i + 1].high && c.high >= cs[i + 2].high) H.push([c.high, i]); if (c.low <= cs[i - 1].low && c.low <= cs[i - 2].low && c.low <= cs[i + 1].low && c.low <= cs[i + 2].low) L.push([c.low, i]); }
  const grp = (A, up) => { const out = []; A.forEach(([p, i]) => { const g = out.find((q) => Math.abs(q.p - p) <= tol); if (g) { g.n++; g.p = up ? Math.max(g.p, p) : Math.min(g.p, p); g.last = Math.max(g.last, i); } else out.push({ p, n: 1, last: i }); });
    return out.filter((g) => { if (g.n < 2) return false; for (let k = g.last + 1; k < n; k++) if (up ? cs[k].high > g.p + tol * 0.2 : cs[k].low < g.p - tol * 0.2) return false; return true; }); };
  return { up: grp(H, true), dn: grp(L, false) };
}
function moneyModel() {
  const cs = S.data.candles, n = cs.length; if (n < 30) return null; const f = NF(), key = S.sym + S.tf + cs[n - 1].time + ":" + n + ":" + (f ? f.ver() : ""); if (S._mm && S._mm.key === key) return S._mm;
  const em = exModel(), lm = liqModel(), sn = f ? f.snap(S.sym) : null, off = pxOff(), NB = em.NB, a0 = em.a0, st = em.st, px = cs[n - 1].close, at = (p) => Math.floor((p - a0) / st), ab = (p) => at(p + off), pb = at(px);
  const bid = new Float64Array(NB), ask = new Float64Array(NB), lqL = new Float64Array(NB), lqS = new Float64Array(NB), pool = new Float64Array(NB);
  const closed = !!(S.tk && S.tk.watch && S.tk.watch[S.sym] && S.tk.watch[S.sym].closed), book = !!(sn && !closed && Date.now() / 1000 - sn.t < 60); if (book) { sn.bids.forEach(([p, u]) => { const b = ab(p); if (b >= 0 && b < NB) bid[b] += u; }); sn.asks.forEach(([p, u]) => { const b = ab(p); if (b >= 0 && b < NB) ask[b] += u; }); }
  for (let b = 0; b < lm.NB; b++) { const k = at(lm.a0 + (b + 0.5) * lm.st); if (k >= 0 && k < NB) { lqL[k] += lm.Lg[b]; lqS[k] += lm.Sh[b]; } }
  const sp = stopPools(cs); [...sp.up, ...sp.dn].forEach((g) => { const k = at(g.p); if (k >= 0 && k < NB) pool[k] += g.n; });
  const mx = (A) => { let m = 0; for (let i = 0; i < NB; i++) m = Math.max(m, A[i]); return m || 1; }, mB = Math.max(mx(bid), mx(ask)), mL = Math.max(mx(lqL), mx(lqS)), mP = mx(pool), mV = mx(em.rowV);
  const comb = new Float64Array(NB); for (let b = 0; b < NB; b++) comb[b] = (book ? 0.42 * (bid[b] + ask[b]) / mB : 0) + (book ? 0.33 : 0.6) * (lqL[b] + lqS[b]) / mL + 0.25 * pool[b] / mP;
  let up = 0, dn = 0, bu = 0, bd = 0, lu = 0, ld = 0; for (let b = 0; b < NB; b++) { if (b > pb) { up += comb[b]; bu += ask[b] + bid[b]; lu += lqS[b] + lqL[b]; } else if (b < pb) { dn += comb[b]; bd += bid[b] + ask[b]; ld += lqL[b] + lqS[b]; } }
  const best = (lo, hi) => { let bi = -1; for (let b = Math.max(0, lo); b <= Math.min(NB - 1, hi); b++) if (bi < 0 || comb[b] > comb[bi]) bi = b; return bi >= 0 && comb[bi] > 0.05 ? { p: a0 + (bi + 0.5) * st, v: comb[bi], b: bi } : null; };
  let poc = 0; for (let b = 1; b < NB; b++) if (em.rowV[b] > em.rowV[poc]) poc = b; let bz = -1, sz = -1, bzv = 0, szv = 0; for (let b = 0; b < NB; b++) { if (em.rowV[b] < mV * 0.35) continue; const sh = em.rowBuy[b] / (em.rowV[b] || 1); if (sh > 0.5 && em.rowV[b] * (sh - 0.5) > bzv) { bzv = em.rowV[b] * (sh - 0.5); bz = b; } if (sh < 0.5 && em.rowV[b] * (0.5 - sh) > szv) { szv = em.rowV[b] * (0.5 - sh); sz = b; } }
  return (S._mm = { key, NB, a0, st, px, pb, bid, ask, lqL, lqS, pool, comb, book, mB, mL, up, dn, upPct: up + dn ? up / (up + dn) : 0.5, bu, bd, lu, ld, sp, magUp: best(pb + 1, NB - 1), magDn: best(0, pb - 1), poc: a0 + (poc + 0.5) * st, bz: bz >= 0 ? a0 + (bz + 0.5) * st : null, sz: sz >= 0 ? a0 + (sz + 0.5) * st : null });
}
/* Likidite ayarları (kartın ⚙ düğmesi): grafikte neyin çizileceği */
const MC_DEF = { book: true, liq: false, pools: 2, plab: true, mag: true, poc: false, width: 22, alpha: 80 };
function mcCfg() { if (!S._mc) { try { S._mc = Object.assign({}, MC_DEF, JSON.parse(localStorage.getItem("nera_mc_cfg") || "{}")); } catch (e) { S._mc = Object.assign({}, MC_DEF); } } return S._mc; }
function drawMoney(ctx, X, Y, W, H, txt) {
  const m = moneyModel(); if (!m) return; const cf = mcCfg(), bw = W * cf.width / 100, by = (b) => [Y(m.a0 + (b + 1) * m.st), Y(m.a0 + b * m.st)];
  ctx.save(); ctx.globalAlpha = cf.alpha / 100;
  if (cf.book || cf.liq) for (let b = 0; b < m.NB; b++) { const [y0, y1] = by(b); if (y0 == null || y1 == null) continue; const hgt = Math.max(1.2, y1 - y0 - 0.6), above = b > m.pb;
    const ob = cf.book && m.book ? (above ? m.ask[b] : m.bid[b]) / m.mB : 0, lq = cf.liq ? (above ? m.lqS[b] : m.lqL[b]) / m.mL : 0;
    if (ob > 0.04) { const w = bw * Math.sqrt(ob); ctx.fillStyle = above ? `rgba(47,140,255,${0.18 + 0.55 * ob})` : `rgba(242,70,90,${0.18 + 0.55 * ob})`; ctx.fillRect(W - w, y0, w, hgt); }
    if (lq > 0.06) { const w = bw * 0.75 * Math.sqrt(lq); ctx.fillStyle = above ? `rgba(124,196,255,${0.15 + 0.5 * lq})` : `rgba(255,128,140,${0.15 + 0.5 * lq})`; ctx.fillRect(W - (cf.book ? bw + 4 : 0) - w, y0 + hgt * 0.2, w, Math.max(1, hgt * 0.6)); } }
  const pl = (g, up) => { const y = Y(g.p); if (y == null) return; ctx.strokeStyle = up ? "rgba(255,210,122,.85)" : "rgba(255,210,122,.85)"; ctx.setLineDash([2, 4]); ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo(0, y + 0.5); ctx.lineTo(W - bw - 8, y + 0.5); ctx.stroke(); ctx.setLineDash([]); ctx.lineWidth = 1; if (cf.plab) txt(`Stop havuzu ${up ? "▲" : "▼"} ${g.n} eşit ${up ? "tepe" : "dip"} · ${fp(g.p)}`, 8, y - 4, "rgba(255,210,122,.95)", 10, "left", true); };
  if (cf.pools > 0) { const near = (A) => A.slice().sort((a, b) => Math.abs(a.p - m.px) - Math.abs(b.p - m.px)).slice(0, cf.pools); near(m.sp.up).forEach((g) => pl(g, true)); near(m.sp.dn).forEach((g) => pl(g, false)); }
  const mag = (g, up) => { if (!g) return; const y = Y(g.p); if (y == null) return; const pulse = 0.55 + 0.45 * Math.sin(Date.now() / 350), col = up ? "47,140,255" : "242,70,90"; const gr = ctx.createLinearGradient(0, 0, W, 0); gr.addColorStop(0, `rgba(${col},0)`); gr.addColorStop(1, `rgba(${col},${0.22 * pulse})`); ctx.fillStyle = gr; ctx.fillRect(0, y - 5, W, 10);
    ctx.strokeStyle = `rgba(${col},.95)`; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(W * 0.25, y + 0.5); ctx.lineTo(W, y + 0.5); ctx.stroke(); ctx.lineWidth = 1; txt(`🧲 ${up ? "Yukarı" : "Aşağı"} mıknatıs ${fp(g.p)} (${up ? "+" : ""}${(((g.p - m.px) / m.px) * 100).toFixed(2)}%)`, W - bw - 10, y + (up ? -7 : 14), `rgb(${col})`, 11, "right", true); };
  if (cf.mag) { mag(m.magUp, true); mag(m.magDn, false); }
  if (cf.poc) { const yp = Y(m.poc); if (yp != null) txt("◆ en çok işlem (POC) " + fp(m.poc), W - bw - 10, yp + 3, "rgba(255,210,122,.75)", 9, "right"); }
  ctx.restore();
  moneyCard(m);
}
function mcSet(box) {
  const cf = mcCfg(), ck = (k, t) => `<label class="mc-ck"><input type="checkbox" data-k="${k}" ${cf[k] ? "checked" : ""}><i></i>${t}</label>`;
  box.innerHTML = `<div class="mc-st">Grafikte göster</div>${ck("book", "Emir defteri çubukları")}${ck("liq", "Tasfiye çubukları (model)")}${ck("mag", "Mıknatıs çizgileri")}${ck("poc", "POC etiketi")}${ck("plab", "Stop havuzu yazıları")}
    <label class="mc-rg">Stop havuzu çizgisi (her yönde) <b>${cf.pools}</b><input type="range" min="0" max="5" step="1" data-k="pools" value="${cf.pools}"></label>
    <label class="mc-rg">Çubuk genişliği <b>%${cf.width}</b><input type="range" min="8" max="40" step="1" data-k="width" value="${cf.width}"></label>
    <label class="mc-rg">Görünürlük <b>%${cf.alpha}</b><input type="range" min="20" max="100" step="5" data-k="alpha" value="${cf.alpha}"></label>
    <div class="mc-bt"><button data-a="clean">Diğer seviye çizgilerini kapat</button><button data-a="def">Varsayılan</button></div>`;
  const save = () => { try { localStorage.setItem("nera_mc_cfg", JSON.stringify(cf)); } catch (e) { /* */ } drawOverlay(); };
  box.querySelectorAll("input").forEach((i) => (i.oninput = () => { const k = i.dataset.k; cf[k] = i.type === "checkbox" ? i.checked : +i.value; if (i.type === "range") i.parentNode.querySelector("b").textContent = k === "pools" ? i.value : "%" + i.value; save(); }));
  box.querySelector('[data-a="def"]').onclick = () => { Object.keys(cf).forEach((k) => delete cf[k]); Object.assign(cf, MC_DEF); save(); mcSet(box); };
  box.querySelector('[data-a="clean"]').onclick = (e) => { ["liq", "vp", "sr", "fib", "pdz"].forEach((k) => (S.opts[k] = false)); localStorage.setItem("opts", JSON.stringify(S.opts)); $$('#ind-menu input[data-k]').forEach((i) => (i.checked = !!S.opts[i.dataset.k])); e.target.textContent = "Kapatıldı (Göstergeler'den açılır)"; drawOverlay(); };
}
function moneyCard(m) {
  let el = document.getElementById("money-card"); if (!m) { if (el) el.remove(); return; } const wrap = document.getElementById("chart-wrap"); if (!wrap) return;
  if (!el) { el = document.createElement("div"); el.id = "money-card"; el.innerHTML = `<div class="mc-h"><b>Para nerede?</b><span><button class="mc-cog" title="ayarlar">⚙</button><button class="mc-x" title="küçült">–</button></span></div><div class="mc-set"></div><div class="mc-g"><span class="mc-up"></span><span class="mc-dn"></span><i class="mc-px"></i></div><div class="mc-l"><b class="mc-ut"></b><b class="mc-dt"></b></div><div class="mc-rows"></div><div class="mc-n">Gerçek: emir defteri, işlem akışı, balina ve tasfiye olayları (Binance vadeli). Model: tasfiye seviyeleri (açık pozisyonlar kimseye görünmez). Sinyali etkilemez; sinyal testi yararını ölçer.</div>`; wrap.appendChild(el); el.querySelector(".mc-x").onclick = () => { el.classList.toggle("mini"); localStorage.setItem("nera_mc_mini", el.classList.contains("mini") ? "1" : "0"); }; const mm = localStorage.getItem("nera_mc_mini"); if (mm === "1" || (mm == null && wrap.clientWidth < 760)) el.classList.add("mini"); el.querySelector(".mc-cog").onclick = () => { el.classList.toggle("set"); if (el.classList.contains("set")) mcSet(el.querySelector(".mc-set")); }; }
  const now = Date.now(); if (el._t && now - el._t < 900) return; el._t = now;
  const sk = S.sym + S.tf; if (el._sym !== sk) { el._sym = sk; el._sm = null; el._s = null; }
  el._sm = el._sm == null ? m.upPct : el._sm * 0.85 + m.upPct * 0.15; const up = Math.round(el._sm * 100);
  if (el._up !== up) { el._up = up; el.querySelector(".mc-up").style.width = up + "%"; el.querySelector(".mc-dn").style.width = 100 - up + "%"; el.querySelector(".mc-ut").textContent = `▲ Yukarıda %${up}`; el.querySelector(".mc-dt").textContent = `▼ Aşağıda %${100 - up}`; }
  const side = up >= 57 || (el._s === "bull" && up > 53) ? "bull" : up <= 43 || (el._s === "bear" && up < 47) ? "bear" : ""; if (el._s !== side) { el._s = side; el.classList.toggle("bull", side === "bull"); el.classList.toggle("bear", side === "bear"); }
  const rel = (a, b) => (a + b ? Math.round((a / (a + b)) * 100) : 50), dir = side === "bull" ? "Yukarıda daha çok para birikmiş: fiyat yukarı çekilebilir" : side === "bear" ? "Aşağıda daha çok para birikmiş: fiyat aşağı çekilebilir" : "Likidite iki tarafta dengeli";
  const rows = [m.book ? ["Emir defteri", `yukarı satış ${usdS(m.bu)} · aşağı alış ${usdS(m.bd)}`] : ["Emir defteri", S.sym === "EURUSD" ? "EUR/USD'de emir defteri yayınlanmıyor" : S.tk && S.tk.watch && S.tk.watch[S.sym] && S.tk.watch[S.sym].closed ? "piyasa kapalı: emir defteri okunmuyor" : "okunuyor…"], ["Tasfiye (tahmini)", `shortlar yukarıda %${rel(m.lu, m.ld)} · longlar aşağıda %${rel(m.ld, m.lu)}`], ["Stop havuzu", `yukarıda ${m.sp.up.length} · aşağıda ${m.sp.dn.length} (eşit tepe/dip)`],
    ["En çok işlem", `${fp(m.poc)}${m.bz ? ` · alıcı bölgesi ${fp(m.bz)}` : ""}${m.sz ? ` · satıcı bölgesi ${fp(m.sz)}` : ""}`], ["Mıknatıs", `${m.magUp ? "▲ " + fp(m.magUp.p) : "—"}  ${m.magDn ? "▼ " + fp(m.magDn.p) : ""}`], ["Sonuç", dir]];
  const f = NF(), fs = f ? f.sum(S.sym, 3600) : null;
  if (fs && fs.mins) { const d = fs.B - fs.S, px = m.px; rows.splice(1, 0, ["Gerçek akış (1 sa)", `alış ${usdS(fs.B * px)} · satış ${usdS(fs.S * px)} · net <b class="${cls(d)}">${d >= 0 ? "+" : "−"}${usdS(Math.abs(d) * px)}</b>${fs.cover < 0.9 ? ` (kayıt ${fs.mins} dk)` : ""}`], ["Balina / tasfiye (1 sa)", `balina alış ${usdS(fs.wb)} · satış ${usdS(fs.ws)} · long tasfiye ${usdS(fs.longLiq)} · short ${usdS(fs.shortLiq)}`]); }
  const ob = obsStats(); rows.push(["Sinyal testi", ob.txt]);
  const r = el.querySelector(".mc-rows"), keys = rows.map((x) => x[0]).join("|");
  if (r._k !== keys) { r._k = keys; r.innerHTML = rows.map(([k]) => `<div><span>${k}</span><em></em></div>`).join(""); r.classList.remove("on"); setTimeout(() => r.classList.add("on"), 450); }
  const ems = r.querySelectorAll("em"); rows.forEach(([, v], i) => { if (ems[i] && ems[i]._v !== v) { ems[i]._v = v; ems[i].innerHTML = v; } });
}
function drawMaps(ctx, o, X, Y, W, H, txt) {
  const cs = S.data.candles, stp = cs.length > 1 ? cs[1].time - cs[0].time : 900, snap = (t) => Math.floor(t / stp) * stp, f = NF(), off = pxOff(), t0 = cs[0].time;
  const wh = f ? { big: f.big(S.sym).filter((e) => e.t >= t0), liq: f.liq(S.sym).filter((e) => e.t >= t0) } : (S.wh && S.wh[S.sym]) || { big: [], liq: [] };
  if (o.liqmap) {
    const m = liqModel(), bw = W * 0.34, draw = (A, rgb) => { for (let b = 0; b < m.NB; b++) { const v = A[b] / m.mx; if (v < 0.05) continue; const y0 = Y(m.a0 + (b + 1) * m.st), y1 = Y(m.a0 + b * m.st); if (y0 == null || y1 == null) continue; ctx.fillStyle = `rgba(${rgb},${0.12 + 0.6 * v})`; const w = bw * Math.sqrt(v); ctx.fillRect(W - w, y0, w, Math.max(1.5, y1 - y0 - 0.5)); } };
    draw(m.Lg, "255,112,67"); draw(m.Sh, "38,198,160");
    if (m.pl != null) { const y = Y(m.pl); if (y != null) txt("Long tasfiye yoğunluğu " + fp(m.pl), W - bw - 6, y + 3, "rgba(255,138,101,.95)", 10, "right"); }
    if (m.ps != null) { const y = Y(m.ps); if (y != null) txt("Short tasfiye yoğunluğu " + fp(m.ps), W - bw - 6, y + 3, "rgba(77,208,196,.95)", 10, "right"); }
    wh.liq.forEach((e) => { const x = X(snap(e.t)), y = Y(e.p + off); if (y == null || x < -20 || x > W + 20) return; const r = Math.min(15, 3 + Math.sqrt(e.usd / 15000)), c = e.side < 0 ? "255,112,67" : "38,198,160"; ctx.fillStyle = `rgba(${c},.35)`; ctx.strokeStyle = `rgba(${c},.95)`; ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill(); ctx.stroke(); if (r > 8) txt(usdS(e.usd), x, y - r - 3, `rgb(${c})`, 9, "center"); });
    txt("Çubuklar = MODEL (açık pozisyonlar görünmez; hacim × kaldıraç) · daireler = GERÇEK tasfiyeler (Binance)", 6, H - 24, "rgba(180,188,205,.6)", 9);
  }
  if (o.whales) {
    const thr = f ? f.thr(S.sym) : 25000; let nb = 0, ns = 0, ub = 0, us = 0;
    wh.big.forEach((e) => { if (e.side > 0) { nb++; ub += e.usd; } else { ns++; us += e.usd; } const x = X(snap(e.t)) + (((e.t % stp) / stp) - 0.5) * 6, y = Y(e.p + off); if (y == null || x < -20 || x > W + 20) return; const k = Math.sqrt(e.usd / thr), r = Math.min(22, 3 + k * 4), c = e.side > 0 ? "38,198,160" : "242,54,69"; ctx.strokeStyle = `rgba(${c},1)`; ctx.fillStyle = `rgba(${c},${Math.min(0.55, 0.18 + k * 0.06)})`; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill(); ctx.stroke(); ctx.lineWidth = 1; if (r > 13) txt(usdS(e.usd), x, y - r - 3, `rgb(${c})`, 9, "center", true); });
    const net = ub - us; txt(`Balina (gerçek, tek işlem ≥ ${usdS(thr)}): net ${net >= 0 ? "+" : "−"}${usdS(Math.abs(net))} · alım ${nb} · satım ${ns}${f && f.since(S.sym) ? ` · kayıt ${dtm(f.since(S.sym))}'den beri` : ""}`, 6, H - 10, net >= 0 ? "#26a69a" : "#ef5350", 10, "left", true);
  }
  if (o.pulse2) {
    const P = pulseModel().out; let prev = null, last = null;
    P.forEach((p) => { const x = X(p.t); if (prev != null && x >= -4 && x <= W + 4) { const a = Math.min(1, Math.abs(p.v) / 70); ctx.fillStyle = p.v >= 0 ? `rgba(8,153,129,${0.15 + 0.7 * a})` : `rgba(242,54,69,${0.15 + 0.7 * a})`; ctx.fillRect(prev, 3, Math.max(1, x - prev + 1), 5); } prev = x; last = p;
      if (p.x) { const cd = cs.find((c) => c.time === p.t); if (!cd) return; const y = Y(p.x > 0 ? cd.low : cd.high); if (y == null) return; ctx.fillStyle = p.x > 0 ? TV.up : TV.down; ctx.beginPath(); if (p.x > 0) { ctx.moveTo(x, y + 6); ctx.lineTo(x - 5, y + 15); ctx.lineTo(x + 5, y + 15); } else { ctx.moveTo(x, y - 6); ctx.lineTo(x - 5, y - 15); ctx.lineTo(x + 5, y - 15); } ctx.closePath(); ctx.fill(); } });
    if (last) { const v = last.v; txt(`PULSE v2β ${v >= 0 ? "+" : ""}${v.toFixed(0)} · ${v > 50 ? "güçlü yukarı" : v > 25 ? "yukarı" : v < -50 ? "güçlü aşağı" : v < -25 ? "aşağı" : "nötr"}`, 6, 22, v > 25 ? "#26a69a" : v < -25 ? "#ef5350" : TV.muted, 10, "left", true); }
  }
}
/* ---------- ayak izi (footprint): mum içinde fiyat satırı başına gerçek taker satış × alış ---------- */
function drawFp(ctx, X, Y, W, H, txt) {
  const m = flowModel(); if (!m) { txt(S.sym === "EURUSD" ? "Ayak izi: EUR/USD'de gerçek işlem verisi yok" : "Ayak izi: akış bağlanıyor…", 6, 36, "rgba(255,210,122,.9)", 10, "left", true); return; }
  const cs = S.data.candles, bs = Math.abs(X(cs[cs.length - 1].time) - X(cs[cs.length - 2].time)); if (bs < 30) { txt("Ayak izi: satırları görmek için grafiği yakınlaştır (tekerlek / iki parmak)", 6, 36, "rgba(255,210,122,.95)", 11, "left", true); return; }
  const cw = Math.min(bs * 0.92, 160), R = m.R, ya0 = Y(R + m.off), yb0 = Y(m.off); if (ya0 == null || yb0 == null) return;
  const rowPx = Math.max(0.01, Math.abs(yb0 - ya0)), g = Math.max(1, Math.ceil(12 / rowPx)), cellPx = rowPx * g, fs = Math.max(7, Math.min(10, cellPx - 3)), showT = cw >= 56 && cellPx >= 9;
  m.bk.forEach((b, bt) => {
    const xc = X(bt); if (xc < -cw || xc > W + cw) return;
    const rows = new Map(); b.r.forEach((c, k) => { const gk = Math.floor(k / g), o = rows.get(gk) || [0, 0]; o[0] += c[0]; o[1] += c[1]; rows.set(gk, o); });
    let mx = 0, poc = null, ybot = -1, ytop = 1e9; rows.forEach((o, gk) => { if (o[0] + o[1] > mx) { mx = o[0] + o[1]; poc = gk; } }); if (!mx) return;
    rows.forEach((o, gk) => {
      const ya = Y(((gk + 1) * g - 0.5) * R + m.off), yb = Y((gk * g - 0.5) * R + m.off); if (ya == null || yb == null) return; const h = Math.max(1, yb - ya - 1), v = o[0] + o[1], a = 0.1 + 0.55 * Math.sqrt(v / mx);
      ybot = Math.max(ybot, yb); ytop = Math.min(ytop, ya);
      const lo = rows.get(gk - 1), up = rows.get(gk + 1), bi = o[0] > mx * 0.08 && o[0] >= 3 * ((lo && lo[1]) || 0), si = o[1] > mx * 0.08 && o[1] >= 3 * ((up && up[0]) || 0);
      ctx.fillStyle = `rgba(242,54,69,${(a * (0.35 + 0.65 * o[1] / v)).toFixed(3)})`; ctx.fillRect(xc - cw / 2, ya, cw / 2 - 0.5, h);
      ctx.fillStyle = `rgba(8,153,129,${(a * (0.35 + 0.65 * o[0] / v)).toFixed(3)})`; ctx.fillRect(xc + 0.5, ya, cw / 2 - 0.5, h);
      if (gk === poc) { ctx.strokeStyle = "#fdd835"; ctx.lineWidth = 1.2; ctx.strokeRect(xc - cw / 2 + 0.5, ya + 0.5, cw - 1, h); ctx.lineWidth = 1; }
      if (showT) { txt(num(o[1]), xc - 3, ya + h / 2 + fs * 0.35, si ? "#ff7b88" : "#e8eaed", fs, "right", si); txt(num(o[0]), xc + 3, ya + h / 2 + fs * 0.35, bi ? "#3df0b4" : "#e8eaed", fs, "left", bi); }
    });
    if (!b.live && ybot > 0) { ctx.strokeStyle = "rgba(180,188,205,.35)"; ctx.setLineDash([2, 3]); ctx.strokeRect(xc - cw / 2, ytop, cw, ybot - ytop); ctx.setLineDash([]); }
    const d = b.B - b.S; if (ybot > 0) txt(`Δ ${d >= 0 ? "+" : ""}${num(d)}${b.live ? "" : " ≈"}`, xc, ybot + 11, d >= 0 ? TV.up : TV.down, 9, "center", true);
  });
  txt("Ayak izi (gerçek taker işlemleri): sol satış × sağ alış · sarı = mumun POC'u · parlak = 3× dengesizlik · ≈ = o mum kaydedilmedi, Binance dakika hacmi satırlara eşit yayıldı", 6, 36, "rgba(180,188,205,.75)", 9);
}
/* ---------- sinyal testi: akış/likidite sinyale yarıyor mu? ----------
   Her yeni Nera sinyalinde o anki gerçek akış (1 sa net taker alış), giriş fiyatının ±%0,5'indeki emir defteri dengesizliği ve balina net akışı kaydedilir.
   Sinyal sonuçlanınca akışla UYUMLU ve TERS sinyallerin sonuçları ayrı karşılaştırılır. Fark kanıtlanana kadar sinyale karışmaz. */
function obsLoad() { try { return JSON.parse(localStorage.getItem("nera_flow_obs") || "{}"); } catch (e) { return {}; } }
function obsSigs() {
  const f = window.NeraFlow; if (!f || !S.sigs) return; const O = obsLoad(), now = Date.now() / 1000; let ch = false;
  S.sigs.forEach((x) => {
    const o = O[x.id];
    if (!o) {
      if (x.status !== "açık" || now - x.ts > 900 || !f.has(x.sym)) return; const s1 = f.sum(x.sym, 3600); if (!s1 || s1.cover < 0.5) return;
      const sn = f.snap(x.sym); let ib = 0; if (sn && now - sn.t < 120) { let b = 0, a = 0; const lim = x.entry * 0.005; sn.bids.forEach(([p, u]) => { if (x.entry - p <= lim) b += u; }); sn.asks.forEach(([p, u]) => { if (p - x.entry <= lim) a += u; }); ib = (b - a) / ((a + b) || 1); }
      const cvd = (s1.B - s1.S) / ((s1.B + s1.S) || 1), wh = (s1.wb - s1.ws) / ((s1.wb + s1.ws) || 1), sc = 0.5 * Math.sign(cvd) * Math.min(1, Math.abs(cvd) * 5) + 0.3 * ib + 0.2 * wh;
      O[x.id] = { s: x.sym, side: x.side, sc: +sc.toFixed(3), t: x.ts }; ch = true;
    } else if (o.r == null && x.status !== "açık" && x.net_r != null) { o.r = x.net_r; ch = true; }
  });
  if (!ch) return; const ks = Object.keys(O); if (ks.length > 400) ks.sort((a, b) => O[a].t - O[b].t).slice(0, ks.length - 400).forEach((id) => delete O[id]);
  try { localStorage.setItem("nera_flow_obs", JSON.stringify(O)); } catch (e) { /* dolu */ }
}
function obsStats() {
  const O = obsLoad(), A = [], T = []; let pend = 0;
  Object.values(O).forEach((o) => { if (o.r == null) { pend++; return; } const k = o.side * o.sc; if (k > 0.05) A.push(o.r); else if (k < -0.05) T.push(o.r); });
  const st = (G) => (G.length ? `${G.length} · kazanan %${Math.round((G.filter((r) => r > 0).length / G.length) * 100)} · ort ${(G.reduce((s, r) => s + r, 0) / G.length).toFixed(2)}R` : "0");
  const n = A.length + T.length, p = pend ? ` · ${pend} açık` : "";
  return { A, T, txt: n < 20 ? `ölçülüyor: ${n}/20 sonuçlanan${p}${n ? ` · akışla uyumlu ${st(A)} · ters ${st(T)}` : ""}` : `akışla uyumlu ${st(A)} · ters ${st(T)}${A.length >= 15 && T.length >= 15 ? "" : " (örnek küçük)"}${p}` };
}
function currentPlan() {
  const ev = S.ana && S.ana.eval;
  if (ev && ev.state !== "BEKLE" && ev.plan) return Object.assign({}, ev.plan, { t: S.candleLast ? S.candleLast.time : ev.t, live: true, setup: ev.setup });
  const open = S.sigs.find((x) => x.sym === S.sym && x.tf === S.tf && x.status === "açık");
  if (open) return { side: open.side, entry: open.entry, stop: open.stop, tp1: open.tp1, tp2: open.tp2, risk: open.risk, r1: open.r1, r2: open.r2, t: open.ts, live: false, setup: open.setup };
  return null;
}
function drawPlan(ctx, p, X, Y, W, band, hline, txt) {
  const x0 = X(p.t), x1 = Math.min(W - 4, x0 + Math.max(160, W * 0.28)), yE = Y(p.entry), yS = Y(p.stop), y1 = Y(p.tp1), y2 = Y(p.tp2);
  if (yE == null || yS == null || y1 == null) return;
  const g = p.side === 1;
  band(x0, x1, yE, y2 == null ? y1 : y2, UPA(.07)); band(x0, x1, yE, y1, UPA(.22)); band(x0, x1, yE, yS, DNA(.22));
  [[p.entry, "#d1d4dc", []], [p.stop, TV.down, [5, 3]], [p.tp1, TV.up, [5, 3]], [p.tp2, UPA(.7), [2, 4]]].forEach(([v, c, d]) => hline(v, x0, W, c, d, 1.5));
  const lab = (y, s, c) => { ctx.font = "700 11px Trebuchet MS, Segoe UI"; const w = ctx.measureText(s).width + 10; ctx.fillStyle = c; ctx.fillRect(x1 - w, y - 8, w, 16); txt(s, x1 - w + 5, y + 4, "#fff", 11, "left", true); };
  lab(yS, `Stop −${dist(p.risk)}`, DNA(.95)); lab(y1, `Hedef 1 +${dist(Math.abs(p.tp1 - p.entry))} · ${p.r1.toFixed(1)}R`, UPA(.95));
  if (y2 != null) lab(y2, `Hedef 2 +${dist(Math.abs(p.tp2 - p.entry))} · ${p.r2.toFixed(1)}R`, UPA(.7));
  lab(yE, `${g ? "LONG" : "SHORT"} ${p.live ? "(canlı)" : ""} giriş ${fp(p.entry)}`, g ? UPA(.95) : DNA(.95));
}

/* ---------- açıklamalar / sağ panel ---------- */
function legend(p) {
  const c = p && p.seriesData ? p.seriesData.get(C.ser.candle) : null; const lc = c || (S.candleLast && { open: S.candleLast.open, high: S.candleLast.high, low: S.candleLast.low, close: S.candleLast.close });
  if (!lc) return;
  const a = S.ana && S.ana.eval;
  $("#legend").innerHTML = `<b>${NAMES[S.sym]}</b> · ${TF_LABEL[S.tf]} <span>A <b class="${cls(lc.close - lc.open)}">${fp(lc.open)}</b></span><span>Y <b class="${cls(lc.close - lc.open)}">${fp(lc.high)}</b></span><span>D <b class="${cls(lc.close - lc.open)}">${fp(lc.low)}</b></span><span>K <b class="${cls(lc.close - lc.open)}">${fp(lc.close)}</b></span>`
    + (a ? `<span>ADX <b>${a.adx.toFixed(0)}</b></span><span>ATR <b>${fp(a.atr)}</b></span>` : "");
}
const bar = (v, w = 130) => { const x = Math.max(-1, Math.min(1, v)), c = x >= 0 ? TV.up : TV.down; return `<div class="vbar" style="width:${w}px"><b style="background:${c};${x >= 0 ? "left:50%;" : `left:${50 + x * 50}%;`}width:${Math.abs(x) * 50}%"></b></div>`; };
function renderSig() {
  const el = $("#tab-sig"), a = S.ana, ev = a && a.eval;
  if (!ev) { setHtml(el, `<div class="empty">${S.reason || "Analiz hazırlanıyor…"}</div>`); return; }
  const cls2 = ev.state === "LONG" ? "L" : ev.state === "SHORT" ? "S" : "W";
  { const k = S.sym + S.tf; if (S._st && S._st.k === k && S._st.s !== ev.state && ev.state !== "BEKLE") setTimeout(() => { const c = $(".s2"); if (c && window.NeraFx) NeraFx.burstEl(c, ev.state === "LONG" ? TV.up : TV.down, 60, 1.1); }, 120); S._st = { k, s: ev.state }; }
  const risk = ev.agents.find((x) => x.name === "Risk");
  const nA = ev.agents.length, sc = ev.score, word = ev.state === "BEKLE" ? "BEKLE" : ev.state, ico = ev.state === "LONG" ? "M5 14l5-6 3 3 5-7" : ev.state === "SHORT" ? "M5 6l5 6 3-3 5 7" : "M6 12h12";
  let h = `<div class="state"><div class="s2 ${cls2}"><i class="s2-beam"></i>
    <div class="s2-top"><span class="s2-chip"><i></i>Canlı analiz</span><span class="s2-ctx">${NAMES[S.sym]} · ${TF_LABEL[S.tf]}</span></div>
    <div class="s2-main"><span class="s2-ico"><svg viewBox="0 0 24 20" width="26" height="22"><path d="${ico}" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg></span><span class="s2-word">${word}</span></div>
    <div class="s2-mt"><span class="s2-k">Skor</span><span class="s2-v ${sc >= 0 ? "up" : "down"}">${sc >= 0 ? "+" : "−"}${Math.abs(sc).toFixed(2)}</span><span class="s2-sp"></span><span class="s2-k">Fiyat</span><span class="s2-v">${fp(ev.price)}</span></div>
    <div class="mbar"><b style="background:${sc >= 0 ? TV.up : TV.down};${sc >= 0 ? "left:50%" : `left:${50 + sc * 100}%`};width:${Math.abs(sc) * 100}%"></b><i style="left:calc(${50 + sc * 100}% - 1px)"></i></div>
    <div class="s2-ag"><span class="s2-pips">${Array.from({ length: nA }, (_, k) => `<i class="${k < ev.agree ? "on" : ""}"></i>`).join("")}</span><span class="s2-k">${ev.agree}/${nA} ajan uyumlu</span></div></div></div>`;
  if (ev.state === "BEKLE") {
    h += `<div class="box"><h4>Neden işlem yok?</h4><ul class="why">${ev.why_wait.map((x) => `<li>${x}</li>`).join("")}</ul></div>`;
  } else {
    const p = ev.plan, g = p.side === 1;
    const qty = S.sym === "EURUSD" ? `${(p.risk_usd / (p.risk * 10000 * 10)).toFixed(2)} lot` : `${p.qty >= 100 ? p.qty.toFixed(0) : p.qty >= 1 ? p.qty.toFixed(2) : p.qty.toFixed(4)} ${S.sym.replace("USDT", "")}`;
    const lv = [["HEDEF 2", p.tp2, "up"], ["HEDEF 1", p.tp1, "up"], ["GİRİŞ", p.entry, "in"], ["STOP", p.stop, "down"]], hi = Math.max(...lv.map((x) => x[1])), lo = Math.min(...lv.map((x) => x[1])), sp = (hi - lo) || 1;
    const lad = `<div class="lad">${lv.map((x) => `<div class="lr ${x[2]}" style="top:${(((hi - x[1]) / sp) * 100).toFixed(1)}%"><i></i><span class="ln">${x[0]}</span><span class="lp">${fp(x[1])}</span></div>`).join("")}</div>`;
    h += `<div class="box"><h4>${ev.setup} · ${g ? "LONG" : "SHORT"} önerisi</h4>${lad}
      <div class="goal"><div class="stop"><div class="l">STOP</div><div class="v down">−${dist(p.risk)}</div><div class="l">${fp(p.stop)} · %${p.stop_pct.toFixed(2)}</div></div>
      <div class="tgt"><div class="l">HEDEF 1 (${p.tp1_basis})</div><div class="v up">+${dist(Math.abs(p.tp1 - p.entry))}</div><div class="l">${fp(p.tp1)} · ${p.r1.toFixed(1)}R</div></div></div>
      <table class="plan"><tr><td>Giriş (güncel fiyat)</td><td>${fp(p.entry)}</td></tr><tr><td>Hedef 2 (${p.tp2_basis})</td><td class="up">${fp(p.tp2)} · +${dist(Math.abs(p.tp2 - p.entry))} · ${p.r2.toFixed(1)}R</td></tr>
      <tr><td>Stop dayanağı</td><td class="mut" style="font-weight:400">${p.stop_basis} · ${p.stop_atr.toFixed(1)} ATR</td></tr>
      ${p.cost_r != null ? `<tr><td>İşlem maliyeti (XM spreadi)</td><td class="${p.cost_r > 0.15 ? "down" : "mut"}" style="font-weight:400">≈ ${p.cost_r.toFixed(2)}R · ≈ ${(p.cost_r * p.risk_usd).toFixed(2)} $</td></tr>` : ""}
      <tr><td>Risk tutarı <input class="num" id="riskusd" value="${S.risk}"> $</td><td>≈ ${qty}</td></tr></table>
      <div class="mini" style="margin-top:4px">Örnek: ${dist(p.risk)} stop, ${dist(Math.abs(p.tp1 - p.entry))} hedef ⇒ ${p.r1.toFixed(1)} kazanç : 1 kayıp. Pozisyon büyüklüğü, stop çalışırsa tam olarak ${p.risk_usd}$ kaybettirecek şekilde hesaplanır (komisyon/kayma hariç).</div></div>
      <div class="box"><h4>Neden bu işlem?</h4>${ev.reasons.map((r) => `<div><b>${r.icon} ${r.agent}</b><ul class="why">${r.pts.map((x) => `<li>${x}</li>`).join("")}</ul></div>`).join("")}</div>
      <div class="box"><h4>Ne kadar yanılabilir?</h4><div class="big-num"><span class="down">%${(ev.wrong.baseline_loss * 100).toFixed(0)}</span> <span class="mut" style="font-size:12px">stop ihtimali (avantajsız piyasa)</span></div>
      <div class="mini" style="margin:4px 0">${ev.wrong.text}</div>${measured(ev)}<div class="honest">${ev.invalid}</div></div>`;
  }
  if (risk) {
    h += `<div class="box"><h4>Risk <span class="risk-chip rk-${risk.label.split(" ")[0]}">${risk.label}</span> <span class="mut">(${risk.score}/100)</span></h4><ul class="why">${risk.why.map((x) => `<li>${x}</li>`).join("")}</ul>
      <div class="mini">ATR %${risk.atr_pct.toFixed(2)} · yüzdelik ${(risk.atr_pctile * 100).toFixed(0)} · kaldıraç ne olursa olsun stopta kayıp = seçtiğin risk tutarı, ama gap/kayma bunu aşabilir.</div></div>`;
  }
  h += `<div class="honest">Hiçbir strateji/ajan kombinasyonu geçmiş testlerde (2011-2026, çoklu-test düzeltmeli) kanıtlı avantaj göstermedi. Sinyal = bilgi; tavsiye değil. Gerçek para riski senin sorumluluğun.</div>`;
  setHtml(el, h, () => { const ri = $("#riskusd"); if (ri) ri.onchange = async () => { S.risk = parseFloat(ri.value) || 50; await api("/api/settings", { method: "POST", body: JSON.stringify({ risk_usd: S.risk }) }); loadAna(); }; });
}
/** Yerinde (flicker'sız) güncelleme: yeni HTML ile mevcut DOM'u karşılaştırıp sadece değişen metin/özellikleri yamar. Düğümler korunur: animasyon yeniden başlamaz, kaydırma/odak bozulmaz. */
function morph(a, b) {
  const ac = [...a.childNodes], bc = [...b.childNodes];
  for (let i = 0; i < bc.length; i++) {
    const x = ac[i], y = bc[i];
    if (!x) { a.appendChild(y.cloneNode(true)); continue; }
    if (x.nodeType !== y.nodeType || x.nodeName !== y.nodeName) { a.replaceChild(y.cloneNode(true), x); continue; }
    if (x.nodeType === 3 || x.nodeType === 8) { if (x.data !== y.data) x.data = y.data; continue; }
    if (x.nodeType === 1) {
      for (const at of [...x.attributes]) if (!y.hasAttribute(at.name)) x.removeAttribute(at.name);
      for (const at of [...y.attributes]) { if (x.nodeName === "INPUT" && at.name === "value" && document.activeElement === x) continue; if (x.getAttribute(at.name) !== at.value) x.setAttribute(at.name, at.value); }
      if (x.nodeName === "INPUT" && document.activeElement !== x && x.value !== y.getAttribute("value")) x.value = y.getAttribute("value") || "";
      morph(x, y);
    }
  }
  for (let i = ac.length - 1; i >= bc.length; i--) a.removeChild(ac[i]);
}
function setHtml(el, html, after) { if (el._h === html) return; el._h = html; const t = document.createElement("template"); t.innerHTML = html; morph(el, t.content); if (after) after(); }
function measured(ev) {
  const st = ev.wrong.measured, all = S.stats["*"];
  if (st && st.n >= 5) return `<div class="mini">Bu kurulum türünde botun KENDİ ölçümü: ${st.n} sinyal, hedefe ulaşan %${(st.win * 100).toFixed(0)} (%80 aralık ${(st.lo * 100).toFixed(0)}–${(st.hi * 100).toFixed(0)}), ortalama net ${st.avg_r.toFixed(2)}R ${st.n < 30 ? "· <b>örnek küçük, güvenilmez</b>" : ""}</div>`;
  return `<div class="mini">${all ? `Botun toplam ölçümü: ${all.n} sonuçlanmış sinyal, hedefe ulaşan %${(all.win * 100).toFixed(0)}, ort. net ${all.avg_r.toFixed(2)}R. ` : ""}Bu kurulum türü için henüz yeterli ölçüm yok: kazanma oranı BİLİNMİYOR.</div>`;
}
function renderAgents() {
  const el = $("#tab-agents"), ev = S.ana && S.ana.eval; if (!ev) { setHtml(el, '<div class="empty">Hazırlanıyor…</div>'); return; }
  const sc = ev.score, C = 2 * Math.PI * 34, pc = sc > 0.15 ? "up" : sc < -0.15 ? "dn" : "nt";
  let h = `<div class="ag2-hero ${pc}"><svg viewBox="0 0 80 80" class="ag2-ring"><circle cx="40" cy="40" r="34" class="bg"/><circle cx="40" cy="40" r="34" class="fg" stroke-dasharray="${(Math.min(1, Math.abs(sc)) * C * 0.5).toFixed(1)} ${C.toFixed(1)}" transform="rotate(${sc >= 0 ? -90 : -90 - Math.min(1, Math.abs(sc)) * 180} 40 40)"/><text x="40" y="44" text-anchor="middle">${sc >= 0 ? "+" : "−"}${Math.abs(sc).toFixed(2)}</text></svg>
    <div class="ag2-ht"><span class="k">Koordinatör · ağırlıklı skor</span><b>${ev.state}</b><span class="m">|skor| ≥ 0.25 · en az 3 ajan aynı yönde · ADX ≥ 16 · güçlü ters ajan yok · risk vetosu yok${ev.why_wait.length ? " — " + ev.why_wait[0] : ""}</span></div></div><div class="ag2-grid">`;
  ev.agents.forEach((a, i) => {
    if (a.name === "Risk") { h += `<div class="ag2-t risk" style="--i:${i}"><div class="top"><span class="ic">${a.icon}</span><b>Risk yöneticisi</b><span class="risk-chip rk-${a.label.split(" ")[0]}">${a.label}</span></div><ul class="why">${a.why.map((x) => `<li>${x}</li>`).join("")}</ul></div>`; return; }
    const v = a.vote, w = Math.min(1, Math.abs(v)) * 50, sd = v > 0.05 ? "up" : v < -0.05 ? "dn" : "nt";
    h += `<div class="ag2-t ${sd}" style="--i:${i}"><div class="top"><span class="ic">${a.icon}</span><b>${a.name}</b><span class="v">${v >= 0 ? "+" : "−"}${Math.abs(v).toFixed(2)}</span></div><div class="mt"><i style="${v >= 0 ? "left:50%" : `right:50%`};width:${w}%"></i></div><div class="cf"><span>güven</span><em><u style="width:${(a.conf * 100).toFixed(0)}%"></u></em><span>${(a.conf * 100).toFixed(0)}%</span></div><ul class="why">${a.why.map((x) => `<li>${x}</li>`).join("")}</ul></div>`;
  });
  setHtml(el, h + "</div>");
}
function gauge(score, label, s) {
  const a = Math.PI * (1 - (score + 1) / 2), cx = 50, cy = 50, r = 38, x = cx + r * Math.cos(a), y = cy - r * Math.sin(a);
  const txt = score > 0.5 ? "Güçlü Al" : score > 0.15 ? "Al" : score < -0.5 ? "Güçlü Sat" : score < -0.15 ? "Sat" : "Nötr", c = score > 0.15 ? TV.up : score < -0.15 ? TV.down : TV.muted;
  return `<div class="gauge"><svg viewBox="0 0 100 58"><path d="M12 50 A38 38 0 0 1 88 50" fill="none" stroke="#2a2e39" stroke-width="7" stroke-linecap="round"/><path d="M12 50 A38 38 0 0 1 31 17" fill="none" stroke="${TV.down}" stroke-width="7" stroke-linecap="round" opacity=".6"/><path d="M69 17 A38 38 0 0 1 88 50" fill="none" stroke="${TV.up}" stroke-width="7" stroke-linecap="round" opacity=".6"/><line x1="${cx}" y1="${cy}" x2="${x}" y2="${y}" stroke="${c}" stroke-width="3" stroke-linecap="round"/><circle cx="${cx}" cy="${cy}" r="4" fill="${c}"/></svg><div class="gv" style="color:${c}">${txt}</div><div class="gl">${label}</div><div class="gl"><span class="down">${s.sell}</span> · ${s.neutral} · <span class="up">${s.buy}</span></div></div>`;
}
const IR = { shown: 0, prev: {}, e: {} };
function renderInd() {
  const el = $("#tab-ind"), a = S.ana && S.ana.ind; if (!a || !a.ma) { if (!el.querySelector("#ind-ring")) setHtml(el, '<div class="empty">Hazırlanıyor…</div>'); return; }
  if (!el.querySelector("#ind-ring")) { el._h = null; el.innerHTML = '<div class="indhero"><canvas id="ind-ring"></canvas><div class="indc"><b id="ic-b">—</b><span>META ÖZET</span><em id="ic-e"></em></div></div><div class="grpbars" id="ic-g"></div><div class="indgrp" id="ic-body"></div>'; el._ic = 1; }
  const all = a.sum.all, txt = all.score > 0.5 ? "Güçlü Al" : all.score > 0.15 ? "Al" : all.score < -0.5 ? "Güçlü Sat" : all.score < -0.15 ? "Sat" : "Nötr", col = all.score > 0.15 ? "var(--up)" : all.score < -0.15 ? "var(--down)" : "var(--muted)";
  const b = $("#ic-b", el); b.textContent = txt; b.style.color = col; $("#ic-e", el).textContent = `${all.sell} sat · ${all.neutral} nötr · ${all.buy} al`;
  const grp = (n, s) => `<div class="gb"><div class="t">${n}</div><div class="bar3"><i style="flex-grow:${s.sell};background:var(--down)"></i><i style="flex-grow:${s.neutral};background:var(--muted);opacity:.5"></i><i style="flex-grow:${s.buy};background:var(--up)"></i></div><div class="n"><span class="down">${s.sell}</span><span>${s.neutral}</span><span class="up">${s.buy}</span></div></div>`;
  setHtml($("#ic-g", el), grp("OSİLATÖR", a.sum.osc) + grp("META", a.sum.all) + grp("ORT. & TREND", a.sum.ma));
  const row = (r, i) => `<div class="ix ${r.o > 0 ? "b" : r.o < 0 ? "s" : "n"}" style="--i:${i}"><span class="vn">${r.n}</span><span class="vv">${r.v}</span><span class="vp">${r.o > 0 ? "AL" : r.o < 0 ? "SAT" : "NÖTR"}</span></div>`;
  setHtml($("#ic-body", el), `<h4>Hareketli ortalamalar &amp; trend <em>${a.ma.length}</em></h4><div class="ix-g">${a.ma.map(row).join("")}</div><h4>Osilatörler &amp; order flow <em>${a.osc.length}</em></h4><div class="ix-g">${a.osc.map((r, i) => row(r, i + a.ma.length)).join("")}</div>`);
}
TICKS.push((dt, t) => {                                   // konsensüs halkası: her gösterge halka üzerinde bir nöron, merkezde meta özet küresi
  const cv = $("#ind-ring"); if (!cv || !vis(cv) || !S.ana || !S.ana.ind || !S.ana.ind.ma) return; const w = cv.parentElement.clientWidth, h = 210, c = fitCanvas(cv, w, h), a = S.ana.ind, rows = [...a.ma, ...a.osc], sc = a.sum.all.score;
  const cx = w / 2, cy = h / 2, R = Math.min(w, h) * 0.44, up = "#26c6a0", dn = "#f2566a"; IR.shown += (sc - IR.shown) * Math.min(1, dt * 1.4); c.clearRect(0, 0, w, h);
  const bg = c.createRadialGradient(cx, cy, 4, cx, cy, R * 1.5); bg.addColorStop(0, "rgba(138,123,255,.10)"); bg.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = bg; c.fillRect(0, 0, w, h);
  c.lineCap = "round"; c.strokeStyle = "rgba(120,140,200,.18)"; c.lineWidth = 6; c.beginPath(); c.arc(cx, cy, R, 0, 6.3); c.stroke();
  const ang = IR.shown * Math.PI, a0 = -Math.PI / 2, col = sc >= 0 ? up : dn; c.strokeStyle = col; c.shadowColor = col; c.shadowBlur = 12; c.lineWidth = 6; c.beginPath(); c.arc(cx, cy, R, a0, a0 + ang, ang < 0); c.stroke(); c.shadowBlur = 0;
  const hx = cx + Math.cos(a0 + ang) * R, hy = cy + Math.sin(a0 + ang) * R, hg = c.createRadialGradient(hx, hy, 0, hx, hy, 16); hg.addColorStop(0, "rgba(255,255,255,.95)"); hg.addColorStop(0.35, col); hg.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = hg; c.fillRect(hx - 16, hy - 16, 32, 32);
  const N = rows.length, rr = R * 0.7, br = 1 + 0.04 * Math.sin(t * 1.6);
  rows.forEach((r, i) => { const key = r.n, v = r.o > 0 ? 1 : r.o < 0 ? -1 : 0; if (IR.prev[key] !== undefined && IR.prev[key] !== v) IR.e[key] = 1; IR.prev[key] = v; const e = IR.e[key] = (IR.e[key] || 0) * Math.pow(0.15, dt);
    const an = -Math.PI / 2 + (i / N) * 6.2832 + t * 0.07, x = cx + Math.cos(an) * rr * br, y = cy + Math.sin(an) * rr * br, cc = v > 0 ? up : v < 0 ? dn : "#7a8199";
    c.strokeStyle = cc; c.globalAlpha = v ? 0.16 + e * 0.5 : 0.06; c.lineWidth = 1; c.beginPath(); c.moveTo(cx, cy); c.lineTo(x, y); c.stroke(); c.globalAlpha = 1;
    const g = c.createRadialGradient(x, y, 0, x, y, 9 + e * 9); g.addColorStop(0, cc); g.addColorStop(1, "rgba(0,0,0,0)"); c.globalAlpha = v ? 0.55 + e * 0.4 : 0.25; c.fillStyle = g; c.fillRect(x - 18, y - 18, 36, 36); c.globalAlpha = 1; c.fillStyle = v ? "#fff" : cc; c.beginPath(); c.arc(x, y, 2.4 + e * 2, 0, 6.3); c.fill(); });
  const og = c.createRadialGradient(cx, cy, 0, cx, cy, R * 0.5 * br); og.addColorStop(0, sc > 0.15 ? "rgba(38,198,160,.38)" : sc < -0.15 ? "rgba(242,86,106,.38)" : "rgba(138,123,255,.32)"); og.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = og; c.beginPath(); c.arc(cx, cy, R * 0.5 * br, 0, 6.3); c.fill();
});
let AG = null, agSeen = null;
window.AGFIRE = (ev) => {
  const cv = $("#ag-graph canvas"); if (!cv || !ev) return;
  if (!AG) { const ids = ev.agents.map((_, i) => "a" + i), nodes = ids.map((id, i) => ({ id, x: (i + 0.5) / ids.length, y: 0.2, r: 4.5, col: "#8a7bff" })).concat([{ id: "hub", x: 0.5, y: 0.78, r: 8, col: "#ffb04a", label: "koordinatör" }]); AG = new NeuroGraph(cv, nodes, ids.map((i) => [i, "hub"]), { idle: false, curve: 0, labels: true }); }
  if (agSeen === ev) return; agSeen = ev; let k = 0;
  ev.agents.forEach((a, i) => { const col = a.name === "Risk" ? "#ff9800" : a.vote > 0.05 ? "#26c6a0" : a.vote < -0.05 ? "#f2566a" : "#8c96af", n = AG.byId["a" + i]; if (n) { n.label = a.name === "Risk" ? "Risk" : a.name.split(" ")[0].slice(0, 7); setTimeout(() => AG.fire("a" + i, col, 0.4 + Math.abs(a.vote), 0, "hub"), k * 110); k++; } });
  setTimeout(() => AG.fire("hub", ev.score > 0.15 ? "#26c6a0" : ev.score < -0.15 ? "#f2566a" : "#ffb04a", 1, 0), k * 110 + 650);
};
function renderHist() {
  const el = $("#tab-hist"), all = S.stats["*"];
  const sig = S.sigs;
  let h = `<div class="box"><h4>◉ Sinaps geçmişi · Nera sinyalleri (kâğıt üstü ölçüm)</h4>${all ? `<div>Sonuçlanan: <b>${all.n}</b> · hedefe ulaşan <b>%${(all.win * 100).toFixed(0)}</b> (%80 aralık ${(all.lo * 100).toFixed(0)}–${(all.hi * 100).toFixed(0)}) · ort. net <b class="${cls(all.avg_r)}">${all.avg_r.toFixed(2)}R</b> (komisyon dahil)</div>` : '<div class="mini">Henüz sonuçlanmış sinyal yok.</div>'}
    <div class="honest">Ölçüm, sinyalin sonrasını 1 dk mumlarla izler: stop mu hedef mi önce. Örnek küçükken oranlara güvenme.</div></div>`;
  if (!sig.length) h += '<div class="empty">Henüz sinaps (sinyal) yok. Sinyal, taranan aralıklarda (5m/15m/1H/4H) bir mum kapanınca koşullar sağlanırsa gelir.</div>';
  sig.forEach((x) => {
    const g = x.side === 1, stt = x.status === "açık" ? "açık" : x.status;
    const res = x.net_r != null ? `${x.net_r >= 0 ? "+" : ""}${x.net_r.toFixed(2)}R` : "";
    h += `<div class="sg" data-id="${x.id}"><div class="r1"><span class="chip ${g ? "L" : "S"}">${g ? "LONG" : "SHORT"}</span><b>${NAMES[x.sym]} · ${TF_LABEL[x.tf]}</b><span class="st-${stt}">${stt === "TP1" ? "✓ hedef" : stt === "SL" ? "✗ stop" : stt === "açık" ? "● açık" : "⏱ süre"} ${res}</span></div>
      <div class="mini">${dtm(x.ts)} · ${x.setup} · skor ${x.score >= 0 ? "+" : ""}${x.score.toFixed(2)} · risk ${x.risk_label}</div>
      <div class="mini">Giriş ${fp(x.entry, x.sym)} · Stop ${fp(x.stop, x.sym)} (−${dist(x.risk, x.sym)}) · Hedef ${fp(x.tp1, x.sym)} (+${dist(Math.abs(x.tp1 - x.entry), x.sym)}, ${x.r1.toFixed(1)}R)</div>
      <div class="mini">${(x.reasons || []).slice(0, 3).join(" · ")}</div></div>`;
  });
  setHtml(el, h, () => $$(".sg", el).forEach((e) => (e.onclick = () => { const x = S.sigs.find((s) => s.id == e.dataset.id); if (x) { S.sym = x.sym; S.tf = x.tf; localStorage.setItem("sym", x.sym); localStorage.setItem("tf", x.tf); markTop(); reload(true); if (window.MOBILE) window.MOBILE.mTab("chart"); } })));
}
function renderCal() {
  const el = $("#tab-cal"), now = Date.now() / 1000;
  const h = `<div class="box"><h4>Makro takvim (yerel saat)</h4><table class="t">${S.cal.map((e) => { const m = Math.round((e.t - now) / 60), s = m < 0 ? `${-m} dk önce` : m < 60 ? `${m} dk` : m < 1440 ? `${Math.floor(m / 60)} sa ${m % 60} dk` : `${Math.floor(m / 1440)} g ${Math.floor((m % 1440) / 60)} sa`; return `<tr><td>${e.name}</td><td>${new Date(e.t * 1000).toLocaleString("tr-TR", { weekday: "short", day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" })}</td><td class="${m >= 0 && m <= 60 ? "warn" : "mut"}">${s}</td></tr>`; }).join("")}</table>
    <div class="honest">Kaynak: federalreserve.gov (FOMC), bls.gov (CPI, NFP) planlanan tarihleri. Olaydan 20 dk önce ve 10 dk sonra yeni sinyal verilmez; risk skoru yükselir.</div></div>`;
  setHtml(el, h);
}
function renderTabs() { ({ sig: renderSig, agents: renderAgents, ind: renderInd, hist: renderHist, cal: renderCal })[S.tab](); }

/* ---------- order flow şeridi ---------- */
function renderFlow(f) {
  const el = $("#flow-card");
  if (!f) { el.innerHTML = `<div class="card-title">Order flow</div><div class="mini">${S.sym === "EURUSD" ? "EUR/USD spot FX: gerçek order flow verisi yok (delta VEKİL: mum içi konum)." : "Bağlanıyor…"}</div>`; drawFootprint(null); $("#big-card").innerHTML = ""; return; }
  const tot = f.buy5 + f.sell5, bp = tot ? f.buy5 / tot : 0.5, d5 = f.buy5 - f.sell5, d1 = f.cur_buy - f.cur_sell;
  el.innerHTML = `<div class="card-title">Canlı order flow · GERÇEK <small>(taker agresör)</small></div>
    <div class="kv"><span>Son 5 dk alış / satış</span><span><b class="up">${num(f.buy5)}</b> / <b class="down">${num(f.sell5)}</b></span></div><div class="bar"><i style="width:${bp * 100}%"></i></div>
    <div class="kv"><span>Delta 5 dk</span><b class="${cls(d5)}">${d5 >= 0 ? "+" : ""}${num(d5)}</b></div><div class="kv"><span>Delta bu dk</span><b class="${cls(d1)}">${d1 >= 0 ? "+" : ""}${num(d1)}</b></div>
    <div class="kv"><span>CVD (oturum)</span><b class="${cls(f.cvd)}">${f.cvd >= 0 ? "+" : ""}${num(f.cvd)}</b></div>
    <div class="kv"><span>Bid / Ask</span><span>${fp(f.bid)} (${num(f.bidq)}) / ${fp(f.ask)} (${num(f.askq)})</span></div><canvas id="cvdspark" height="34" style="width:100%"></canvas>`;
  const cvs2 = $("#cvdspark"); if (cvs2 && f.cvd_hist.length > 2) { cvs2.width = cvs2.clientWidth * 2; cvs2.height = 68; const c = cvs2.getContext("2d"), v = f.cvd_hist.map((x) => x[1]).concat([f.cvd]), mn = Math.min(...v), mx = Math.max(...v), rg = mx - mn || 1; c.strokeStyle = f.cvd >= v[0] ? TV.up : TV.down; c.lineWidth = 2; c.beginPath(); v.forEach((y, i) => { const px = (i / (v.length - 1)) * cvs2.width, py = 66 - ((y - mn) / rg) * 62; i ? c.lineTo(px, py) : c.moveTo(px, py); }); c.stroke(); }
  drawFootprint(f);
  const row = (x, kind) => `<div class="row"><span class="${x.side > 0 ? "up" : "down"}">${x.side > 0 ? "▲" : "▼"} ${hhmm(x.t)}</span><span>${fp(x.p)}</span><b>${num(x.usd)}$</b></div>`;
  $("#big-card").innerHTML = `<div class="col2"><div class="card-title">Büyük işlemler</div>${f.big.slice(0, 8).map(row).join("") || '<div class="mini">henüz yok</div>'}</div><div class="col2"><div class="card-title">Tasfiyeler</div>${f.liq.slice(0, 8).map((x) => `<div class="row"><span class="${x.side > 0 ? "up" : "down"}">${x.side > 0 ? "kısa" : "uzun"} ${hhmm(x.t)}</span><span>${fp(x.p)}</span><b>${num(x.usd)}$</b></div>`).join("") || '<div class="mini">henüz yok</div>'}</div>`;
}
function drawFootprint(f) {
  const c = $("#fp"), d = Math.min(window.devicePixelRatio || 1, IS_MOB_DPR), w = c.clientWidth, h = c.clientHeight; if (c.width !== Math.round(w * d)) { c.width = Math.round(w * d); c.height = Math.round(h * d); }
  const x = c.getContext("2d"); x.setTransform(d, 0, 0, d, 0, 0); x.clearRect(0, 0, w, h);
  if (!f || !f.fp.length) { x.fillStyle = TV.muted; x.font = "12px Trebuchet MS"; x.fillText(f ? "Veri toplanıyor…" : "—", 8, 18); return; }
  const cols = f.fp.slice(-8), allp = [...new Set(cols.flatMap((m) => m.bins.map((b) => b[0])))].sort((a, b) => b - a);
  const mid = f.price || allp[0]; let rows = allp.sort((a, b) => Math.abs(a - mid) - Math.abs(b - mid)).slice(0, 12).sort((a, b) => b - a);
  if (!rows.length) return;
  const rh = Math.max(12, Math.floor((h - 14) / rows.length)), cw = Math.floor((w - 62) / cols.length), mx = Math.max(...cols.flatMap((m) => m.bins.map((b) => b[1] + b[2]))) || 1;
  x.font = "10px Trebuchet MS"; x.textBaseline = "middle";
  rows.forEach((p, i) => { x.fillStyle = Math.abs(p - mid) < (f.step || 1) * 0.6 ? TV.yellow : TV.muted; x.textAlign = "right"; x.fillText(fp(p), 56, 8 + i * rh + rh / 2); });
  cols.forEach((m, ci) => {
    const bm = new Map(m.bins.map((b) => [b[0], b])); let poc = null, pv = 0; m.bins.forEach((b) => { if (b[1] + b[2] > pv) { pv = b[1] + b[2]; poc = b[0]; } });
    rows.forEach((p, i) => { const b = bm.get(p); const x0 = 62 + ci * cw, y0 = 8 + i * rh; if (!b) return; const lo = bm.get(rows[i + 1]), up = bm.get(rows[i - 1]); const bi = b[1] > 3 * ((lo && lo[2]) || 1e-12) && b[1] > 0, si = b[2] > 3 * ((up && up[1]) || 1e-12) && b[2] > 0;
      const iv = Math.min(1, (b[1] + b[2]) / mx), a = 0.12 + iv * 0.55; x.fillStyle = b[1] >= b[2] ? `rgba(8,153,129,${a})` : `rgba(242,54,69,${a})`; x.fillRect(x0 + 1, y0, cw - 2, rh - 1);
      if (bi || si) { x.strokeStyle = bi ? TV.up : TV.down; x.lineWidth = 1.5; x.strokeRect(x0 + 1.5, y0 + .5, cw - 3, rh - 2); }
      if (p === poc) { x.strokeStyle = TV.yellow; x.lineWidth = 1; x.strokeRect(x0 + .5, y0 - .5, cw - 1, rh); }
      x.fillStyle = "#e8eaed"; x.textAlign = "center"; x.fillText(`${num(b[2])}×${num(b[1])}`, x0 + cw / 2, y0 + rh / 2); });
    x.fillStyle = TV.muted; x.textAlign = "center"; x.fillText(hhmm(m.t), 62 + ci * cw + cw / 2, h - 5);
  });
}

/* ---------- şimşek animasyonu ---------- */
let audio = null;
/** Bildirim sesi: kısa yumuşak "zap" (şimşek çıtırtısı) + üç notalı çan arpeji (LONG yükselen, SHORT alçalan) + hafif alt gürleme + yankı. Sert gürültü yok. */
function bell(ctx, dest, f, t, dur) {
  [[1, 0.5], [2, 0.16], [3.01, 0.06]].forEach(([m, a]) => {
    const o = ctx.createOscillator(), g = ctx.createGain(); o.type = "sine"; o.frequency.value = f * m;
    g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(a, t + 0.008); g.gain.exponentialRampToValueAtTime(0.0008, t + dur);
    o.connect(g); g.connect(dest); o.start(t); o.stop(t + dur + 0.05);
  });
}
function thunder(side = 1) {
  if (window.Sound) { Sound.signal(side); return; }
  try {
    audio = audio || new (window.AudioContext || window.webkitAudioContext)(); const ctx = audio; if (ctx.state === "suspended") ctx.resume();
    const t0 = ctx.currentTime + 0.02, master = ctx.createGain(); master.gain.value = 0.5; master.connect(ctx.destination);
    const dl = ctx.createDelay(0.5), fb = ctx.createGain(), lp = ctx.createBiquadFilter(); dl.delayTime.value = 0.16; fb.gain.value = 0.3; lp.type = "lowpass"; lp.frequency.value = 3000;
    master.connect(dl); dl.connect(lp); lp.connect(fb); fb.connect(dl); lp.connect(ctx.destination);                       // yankı
    const len = Math.floor(ctx.sampleRate * 0.14), nb = ctx.createBuffer(1, len, ctx.sampleRate), d = nb.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 3);
    const ns = ctx.createBufferSource(), bp = ctx.createBiquadFilter(), zg = ctx.createGain(); ns.buffer = nb; bp.type = "bandpass"; bp.Q.value = 0.9; bp.frequency.setValueAtTime(5200, t0); bp.frequency.exponentialRampToValueAtTime(900, t0 + 0.12); zg.gain.value = 0.3;
    ns.connect(bp); bp.connect(zg); zg.connect(master); ns.start(t0);                                                      // zap
    (side < 0 ? [784, 523.25, 392] : [523.25, 659.25, 987.77]).forEach((f, i) => bell(ctx, master, f, t0 + 0.07 + i * 0.11, 0.6));      // arpej
    const sub = ctx.createOscillator(), sg = ctx.createGain(); sub.type = "sine"; sub.frequency.setValueAtTime(110, t0); sub.frequency.exponentialRampToValueAtTime(48, t0 + 0.5);
    sg.gain.setValueAtTime(0, t0); sg.gain.linearRampToValueAtTime(0.26, t0 + 0.03); sg.gain.exponentialRampToValueAtTime(0.001, t0 + 0.55); sub.connect(sg); sg.connect(master); sub.start(t0); sub.stop(t0 + 0.6);   // gürleme
  } catch (e) { /* ses yok */ }
}
/** Uygulama kapalı/askıdayken oluşmuş sinyal: animasyon yok, plan yok (fiyat çoktan değişti), sadece bilgi. */
function missedAlert(e) {
  const t = $("#toast"); t.className = "toast";
  t.innerHTML = `<div class="th">🕓 Kaçırılan sinyal · <span class="${e.side === 1 ? "up" : "down"}">${e.side === 1 ? "LONG ▲" : "SHORT ▼"}</span> · ${e.name} · ${TF_LABEL[e.tf]}</div>
    <div class="tg">Uygulama arka plandayken yaklaşık ${e.ago} dk önce oluştu. Fiyat o günden bu yana değişti: eski plan GEÇERSİZ olabilir, grafiğe bakıp yeniden değerlendir.</div>`;
  t.onclick = () => { t.classList.add("hidden"); S.sym = e.sym; S.tf = e.tf; markTop(); reload(true); setTab("sig"); };
  clearTimeout(t._h); t._h = setTimeout(() => t.classList.add("hidden"), 20000);
}
function lightning(ev) {
  const x = ev.sig, g = x.side === 1; DT.emit("signal", { side: x.side, sym: x.sym });
  const t = $("#toast"); t.className = "toast " + (g ? "L" : "S");
  t.innerHTML = `<div class="th">YENİ SİNYAL · <span class="${g ? "up" : "down"}">${g ? "LONG ▲" : "SHORT ▼"}</span> · ${ev.name} · ${TF_LABEL[x.tf]}</div>
    <div>Giriş <b>${fp(x.entry, x.sym)}</b> · Stop <b class="down">−${dist(x.risk, x.sym)}</b> (${fp(x.stop, x.sym)}) · Hedef <b class="up">+${dist(Math.abs(x.tp1 - x.entry), x.sym)}</b> (${fp(x.tp1, x.sym)}) · ${x.r1.toFixed(1)}R</div>
    <div class="tg">${x.setup} · skor ${x.score >= 0 ? "+" : ""}${x.score.toFixed(2)} · risk ${x.risk_label} · tavsiye değil, kanıtsız</div>`;
  t.onclick = () => { t.classList.add("hidden"); S.sym = x.sym; S.tf = x.tf; markTop(); reload(true); setTab("sig"); };
  clearTimeout(t._h); if (!S.demo) t._h = setTimeout(() => t.classList.add("hidden"), IS_MOBILE() ? 6000 : 9000);
  S.unseen++; badge(); const bb = $("#btn-hist"); bb.classList.remove("pulse"); void bb.offsetWidth; bb.classList.add("pulse");
  if (S.sound) thunder(x.side);
  try { if (navigator.vibrate) navigator.vibrate([180, 90, 180]); } catch (e) { /* desteklenmiyor */ }
  try {                                    // sayfa arka plandaysa (sekme/uygulama açık ama görünmüyor) sistem bildirimi
    if (document.hidden && "Notification" in window && Notification.permission === "granted") {
      const body = `${x.setup} · giriş ${fp(x.entry, x.sym)} · stop −${dist(x.risk, x.sym)} · hedef +${dist(Math.abs(x.tp1 - x.entry), x.sym)}`;
      const title = `${g ? "LONG" : "SHORT"} · ${ev.name} · ${TF_LABEL[x.tf]}`;
      if (navigator.serviceWorker && navigator.serviceWorker.ready) navigator.serviceWorker.ready.then((r) => r.showNotification(title, { body, tag: "dt-" + x.id, vibrate: [200, 100, 200] })).catch(() => new Notification(title, { body }));
      else new Notification(title, { body });
    }
  } catch (e) { /* bildirim izni yok */ }
}

/* ---------- döngüler ---------- */
async function loadAna() {
  const j = await api(`/api/analysis?sym=${S.sym}&tf=${S.tf}`);
  if (!j || !j.ready) { S.reason = j && j.reason ? j.reason : (!j && window.__apiErr ? "Motor hatası: " + window.__apiErr : ""); if (S.tab === "sig") renderSig(); return; }
  S.reason = "";
  if (j.stats) S.stats = j.stats; S.ana = j; S.risk = S.risk;
  const ev = j.event, b = $("#banner");
  if (ev && ev[0] >= -30 && ev[0] <= 120) { b.classList.remove("hidden"); b.textContent = `⚠ ${ev[1]} ${ev[0] >= 0 ? ev[0] + " dk sonra" : -ev[0] + " dk önce"} — oynaklık/spread artabilir, yeni sinyal çekingen verilir`; } else b.classList.add("hidden");
  if (S.tab === "sig" || S.tab === "ind" || S.tab === "agents") renderTabs(); legend(null); DT.emit("ana", j); if (j.eval && window.AGFIRE) AGFIRE(j.eval); { const sy = $("#syn"); if (sy) { sy.classList.remove("ping"); requestAnimationFrame(() => requestAnimationFrame(() => sy.classList.add("ping"))); } }
}
async function loadSigs() { const j = await api("/api/signals"); if (!j) return; S.sigs = j.sigs; S.stats = j.stats; markers(); if (S.tab === "hist") renderHist(); obsSigs(); }
setInterval(() => { if (S.ready || S.data) loadSigs(); }, 120000);
async function tick() {
  const j = await api(`/api/tick?sym=${S.sym}&tf=${S.tf}&since=${S.lastEv}`); if (!j) { $("#status-txt").textContent = "Motor hatası: " + String(window.__apiErr || "?").slice(0, 60); $("#dot").classList.remove("ok"); return; }
  S.tk = j; feedWh(j.flow); DT.emit("tick");
  if (!S.data && S.loadedKey !== "x" && !S._retry) { S._retry = true; reload(false).finally(() => (S._retry = false)); }       // ilk yükleme veri yetersizliğiyle başarısız olduysa yeniden dene
  SYMS.forEach((s) => { const w = j.watch[s]; if (!w) return; { const pe = $("#px-" + s), nt = w.price ? fp(w.price, s) : "—"; if (pe.textContent !== nt) { const up = w.price > (pe._p || 0); pe._p = w.price; pe.textContent = nt; pe.classList.remove("px-up", "px-dn"); void pe.offsetWidth; pe.classList.add(up ? "px-up" : "px-dn"); } } { const st = $(".symtab[data-s=\"" + s + "\"]"); if (st) st.classList.toggle("closed", !!w.closed); } const ch = $("#ch-" + s); ch.textContent = w.chg == null ? "" : (w.chg >= 0 ? "+" : "") + w.chg.toFixed(2) + "%"; ch.className = cls(w.chg);
    { const de = $("#dots-" + s), dh = SCAN.map((t) => `<i class="sdot ${w.states[t] === "LONG" ? "L" : w.states[t] === "SHORT" ? "S" : ""}" title="${TF_LABEL[t]}: ${w.states[t] || "—"}"></i>`).join(""); if (de && de._h !== dh) { de._h = dh; de.innerHTML = dh; } } });
  if (j.candle && S.data) {
    const c = j.candle, lastT = S.data.candles[S.data.candles.length - 1].time;
    if (c.time > lastT) { if (!S._loading) { S._loading = true; await loadChart(false); await loadAna(); S._loading = false; } }
    else { C.ser.candle.update({ time: loc(c.time), open: c.open, high: c.high, low: c.low, close: c.close }); C.ser.vol.update({ time: loc(c.time), value: c.volume, color: c.close >= c.open ? UPA(.35) : DNA(.35) }); S.candleLast = c; }
  }
  if (!IS_MOBILE() || window.__flowOpen) renderFlow(j.flow);          // telefonda akış sekmesi kapalıyken boşuna çizme (akıcılık)
  drawOverlay();
  j.events.forEach((e) => { if (e.missed) missedAlert(e); else lightning(e); S.lastEv = Math.max(S.lastEv, e.id); loadSigs(); });
  S.lastEv = Math.max(S.lastEv, j.last_ev && S.lastEv === 0 ? j.last_ev : S.lastEv);
  const age = j.ws_age; const ok = age != null && age < 20;
  $("#dot").classList.toggle("ok", ok); $("#status-txt").textContent = ok ? "Canlı" : (j.ready < 35 ? `Yükleniyor ${j.ready}/35` : "Akış bekleniyor");
}
async function init() {
  applyTheme0();
  buildTop(); buildMenu(); mk(); applyTheme();
  const showErr = (n, e) => { try { $("#status-txt").textContent = `Hata ${n}: ${String((e && e.message) || e).slice(0, 60)}`; $("#dot").classList.remove("ok"); console.error(n, e); } catch (x) { /* */ } };
  window.addEventListener("unhandledrejection", (ev) => showErr("söz", ev.reason)); window.addEventListener("error", (ev) => showErr("js", ev.error || ev.message));
  const guard = (f, n) => async () => { try { await f(); } catch (e) { showErr(n, e); } };
  setInterval(guard(tick, "tick"), IS_MOBILE() ? 1100 : 700); setInterval(guard(loadAna, "analiz"), IS_MOBILE() ? 3500 : 2500);      // başlatma beklemesinden bağımsız: veri/analiz akışı her durumda başlar
  const st = await api("/api/settings"); if (st) S.risk = st.risk_usd;
  S.cal = (await api("/api/calendar")) || [];
  const first = await api("/api/tick?sym=XAUUSDT&tf=15m&since=0"); if (first) S.lastEv = first.last_ev;     // eski olaylar için animasyon çalma
  const splash = $("#splash"), t0 = Date.now();
  const note = (txt, frac) => { if (splash) { $(".note", splash).textContent = txt; splash.style.setProperty("--p", Math.max(0.04, Math.min(1, frac))); } };
  for (;;) {                                  // veriler gelene dek bekle; 14 sn sonra elde olanla aç (eksik olan sembol nedenini kendisi söyler), en çok 45 sn
    const p = await api("/api/ping"), ready = p ? p.ready : 0, need = p ? p.need : 35, sec = (Date.now() - t0) / 1000, er = p && p.err ? Object.entries(p.err)[0] : null;
    note(`Piyasa verisi bağlanıyor… ${ready}/${need}` + (er && sec > 5 ? ` · ${er[0]}: ${er[1]}` : ""), ready / need);
    $("#loader").textContent = `Veri yükleniyor… ${ready}/${need}`;
    if (p && ready >= need) break; if (sec > 14 && ready >= 7) break; if (sec > 45) break;
    await new Promise((r) => setTimeout(r, 500));
  }
  note("Analiz hazırlanıyor…", 0.97);
  const Q = new URLSearchParams(location.search);          // geliştirme/test kısayolları
  if (Q.get("sym") && SYMS.includes(Q.get("sym"))) { S.sym = Q.get("sym"); markTop(); }
  if (Q.get("tf") && TFS.includes(Q.get("tf"))) { S.tf = Q.get("tf"); markTop(); }
  if (Q.get("demo")) S.demo = true;
  if (Q.get("all")) { Object.keys(S.opts).forEach((k) => (S.opts[k] = true)); S.opts.sr = S.opts.fib = true; buildMenu(); }
  if (Q.get("theme")) { S.theme = Q.get("theme"); applyTheme(); }
  try { await reload(true); } catch (e) { showErr("grafik", e); } try { await loadSigs(); } catch (e) { showErr("defter", e); }
  note("Hazır", 1);
  const wait = Math.max(0, 600 - (Date.now() - t0)); setTimeout(() => { if (window.Splash) Splash.finish(); else if (splash) { splash.classList.add("hide"); setTimeout(() => splash.remove(), 900); } }, wait); requestAnimationFrame(inkTo);        // açılış animasyonu en az ~2 sn görünür
  if (Q.get("tab")) setTab(Q.get("tab"));
  if (Q.get("demo")) setTimeout(() => { lightning({ name: NAMES[S.sym], sig: { sym: S.sym, tf: S.tf, side: 1, entry: S.candleLast.close, stop: S.candleLast.close - 10, tp1: S.candleLast.close + 15, risk: 10, r1: 1.5, setup: "Likidite süpürme + CHoCH dönüşü", score: 0.41, risk_label: "ORTA" } }); $("#bolt-layer").classList.add("freeze"); }, 1500);
  setInterval(loadSigs, 8000); setInterval(() => api("/api/ping"), 5000); setInterval(async () => { S.cal = (await api("/api/calendar")) || S.cal; if (S.tab === "cal") renderCal(); }, 30000);
  setInterval(drawOverlay, IS_MOBILE() ? 450 : 150); window.addEventListener("resize", () => { drawOverlay(); });       // kaydırma/yakınlaştırmada zaten aralık olayıyla anında çizilir
  C.main.timeScale().subscribeVisibleLogicalRangeChange(drawOverlay);
}
function applyTheme0() { setThemeClass(); }
DT.on("view", (v) => { if (v !== "market") return; setTimeout(() => { try { if (S.data) { const n = S.data.candles.length; C.main.timeScale().setVisibleLogicalRange({ from: Math.max(0, n - 130), to: n + 10 }); } else reload(true); window.dispatchEvent(new Event("resize")); drawOverlay(); } catch (e) { /* */ } }, 160); });
DT.on("palette", (p) => { TV.up = p.up; TV.down = p.dn; try { C.ser.candle.applyOptions({ upColor: p.up, downColor: p.dn, wickUpColor: p.up, wickDownColor: p.dn }); } catch (e) { /* */ } });
init();


