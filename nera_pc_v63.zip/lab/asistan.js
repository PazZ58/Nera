/* Nera Asistan: sag alt panel, sesle/yaziyla soru, parite raporu, kendi gorusu + karne, gunluk selam.
   Hesaplar lab/asistan_core.js (NeraAsistCore), animasyon ui3/asistan_fx.js (NeraAsistFx).
   Islem ACMAZ: /api/bot ve MT5'e hicbir istek gondermez. Nera'nin ajan oylarini/skorunu okumaz. */
(function () {
  if (window.LOCAL_API) return;
  const C = window.NeraAsistCore, F = window.NeraAsistFx;
  if (!C || !F) return;
  const DEF = { name: "", engine: "eleven", elVoice: "cgSgspJ2msm6clMCkdW9", on: true, voice: true, tech: false, sym: "XAUUSDT", daily: true, lot: {}, risk: 50, voiceName: "", rate: 1, useOllama: true };
  const LSg = (k, d) => { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } };
  const LSs = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* dolu/kapali */ } };
  let CFG = Object.assign({}, DEF, LSg("nera_asist", {}));
  let KARNE = LSg("nera_asist_karne", []);
  const H1C = {};
  let busy = false, rec = null, host, body, mic, inp, cvs, tab = "chat", TTS_OK = false, audio = null, actx = null;
  // ElevenLabs'in ucretsiz planda calisan hazir sesleri (kutuphane sesleri API'de ucretli)
  const EL_VOICES = [["cgSgspJ2msm6clMCkdW9", "Jessica"], ["EXAVITQu4vr4xnSDxMaL", "Sarah"], ["FGY2WhTYpPnrIDTdsKH5", "Laura"], ["pFZP5JQG7iQjIQuC4Bku", "Lily"], ["Xb7hH8MSUJpSbSDYk0k2", "Alice"], ["XrExE9yKIg1WjnnlVkGX", "Matilda"], ["SAz9YHcvj6GT2YYXdXww", "River"], ["JBFqnCBsd6RMkjVDRZzb", "George"], ["pNInz6obpgDQGcFmaJgB", "Adam"], ["nPczCjzI2devNBz1zQrb", "Brian"], ["onwK4e9ZLuTAKqWW03F9", "Daniel"]];

  const J = (u) => fetch(u, { cache: "no-store" }).then((r) => r.json()).catch(() => null);
  function llm(prompt, only) {
    const ac = new AbortController(), to = setTimeout(() => ac.abort(), 200000);
    return fetch("/api/llm", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ prompt, only }), signal: ac.signal })
      .then((r) => r.json()).catch((e) => ({ err: String(e && e.message || e) })).finally(() => clearTimeout(to));
  }
  const strip = (s) => String(s || "").replace(/<think>[\s\S]*?<\/think>/gi, "").trim();
  function myName() {
    const p = LSg("nera_prof", {}) || {};
    return (p.nick || (window.NeraNet && NeraNet.user && NeraNet.user()) || CFG.name || "").toString().trim();
  }
  const lotOf = (sym) => +(CFG.lot && CFG.lot[sym]) || 0.01;

  /* ---- arayuz: sag altta kucuk yildiz; tiklayinca ekranin ortasina suzulur, arka bulaniklasir, balonlar animasyonla gelir */
  let veil, hero, btn, bgEl, isOpen = false, TL = null, thinkEl = null;
  const CHAT = [];
  const gs = () => window.gsap;
  // performans modu / azaltilmis hareket / gsap yok: animasyonsuz ac-kapa
  const fast = () => !gs() || document.body.classList.contains("perf") || !!(window.NeraUI && (typeof NeraUI.reduced === "function" ? NeraUI.reduced() : NeraUI.reduced));
  const GREET = () => "Merhaba" + (myName() ? " " + myName() : "") + "! Bir parite sor: \"altın raporu\", \"bitcoin nereye gider?\" ya da \"karnen nasıl?\"";

  function build() {
    host = document.createElement("div");
    host.id = "na-host";
    host.innerHTML = `<div class="na-btn" title="Nera Asistan (Ctrl+Boşluk: konuş)"></div>`;
    document.body.appendChild(host);
    veil = document.createElement("div");
    veil.id = "na-veil";
    veil.innerHTML = `<div class="na-bg"></div><div class="na-stage"><div class="na-hero"></div>
<div class="na-tabs"><button data-t="chat" class="on">SOHBET</button><button data-t="karne">KARNE</button></div><button class="na-x" title="Kapat (Esc)">✕</button>
<div class="na-body" data-lenis-prevent></div>
<div class="na-bar"><input placeholder="Sor: altın raporu, bitcoin nereye gider…" maxlength="300"><button class="na-mic" title="Konuş (Ctrl+Boşluk)">🎙</button></div></div>`;
    document.body.appendChild(veil);
    btn = host.querySelector(".na-btn"); hero = veil.querySelector(".na-hero"); bgEl = veil.querySelector(".na-bg");
    body = veil.querySelector(".na-body"); mic = veil.querySelector(".na-mic"); inp = veil.querySelector("input");
    cvs = document.createElement("canvas");
    btn.appendChild(cvs);
    F.mount(cvs);
    btn.onclick = open;
    veil.querySelector(".na-x").onclick = close;
    veil.addEventListener("mousedown", (e) => { if (e.target === veil || e.target === bgEl) close(); });
    mic.onclick = toggleListen;
    inp.onkeydown = (e) => { if (e.key === "Enter" && inp.value.trim()) { const q = inp.value.trim(); inp.value = ""; ask(q); } };
    veil.querySelectorAll(".na-tabs button").forEach((b) => (b.onclick = () => showTab(b.dataset.t)));
    addEventListener("keydown", (e) => {
      if (e.key === "Escape" && isOpen) { close(); return; }
      if (!CFG.on || !(e.ctrlKey && e.code === "Space")) return;
      e.preventDefault(); open(); toggleListen();
    });
    addEventListener("resize", () => F.resize());
    apply();
  }
  function apply() { if (host) host.style.display = CFG.on ? "" : "none"; if (!CFG.on && isOpen) close(); }

  // heronun (donusumsuz) yerlesim merkezinden sag alttaki dugmeye uzaklik ve olcek: FLIP
  function flip() {
    const st = veil.querySelector(".na-stage").getBoundingClientRect(), h = host.getBoundingClientRect();
    const w = hero.offsetWidth, hh = hero.offsetHeight;
    return { dx: h.left + h.width / 2 - (st.left + hero.offsetLeft + w / 2), dy: h.top + h.height / 2 - (st.top + hero.offsetTop + hh / 2), s: h.width / w };
  }
  function open() {
    if (isOpen) return;
    isOpen = true;
    if (TL) TL.kill();
    veil.classList.add("on");
    hero.appendChild(cvs); cvs.style.cssText = "width:100%;height:100%";
    F.big(true);
    if (!body.children.length) msg(GREET(), "card", true);
    if (fast()) { inp.focus({ preventScroll: true }); return; }
    const g = gs(), r = flip(), tabs = veil.querySelectorAll(".na-tabs button, .na-x"), bar = veil.querySelector(".na-bar");
    TL = g.timeline({ onComplete: () => { TL = null; inp.focus({ preventScroll: true }); } });
    TL.fromTo(bgEl, { opacity: 0, "--nb": "0px" }, { opacity: 1, "--nb": "18px", duration: 0.8, ease: "power2.out" }, 0)
      .to(btn, { opacity: 0, scale: 0.55, duration: 0.3, ease: "power2.in" }, 0)
      .fromTo(hero, { x: r.dx, y: r.dy, scale: r.s, rotation: -50, opacity: 0.35 }, { x: 0, y: 0, scale: 1, rotation: 0, opacity: 1, duration: 1.2, ease: "nera.out" }, 0.04)
      .fromTo(tabs, { y: -16, opacity: 0 }, { y: 0, opacity: 1, duration: 0.5, stagger: 0.06, clearProps: "transform,opacity" }, 0.42)
      .fromTo(body.children, { y: 28, opacity: 0, filter: "blur(10px)" }, { y: 0, opacity: 1, filter: "blur(0px)", duration: 0.65, stagger: 0.07, clearProps: "transform,opacity,filter" }, 0.55)
      .fromTo(bar, { y: 44, opacity: 0, scale: 0.94 }, { y: 0, opacity: 1, scale: 1, duration: 0.7, ease: "nera.spring", clearProps: "transform,opacity" }, 0.5);
  }
  function close() {
    if (!isOpen) return;
    isOpen = false;
    if (TL) TL.kill();
    const g = gs();
    const done = () => {
      TL = null;
      btn.appendChild(cvs); cvs.style.cssText = "";
      F.big(false);
      veil.classList.remove("on");
      if (g) {
        g.set([hero, btn, bgEl], { clearProps: "all" });
        g.set(veil.querySelectorAll(".na-tabs button, .na-x, .na-bar, .na-body > *"), { clearProps: "transform,opacity,filter" });
      }
    };
    if (fast()) { done(); return; }
    const r = flip(), tabs = veil.querySelectorAll(".na-tabs button, .na-x"), bar = veil.querySelector(".na-bar");
    TL = g.timeline({ onComplete: done });
    TL.to([tabs, bar], { y: 22, opacity: 0, duration: 0.3, stagger: 0.03, ease: "power2.in" }, 0)
      .to(body.children, { y: 16, opacity: 0, filter: "blur(8px)", duration: 0.3, stagger: { each: 0.02, from: "end" }, ease: "power2.in" }, 0)
      .to(hero, { x: r.dx, y: r.dy, scale: r.s, rotation: 50, duration: 0.85, ease: "nera.inOut" }, 0.12)
      .to(bgEl, { opacity: 0, "--nb": "0px", duration: 0.6, ease: "power2.inOut" }, 0.3)
      .fromTo(btn, { opacity: 0, scale: 0.55 }, { opacity: 1, scale: 1, duration: 0.45, ease: "nera.spring" }, 0.62)
      .to(hero, { opacity: 0, duration: 0.25 }, 0.74);
  }

  // yeni balon: asistan soldan kelime kelime belirir, kullanici sagdan kayar
  function pop(d, me) {
    const g = gs();
    g.fromTo(d, { x: me ? 30 : -22, y: 18, opacity: 0, scale: 0.94, filter: "blur(8px)" }, { x: 0, y: 0, opacity: 1, scale: 1, filter: "blur(0px)", duration: 0.65, ease: "nera.out", clearProps: "transform,filter,opacity" });
    const txt = d.textContent.trim();
    if (!me && txt && txt.length < 900 && window.SplitText) {
      try {
        const sp = SplitText.create(d, { type: "words" });
        g.from(sp.words, { opacity: 0, y: 5, duration: 0.35, stagger: 0.022, delay: 0.15, ease: "power2.out", onComplete: () => sp.revert() });
      } catch (e) { /* duz metin */ }
    }
  }
  function msg(text, cls, still) {
    const d = document.createElement("div");
    d.className = "na-m" + (cls ? " " + cls : "");
    d.textContent = text;
    body.appendChild(d);
    if (thinkEl) body.appendChild(thinkEl);
    while (body.children.length > 60) body.firstChild.remove();
    body.scrollTo({ top: body.scrollHeight, behavior: still || !isOpen ? "auto" : "smooth" });
    if (isOpen && !still && !fast()) pop(d, cls === "me");
    return d;
  }
  // cevap hazirlanirken uc noktali "yaziyor" balonu
  function thinking() {
    F.state("think");
    if (thinkEl || !body || tab !== "chat") return;
    thinkEl = document.createElement("div");
    thinkEl.className = "na-m think";
    thinkEl.innerHTML = "<i></i><i></i><i></i>";
    body.appendChild(thinkEl);
    body.scrollTo({ top: body.scrollHeight, behavior: isOpen ? "smooth" : "auto" });
    if (isOpen && !fast()) pop(thinkEl, false);
  }
  function thinkOff() { if (thinkEl) { thinkEl.remove(); thinkEl = null; } }
  function showTab(t) {
    if (t === tab) return;
    tab = t;
    veil.querySelectorAll(".na-tabs button").forEach((b) => b.classList.toggle("on", b.dataset.t === t));
    const fill = () => {
      body.innerHTML = "";
      if (t === "karne") karneView();
      else { CHAT.slice(-40).forEach(([x, c]) => msg(x, c, true)); if (thinkEl) body.appendChild(thinkEl); }
    };
    if (!isOpen || fast()) { fill(); return; }
    const g = gs();
    g.to(body, { opacity: 0, y: -8, duration: 0.18, ease: "power2.in", onComplete: () => {
      fill();
      g.to(body, { opacity: 1, y: 0, duration: 0.3, clearProps: "opacity,transform" });
      g.fromTo(body.children, { y: 18, opacity: 0, filter: "blur(6px)" }, { y: 0, opacity: 1, filter: "blur(0px)", duration: 0.5, stagger: 0.05, clearProps: "transform,opacity,filter" });
    } });
  }
  function say(text, cls) { CHAT.push([text, cls]); if (CHAT.length > 80) CHAT.shift(); if (tab === "chat" && body) msg(text, cls); }

  /* ---- ses */
  function voice() {
    const vs = speechSynthesis.getVoices().filter((v) => /^tr/i.test(v.lang));
    return vs.find((v) => v.name === CFG.voiceName) || vs.find((v) => /natural|online/i.test(v.name)) || vs[0] || null;
  }
  function stopSpeech() {
    if (audio) { try { audio.pause(); } catch (e) { /* */ } audio = null; }
    if (window.speechSynthesis) speechSynthesis.cancel();
  }
  function speakEdge(t) {
    if (!window.speechSynthesis) { setTimeout(() => F.state("idle"), 2500); return; }
    const parts = t.split(/(?<=[.!?])\s+/).filter(Boolean), v = voice();
    parts.forEach((p, i) => {
      const u = new SpeechSynthesisUtterance(p);
      u.lang = "tr-TR"; if (v) u.voice = v; u.rate = +CFG.rate || 1;
      u.onboundary = () => F.amp(0.8);
      if (i === parts.length - 1) { u.onend = () => F.state("idle"); u.onerror = () => F.state("idle"); }
      speechSynthesis.speak(u);
    });
  }
  // ElevenLabs: mp3 sunucudan (anahtar tarayiciya inmez); animasyon sesin gercek siddetiyle
  async function speakEleven(t) {
    const r = await fetch("/api/tts", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ text: t, voice: CFG.elVoice }) });
    if (!r.ok || !/audio/.test(r.headers.get("Content-Type") || "")) throw new Error("tts " + r.status);
    const url = URL.createObjectURL(await r.blob()), a = new Audio(url);
    a.playbackRate = +CFG.rate || 1;
    audio = a;
    try {
      actx = actx || new (window.AudioContext || window.webkitAudioContext)();
      const an = actx.createAnalyser(); an.fftSize = 256;
      actx.createMediaElementSource(a).connect(an); an.connect(actx.destination);
      const buf = new Uint8Array(an.frequencyBinCount);
      const tick = () => { if (audio !== a || a.paused) return; an.getByteFrequencyData(buf); let m = 0; for (const x of buf) m += x; F.amp(Math.min(1, m / buf.length / 90)); requestAnimationFrame(tick); };
      a.onplay = tick;
    } catch (e) { a.onplay = () => F.amp(0.7); }
    a.onended = () => { URL.revokeObjectURL(url); if (audio === a) { audio = null; F.state("idle"); } };
    await a.play();
  }
  function speak(text, endState) {
    F.state(endState === "view" ? "view" : "speak");
    stopSpeech();
    if (!CFG.voice) { setTimeout(() => F.state("idle"), 2500); return; }
    const t = C.spoken(text);
    if (TTS_OK && CFG.engine !== "edge") speakEleven(t).catch(() => speakEdge(t));
    else speakEdge(t);
  }
  function toggleListen() {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (rec) { rec.stop(); return; }
    if (!SR) { say("Bu pencerede sesli dinleme yok; yazarak sorabilirsin.", "err"); return; }
    stopSpeech();
    rec = new SR(); rec.lang = "tr-TR"; rec.interimResults = false;
    let got = "";
    rec.onresult = (e) => { got = e.results[0][0].transcript || ""; };
    rec.onerror = (e) => { say(e.error === "not-allowed" ? "Mikrofon izni verilmedi. Yazarak sorabilirsin." : "Seni duyamadım (" + e.error + "). Tekrar dener misin ya da yazar mısın?", "err"); };
    rec.onend = () => { rec = null; mic.classList.remove("on"); F.state("idle"); if (got.trim()) ask(got.trim()); };
    mic.classList.add("on"); F.state("listen");
    try { rec.start(); } catch (e) { rec = null; mic.classList.remove("on"); F.state("idle"); }
  }

  /* ---- akis */
  async function ask(text) {
    open();
    say(text, "me");
    if (busy) { say("Bir saniye, hâlâ düşünüyorum."); return; }
    const it = C.intent(text);
    if (it.kind === "karne") return karneSay();
    if (it.kind === "report") return report(it.sym || CFG.sym);
    return free(text, it.sym || CFG.sym);
  }

  async function gather(sym) {
    const q = (tf) => J("/api/chart?sym=" + sym + "&tf=" + tf);
    const [h1, h4, m15, tk, news, cal] = await Promise.all([q("1h"), q("4h"), q("15m"), J("/api/tick?sym=" + sym + "&tf=1h"), J("/api/news"), J("/api/calendar")]);
    if (!h1 || !h1.ready || !h1.candles || !h1.candles.length) return null;
    const H = h1.candles, d1 = C.daily(H), w = (tk && tk.watch && tk.watch[sym]) || {};
    H1C[sym] = H;
    const price = +w.price || (m15 && m15.candles && m15.candles.length ? m15.candles[m15.candles.length - 1].close : H[H.length - 1].close);
    return {
      sym, price, H, h4: (h4 && h4.candles) || [], m15: (m15 && m15.candles) || [], closed: !!w.closed,
      atr: C.atrD(d1), lv: C.levels(H, d1), cal: Array.isArray(cal) ? cal : [],
      news: ((news && news.items) || []).filter((n) => (n.syms || []).includes(sym)).slice(0, 6).map((n) => n.title),
      keys: (news && news.keys) || {}, prov: (news && news.prov) || "auto",
    };
  }

  function evLines(g) {
    const now = Date.now() / 1000, out = [];
    for (const e of g.cal) {
      if (!((e.c || "USD") === "USD" || g.sym === "EURUSD")) continue;
      if (e.t > now && e.t <= now + 12 * 3600) out.push(C.eventLine(e, g.sym, now));
      else if (e.t <= now && e.t >= now - 3 * 3600) {
        const base = C.priceAt(g.m15.length ? g.m15 : g.H, e.t);
        out.push(C.eventLine(e, g.sym, now, base != null ? g.price - base : null));
      }
      if (out.length >= 3) break;
    }
    return out;
  }

  function karneInfo() {
    const done = KARNE.filter((r) => r.res);
    const s = C.karneStats(done);
    if (s.n < 10) return null;
    const b = C.baseline(done.slice(-200), 200);
    return b ? { n: s.n, rate: s.rate, lo: b.lo, hi: b.hi } : null;
  }

  async function report(sym) {
    if (busy) return false;
    busy = true; thinking();
    try {
      const g = await gather(sym);
      if (!g) { say("Bu paritenin verisi henüz hazır değil, biraz sonra tekrar dener misin?", "err"); F.state("idle"); return false; }
      const greet = C.greet(new Date(), myName());
      const evs = evLines(g), soon = C.eventSoon(g.cal, sym, Date.now() / 1000);
      const prov = C.pickProv(g.keys, g.prov, CFG.useOllama);
      let v = null, ok = false, light = !prov, note = "";
      if (!g.closed && prov) {
        const prompt = C.buildPrompt({ sym, price: g.price, h1: g.H, h4: g.h4, m15: g.m15, lv: g.lv, atrD: g.atr, news: g.news, tech: CFG.tech });
        for (let i = 0; i < 2 && !v; i++) {
          const r = await llm(prompt, prov);
          if (r && r.err) { note = r.err; break; }
          v = C.parseView(strip(r && r.text), g.price);
        }
        ok = C.validView(v, g.price, g.atr);
        if (note) say("Şu an düşünemiyorum (" + note.slice(0, 80) + "). Elimdeki veriyle anlatayım.", "err");
      }
      const vd = C.verdict({ closed: g.closed, eventSoon: soon, view: v, ok, sym, lot: lotOf(sym), risk: +CFG.risk || 50, price: g.price });
      const allowed = [g.price, g.lv.pdh, g.lv.pdl, g.lv.wkh, g.lv.wkl, g.lv.asiah, g.lv.asial, ...(g.lv.highs || []), ...(g.lv.lows || []), v && v.invalid, v && v.target].filter((x) => x > 0);
      if (v) { v.story = C.scrub(v.story, allowed, true); v.why = C.scrub(v.why, allowed, true); }
      const t = C.reportText({ greet, sym, price: g.price, view: v, ok, verdict: vd, atrD: g.atr, lot: lotOf(sym), evLines: evs, karne: karneInfo(), tech: CFG.tech, closed: g.closed, lv: g.lv, light, err: !!note });
      say(t.show, ok ? "" : light ? "card" : "");
      if (ok) {
        addKarne({ sym, t: Math.floor(Date.now() / 1000), price: g.price, dir: v.dir, invalid: v.invalid, target: v.target, atrD: g.atr, tf: "1h", src: "rapor", verdict: vd.kind });
        F.view({ dir: v.dir === "up" ? 1 : -1, tgtLabel: C.px(v.target, sym) + "  hedef", badLabel: C.px(v.invalid, sym) + "  fikir bozulur" });
      }
      speak(t.say, ok ? "view" : "speak");
      return true;
    } catch (e) {
      say("Bir şeyler ters gitti: " + String(e && e.message || e).slice(0, 120), "err"); F.state("idle");
      return false;
    } finally { busy = false; thinkOff(); }
  }

  async function free(text, sym) {
    busy = true; thinking();
    try {
      const g = await gather(sym);
      const prov = g && C.pickProv(g.keys, g.prov, CFG.useOllama);
      if (!g || !prov) { say("Serbest sorulara cevap verebilmem için Ayarlar'dan bir yapay zekâ (Ollama ya da ücretsiz Groq/Gemini anahtarı) gerekiyor. Parite raporunu yine verebilirim: \"altın raporu\" de.", "card"); F.state("idle"); return; }
      const lv = g.lv, nm = C.SYMN[sym] || sym;
      const prompt = ["/no_think", "Sen Nera'nın piyasa asistanısın. Türkçe, sıcak, kısa (en çok 4 cümle) konuşursun; kullanıcıya 'sen' dersin. Kazanç vaadi vermezsin. İşlem açamazsın ve açtığını söylemezsin.",
        "Yalnız aşağıdaki rakamları kullan; başka fiyat uydurma. Yön sorusuysa 'bunun için rapor isteyebilirsin' de.",
        "Bağlam: " + nm + " fiyatı " + g.price + ", dün tepe " + lv.pdh + " dip " + lv.pdl + ", günlük ortalama aralık " + g.atr.toFixed(2) + ". Piyasa " + (g.closed ? "kapalı" : "açık") + ".",
        "Haber başlıkları: " + (g.news.join(" | ") || "yok"),
        "Kullanıcının adı: " + (myName() || "bilinmiyor"), "Soru: " + text].join("\n");
      const r = await llm(prompt, prov);
      if (r && r.err) { say("Şu an düşünemiyorum (" + r.err.slice(0, 80) + ").", "err"); F.state("idle"); return; }
      const allowed = [g.price, lv.pdh, lv.pdl, lv.wkh, lv.wkl, lv.asiah, lv.asial, ...(lv.highs || []), ...(lv.lows || [])].filter((x) => x > 0);
      const ans = C.scrub(strip(r && r.text), allowed) || "Bunu şu an net söyleyemem.";
      say(ans);
      speak(ans);
    } catch (e) {
      say("Bir şeyler ters gitti: " + String(e && e.message || e).slice(0, 120), "err"); F.state("idle");
    } finally { busy = false; thinkOff(); }
  }

  /* ---- karne */
  function addKarne(r) {
    const hour = KARNE.find((k) => k.sym === r.sym && r.t - k.t < 3600);
    if (hour) return;
    r.id = r.sym + "_" + r.t;
    KARNE.push(r);
    if (KARNE.length > 500) KARNE = KARNE.slice(-500);
    LSs("nera_asist_karne", KARNE);
    if (window.NERA_SAVE) setTimeout(window.NERA_SAVE, 50);
  }
  async function resolveOpen() {
    const syms = [...new Set(KARNE.map((r) => r.sym))];
    for (const s of syms) {
      const h = await J("/api/chart?sym=" + s + "&tf=1h");
      if (h && h.candles) H1C[s] = h.candles;
    }
    let ch = false;
    for (const r of KARNE) {
      const h = H1C[r.sym];
      if (!h) continue;
      if (!r.res) { const x = C.resolve(r, h); if (x) { r.res = x; ch = true; } }
      if (r.res && !r.resAlt) {
        const d = Math.abs(r.price - r.invalid), alt = r.dir === "up" ? "down" : "up";
        const y = C.resolve({ t: r.t, price: r.price, dir: alt, invalid: r.price + (alt === "up" ? -d : d) }, h);
        if (y) { r.resAlt = y; ch = true; }
      }
    }
    if (ch) { LSs("nera_asist_karne", KARNE); if (tab === "karne") karneView(); }
  }
  function karneSay() {
    const k = karneInfo(), s = C.karneStats(KARNE.filter((r) => r.res));
    const t = k ? "Sonuçlanan " + k.n + " görüşümün %" + Math.round(k.rate * 100) + "'i tuttu. Rastgele seçseydim %" + Math.round(k.lo * 100) + " ile %" + Math.round(k.hi * 100) + " arası beklenirdi" + (k.rate > k.hi ? "; şimdilik şanstan iyiyim ama bu kanıt değil." : "; yani henüz şanstan farkım yok.")
      : "Henüz yeterli karnem yok: " + s.n + " görüşüm sonuçlandı, en az 10 lazım. Açıkta bekleyen " + KARNE.filter((r) => !r.res).length + " görüş var.";
    say(t); speak(t);
  }
  function karneView() {
    const done = KARNE.filter((r) => r.res), s = C.karneStats(done), k = karneInfo();
    const rows = KARNE.slice(-20).reverse().map((r) => `<tr><td>${new Date(r.t * 1000).toLocaleString("tr-TR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" })}</td><td>${C.SYMN[r.sym] || r.sym}</td><td>${r.dir === "up" ? "▲ yukarı" : "▼ aşağı"}</td><td class="${r.res === "win" ? "w" : r.res === "loss" ? "l" : "n"}">${r.res === "win" ? "tuttu" : r.res === "loss" ? "tutmadı" : r.res === "none" ? "sonuçsuz" : "açık"}</td></tr>`).join("");
    body.innerHTML = `<div class="na-k"><div class="na-big">${s.win + s.loss ? "%" + Math.round(s.rate * 100) : "—"}</div>
<div>Tuttu ${s.win} · tutmadı ${s.loss} · sonuçsuz ${s.none} · açık ${KARNE.length - s.n}</div>
<div style="color:#9b97c4;margin:6px 0">${k ? "Rastgele yön seçseydim: %" + Math.round(k.lo * 100) + "–%" + Math.round(k.hi * 100) : "Rastgele kıyas için en az 10 sonuçlanan görüş gerekir."} Ölçü: görüşün bozulma seviyesi kadar lehe (1R) ya da aleyhe ilk dokunuş, 24 saat.</div>
<table>${rows || "<tr><td>Henüz görüş yok.</td></tr>"}</table></div>`;
  }

  /* ---- gunluk selam */
  // soguk acilista veri gec gelir: gun yalniz rapor basarili olunca kullanilmis sayilir, 3 kez dener
  async function daily(tries = 3) {
    const today = new Date().toISOString().slice(0, 10);
    if (!CFG.on || !CFG.daily || LSg("nera_asist_day", "") === today) return;
    if (await report(CFG.sym)) LSs("nera_asist_day", today);
    else if (tries > 1) setTimeout(() => daily(tries - 1), 25000);
  }

  window.NeraAsist = {
    open, close, ask, report,
    cfg: () => Object.assign({}, CFG),
    setCfg(p) { CFG = Object.assign({}, CFG, p || {}); LSs("nera_asist", CFG); apply(); if (window.NERA_SAVE) setTimeout(window.NERA_SAVE, 50); },
    voices: () => (window.speechSynthesis ? speechSynthesis.getVoices().filter((v) => /^tr/i.test(v.lang)).map((v) => v.name) : []),
    settings,
  };

  /* ---- Ayarlar > Asistan (lab3.js #st-asist yuvasina cizer) */
  function settings(el) {
    if (!el) return;
    const sw = (id, on) => `<label class="sw"><input type="checkbox" id="${id}" ${on ? "checked" : ""}><i></i></label>`;
    const row = (t, d, ctl) => `<div class="setrow"><div><b>${t}</b>${d ? `<div class="muted" style="font-size:11px">${d}</div>` : ""}</div>${ctl}<span></span></div>`;
    const opt = (v, n, cur) => `<option value="${v}" ${String(v) === String(cur) ? "selected" : ""}>${n}</option>`;
    const syms = Object.keys(C.SYMN);
    const esc = (s) => String(s).replace(/[&<>"']/g, (c) => "&#" + c.charCodeAt(0) + ";");
    const vs = window.NeraAsist.voices();
    el.innerHTML = `<div class="ph">Asistan</div>
${row("Asistan", "sağ altta Nera Asistan (Ctrl+Boşluk: konuş)", sw("na-on", CFG.on))}
${row("Sesli cevap", "kapalıysa yalnız yazar", sw("na-voice", CFG.voice))}
${row("Anlatım dili", "Teknik: seviye adları ve ATR eklenir; görüş değişmez", `<select id="na-tech" class="sel">${opt(0, "Sade", +CFG.tech)}${opt(1, "Teknik", +CFG.tech)}</select>`)}
${row("Günlük açılış raporu", "günün ilk açılışında selam + rapor", sw("na-daily", CFG.daily))}
${row("Varsayılan parite", "açılış raporu ve parite söylenmeyen sorular", `<select id="na-sym" class="sel">${syms.map((s) => opt(s, C.SYMN[s], CFG.sym)).join("")}</select>`)}
${syms.map((s) => row("Lot · " + C.SYMN[s], "olası kazanç/kayıp ve stop $ bu lotla hesaplanır", `<input id="na-lot-${s}" class="sel" type="number" min="0.01" step="0.01" value="${lotOf(s)}" style="width:90px">`)).join("")}
${row("İşlem başı risk sınırı ($)", "stop bunu aşarsa 'bu lotla açmazdım' der", `<input id="na-risk" class="sel" type="number" min="1" step="1" value="${+CFG.risk || 50}" style="width:90px">`)}
${row("ElevenLabs anahtarı", "doğal ses için", `<span style="display:flex;gap:6px;align-items:center"><input id="na-key" class="sel" type="text" autocomplete="off" spellcheck="false" placeholder="anahtarı yapıştır" style="width:190px;-webkit-text-security:disc"><button class="btn pri" id="na-keyb">Kaydet ve dene</button><button class="btn" id="na-keyd">Sil</button></span>`)}
<div class="muted" id="na-keyn" style="font-size:11px;padding:0 18px 8px">${TTS_OK ? "Anahtar kayıtlı ✓ (değiştirmek için yenisini yapıştır)" : "Anahtar yok: şimdilik Edge sesi kullanılıyor."}</div>
<div class="muted" style="font-size:11px;padding:0 18px 8px">Nasıl alınır: elevenlabs.io → Developers → API Keys → Create Key; yalnız "Text to Speech" izni açık olsun. Anahtar bu bilgisayarda saklanır.</div>
${row("Ses motoru", TTS_OK ? "ElevenLabs: doğal ses (anahtarın bilgisayarda kayıtlı)" : "ElevenLabs anahtarı bulunamadı: Edge sesi kullanılıyor", `<select id="na-eng" class="sel">${opt("eleven", "ElevenLabs", CFG.engine)}${opt("edge", "Edge (yerel)", CFG.engine)}</select>`)}
${row("ElevenLabs sesi", "ücretsiz planda kullanılabilen sesler", `<select id="na-elv" class="sel">${EL_VOICES.map(([id, n]) => opt(id, n, CFG.elVoice)).join("")}</select>`)}
${row("Edge sesi", "ElevenLabs yoksa ya da Edge seçiliyse", `<select id="na-vn" class="sel">${opt("", "Otomatik", CFG.voiceName)}${vs.map((v) => opt(esc(v), esc(v), CFG.voiceName)).join("")}</select>`)}
${row("Konuşma hızı", "", `<select id="na-rate" class="sel">${[0.85, 1, 1.15].map((r) => opt(r, r === 1 ? "Normal" : r < 1 ? "Yavaş" : "Hızlı", CFG.rate)).join("")}</select>`)}
${row("Ollama varsa onu kullan", "yerel ve ücretsiz; yoksa ücretsiz bulut anahtarı (Groq, Gemini…). Ücretli sağlayıcılar asla otomatik kullanılmaz", sw("na-oll", CFG.useOllama))}
${(LSg("nera_prof", {}) || {}).nick ? "" : row("Adın", "profilinde takma ad yoksa asistan sana bu adla hitap eder", `<input id="na-name" class="sel" maxlength="20" placeholder="örn. Adil" value="${esc(CFG.name || "")}" style="width:140px">`)}
<div class="muted" style="font-size:11px;padding:0 18px 12px">Konuşman Microsoft'un tanıma servisine, seslendirilen cevap metni ElevenLabs'e gider. Asistanın görüşü kanıtlanmış bir tahmin değildir; karnesine bak. Asistan işlem açmaz.</div>`;
    const $ = (id) => el.querySelector("#" + id);
    const bind = (id, f) => { const x = $(id); if (x) x.onchange = () => f(x); };
    bind("na-on", (x) => window.NeraAsist.setCfg({ on: x.checked }));
    bind("na-voice", (x) => window.NeraAsist.setCfg({ voice: x.checked }));
    bind("na-tech", (x) => window.NeraAsist.setCfg({ tech: x.value === "1" }));
    bind("na-daily", (x) => window.NeraAsist.setCfg({ daily: x.checked }));
    bind("na-sym", (x) => window.NeraAsist.setCfg({ sym: x.value }));
    syms.forEach((s) => bind("na-lot-" + s, (x) => { const v = Math.max(0.01, Math.min(100, +x.value || 0.01)); x.value = v; window.NeraAsist.setCfg({ lot: Object.assign({}, CFG.lot, { [s]: v }) }); }));
    bind("na-risk", (x) => { const v = Math.max(1, Math.min(1e6, +x.value || 50)); x.value = v; window.NeraAsist.setCfg({ risk: v }); });
    bind("na-vn", (x) => window.NeraAsist.setCfg({ voiceName: x.value }));
    bind("na-eng", (x) => window.NeraAsist.setCfg({ engine: x.value }));
    bind("na-elv", (x) => window.NeraAsist.setCfg({ elVoice: x.value }));
    bind("na-rate", (x) => window.NeraAsist.setCfg({ rate: +x.value || 1 }));
    bind("na-oll", (x) => window.NeraAsist.setCfg({ useOllama: x.checked }));
    bind("na-name", (x) => window.NeraAsist.setCfg({ name: x.value.trim().slice(0, 20) }));
    // ElevenLabs anahtari: sunucuya kaydedilir (tarayiciya geri donmez), hemen denenir; gecersizse silinir
    const note = (t, bad) => { const n = $("na-keyn"); if (n) { n.textContent = t; n.style.color = bad ? "#ff7ad9" : "#7cf2ff"; } };
    const setKey = (v) => fetch("/api/keys", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ elevenlabs: v }) }).then((r) => r.json());
    const keyB = $("na-keyb"), keyD = $("na-keyd");
    if (keyB) keyB.onclick = async () => {
      const v = $("na-key").value.trim();
      if (v.length < 20) { note("Anahtarı yapıştır (ElevenLabs sayfasındaki uzun kod).", true); return; }
      keyB.disabled = true; note("Kaydediliyor ve deneniyor…");
      try {
        const k = await setKey(v);
        if (!("elevenlabs" in k)) { note("Bu özellik için Nera'nın yeni sürümü (exe) gerekiyor.", true); return; }
        const r = await fetch("/api/tts", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ text: "Merhaba, ben Nera. Sesim böyle olacak.", voice: CFG.elVoice }) });
        if (r.ok && /audio/.test(r.headers.get("Content-Type") || "")) {
          TTS_OK = true; $("na-key").value = "";
          new Audio(URL.createObjectURL(await r.blob())).play().catch(() => {});
          window.NeraAsist.setCfg({ engine: "eleven" });
          note("Kaydedildi, ses çalışıyor ✓");
          return;
        }
        const j = await r.json().catch(() => ({})), e = String(j.err || "");
        if (/402/.test(e)) { TTS_OK = true; note("Anahtar kabul edildi ama bu ses ücretsiz planda kullanılamıyor ya da kredi bitti. Listeden başka bir ses seç.", true); return; }
        await setKey("");
        TTS_OK = false;
        note(/401|403/.test(e) ? "Anahtar geçersiz ya da Text to Speech izni kapalı; kaydedilmedi." : "Denenemedi: " + e.slice(0, 120), true);
      } catch (err) { note("Hata: " + String(err && err.message || err).slice(0, 100), true); }
      finally { keyB.disabled = false; }
    };
    if (keyD) keyD.onclick = async () => {
      try { await setKey(""); const j = await J("/api/tts"); TTS_OK = !!(j && j.ok); note(TTS_OK ? "Kayıtlı anahtar silindi; bilgisayardaki ortam değişkeni kullanılıyor." : "Anahtar silindi; Edge sesi kullanılacak."); }
      catch (e) { note("Silinemedi.", true); }
    };
  }

  function start() {
    if (document.body.classList.contains("m")) return;
    J("/api/tts").then((j) => { TTS_OK = !!(j && j.ok); });
    build();
    setTimeout(() => resolveOpen().catch(() => {}).finally(() => daily()), 6000);
    setInterval(() => resolveOpen().catch(() => {}), 5 * 60 * 1000);
  }
  if (document.readyState === "loading") addEventListener("DOMContentLoaded", start); else start();
})();
