/* Nera Asistan cekirdegi: saf hesaplar (DOM yok). Tarayicida window.NeraAsistCore, Node'da require. Test: lab_test/asistan_test.js */
(function () {
  const DAY = 86400;
  const CONTRACT = { XAUUSDT: 100, XAGUSDT: 5000, EURUSD: 100000, BTCUSDT: 1, ETHUSDT: 1 };

  function money(sym, lot, dist) {
    return Math.round(Math.abs(dist) * lot * (CONTRACT[sym] || 1) * 100) / 100;
  }

  function greet(date, name) {
    const h = date.getHours();
    const w = h >= 5 && h < 12 ? "Günaydın" : h >= 12 && h < 18 ? "İyi günler" : h >= 18 && h < 23 ? "İyi akşamlar" : "İyi geceler";
    return name ? w + " " + name : w;
  }

  // \b Turkce harfleri (ş, ı, ü) kelime saymaz: yalniz baslangicta harf siniri, sonda Turkce ek serbest
  const W = (s) => new RegExp("(?<!\\p{L})(" + s + ")", "iu");
  const SYMW = [
    [W("altın|altin|xau|gold"), "XAUUSDT"],
    [W("gümüş|gumus|xag|silver"), "XAGUSDT"],
    [W("bitcoin|btc"), "BTCUSDT"],
    [W("ethereum|ether|eth"), "ETHUSDT"],
    [W("euro|eurusd|eur"), "EURUSD"],
  ];
  const REPORT = /(rapor|durum|ne olacak|nereye|yüksel|yuksel|düşer|duser|düşecek|açalım|acalim|alayım|alayim|satayım|satayim)/i;
  const KARNE = /(karne|kaç tuttu|kac tuttu|tuttu mu)/i;

  function intent(text) {
    const t = String(text || "");
    let sym = null;
    for (const [re, s] of SYMW) if (re.test(t)) { sym = s; break; }
    if (KARNE.test(t)) return { kind: "karne", sym: null };
    if (REPORT.test(t)) return { kind: "report", sym };
    return { kind: "free", sym };
  }

  // sunucuda 1d yuklu degil: 1h mumlarini UTC gunlerine topla
  function daily(h1) {
    const out = [];
    for (const c of h1) {
      const day = Math.floor(c.time / DAY) * DAY, o = out[out.length - 1];
      if (o && o.time === day) { o.high = Math.max(o.high, c.high); o.low = Math.min(o.low, c.low); o.close = c.close; }
      else out.push({ time: day, open: c.open, high: c.high, low: c.low, close: c.close });
    }
    return out;
  }

  function atrD(daily, n = 14) {
    const d = daily.slice(-(n + 1));
    const tr = [];
    for (let i = 1; i < d.length; i++) {
      const pc = d[i - 1].close;
      tr.push(Math.max(d[i].high - d[i].low, Math.abs(d[i].high - pc), Math.abs(d[i].low - pc)));
    }
    if (!tr.length && d.length) tr.push(d[0].high - d[0].low);
    return tr.length ? tr.reduce((a, b) => a + b, 0) / tr.length : 0;
  }

  function pivots(c, L = 3) {
    const highs = [], lows = [];
    for (let i = c.length - 1 - L; i >= L && (highs.length < 3 || lows.length < 3); i--) {
      let ph = true, pl = true;
      for (let k = 1; k <= L; k++) {
        if (!(c[i].high > c[i - k].high && c[i].high > c[i + k].high)) ph = false;
        if (!(c[i].low < c[i - k].low && c[i].low < c[i + k].low)) pl = false;
      }
      if (ph && highs.length < 3) highs.push(c[i].high);
      if (pl && lows.length < 3) lows.push(c[i].low);
    }
    return { highs, lows };
  }

  const hi = (a) => (a.length ? Math.max(...a.map((x) => x.high)) : null);
  const lo = (a) => (a.length ? Math.min(...a.map((x) => x.low)) : null);

  function levels(h1, d1) {
    const last = h1[h1.length - 1];
    const today = Math.floor(last.time / DAY);
    const prev = h1.filter((x) => Math.floor(x.time / DAY) === today - 1);
    const tod = h1.filter((x) => Math.floor(x.time / DAY) === today);
    const asia = tod.filter((x) => ((x.time % DAY) / 3600) < 7);
    const dow = (new Date(today * DAY * 1000).getUTCDay() + 6) % 7;
    const monday = (today - dow) * DAY;
    const wk = (d1 || []).filter((x) => x.time >= monday).concat(tod);
    const p = pivots(h1);
    return { pdh: hi(prev), pdl: lo(prev), wkh: hi(wk), wkl: lo(wk), asiah: hi(asia), asial: lo(asia), highs: p.highs, lows: p.lows };
  }

  // "2.668,5" / "2,668.5" / "2668.5"; tek ayrac + tam 3 hane belirsiz: ref verilirse ona yakin okuma (EURUSD "1.085")
  function num(s, ref) {
    if (typeof s === "number") return s;
    let t = String(s == null ? "" : s).replace(/[^\d.,-]/g, "");
    if (!/\d/.test(t)) return NaN;
    const d = t.lastIndexOf("."), c = t.lastIndexOf(",");
    if (d >= 0 && c >= 0) {
      const dec = d > c ? "." : ",";
      t = t.split(dec === "." ? "," : ".").join("").replace(dec, ".");
      return parseFloat(t);
    }
    const sep = d >= 0 ? "." : c >= 0 ? "," : null;
    if (!sep) return parseFloat(t);
    const parts = t.split(sep);
    const asThou = parseFloat(parts.join(""));
    const asDec = parts.length === 2 ? parseFloat(parts[0] + "." + parts[1]) : NaN;
    if (parts.length > 2) return asThou;
    if (parts[1].length !== 3) return asDec;
    if (ref > 0) return Math.abs(asDec - ref) < Math.abs(asThou - ref) ? asDec : asThou;
    return asThou;
  }

  function parseView(text, ref) {
    const s = String(text || "").replace(/<think>[\s\S]*?<\/think>/gi, "");
    const m = s.match(/\{[\s\S]*?\}/);
    if (!m) return null;
    let o;
    try { o = JSON.parse(m[0]); } catch (e) { return null; }
    const dir = String(o.dir || "").toLowerCase();
    const invalid = num(o.invalid, ref), target = num(o.target, ref);
    if (!["up", "down", "flat"].includes(dir) || !isFinite(invalid) || !isFinite(target)) return null;
    return { dir, invalid, target, why: String(o.why || "").slice(0, 300), story: String(o.story || "").slice(0, 600) };
  }

  function validView(v, price, atr) {
    if (!v || !(atr > 0) || !(price > 0)) return false;
    const lim = 3 * atr;
    if (Math.abs(v.invalid - price) > lim || Math.abs(v.target - price) > lim) return false;
    // stop gunluk araligin %15'inden yakinsa ilk kipirdamada tetiklenir; karneyi gurultuyle doldurur
    if (Math.abs(v.invalid - price) < 0.15 * atr) return false;
    if (v.dir === "up") return v.invalid < price && price < v.target;
    if (v.dir === "down") return v.target < price && price < v.invalid;
    return false;
  }

  function verdict(o) {
    if (o.closed) return { kind: "none" };
    if (o.eventSoon) return { kind: "wait" };
    if (!o.ok || !o.view || (o.view.dir !== "up" && o.view.dir !== "down")) return { kind: "skip" };
    const side = o.view.dir === "up" ? 1 : -1, dist = Math.abs(o.price - o.view.invalid);
    const stopUsd = money(o.sym, o.lot, dist);
    const res = { entry: o.price, stop: o.view.invalid, tgt: o.price + side * dist, stopUsd, tgtUsd: stopUsd };
    if (stopUsd > o.risk) return Object.assign({ kind: "risk" }, res);
    return Object.assign({ kind: side > 0 ? "long" : "short" }, res);
  }

  // karne: 1R simetrik; ilk dokunan; ayni mumda ikisi = yanlis; 24 mumda hicbiri = sonucsuz; az mum = null (acik)
  function resolve(rec, h1) {
    const side = rec.dir === "up" ? 1 : -1, d = Math.abs(rec.price - rec.invalid);
    const win = rec.price + side * d, lose = rec.invalid;
    // mumlar kaydin zamanini kapsamiyorsa (Nera uzun sure kapali kaldi) ilgisiz mumlarla puanlama
    if (h1.length && h1[0].time > rec.t + 3600) return "none";
    const after = h1.filter((c) => c.time > rec.t);
    for (let i = 0; i < Math.min(24, after.length); i++) {
      const c = after[i];
      const hitL = side > 0 ? c.low <= lose : c.high >= lose;
      const hitW = side > 0 ? c.high >= win : c.low <= win;
      if (hitL) return "loss";
      if (hitW) return "win";
    }
    return after.length >= 24 ? "none" : null;
  }

  function karneStats(recs) {
    const s = { n: 0, win: 0, loss: 0, none: 0, rate: 0 };
    for (const r of recs) if (r.res === "win" || r.res === "loss" || r.res === "none") { s.n++; s[r.res]++; }
    s.rate = s.win + s.loss ? s.win / (s.win + s.loss) : 0;
    return s;
  }

  // rastgele kiyas: her kayitta yon yazi-tura; ters yonun sonucu (resAlt) kayit sonuclanirken saklanir
  function baseline(recs, runs = 200, rnd = Math.random) {
    const use = recs.filter((r) => (r.res === "win" || r.res === "loss") && (r.resAlt === "win" || r.resAlt === "loss"));
    if (!use.length) return null;
    const rates = [];
    for (let k = 0; k < runs; k++) {
      let w = 0;
      for (const r of use) if ((rnd() < 0.5 ? r.res : r.resAlt) === "win") w++;
      rates.push(w / use.length);
    }
    rates.sort((a, b) => a - b);
    const q = (p) => rates[Math.min(rates.length - 1, Math.floor(p * rates.length))];
    return { mean: rates.reduce((a, b) => a + b, 0) / rates.length, lo: q(0.05), hi: q(0.95) };
  }

  // ---- seslendirme: ses motorlari "2602"yi rakam rakam okuyor; sayilar Turkce yaziya cevrilir
  const BIR = ["", "bir", "iki", "üç", "dört", "beş", "altı", "yedi", "sekiz", "dokuz"];
  const ON = ["", "on", "yirmi", "otuz", "kırk", "elli", "altmış", "yetmiş", "seksen", "doksan"];
  function trNum(n) {
    n = Math.floor(Math.abs(n));
    if (n === 0) return "sıfır";
    const three = (x) => {
      const y = Math.floor(x / 100), r = x % 100, w = [];
      if (y) w.push(y === 1 ? "yüz" : BIR[y] + " yüz");
      if (r >= 10) w.push(ON[Math.floor(r / 10)]);
      if (r % 10) w.push(BIR[r % 10]);
      return w.join(" ");
    };
    const units = [["milyar", 1e9], ["milyon", 1e6], ["bin", 1e3]], out = [];
    for (const [nm, v] of units) {
      const k = Math.floor(n / v);
      if (k) { out.push(nm === "bin" && k === 1 ? "bin" : three(k) + " " + nm); n %= v; }
    }
    if (n) out.push(three(n));
    return out.join(" ").trim();
  }
  const digitsTr = (s) => s.split("").map((d) => (d === "0" ? "sıfır" : BIR[+d])).join(" ");
  // bulunma eki (-de/-da/-te/-ta): son unlu ve son harfe gore
  function loc(w) {
    const v = (w.match(/[aeıioöuü](?=[^aeıioöuü]*$)/i) || ["e"])[0];
    const back = /[aıou]/i.test(v), hard = /[fstkçşhp]$/i.test(w);
    return w + (hard ? "t" : "d") + (back ? "a" : "e");
  }
  function decTr(t) {
    const m = t.match(/^(\d+)(?:[.,](\d+))?$/);
    if (!m) return t;
    if (m[2] && m[2].length === 3 && t.includes(".") && m[1].length <= 3) return trNum(+(m[1] + m[2]));
    return trNum(+m[1]) + (m[2] ? " virgül " + digitsTr(m[2]) : "");
  }
  function spoken(text) {
    let s = String(text || "");
    s = s.replace(/(\d{1,2}):(\d{2})(?:'(?:de|da|te|ta))?/g, (_, h, m) => { const w = trNum(+h) + (+m ? " " + trNum(+m) : ""); return loc(w); });
    s = s.replace(/(?:([−-])\s?)?(\d[\d.,]*?)[.,]?\s?\$/g, (_, neg, n) => (neg ? "eksi " : "") + trNum(Math.round(num(n))) + " dolar");
    s = s.replace(/(?:([−-])\s?)?%\s?(\d+(?:[.,]\d+)?)/g, (_, neg, n) => (neg ? "eksi " : "") + "yüzde " + decTr(n));
    s = s.replace(/\d[\d.,]*\d|\d/g, (t) => decTr(t));
    return s;
  }

  // olay anindaki fiyat: olayin dustugu mumun acilisi
  function priceAt(candles, t) {
    const c = (candles || []).filter((x) => x.time <= t).pop();
    return c ? c.open : null;
  }

  // olay turu -> "beklentiden yuksek gelirse" o para birimi icin +1 (guclenir) / -1
  const EFFECT = [
    [/unemployment|jobless|claimant|işsizlik|issizlik/i, -1],
    [/cpi|ppi|pce|inflation|enflasyon|non-farm|nfp|istihdam|employment change|gdp|büyüme|retail sales|ism|pmi|fomc|faiz|rate|interest|average hourly|core/i, 1],
  ];
  // sembol bu para biriminin guclenmesinden nasil etkilenir: +1 olumlu, -1 olumsuz
  const SENS = { USD: { XAUUSDT: -1, XAGUSDT: -1, EURUSD: -1, BTCUSDT: -1, ETHUSDT: -1 }, EUR: { EURUSD: 1 } };
  function effect(title, cur, sym) {
    const s = (SENS[cur || "USD"] || {})[sym];
    if (!s) return null;
    const row = EFFECT.find(([re]) => re.test(title || ""));
    if (!row) return null;
    const hiPos = row[1] * s > 0;
    return { hi: hiPos ? "pos" : "neg", lo: hiPos ? "neg" : "pos" };
  }

  const SYMN = { XAUUSDT: "altın", XAGUSDT: "gümüş", BTCUSDT: "bitcoin", ETHUSDT: "ether", EURUSD: "euro/dolar" };
  const SYMD = { XAUUSDT: "altına", XAGUSDT: "gümüşe", BTCUSDT: "bitcoine", ETHUSDT: "ethere", EURUSD: "euro/dolara" };
  const hm = (t) => { const d = new Date(t * 1000); return String(d.getHours()).padStart(2, "0") + ":" + String(d.getMinutes()).padStart(2, "0"); };
  const fmt = (x) => (Math.abs(x) >= 10 ? Math.round(Math.abs(x)).toString() : Math.abs(x) >= 1 ? Math.abs(x).toFixed(1) : Math.abs(x).toFixed(4)).replace(".", ",");
  const pctTr = (s) => { const t = String(s).replace(".", ","); return /%$/.test(t) ? t.replace(/^(-?)(.*)%$/, "$1%$2") : t; };

  function eventLine(ev, sym, now, move = null) {
    const cur = ev.c || "USD", eff = effect(ev.name, cur, sym), nm = SYMN[sym] || sym;
    if (ev.t > now) {
      let s = hm(ev.t) + "'de " + ev.name + " açıklanacak.";
      if (ev.f || ev.p) s += " Beklenti " + pctTr(ev.f || "?") + ", önceki " + pctTr(ev.p || "?") + ".";
      s += eff ? " Veri yüksek gelirse " + SYMD[sym] + " " + (eff.hi === "pos" ? "olumlu" : "olumsuz") + ", düşük gelirse " + (eff.lo === "pos" ? "olumlu" : "olumsuz") + " olur." : " Sonuç fiyatı sert oynatabilir.";
      return s;
    }
    if (move == null || !isFinite(move) || move === 0) return ev.name + " açıklandı.";
    const unit = sym === "EURUSD" ? "" : "$";
    const favUsd = (move < 0) === ((SENS.USD[sym] || -1) < 0);
    const side = cur === "EUR" ? (move > 0 ? "euro lehine" : "euro aleyhine") : favUsd ? "dolar lehine" : "dolar aleyhine";
    return "Açıklamadan sonra " + nm + " " + fmt(move) + unit + " " + (move < 0 ? "düştü" : "yükseldi") + "; piyasa veriyi " + side + " okudu gibi.";
  }

  function eventSoon(evs, sym, now, hours = 2) {
    return (evs || []).some((e) => e.t > now && e.t <= now + hours * 3600 && ((e.c || "USD") === "USD" || sym === "EURUSD"));
  }

  // ucretli (openai, deepseek) asla otomatik secilmez
  const FREE = ["groq", "gemini", "cerebras", "openrouter", "mistral"];
  function pickProv(keys, prov, useOllama) {
    keys = keys || {};
    if (useOllama && keys.ollama) return "ollama";
    if (FREE.includes(prov) && keys[prov]) return prov;
    return FREE.find((k) => keys[k]) || null;
  }

  const DEC = { EURUSD: 4, XAGUSDT: 2, XAUUSDT: 1, BTCUSDT: 0, ETHUSDT: 1 };
  const px = (x, sym) => (x == null || !isFinite(x) ? "?" : String(+(+x).toFixed(DEC[sym] ?? 2)).replace(".", ","));
  const sig = (x) => String(+(+x).toPrecision(6));
  const rows = (c, n) => c.slice(-n).map((k) => [new Date(k.time * 1000).toISOString().slice(5, 16).replace("T", " "), sig(k.open), sig(k.high), sig(k.low), sig(k.close)].join(" ")).join("\n");

  function buildPrompt(o) {
    const lv = o.lv || {};
    const head = [
      "/no_think",
      "Sen Nera'nın piyasa asistanısın. Görevin: " + (SYMN[o.sym] || o.sym) + " grafiğine bakıp bugünün yönü hakkında KENDİ görüşünü vermek. Aşağıda veri var; veriyi anlatma, yorumla.",
      "Güncel fiyat: " + sig(o.price) + " · günlük ortalama aralık: " + sig(o.atrD),
      "Seviyeler: dün tepe " + lv.pdh + " dip " + lv.pdl + " · hafta tepe " + lv.wkh + " dip " + lv.wkl + " · Asya tepe " + lv.asiah + " dip " + lv.asial + " · son tepeler " + (lv.highs || []).join(", ") + " · son dipler " + (lv.lows || []).join(", "),
      "Haber başlıkları: " + ((o.news || []).slice(0, 6).join(" | ") || "yok"),
      "Mumlar (zaman açılış tepe dip kapanış, UTC):",
    ].join("\n");
    // kucuk yerel model talimati uzun verinin ardindan unutuyor: kurallar ve JSON en sonda
    const tail = [
      "Kurallar: Türkçe, sıcak, sade konuş; 'bence' de, kazanç vaadi verme, rakam uydurma, yalnız yukarıdaki veriye dayan." + (o.tech ? " Teknik terim kullanabilirsin." : " Teknik terim kullanma, günlük dille anlat."),
      "up ise invalid < " + sig(o.price) + " < target; down ise target < " + sig(o.price) + " < invalid; ikisi de fiyattan en çok " + sig(3 * o.atrD) + " uzakta; invalid fiyattan en az " + sig(0.15 * o.atrD) + " uzakta (yakın stop hemen tetiklenir). Emin değilsen dir=flat.",
      'Şimdi YALNIZ şu JSON\'u yaz, başka hiçbir şey yazma: {"dir":"up|down|flat","invalid":<fikrini bozacak fiyat>,"target":<hedef fiyat>,"why":"<tek cümle gerekçe>","story":"<son 24 saatte ne oldu, 2-3 cümle>"}',
    ].join("\n");
    let n4 = 30, n1 = 48, n15 = 24, p;
    for (;;) {
      p = head + "\n4 saatlik:\n" + rows(o.h4 || [], n4) + "\n1 saatlik:\n" + rows(o.h1 || [], n1) + "\n15 dakikalık:\n" + rows(o.m15 || [], n15) + "\n" + tail;
      if (p.length <= 5800 || n1 <= 6) break;
      n4 = Math.floor(n4 * 0.8); n1 = Math.floor(n1 * 0.8); n15 = Math.floor(n15 * 0.8);
    }
    return p.length <= 5800 ? p : head.slice(0, 5800 - tail.length - 1) + "\n" + tail;
  }

  // fiyat benzeri sayi (>=3 hane ya da ondalikli) izinlilerden %0,5 uzaksa o cumle duser; yuzde ve saat dokunulmaz.
  // strict (story/why): yuzde ve "$/dolar/bin/puan" yanindaki sayilar da izinli degilse cumle duser
  const near = (t, ok) => ok.some((a) => { const v = num(t, a); return isFinite(v) && Math.abs(v - a) <= a * 0.005; });
  function scrub(text, allowed, strict = false) {
    const ok = (allowed || []).filter((x) => x > 0);
    const sents = String(text || "").split(/(?<=[.!?])\s+/);
    const keep = sents.filter((s) => {
      const clean = s.replace(/\d{1,2}:\d{2}/g, " ").replace(/%\s?-?\d[\d.,]*|-?\d[\d.,]*\s?%/g, " ");
      if (strict) {
        if (/%\s*\d|\d\s*%/.test(s)) return false;
        const money = s.match(/\d[\d.,]*(?=\s*(\$|dolar|bin\b|puan))/gi) || [];
        if (money.some((t) => !near(t, ok))) return false;
      }
      const nums = clean.match(/\d[\d.,]*\d|\d/g) || [];
      return nums.every((t) => {
        const digits = t.replace(/\D/g, "").length;
        if (digits < 3 && !/[.,]/.test(t)) return true;
        return ok.some((a) => { const v = num(t, a); return isFinite(v) && Math.abs(v - a) <= a * 0.005; });
      });
    });
    return keep.join(" ").trim();
  }

  function cut(s, n) {
    if (s.length <= n) return s;
    const parts = s.split(/(?<=[.!?])\s+/);
    let out = "";
    for (const p of parts) { if ((out + " " + p).trim().length > n) break; out = (out + " " + p).trim(); }
    return out || s.slice(0, n);
  }

  function reportText(o) {
    const nm = SYMN[o.sym] || o.sym, Nm = nm.charAt(0).toLocaleUpperCase("tr") + nm.slice(1);
    if (o.closed) { const t = o.greet + ". Piyasa şu an kapalı, bugün bir görüş vermiyorum."; return { say: t, show: t }; }
    const P = (x) => px(x, o.sym), v = o.view, vd = o.verdict || { kind: "skip" };
    const story = v && v.story ? v.story : Nm + " şu an " + P(o.price) + ".";
    let opin;
    if (o.err) opin = "Şu an düşünemedim, görüşümü birazdan tekrar sorabilirsin.";
    else if (o.light) opin = "Kendi fikrimi söyleyebilmem için Ayarlar'dan ücretsiz bir yapay zekâ anahtarı (ör. Groq) gir.";
    else if (o.ok && v) opin = "Bence bugün " + (v.dir === "up" ? "yukarı" : "aşağı") + (v.why ? ": " + v.why.replace(/\.*$/, "") : "") + ". " + P(v.target) + (v.dir === "up" ? " üstüne çıkarsa" : " altına inerse") + " yol açık; " + P(v.invalid) + (v.dir === "up" ? " altı" : " üstü") + " fikrimi bozar.";
    else opin = "Bugün net bir fikrim yok.";
    const usd = (x) => String(x).replace(".", ",");
    const mv = usd(money(o.sym, o.lot, o.atrD));
    const range = Nm + " son günlerde günde ortalama " + P(o.atrD) + (o.sym === "EURUSD" ? "" : "$") + " oynuyor; " + String(o.lot).replace(".", ",") + " lotla doğru yönde yaklaşık " + mv + "$, yanlış yönde −" + mv + "$ eder.";
    const VERD = {
      long: "Ben olsam long düşünürdüm: giriş " + P(vd.entry) + ", stop " + P(vd.stop) + " (−" + usd(vd.stopUsd) + "$), ilk hedef " + P(vd.tgt) + " (+" + usd(vd.tgtUsd) + "$).",
      short: "Ben olsam short düşünürdüm: giriş " + P(vd.entry) + ", stop " + P(vd.stop) + " (−" + usd(vd.stopUsd) + "$), ilk hedef " + P(vd.tgt) + " (+" + usd(vd.tgtUsd) + "$).",
      wait: "Ben olsam haberi bekler, sonra bakardım.",
      skip: "Ben olsam bugün açmazdım.",
      risk: "Bu lotla açmazdım; stop mesafesi " + usd(vd.stopUsd) + "$ risk demek.",
      none: "",
    };
    const verd = VERD[vd.kind] || "";
    const k = o.karne;
    const karne = k && k.n >= 10 ? "Son " + k.n + " görüşümde isabet oranım %" + Math.round(k.rate * 100) + "; rastgele seçseydim %" + Math.round(k.lo * 100) + "-%" + Math.round(k.hi * 100) + " arası beklenirdi." : "Henüz karnem yok, bunu bir tahmin olarak dinle.";
    const lv = o.lv || {};
    const tech = o.tech ? "Teknik: PDH " + P(lv.pdh) + ", PDL " + P(lv.pdl) + ", Asya " + P(lv.asial) + "-" + P(lv.asiah) + ", ATR-D " + P(o.atrD) + "." : "";
    const ev = (o.evLines || []).join(" ");
    const show = [o.greet + "!", story, opin, range, ev, tech, verd, karne].filter(Boolean).join(" ");
    const head = [o.greet + "!", story, opin, verd, karne].filter(Boolean).join(" ");
    return { say: cut([head, ev].filter(Boolean).join(" "), 600), show };
  }

  const API = { CONTRACT, SYMN, daily, money, greet, intent, atrD, levels, num, parseView, validView, verdict, resolve, karneStats, baseline, EFFECT, effect, eventLine, eventSoon, priceAt, trNum, spoken, pickProv, buildPrompt, scrub, reportText, px };
  if (typeof module !== "undefined") module.exports = API;
  else window.NeraAsistCore = API;
})();
