/* Nera Asistan animasyonu (A4: Nera yildizi + uc yorunge). Kaynak: onaylanan mockup asistan-a4-detay-v5.
   window.NeraAsistFx = { mount(canvas), state(s), view({dir, tgtLabel, badLabel}), amp(v), big(on), destroy() }
   Dongu NeraUI.tick ile (tek zamanlayici); body.perf'te tek kare cizilir. */
(function () {
  const R = Math.random;
  let OUT = null, cv = null, SCN, g, bc, bg, W = 600, H = 600, CX = 300, CY = 300, K = 1;
  let S = "idle", A = 0, ampT = 0, ampAt = 0, BIG = false, off = null, t0 = performance.now(), last = 0;
  let C = ["#7cf2ff", "#a98bff", "#ff7ad9"], RGB = ["124,242,255", "169,139,255", "255,122,217"];
  let LBL = { dir: 1, tgt: "", bad: "" };
  const E = { open: 0, gyro: 0, flat: 0, think: 0, lis: 0, dir: 1 };
  const ease = (k, v, s = 0.02) => (E[k] += (v - E[k]) * s);
  const ORB = [{ r: 0.3, ti: 0.95, az: 0.2, sp: 0.1, c: 0 }, { r: 0.4, ti: -0.75, az: 1.3, sp: -0.07, c: 1 }, { r: 0.48, ti: 0.45, az: 2.4, sp: 0.05, c: 2 }];
  let DUST = [], NEB = [], INF = [], RINGS = [], PULSES = [], lastBeat = 0;

  function build(small) {
    const np = small ? 120 : 300, nd = small ? 180 : 800;
    ORB.forEach((o) => {
      o.pts = Array.from({ length: np }, () => ({ a: R() * 6.283, b: R() }));
      const ns = o.c === 2 ? 3 : 2;
      o.sat = Array.from({ length: ns }, (_, i) => ({ a: (i * 6.283) / ns + R(), s: 2.6 + R() * 1.6 }));
      o.com = { a: R() * 6.283, tr: [] };
    });
    DUST = Array.from({ length: nd }, () => {
      const u = R() * 2 - 1, a = R() * 6.283, r = 0.12 + Math.pow(R(), 0.6) * 0.6;
      return { gl: R() < 0.04, x: Math.sqrt(1 - u * u) * Math.cos(a) * r, y: u * r, z: Math.sqrt(1 - u * u) * Math.sin(a) * r, c: (R() * 3) | 0, tw: R() * 6 };
    });
    NEB = Array.from({ length: 6 }, (_, i) => ({ c: i % 3, p: R() * 6.283, d: 0.08 + R() * 0.18, r: 0.28 + R() * 0.2 }));
    INF = Array.from({ length: small ? 30 : 90 }, () => ({ a: R() * 6.283, d: 1 + R(), c: (R() * 3) | 0 }));
  }

  const rotY = (p, a) => [p[0] * Math.cos(a) - p[2] * Math.sin(a), p[1], p[0] * Math.sin(a) + p[2] * Math.cos(a)];
  const rotX = (p, a) => [p[0], p[1] * Math.cos(a) - p[2] * Math.sin(a), p[1] * Math.sin(a) + p[2] * Math.cos(a)];
  const rotZ = (p, a) => [p[0] * Math.cos(a) - p[1] * Math.sin(a), p[0] * Math.sin(a) + p[1] * Math.cos(a), p[2]];
  const proj = (p) => { const s = 2.6 / (3.2 - p[2]), SC = W * 1.5; return [CX + p[0] * SC * s * 0.5, CY + p[1] * SC * s * 0.5, s, p[2]]; };
  function orbPoint(o, a, t, k) {
    let p = [Math.cos(a) * o.r, 0, Math.sin(a) * o.r];
    const ti = o.ti * (1 - 0.6 * E.open) * (1 - E.flat) + E.flat * 0.1;
    p = rotX(p, ti + E.gyro * Math.sin(t * 0.35 + k * 2.1) * 0.9);
    p = rotY(p, o.az + t * 0.02 + E.gyro * t * (k % 2 ? -0.2 : 0.18));
    p = rotZ(p, E.gyro * Math.cos(t * 0.3 + k) * 0.45);
    return rotX(p, -0.25 * (1 - E.open));
  }
  // kucuk noktalar icin arc yerine fillRect: ayni gorunum, cok daha ucuz
  function dot(x, y, r, col, al) { const rr = Math.max(0.5, r * K); g.globalAlpha = al; g.fillStyle = col; if (rr < 1.6) { g.fillRect(x - rr, y - rr, rr * 2, rr * 2); return; } g.beginPath(); g.arc(x, y, rr, 0, 7); g.fill(); }
  const VIEW = () => S === "view";

  function hexRgb(h) {
    const m = String(h || "").trim().match(/^#?([0-9a-f]{6})$/i);
    if (!m) return null;
    const n = parseInt(m[1], 16);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255].join(",");
  }
  function palette() {
    const cs = getComputedStyle(document.body), a = hexRgb(cs.getPropertyValue("--u3-acc")), b = hexRgb(cs.getPropertyValue("--u3-acc2"));
    if (a) RGB[0] = a;
    if (b) RGB[1] = b;
    C = RGB.map((x) => "rgb(" + x + ")");
  }

  function frame(n) {
    if (!g || document.hidden || !cv || !cv.getClientRects().length) return;
    const t = (n - t0) / 1000;
    last = t;
    ampT = Math.max(0, ampT - 0.06);
    const fake = (S === "speak" || VIEW()) && performance.now() - ampAt > 400 ? Math.max(0, 0.3 + 0.3 * Math.sin(t * 7) * Math.sin(t * 2.3) + 0.15 * Math.sin(t * 11)) : 0;
    A += (Math.max(ampT, fake) - A) * 0.12;
    const a = A;
    ease("open", S === "listen" ? 1 : 0); ease("gyro", S === "think" ? 1 : 0, 0.012); ease("flat", VIEW() ? 1 : 0, 0.018);
    ease("think", S === "think" ? 1 : 0, 0.03); ease("lis", S === "listen" ? 1 : 0, 0.03); ease("dir", VIEW() ? LBL.dir : E.dir, 0.03);
    g.globalCompositeOperation = "source-over"; g.globalAlpha = 1; g.fillStyle = "rgba(3,2,16,.38)"; g.fillRect(0, 0, W, H); g.globalCompositeOperation = "lighter";
    NEB.forEach((b, i) => {
      const x = CX + Math.cos(t * 0.03 + b.p) * b.d * W, y = CY + Math.sin(t * 0.025 + b.p * 1.3) * b.d * W * 0.7, r = b.r * W * (1 + 0.06 * Math.sin(t * 0.2 + i));
      const gr = g.createRadialGradient(x, y, 0, x, y, r); gr.addColorStop(0, `rgba(${RGB[b.c]},${0.035 + 0.02 * a})`); gr.addColorStop(1, "rgba(0,0,0,0)");
      g.globalAlpha = 1; g.fillStyle = gr; g.fillRect(x - r, y - r, r * 2, r * 2);
    });
    DUST.forEach((d) => {
      const p = proj(rotY([d.x, d.y, d.z], t * 0.015)), tw = 0.5 + 0.5 * Math.sin(t * 0.8 + d.tw);
      dot(p[0], p[1], 0.6 + 0.5 * tw * p[2], C[d.c], 0.08 + 0.2 * tw);
      if (d.gl && tw > 0.97) { g.globalAlpha = 0.6 * (tw - 0.97) * 33; g.strokeStyle = "#fff"; g.lineWidth = 0.6 * K; g.beginPath(); g.moveTo(p[0] - 7 * K, p[1]); g.lineTo(p[0] + 7 * K, p[1]); g.moveTo(p[0], p[1] - 7 * K); g.lineTo(p[0], p[1] + 7 * K); g.stroke(); }
    });
    if (E.lis > 0.02) INF.forEach((f) => { f.d -= 0.0035; if (f.d < 0.08) { f.d = 1 + R() * 0.6; f.a = R() * 6.283; } dot(CX + Math.cos(f.a) * f.d * W * 0.5, CY + Math.sin(f.a) * f.d * W * 0.5, 1, C[f.c], E.lis * 0.45 * (1 - f.d * 0.4)); });
    const satPos = [];
    ORB.forEach((o, k) => {
      const sp = o.sp * (1 + a * 0.6) * (S === "think" ? 1.3 : 1);
      g.beginPath();
      for (let i = 0; i <= 120; i++) { const q = proj(orbPoint(o, (i / 120) * 6.283, t, k)); if (i) g.lineTo(q[0], q[1]); else g.moveTo(q[0], q[1]); }
      g.strokeStyle = C[o.c]; g.globalAlpha = 0.06 + 0.04 * a; g.lineWidth = 7 * K; g.stroke(); g.globalAlpha = 0.24; g.lineWidth = 0.9 * K; g.stroke();
      o.pts.forEach((p) => { const q = proj(orbPoint(o, p.a + t * sp, t, k)); dot(q[0], q[1], 0.8 * q[2] + 0.3, C[o.c], 0.12 + 0.42 * ((q[3] + 1) / 2) * (0.6 + 0.4 * p.b)); });
      o.sat.forEach((s) => {
        const q = proj(orbPoint(o, s.a + t * sp * 1.2, t, k)); satPos.push([q[0], q[1], o.c]);
        const rr = s.s * 3.2 * q[2] * K, gr = g.createRadialGradient(q[0], q[1], 0, q[0], q[1], rr);
        gr.addColorStop(0, "rgba(255,255,255,.75)"); gr.addColorStop(0.35, `rgba(${RGB[o.c]},.35)`); gr.addColorStop(1, "rgba(0,0,0,0)");
        g.globalAlpha = 1; g.fillStyle = gr; g.beginPath(); g.arc(q[0], q[1], rr, 0, 7); g.fill();
      });
      const cm = o.com; cm.a += 0.004 * (k % 2 ? -1 : 1) * (1 + a * 0.5);
      const q = proj(orbPoint(o, cm.a, t, k)); cm.tr.unshift([q[0], q[1]]); if (cm.tr.length > 40) cm.tr.pop();
      g.lineCap = "round";
      for (let i = 1; i < cm.tr.length; i++) { g.strokeStyle = C[o.c]; g.globalAlpha = (1 - i / cm.tr.length) * 0.35; g.lineWidth = 1.2 * K; g.beginPath(); g.moveTo(cm.tr[i - 1][0], cm.tr[i - 1][1]); g.lineTo(cm.tr[i][0], cm.tr[i][1]); g.stroke(); }
      dot(q[0], q[1], 1.6, "#ffffff", 0.8);
    });
    if (E.think > 0.02) {
      const bend = 24 * K;
      satPos.forEach((s, i) => {
        const mx = (CX + s[0]) / 2 + Math.sin(t * 0.4 + i) * bend, my = (CY + s[1]) / 2 + Math.cos(t * 0.5 + i) * bend;
        g.strokeStyle = C[s[2]]; g.globalAlpha = E.think * 0.16; g.lineWidth = 0.7 * K; g.beginPath(); g.moveTo(CX, CY); g.quadraticCurveTo(mx, my, s[0], s[1]); g.stroke();
        if (R() < 0.008 * E.think) PULSES.push({ i, u: 0, dir: R() < 0.5 ? 1 : -1, c: s[2] });
      });
      for (let j = PULSES.length - 1; j >= 0; j--) {
        const p = PULSES[j], s = satPos[p.i]; p.u += 0.009;
        if (!s || p.u > 1) { PULSES.splice(j, 1); continue; }
        const u = p.dir > 0 ? p.u : 1 - p.u, mx = (CX + s[0]) / 2 + Math.sin(t * 0.4 + p.i) * bend, my = (CY + s[1]) / 2 + Math.cos(t * 0.5 + p.i) * bend;
        const x = (1 - u) * (1 - u) * CX + 2 * (1 - u) * u * mx + u * u * s[0], y = (1 - u) * (1 - u) * CY + 2 * (1 - u) * u * my + u * u * s[1];
        dot(x, y, 1.6, "#ffffff", E.think * 0.9); dot(x, y, 5, C[p.c], E.think * 0.18);
      }
    }
    if ((S === "speak" || VIEW()) && a > 0.5 && t - lastBeat > 0.9) { lastBeat = t; RINGS.push({ r: 0.06 }); }
    for (let j = RINGS.length - 1; j >= 0; j--) {
      const r = RINGS[j]; r.r += 0.003;
      if (r.r > 0.6) { RINGS.splice(j, 1); continue; }
      g.strokeStyle = "#cfd8ff"; g.globalAlpha = (1 - r.r / 0.6) * 0.22; g.lineWidth = K; g.beginPath(); g.ellipse(CX, CY, r.r * W * 0.5, r.r * W * 0.5 * (0.3 + 0.4 * E.open + 0.3 * (1 - E.flat)), 0, 0, 7); g.stroke();
    }
    const d = E.dir * E.flat, cr = d < 0 ? RGB[2] : RGB[0];
    const core = W * 0.024 * (1 + 0.035 * Math.sin(t * 0.9) + a * 0.18);
    const halo = g.createRadialGradient(CX, CY, 0, CX, CY, core * 7);
    halo.addColorStop(0, "rgba(255,255,255,.6)"); halo.addColorStop(0.14, `rgba(${cr},.2)`); halo.addColorStop(0.45, `rgba(${RGB[1]},.07)`); halo.addColorStop(1, "rgba(0,0,0,0)");
    g.globalAlpha = 1; g.fillStyle = halo; g.beginPath(); g.arc(CX, CY, core * 7, 0, 7); g.fill();
    for (let i = 0; i < 8; i++) {
      const an = t * 0.05 + (i / 8) * 6.283, L = core * (2.2 + (i % 2 ? 1 : 1.7) * 1.3) * (1 + a * 0.25) * (0.85 + 0.15 * Math.sin(t * 0.7 + i));
      const gr = g.createLinearGradient(CX, CY, CX + Math.cos(an) * L, CY + Math.sin(an) * L); gr.addColorStop(0, "rgba(255,255,255,.6)"); gr.addColorStop(1, `rgba(${RGB[1]},0)`);
      g.strokeStyle = gr; g.globalAlpha = 0.5; g.lineWidth = (i % 2 ? 0.7 : 1.3) * K; g.beginPath(); g.moveTo(CX, CY); g.lineTo(CX + Math.cos(an) * L, CY + Math.sin(an) * L); g.stroke();
    }
    if (E.think > 0.05) {
      const an = t * 1.1;
      g.strokeStyle = "#ffffff"; g.globalAlpha = E.think * 0.45; g.lineWidth = K; g.beginPath(); g.arc(CX, CY, core * 2.6, an, an + 0.9); g.stroke();
      g.strokeStyle = C[1]; g.globalAlpha = E.think * 0.3; g.beginPath(); g.arc(CX, CY, core * 3.6, -an * 0.7, -an * 0.7 + 0.6); g.stroke();
    }
    const fl = W * 0.42 * (1 + a * 0.3) * (0.92 + 0.08 * Math.sin(t * 0.6)), fg = g.createLinearGradient(CX - fl, CY, CX + fl, CY);
    fg.addColorStop(0, `rgba(${RGB[0]},0)`); fg.addColorStop(0.5, "rgba(220,240,255,.35)"); fg.addColorStop(1, `rgba(${RGB[2]},0)`);
    g.globalAlpha = 1; g.fillStyle = fg; g.fillRect(CX - fl, CY - 1.2 * K, fl * 2, 2.4 * K); g.globalAlpha = 0.18; g.fillRect(CX - fl * 0.6, CY - 4 * K, fl * 1.2, 8 * K);
    g.strokeStyle = `rgba(${cr},.35)`; g.globalAlpha = 0.5; g.lineWidth = K; g.beginPath(); g.arc(CX, CY, core * 5.2, 0, 7); g.stroke();
    g.strokeStyle = `rgba(${RGB[2]},.25)`; g.beginPath(); g.arc(CX, CY, core * 5.6, 0, 7); g.stroke();
    dot(CX, CY, core * 0.8 / K, "#ffffff", 0.95);
    if (E.flat > 0.03 && BIG) {
      const dirS = E.dir >= 0 ? 1 : -1, f = E.flat, top = CY - dirS * H * 0.34 * f;
      const gr = g.createLinearGradient(CX, CY, CX, top); gr.addColorStop(0, `rgba(${cr},0)`); gr.addColorStop(0.6, `rgba(${cr},.35)`); gr.addColorStop(1, `rgba(${cr},.9)`);
      g.strokeStyle = gr; g.globalAlpha = f; g.lineWidth = 1.4 * K; g.beginPath(); g.moveTo(CX, CY - dirS * core * 3); g.lineTo(CX, top); g.stroke();
      g.globalAlpha = f * 0.6; g.lineWidth = 6 * K; g.strokeStyle = `rgba(${cr},.12)`; g.stroke();
      const lv = (yy, txt, col, al) => {
        if (!txt) return;
        g.globalAlpha = al; g.strokeStyle = col; g.lineWidth = K; g.setLineDash([4 * K, 6 * K]); g.beginPath(); g.moveTo(CX - 110 * K, yy); g.lineTo(CX + 110 * K, yy); g.stroke(); g.setLineDash([]);
        g.fillStyle = col; g.font = `500 ${Math.round(17 * K)}px "IBM Plex Mono",ui-monospace,Consolas,monospace`; g.fillText(txt, CX + 122 * K, yy + 6 * K);
      };
      lv(top, LBL.tgt, `rgb(${cr})`, f);
      lv(CY + dirS * H * 0.13 * f, LBL.bad, "#9b97c4", f * 0.8);
      dot(CX, top, 3, "#ffffff", f);
    }
    bg.globalCompositeOperation = "copy"; bg.filter = "blur(" + Math.max(2, Math.round(6 * K)) + "px)"; bg.drawImage(SCN, 0, 0, W / 4, H / 4); bg.filter = "none";
    OUT.globalCompositeOperation = "copy"; OUT.globalAlpha = 1; OUT.drawImage(SCN, 0, 0);
    OUT.globalCompositeOperation = "lighter"; OUT.globalAlpha = 0.38; OUT.drawImage(bc, 0, 0, W, H);
  }

  function size() {
    if (!cv) return;
    const dpr = Math.min(1.5, window.devicePixelRatio || 1), css = Math.max(40, cv.clientWidth || 84);
    W = H = Math.round(css * dpr); CX = W / 2; CY = H / 2; K = W / 900;
    cv.width = cv.height = W; SCN.width = SCN.height = W; bc.width = bc.height = Math.max(8, Math.round(W / 4));
  }

  function run() {
    if (off) off();
    off = null;
    const perf = document.body.classList.contains("perf");
    if (perf || !window.NeraUI || !NeraUI.tick) { frame(performance.now()); return; }
    off = NeraUI.tick(frame, { fps: BIG ? 60 : 12 });
  }

  window.NeraAsistFx = {
    mount(canvas) {
      cv = canvas; OUT = cv.getContext("2d");
      SCN = document.createElement("canvas"); g = SCN.getContext("2d");
      bc = document.createElement("canvas"); bg = bc.getContext("2d");
      palette(); size(); build(!BIG); run();
    },
    state(s) { S = s === "view" || s === "listen" || s === "think" || s === "speak" ? s : "idle"; if (document.body.classList.contains("perf")) frame(performance.now()); },
    view(o) { LBL = { dir: o && o.dir < 0 ? -1 : 1, tgt: (o && o.tgtLabel) || "", bad: (o && o.badLabel) || "" }; },
    amp(v) { ampT = Math.max(ampT, +v || 0); ampAt = performance.now(); },
    big(on) { if (BIG === !!on) return; BIG = !!on; size(); build(!BIG); run(); },
    resize() { size(); },
    destroy() { if (off) off(); off = null; cv = OUT = g = null; },
  };
})();
