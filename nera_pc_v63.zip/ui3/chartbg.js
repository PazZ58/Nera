"use strict";
/* NERA 3 · grafik arka planı (yalnız PC ve tablet): kullanıcının seçtiği GIF/resim yalnız ana fiyat grafiğinin ARKASINA konur (alt paneller ve order flow kutuları opak kalır) (Ayarlar › Grafik arka planı).
   Dosya cihazda IndexedDB'de saklanır, hiçbir yere gönderilmez. Alt paneller (Delta/CVD ve ADX vb.) başlık düğmesiyle animasyonlu gizlenir/açılır. Telefonda ve performans modunda kapalı. */
(function () {
const U = window.NeraUI, left = document.getElementById("chart-wrap"); if (!left) return;
const off = () => (U && (U.mobile() || U.lite())) || document.body.classList.contains("m");
const LS = (k, d) => { try { const v = localStorage.getItem(k); return v === null ? d : v; } catch (e) { return d; } }, SET = (k, v) => { try { localStorage.setItem(k, v); } catch (e) { /* */ } };
const B = (window.NeraChartBg = { on: false });
/* IndexedDB: tek kayıt */
const idb = () => new Promise((res, rej) => { const r = indexedDB.open("nera_bg", 1); r.onupgradeneeded = () => r.result.createObjectStore("k"); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
const put = (blob) => idb().then((d) => new Promise((res) => { const t = d.transaction("k", "readwrite"); blob ? t.objectStore("k").put(blob, "bg") : t.objectStore("k").delete("bg"); t.oncomplete = () => res(); }));
const get = () => idb().then((d) => new Promise((res) => { const q = d.transaction("k").objectStore("k").get("bg"); q.onsuccess = () => res(q.result || null); q.onerror = () => res(null); })).catch(() => null);
const layer = document.createElement("div"); layer.id = "chart-bgm"; left.prepend(layer); let url = null;
function refresh() { if (window.__chartRefresh) window.__chartRefresh(); }
B.apply = (blob) => { if (off() || !blob) return; if (url) URL.revokeObjectURL(url); url = URL.createObjectURL(blob); layer.style.backgroundImage = `url("${url}")`; layer.style.opacity = LS("nera_bgo", "0.5"); layer.style.filter = `blur(${LS("nera_bgb", "0")}px)`; document.body.classList.add("has-bgm"); window.__bgMedia = true; B.on = true; refresh(); };
B.set = (file) => { if (!file || !/^image\//.test(file.type)) return false; if (file.size > 40 * 1024 * 1024) return false; return put(file).then(() => { B.apply(file); return true; }); };
B.clear = () => put(null).then(() => { layer.style.backgroundImage = ""; if (url) URL.revokeObjectURL(url); url = null; document.body.classList.remove("has-bgm"); window.__bgMedia = false; B.on = false; refresh(); });
B.opacity = (v) => { SET("nera_bgo", v); layer.style.opacity = v; };
B.blur = (v) => { SET("nera_bgb", v); layer.style.filter = `blur(${v}px)`; };
if (!off()) { get().then((b) => { if (b) { const go = () => B.apply(b); setTimeout(go, 1200); setTimeout(go, 4000); } }); }
/* alt paneller: animasyonlu gizle / aç */
document.querySelectorAll(".pane-x").forEach((btn) => {
  const pane = document.getElementById(btn.dataset.p), head = btn.closest(".pane-head"); if (!pane) return; const key = "pane_col_" + btn.dataset.p;
  const set = (c, anim) => { pane.classList.toggle("col", c); head.classList.toggle("col", c); btn.setAttribute("title", c ? "Paneli göster" : "Paneli gizle"); SET(key, c ? "1" : "0"); if (anim) { setTimeout(() => window.dispatchEvent(new Event("resize")), 520); } };
  set(LS(key, "0") === "1", false); btn.onclick = (e) => { e.stopPropagation(); set(!pane.classList.contains("col"), true); };
});
setTimeout(() => document.body.classList.add("panes-ready"), 800);
})();
